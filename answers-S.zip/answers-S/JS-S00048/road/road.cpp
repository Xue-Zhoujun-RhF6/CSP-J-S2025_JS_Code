#include<bits/stdc++.h>
using namespace std;

const int maxn=10010;
vector<pair<int,long long> > g[maxn];
int c[15];
long long a[15][maxn];

long long dis[maxn];

int main(){
    freopen("ces.in","r",stdin);
    freopen("ces.out","w",stdout);

    int n,m,k;cin>>n>>m>>k;
    for (int i=0;i<m;i++){
        int u,v;long long co;cin>>u>>v>>co;
        g[u].push_back({v,co});
        g[v].push_back({u,co});
    }
    for (int i=1;i<=k;i++){
        cin>>c[i];
        for (int j=1;j<=n;j++){
            cin>>a[i][j];
        }
    }
    if (k==0){
    queue<int> q;
    q.push(1);
    memset(dis,0x3f,sizeof(dis));
    dis[1]=0;
    while(!q.empty()){
        int u=q.front();
        q.pop();
        for (int i=0;i<g[u].size();i++){
            int to=g[u][i].first;
            int cost=g[u][i].second;
            if (dis[to]<dis[u]+cost) continue;
            q.push(to);
            dis[to]=dis[u]+cost;
        }
    }
    long long ans=0;
    for (int i=1;i<=n;i++){
        ans=max(ans,dis[i]);
    //    cout<<dis[i]<<endl;
    }
    cout<<ans<<endl;
    return 0;

    }

    long long ans=0
    for (int i=1;i<=n;i++) ans +=g[i][0].second;
    cout<<ans<<endl;
    return 0;
}

