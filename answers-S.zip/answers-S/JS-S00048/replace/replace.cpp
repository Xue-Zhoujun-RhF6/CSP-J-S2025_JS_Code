
#include<bits/stdc++.h>
using namespace std;

const int maxn=200100;

map<string,string> m;
set<string> st;

int main(){
    freopen("ces.in","r",stdin);
    freopen("ces.out","w",stdout);

    int n,q;cin>>n>>q;
    while(n--){
        string a,b;cin>>a>>b;
        st.insert(a);
        m[a]=b;
    }

    while(q--){
        string s,t;cin>>s>>t;
        if (s.size()!=t.size()){
            cout<<0<<endl;
            continue;
        }
        int ans=0;
        for (int i=0;i<s.size();i++){
            for (int j=i;j<s.size();j++){
                    string x=s.substr(0,i),z=s.substr(j+1,(n-j));
                    string x1=t.substr(0,i),z1=t.substr(j+1,(n-j));
                    if (x!=x1 || z!=z1) continue;
                string su=s.substr(i,(j-i+1));
                if (!st.count(su)) continue;
                if (t.substr(i,(j-i+1))==m[su]) ans++;
            }
        }
        cout<<ans<<endl;
    }

    return 0;
}

