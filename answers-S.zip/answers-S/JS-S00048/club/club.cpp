#include<bits/stdc++.h>
using namespace std;

const int maxn=100010;
long long an[maxn][4];
long long dp[205][205][205];
int main(){
    freopen("ces.in","r",stdin);
    freopen("ces.out","w",stdout);

    int t;cin>>t;
    while(t--){
        bool has1=1,has2=1;
            memset(dp,0,sizeof(dp));
        int n;cin>>n;
        for (int i=1;i<=n;i++){
            cin>>an[i][1]>>an[i][2]>>an[i][3];
            if (an[i][2]!=0 || an[i][3]!=0) has1=0;
            if (an[i][3]!=0) has2=0;
        }
        if (has1){
                long long as=0;
            vector<int> ans;
            for(int i=0;i<n;i++) ans.push_back(an[i+1][1]);
            sort(ans.begin(),ans.end());
            reverse(ans.begin(),ans.end());
            for (int i=1;i<=n/2;i++){as+=ans[i-1];}
        cout<<as<<endl;
        return 0;
        }
        if (has2){
            long long ans=0;
            for (int i=1;i<=n;i++){
                    for (int a=0;a<=n/2;a++){
                            int b=i-a;
                            if (b>n/2 || b<0) continue;
                            if (a!=0)
                            dp[a][b][0]=max(dp[a][b][0],dp[a-1][b][0]+an[i][1]);
                            if (b!=0)
                            dp[a][b][0]=max(dp[a][b][0],dp[a][b-1][0]+an[i][2]);
                        // cout<<a<<b<<c<<" "<<dp[a][b][c]<<endl;
                            ans=max(ans,dp[a][b][0]);
                    }
            }
            cout<<ans<<endl;
            return 0;
        }
        long long ans=0;
        for (int i=1;i<=n;i++){
                for (int a=0;a<=n/2;a++){
                    for (int b=0;b<=n/2;b++){
                        int c=i-a-b;
                        if (n/2<c || c<0) continue;
                        if (a!=0)
                        dp[a][b][c]=max(dp[a][b][c],dp[a-1][b][c]+an[i][1]);
                        if (b!=0)
                        dp[a][b][c]=max(dp[a][b][c],dp[a][b-1][c]+an[i][2]);
                        if (c!=0)
                        dp[a][b][c]=max(dp[a][b][c],dp[a][b][c-1]+an[i][3]);
                       // cout<<a<<b<<c<<" "<<dp[a][b][c]<<endl;
                        ans=max(ans,dp[a][b][c]);
                    }
                }
        }
        cout<<ans<<endl;
    }

    return 0;
}
