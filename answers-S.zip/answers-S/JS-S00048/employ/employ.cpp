

#include<bits/stdc++.h>
using namespace std;

vector<string> fa;
int n,m;
void dfs(int r,string st,set<char> h){
    if(r==0) fa.push_back(st);
    else{
            for(char i='0';i<'0'+n;i++){
                if (!h.count(i)){
                    h.insert(i);
                //    cout<<i<<endl;
                    dfs(r-1,st+i,h);
                }
            }
    }
}
const int maxn=200100;
int main(){
    freopen("ces.in","r",stdin);
    freopen("ces.out","w",stdout);

    cin>>n>>m;
    string s;cin>>s;
    int c[505];
    int cnt=0;
    for (int i=1;i<=n;i++) {
        cin>>c[i];
        if (c[i]==0) cnt++;
    }
    bool has=1;
    for (int i=0;i<s.size();i++) if (s[i]=='0') {
        has=0;
    }
    if (n<=10){
            int ans=0;
        set<char> h;
        dfs(n,"",h);
        for (int i=0;i<fa.size();i++){
            string f=fa[i];
            int tg=0;
            for (int j=0;j<n;j++){
            //    cout<<f[j];
                if (j-tg>=c[j+1]) continue;
                if (s[f[j]-'0']=='0')continue;
                tg++;
            }
            if (tg>=m) ans++;
            //cout<<endl;
        }
        cout<<ans%998244353<<endl;
        return 0;
    }
    if (m==n) {
            if (has==0){
                cout<<0;
                return 0;
            }
        long long ans=1;
        for (int i=cnt+1;i<=n;i++){
            ans*=i;
            ans%=998244353;
        }
        cout<<cnt<<" "<<ans<<endl;
        return 0;
    }

    long long ans=1;
    for (int i=1;i<=n-cnt;i++) ans=(ans*i)%998244353;
    cout<<ans<<endl;

    return 0;
}

