#include<bits/stdc++.h>
using namespace std;
int n,m;
int a[100005][3];
long long sum[3];
long long ch[100000];
long sum2=0;
int p[20005];
int check(int a,int b,int c,int d){
    int u[10]={0,0,0,0,0};
    u[a]++;
    u[b]++;
    u[c]++;
    u[d]++;
    for(int i=1;i<=3;i++){
        if(u[i]>2)return 0;
    }
    return 1;
}
int cmp(int x,int y){
    return x>y;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>n;
    for(int o=0;o<n;o++){
        cin>>m;
        bool f=0;
        for(int j=1;j<=m;j++){
            for(int z=1;z<=3;z++){
                cin>>a[j][z];
                if(z==1){
                    p[a[j][1]]++;
                    sum2+=a[j][1];
                }
            }
        }
        if(m==2){
            int maxn=-1;
            for(int i=1;i<=3;i++){
                for(int j=1;j<=3;j++){
                    if(i!=j){
                        maxn=max(maxn,a[1][i]+a[2][j]);
                    }
                }
            }
            cout<<maxn<<endl;
            continue;
        }
        if(m==4){
            int maxn=-1;
            for(int i=1;i<=3;i++){
                for(int j=1;j<=3;j++){
                    for(int z=1;z<=3;z++){
                        for(int k=1;k<=3;k++){
                             if(check(i,j,z,k)){
                                 maxn=max(a[1][i]+a[2][j]+a[3][z]+a[4][k],maxn);
                             }
                        }

                    }
                }
            }
         cout<<maxn<<endl;
         continue;
        }
        if(a[1][2]==0&&a[1][3]==0){
                int ans=0,sum1=0;
            for(int i=20000;i>=1;i--){
                if(p[i]){
                    if(ans+p[i]<=m/2){
                        sum1+=p[i]*i;
                    }else{
                        sum1+=(m/2-ans)*i;
                        break;
                    }
                }
            }
            cout<<sum1<<endl;
        }else if(a[1][3]==0){
             for(int i=1;i<=m;i++){
                ch[i]=a[i][2]-a[i][1];
             }
             sort(ch+1,ch+1+m,cmp);
             for(int i=1;i<=m/2;i++){
                 sum2+=ch[i];
             }
             cout<<sum2<<endl;
        }
    }

    return 0;
}
