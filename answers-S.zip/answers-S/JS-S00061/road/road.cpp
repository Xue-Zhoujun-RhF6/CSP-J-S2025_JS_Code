
#include<bits/stdc++.h>
using namespace std;
struct data{
    int v;
    int w;
};
vector<int>g[1000010];
int c[10000010];
int d[10000010];
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    int n,m,k;
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){

    }
    for(int i=1;i<=m;i++){
        int u,v,w;
        cin>>u>>v>>w;
        d[i]=w;

    }
    sort(d+1,d+m+1);
        long long ans=0;
        for(int i=1;i<=n-1;i++){
            ans+=d[i];
        }
    for(int i=1;i<=k;i++){
        int x;
        cin>>x;
        for(int j=1;j<=n;j++){
            cin>>c[i];
            c[i]+=x;
            d[++m]=c[i];
        }
    }

    cout<<ans<<endl;
    return 0;
}
