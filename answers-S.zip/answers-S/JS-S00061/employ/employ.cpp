#include<bits/stdc++.h>
using namespace std;
int c[1000];
const int mod=998244353;
int a[1000];
bool cmp(int x,int y){
    return x>y;
}
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    int n,m;
    cin>>n>>m;
    string s;
    cin>>s;
    int k=0;
    for(int i=1;i<=n;i++){
        cin>>c[i];
        a[c[i]]++;
        if(c[i]==0)k++;

    }
    int fff=1;
    for(int i=0;i<s.size();i++){
        if(s[i]==0){
            fff=0;
            break;
        }
    }
    if((k>0||fff==0)&&m==n){
        cout<<0;
        return 0;
    }
    if(n<=10){
        long long ans=0;
        sort(c+1,c+n+1);
        do{
            int f=0;
            int cnt=0,ok=0;
            for(int i=1;i<=n;i++){
                if(s[i-1]=='0'||c[i]<=cnt){
                    cnt++;
                }
                else{
                    ok++;
                    if(ok>=m){
                        f=1;
                        continue;
                    }
                }
            }
            if(f){
                long long an=1;
              for(int i=1;i<=n;i++){
                 if(a[i]>1){
                    for(int j=2;j<=a[i];j++){
                        an=an*j%mod;
                    }
                  }
               }
                ans=(ans+an)%mod;
            }

        }while(next_permutation(c+1,c+n+1));
        cout<<ans%mod;
        return 0;
    }
    sort(c+1,c+n+1,cmp);
    if(m==1){
        long long ans=1;
        sort(c+1,c+n+1);
        int sss=0;
        do{
            sss++;
            int f=0;
            int cnt=0,ok=0;
            for(int i=1;i<=n;i++){
                if(s[i-1]=='0'||c[i]<=cnt){
                    cnt++;
                }
                else{
                    ok++;
                    if(ok>=m){
                        f=1;
                        break;
                    }
                }
            }
            if(f){
                sss--;
                break;
            }
        }while(next_permutation(c+1,c+n+1));
        for(int i=1;i<=n;i++){
            ans=ans*i%mod;
        }
        ans=((ans-sss)+mod)%mod;
        cout<<ans<<endl;
    }
    return 0;
}
