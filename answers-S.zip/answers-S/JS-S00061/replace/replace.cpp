#include<bits/stdc++.h>
using namespace std;
string s[10010][3];
//bool check(string a,string b){
 //   bool f=false;
//}

int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    int n,q;
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        string s1,s2;
        cin>>s1>>s2;
        s[i][1]=s1;
        s[i][2]=s2;
    }
    while(q--){
        string t1,t2;
        cin>>t1>>t2;
        if(t1.size()!=t2.size()){
            cout<<0<<endl;
            continue;
        }
        long long ans=0;
        for(int i=1;i<=n;i++){
            string tmp=t1;
            int iii=t1.find(s[i][1]);
            if(iii!=-1){
                tmp.replace(iii,s[i][1].size(),s[i][2]);
                int ok=1;
                for(int i=0;i<tmp.size();i++){
                    if(tmp[i]!=t2[i])ok=0;
                }
                if(ok)ans++;
                //idiiiix=t1.find(s[i][1],iii+1);
            }

        }
        cout<<ans<<endl;
    }
    return 0;
}
