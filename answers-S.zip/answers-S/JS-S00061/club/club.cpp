#include<bits/stdc++.h>
using namespace std;
int a[100010][5];
long long ans=0;
int b[100010];
int n;
int m;
long long dfs(int r,long long sum,int cc1,int cc2,int cc3){
    if(r>=n){
        return max(sum,ans);
    }
    if(cc3<m&&cc2<m&&cc1<m){
        return max(dfs(r+1,sum+a[r+1][3],cc1,cc2,cc3+1),max(dfs(r+1,sum+a[r+1][1],cc1+1,cc2,cc3),dfs(r+1,sum+a[r+1][2],cc1,cc2+1,cc3)));
    }
    if(cc1<m&&cc2<m){
        return max(dfs(r+1,sum+a[r+1][1],cc1+1,cc2,cc3),dfs(r+1,sum+a[r+1][2],cc1,cc2+1,cc3));

    }
    if(cc2<m&&cc3<m){
        return max(dfs(r+1,sum+a[r+1][3],cc1,cc2,cc3+1),dfs(r+1,sum+a[r+1][2],cc1,cc2+1,cc3));
    }
    if(cc1<m&&cc3<m){
        return max(dfs(r+1,sum+a[r+1][3],cc1,cc2,cc3+1),dfs(r+1,sum+a[r+1][1],cc1+1,cc2,cc3));
    }
    if(cc1<m){
        return dfs(r+1,sum+a[r+1][1],cc1+1,cc2,cc3);
    }
    if(cc2<m){
        return dfs(r+1,sum+a[r+1][2],cc1,cc2+1,cc3);
    }
    if(cc1<m){
        return dfs(r+1,sum+a[r+1][3],cc1,cc2,cc3+1);
    }
}

int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    int t;
    cin>>t;
    while(t--){
        cin>>n;
        ans=0;
        m=n/2;
        int ff2=1,ff3=1;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=3;j++){
                cin>>a[i][j];
                if(a[i][2]!=0)ff2=0;
                if(a[i][3]!=0)ff3=0;
            }
        }
        if(ff2==1&&ff3==1){
            for(int i=1;i<=n;i++){
                b[i]=a[i][1];
            }
            sort(b+1,b+n+1);
            long long an=0;
            for(int i=n;i>=n-m;i++){
                an+=b[i];
            }
            cout<<an<<endl;
            continue;
        }
        cout<<max(dfs(1,a[1][1],1,0,0),max(dfs(1,a[1][2],0,1,0),dfs(1,a[1][3],0,0,1)))<<endl;
    }

    return 0;
}
