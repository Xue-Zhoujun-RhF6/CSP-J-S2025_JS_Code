#include <string>
#include <iostream>

const int MAXN = 2e5 + 10;

int n, q;
std::string s1[MAXN], s2[MAXN];
std::string t1, t2;

int main()
{
  freopen("replace.in", "r", stdin);
  freopen("replace.out", "w", stdout);

  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  std::cout.tie(nullptr);

  std::cin >> n >> q;
  for (int i = 1; i <= n; i++)
    std::cin >> s1[i] >> s2[i];
  while (q--)
  {
    std::cin >> t1 >> t2;
    int pre = 0, suf = 0;
    int ans = 0;
    for (int i = 0; i < std::min(t1.size(), t2.size()); i++, pre++)
      if (t1[i] != t2[i])
        break;
    for (int i = t1.size() - 1, j = t2.size() - 1; i >= 0 && j >= 0; i--, j--, suf++)
      if (t1[i] != t2[j])
        break;
    for (int i = 1; i <= n; i++)
    {
      int last = 0;
      int p1 = 0, p2 = 0;
      int l1 = s1[i].size(), l2 = s2[i].size();
      while (p1 < t1.size() && p2 < t2.size())
      {
        p1 = t1.find(s1[i], last), p2 = t2.find(s2[i], last);
        if (p1 == -1 || p2 == -1)
          break;
        if (p1 != p2 || p1 > pre || p2 > pre || t1.size() + l1 - l2 != t2.size() || p1 + l1 + suf < t1.size() || p2 + l2 + suf < t2.size())
          break;
        last = p1 + 1;
        ans++;
      }
    }
    std::cout << ans << '\n';
  }

  return 0;
}