#include <iostream>
#include <algorithm>

const int MAXN = 1e4 + 10;
const int MAXM = 1e6 + 10;

int n, m, k;
struct Edge
{
  int u, v, w;
} e[MAXM * 2];
int pos;
int a[20][MAXN];
int c[20];

int fa[MAXN];
int find(int x)
{
  if (fa[x] == x)
    return x;
  return fa[x] = find(fa[x]);
}

int main()
{
  freopen("road.in", "r", stdin);
  freopen("road.out", "w", stdout);

  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  std::cout.tie(nullptr);

  std::cin >> n >> m >> k;
  for (int i = 1; i <= m; i++)
  {
    int u, v, w;
    std::cin >> u >> v >> w;
    e[++pos] = {u, v, w};
  }
  for (int i = 1; i <= k; i++)
  {
    std::cin >> c[i];
    for (int j = 1; j <= n; j++)
      std::cin >> a[i][j];
  }

  int pre = pos;
  int ans = (1LL << 31) - 1;
  for (int state = 0; state < (1 << k); state++)
  {
    pos = pre;
    int curans = 0;
    state <<= 1;
    for (int i = 1; i <= n; i++)
      fa[i] = i;

    for (int i = 1; i <= k; i++)
      if (state >> i)
      {
        curans += c[i];
        for (int j = 1; j <= n; j++)
          for (int k = 1; k < j; k++)
            e[++pos] = {j, k, a[i][j] + a[i][k]};
      }
    std::sort(e + 1, e + 1 + pos, [](const Edge &x, const Edge &y)
              { return x.w < y.w; });
    int cnt = 0;
    for (int i = 1; i <= pos; i++)
    {
      if (find(e[i].u) == find(e[i].v))
        continue;
      fa[find(e[i].u)] = find(e[i].v);
      cnt++;
      curans += e[i].w;
      if (cnt == n - 1)
        break;
    }
    state <<= 1;
    ans = std::min(ans, curans);
  }

  std::cout << ans << std::endl;

  return 0;
}
