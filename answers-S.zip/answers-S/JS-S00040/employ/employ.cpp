#include <iostream>
#include <algorithm>

const int MAXN = 510;
const int MOD = 998244353;

int n, m;
int c[MAXN], p[MAXN];
std::string s;

int main()
{
  freopen("employ.in", "r", stdin);
  freopen("employ.out", "w", stdout);

  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr), std::cout.tie(nullptr);

  std::cin >> n >> m;
  std::cin >> s;
  int ans = 0;
  for (int i = 1; i <= n; i++)
    std::cin >> c[i], p[i] = i;
  do
  {
    int cnt = 0, px = 0;
    for (int i = 1; i <= n; i++)
      if (s[i - 1] == '0' || cnt >= c[p[i]])
        cnt++;
      else
        px++;
    if (px >= m)
      ans++;
  } while (std::next_permutation(p + 1, p + 1 + n));
  std::cout << ans << std::endl;
}