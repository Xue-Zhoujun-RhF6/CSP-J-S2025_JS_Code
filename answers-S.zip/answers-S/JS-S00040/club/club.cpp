#include <vector>
#include <iostream>
#include <algorithm>

int T;

const int MAXN = 1e5 + 10;

int n;
int a[MAXN][4];
int cnt[4];
int ans;
int pick[MAXN];

void dfs(int dep, int sum)
{
  if (dep == n + 1)
  {
    ans = std::max(ans, sum);
    return;
  }
  for (int i = 1; i <= 3; i++)
  {
    if (cnt[i] == n / 2)
      continue;
    cnt[i]++;
    dfs(dep + 1, sum + a[dep][i]);
    cnt[i]--;
  }
}

void A()
{
  std::vector<int> tmp(n);
  for (int i = 0; i < n; i++)
    tmp[i] = a[i + 1][1];
  std::sort(tmp.begin(), tmp.end(), std::greater<int>());
  ans = 0;
  for (int i = 0; i < n / 2; i++)
    ans += tmp[i];
  std::cout << ans << std::endl;
}

void B()
{
  struct node
  {
    int id;
    int delta;
  };
  std::vector<node> tmp(n);
  for (int i = 0; i < n; i++)
    tmp[i].id = i + 1, tmp[i].delta = a[i + 1][2] - a[i + 1][1];
  std::sort(tmp.begin(), tmp.end(), [](const node &x, const node &y)
            { return x.delta > y.delta; });
  ans = 0;
  for (int i = 0; i < n; i++)
    if (i < n / 2)
      ans += a[i + 1][1] + tmp[i].delta;
    else
      ans += a[i + 1][1];
  std::cout << ans << std::endl;
}

int main()
{
  freopen("club.in", "r", stdin);
  freopen("club.out", "w", stdout);

  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  std::cout.tie(nullptr);

  std::cin >> T;

  while (T--)
  {
    std::cin >> n;
    bool isA = true;
    bool isB = true;
    for (int i = 1; i <= n; i++)
      for (int j = 1; j <= 3; j++)
      {
        std::cin >> a[i][j];
        if (j != 1 && a[i][j] != 0)
          isA = false;
        if (j == 3 && a[i][j] != 0)
          isB = false;
      }

    if (n <= 10)
    {
      ans = -1;
      dfs(1, 0);
      std::cout << ans << std::endl;
    }
    else if (isA)
      A();
    else if (isB)
      B();
    else
    {
      struct node
      {
        int id;
        int delta2, delta3;
        int delta;
      };
      std::vector<node> tmp(n);
      int ans = 0;
      for (int i = 0; i < n; i++)
      {
        pick[i + 1] = 1;
        tmp[i].id = i + 1;
        tmp[i].delta2 = a[i + 1][2] - a[i + 1][1];
        tmp[i].delta3 = a[i + 1][3] - a[i + 1][1];
        tmp[i].delta = std::max(tmp[i].delta2, tmp[i].delta3);
      }
      std::sort(tmp.begin(), tmp.end(), [](const node &x, const node &y)
                { return x.delta > y.delta; });
      int cnt = 0;
      std::vector<node> rearrange;
      for (int i = 0; i < n; i++)
      {
        if (cnt < n / 2 || tmp[i].delta > 0)
        {
          rearrange.push_back(tmp[i]);
          cnt++;
          pick[tmp[i].id] = 2;
        }
        else
          break;
      }
      int m = rearrange.size();
      sort(rearrange.begin(), rearrange.end(), [](const node &x, const node &y)
           { return x.delta3 - x.delta2 > y.delta3 - y.delta2; });
      cnt = 0;
      int xxcnt = 0;
      std::vector<node> rearrange2;
      for (int i = 0; i < m; i++)
      {
        if (m - cnt > n / 2 || (rearrange[i].delta3 > rearrange[i].delta2 && cnt < n / 2))
        {
          cnt++;
          pick[rearrange[i].id] = 3;
        }
        else
        {
          int id = rearrange[i].id;
          rearrange2.push_back(rearrange[i]);
        }
      }
      std::sort(rearrange2.begin(), rearrange2.end(), [](const node &x, const node &y)
                { return a[x.id][1] - a[x.id][2] > a[y.id][1] - a[y.id][2]; });
      for (int i = 0; i < rearrange2.size(); i++)
        if (a[rearrange2[i].id][1] > a[rearrange2[i].id][2])
          pick[rearrange2[i].id] = 1;
      for (int i = 1; i <= n; i++)
        ans += a[i][pick[i]];
      std::cout << ans << std::endl;
    }
  }

  return 0;
}
