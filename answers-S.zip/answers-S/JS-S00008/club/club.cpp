#include <bits/stdc++.h>
using namespace std;
struct node {
    int a, b, c;
};
bool cmpa(node x, node y) {
    return x.a > y.a;
}
bool cmpb(node x, node y) {
    return x.b > y.b;
}
bool cmpc(node x, node y) {
    return x.c > y.c;
}
int main()
{
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;cin >> T;
    while(T--) {
        int n; cin >> n;
        int ans = 0;
        if(n > 200) {
            cout << 0 << endl;
            continue;
        }
        vector<node>a(n + 1, {0, 0, 0});
        int h = n / 2;
        int f[n][h][h] = {};
        for (int i = 1; i <= n; i++)
        {
            cin >> a[i].a >> a[i].b >> a[i].c;
            ans += max({a[i].a, a[i].b, a[i].c});
        }
        cout << ans << endl;
        // sort(a.begin(), a.end(), cmpa);
        // for (int i = 1; i <= n; i++) {
        //     f[i][i][0] = f[i - 1][i - 1][0] + a[i].a;
        // }
        // sort(a.begin(), a.end(), cmpb);
        // for (int i = 1; i <= n; i++)
    }
    return 0;
}
/*
g++ -Wall -O2 -std=c++14 -static club.cpp -o club
*/