#include <bits/stdc++.h>
using namespace std;
struct node {
    string a, b;
};
int main()
{
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    int n, q;  cin >> n >> q;
    vector<node>s(n, {"", ""});
    for (int i = 0; i < n; i++) {
        cin >> s[i].a >> s[i].b;
    }
    while(q--)
    {
        int ans = 0;
        string que, to;
        cin >> que >> to;
        for (auto x : s)
        {
            string a = x.a, b = x.b;
            for (int i = 0; i < int(que.size()); i++)
            {
                bool f = true;
                for (int j = 0, k = i; j < int(a.size()) && k < int(que.size()); j++, k++)
                {
                    if(que[k] != a[j]) {
                        f = false;
                        break;
                    }
                }
                if(f) {
                    string temp = que;
                    for (int j = 0, k = i; j < int(b.size()); j++, k++) {
                        temp[k] = b[j];
                    }
                    if(temp == to) ans++;
                }
            }
        }
        cout << ans << endl;
    }
    return 0;
}
/*
g++ -Wall -O2 -std=c++14 -static replace.cpp -o replace
*/