#include <bits/stdc++.h>
using namespace std;
const int mod = 998244353;
int n, m, ans, cnt;
vector<int>c;
string s;
int main()
{
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin >> n >> m >> s;
    c.resize(n + 1, 0);
    for (int i = 1; i <= n; i++) cin >> c[i];
    for (auto x : s) if(x == '1') cnt++;
    if(cnt == n || (m == 1 && cnt > 0))
    {
        ans = n;
        while(--n > 1) {
            ans = (ans * n) % mod;
        }
        cout << ans << endl;
        return 0;
    }
    cout << 0 << endl;
    return 0;
}
/*
g++ -Wall -O2 -std=c++14 -static employ.cpp -o employ
*/