#include <bits/stdc++.h>
#define int long long
using namespace std;
int n, m, k, ans;
struct node {
    int v, w, t;
};
struct que {
    int b, v, w;
    vector<int>a;
    vector<int>vis;
    bool operator<(const que x) const{
        return w > x.w;
    }
};
vector<int>c;
vector<vector<node>>edge;
bool check(int t, vector<int>& a)
{
    for (auto x : a) {
        if(x == t) return true;
    }return false;
}
void dijkstra()
{
    priority_queue<que>pq;
    pq.push({0, 1, 0, {}, {}});
    while(!pq.empty())
    {
        auto temp = pq.top();pq.pop();
        int b = temp.b, u = temp.v, cos = temp.w;
        // cout << u << " " << cos << " " << b << endl;
        vector<int>a = temp.a;
        vector<int>vis = temp.vis;
        for (auto x : edge[u])
        {
            int v = x.v, w = x.w, t = x.t;
            if(check(v, vis)) continue;
            if(t == 0 || check(t, a)) {
                if(b + 1 == n - 1) {
                    cout << cos + w << endl;
                    return;
                }
                pq.push({b + 1, v, cos + w, a});
            }else {
                if(b + 1 == n - 1) {
                    cout << cos + w + c[t] << endl;
                    return;
                }
                a.push_back(t);
                pq.push({b + 1, v, cos + w + c[t], a});
            }
        }
    }
}
signed main()
{
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> n >> m >> k;
    c.resize(n + 1, 0);
    edge.resize(n + 1, vector<node>());
    for (int i = 1; i <= m; i++)
    {
        int u, v, w; cin >> u >> v >> w;
        edge[u].push_back({v, w, 0});
        edge[v].push_back({u, w, 0});
    }
    for (int i = 1; i <= k; i++)
    {
        cin >> c[i];
        vector<int>a(n + 1, 0);
        for (int j = 1; j <= n; j++) cin >> a[j];
        for (int u = 1; u < n; u++) {
            for (int v = u + 1; v <= n; v++) {
                edge[u].push_back({v, a[u] + a[v], i});
                edge[v].push_back({v, a[u] + a[v], i});
            }
        }
    }
    // for (int i = 1; i <= n; i++) {
    //     for (auto x : edge[i]) {
    //         cout << x.v << ' ' << x.w << ' ' << x.t << endl;
    //     }
    // }
    dijkstra();
    return 0;
}
/*
g++ -Wall -O2 -std=c++14 -static road.cpp -o road
*/