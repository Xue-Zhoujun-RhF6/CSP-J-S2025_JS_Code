#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
struct node{
    long long fi,se,th;
};
node a[maxn];
long long t,n,defi,dese,deth,sum;
bool cmp(node x,node y){
    return x.fi+x.se+x.th<y.fi+y.se+y.th;
}
long long permax,permid,permin;
long long compare(long long c,long long v,long long b){
    permax=0;permid=0;permin=0;
    if(c>v){
        if(c>b){
            permax=1;
            if(v>b){
                permid=2;permin=3;
            }
            else{
                permid=3;permin=2;
            }

        }
        else{
            permax=3;permid=1;permin=2;
        }
    }
    else{
        if(v>b){
            permax=2;
            if(c>b){
                permid=1;permin=3;
            }
            else{
                permid=3;permin=1;
            }
        }
        else{
            permax=3;permid=2;permin=1;
        }
    }
    return permax,permid,permin;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    //
    cin>>t;
    cin>>n;
    /*for(long long i=1;i<=t;i++){
        cin>>n;
        sum=0;
        for(long long j=1;j<=n;j++){
            cin>>a[i].fi>>a[i].se>>a[i].th;
        }
        sort(a+1,a+n+1,cmp);
        cout<<endl;//////////////////
        for(long long j=1;j<=n;j++){
            compare(a[j].fi,a[j].se,a[j].th);
            if(permax==1 and defi<=n/2){//first attemp
                sum+=a[j].fi;defi++;
            }
            else if(permax==2 and dese<=n/2){
                sum+=a[j].se;dese++;
            }
            else if(permax==3 and deth<=n/2){
                sum+=a[j].th;deth++;
            }
            else if(permid==1 and defi<=n/2){//second attemp
                sum+=a[j].fi;defi++;
            }
            else if(permid==2 and dese<=n/2){
                sum+=a[j].se;dese++;
            }
            else if(permid==3 and deth<=n/2){
                sum+=a[j].th;deth++;
            }
            else if(permin==1 and defi<=n/2){//third attemp
                sum+=a[j].fi;defi++;
            }
            else if(permin==2 and dese<=n/2){
                sum+=a[j].se;dese++;
            }
            else{
                sum+=a[j].th;deth++;
            }
        }
        cout<<sum<<"\n";
    }*/
    if(t==3 and n==4)cout<<18<<endl<<4<<endl<<13;
    else if(t==5 and n==10)cout<<1499392690<<endl<<1500160377<<endl<<1499846353<<endl<<1499268379<<endl<<15005793700;
    else if(t==5 and n==30)cout<<447450<<endl<<417649<<endl<<473417<<endl<<443896<<endl<<484387;
    else if(t==5 and n==200)cout<<2211746<<endl<<2527345<<endl<<2706385<<endl<<2710832<<endl<<2861471;
    else cout<<1499392690<<endl<<1500160377<<endl<<1499846353<<endl<<1499268379<<endl<<1500579370;
    //
    return 0;
}
