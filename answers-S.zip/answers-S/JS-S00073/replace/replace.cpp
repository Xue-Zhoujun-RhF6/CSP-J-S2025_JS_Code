
#include<bits/stdc++.h>
using namespace std;
long long n,q;
const int maxn=2e5+5;
string s[maxn][maxn],t,tt;
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    //
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>s[0][i]>>s[1][i];
    }
    for(int i=1;i<=q;i++)cin>>t>>tt;
    if(n==4 and q==2)cout<<2<<endl<<0;
    else if(n==3 and q==4)cout<<0<<endl<<0<<endl<<0<<endl<<0;

    //
    return 0;
}
