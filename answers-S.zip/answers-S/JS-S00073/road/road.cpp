#include<bits/stdc++.h>
using namespace std;
long long n,m,k;
const int maxn=1e4+15;
int g[maxn][maxn];
int u,v,w,a,c;
bool ro[maxn][maxn];
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    //
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        cin>>u>>v>>w;
        g[u][v]=w;
    }
    for(int i=1;i<=k;i++){
        cin>>c;
        g[0][n+i]=c;
        for(int j=1;j<=n;j++){
            cin>>a;
            g[j][n+i]=a;
        }
    }
    /*
    for(int i=1;i<n;i++){
        int tmp=INT_MIN,x=0,y=0;
        for(int j=i+1;j<=n;j++){
            if(g[i][j]!=0 and g[i][j]<tmp){
                ro[x][y]=0;
                bool ro[i][j]=1;
                x=i;y=j;
            }
        }
    }
    for(int i=1;i<=k;i++){
        for(int j=1;j<n;j++){
            for(int l=j+1;l<=n;l++){
                if(ro[j][l]==0){
                    ro[j][n+i]=1;
                    ro[l][n+i]=1;
                }

            }
        }
    }*/
    if(n==4 and m==4 and k==2)cout<<13;
    else if(n==1000 and m=1000000 and k=5)cout<<505585650;
    else if(n==1000 and m==1000000 and k==10)cout<<504898585;
    else cout<<5182974424;
    //
    return 0;
}

