#include<bits/stdc++.h>
using namespace std;
long long n,m;
string s;
const int maxn=5e2+5;
long long c[maxn];
long long a[maxn];
bool vis[maxn];
long long ans;
long long wait,em;
void dfs(int x){
    if(x==n+1){//this turn can employ how many
        wait=0;em=0;
        for(int i=1;i<=n;i++){
            if(wait>=c[a[i]])wait++;
            else{
                if(s[i-1]=='0')wait++;
                else em+=1;
            }
        }
        if(em>=m){
            ans++;return ;
        }
    }
    for(int i=1;i<=n;i++){
        if(vis[i])continue;
        vis[i]=1;
        a[x]=i;
        dfs(x+1);
        a[x]=0;
        vis[i]=0;
    }
}
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    //
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++)cin>>c[i];
    dfs(1);
    cout<<ans%998244353;
    //
    return 0;
}

