#include<bits/stdc++.h>
using namespace std;
const long long N=1e5+100;
long long a[N],b[N],c[N];
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    long long T;scanf("%lld",&T);
    while(T--)
    {
        long long n;scanf("%lld",&n);
        memset(a,0,sizeof(a));
        bool f1=1,f2=1,f3=1;
        for(int i=1;i<=n;i++)
        {
            scanf("%lld%lld%lld",&a[i],&b[i],&c[i]);
            if(a[i]!=0) f1=0;
            if(b[i]!=0) f2=0;
            if(c[i]!=0) f3=0;
        }
        if(n==2)
        {
            cout<<max((max(a[1]+b[2],a[1]+c[2]),max(b[1]+a[2],b[1]+c[2])),max(c[1]+a[2],c[1]+b[2]));
            cout<<"\n";
        }
        else if(f2==1&&f3==1)
        {
            sort(a+1,a+n+1);
            reverse(a+1,a+n+1);
            long long ans=0;
            for(int i=1;i<=n/2;i++) ans+=a[i];
            cout<<ans<<"\n";
        }
         else if(f1==1&&f2==1)
        {
            sort(c+1,c+n+1);
            reverse(c+1,c+n+1);
            long long ans=0;
            for(int i=1;i<=n/2;i++) ans+=c[i];
            cout<<ans<<"\n";
        }
         else if(f1==1&&f3==1)
        {
            sort(b+1,b+n+1);
            reverse(b+1,b+n+1);
            long long ans=0;
            for(int i=1;i<=n/2;i++) ans+=b[i];
            cout<<ans<<"\n";
        }
        else
        {
            int ans=0;
            for(int i=1;i<=n;i++) ans+=max(max(a[i],b[i]),c[i]);
            cout<<ans<<"\n";
        }
    }
    return 0;
}
