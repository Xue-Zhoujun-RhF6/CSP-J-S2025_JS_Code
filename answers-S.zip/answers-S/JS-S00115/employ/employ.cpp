#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
long long c[1000];
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;cin>>n>>m;string s;cin>>s;
    for(int i=1;i<=n;i++) cin>>c[i];
    bool flag=1;
    for(int i=0;i<s.size();i++)
    {
        if(s[i]=='0') flag=0;
    }
    if(flag==1)      cout<<pow(2,n);
    return 0;
}
