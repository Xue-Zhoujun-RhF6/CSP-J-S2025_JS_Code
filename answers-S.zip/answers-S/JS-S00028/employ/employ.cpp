#include <bits/stdc++.h>
using namespace std;
const long long mod = 998244353;
int n , m;
long long ans;
string s;
int a[505];
int p[505];
bool chk(){
    int cnt = 0;
    int sum = 0;
    for(int i = 1 ; i <= n ; i++){
        if(cnt >= p[a[i]]){
            cnt++;
            continue;
        }
        if(s[i - 1] == '0'){
            cnt++;
        }else{
            sum++;
        }
    }
    return sum >= m;
}
int main(){
    freopen("employ.in" , "r" , stdin);
    freopen("employ.out" , "w" , stdout);
    cin >> n >> m >> s;
    for(int i = 1 ; i <= n ; i++){
        cin >> p[i];
        a[i] = i;
    }
    do{
        if(chk()){
            //cout << a[1] << " " << a[2] << " " << a[3] << endl;
            ans++;
            ans %= mod;
        }
    }while(next_permutation(a + 1 , a + n + 1));
    cout << ans;
    return 0;
}
