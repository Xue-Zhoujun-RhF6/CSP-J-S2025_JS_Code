#include <bits/stdc++.h>
using namespace std;
int n , m;
map<string , string>mp;
int main(){
    freopen("replace.in" , "r" , stdin);
    freopen("replace.out" , "w" , stdout);
    bool flag = 1;
    scanf("%d %d" , &n , &m);
    for(int i = 1 ; i <= n ; i++){
        string a , b;
        cin >> a >> b;
        mp[a] = b;
    }
    while(m--){
        string a , b;
        long long ans = 0;
        cin >> a >> b;
        if(a.size() != b.size()){
            cout << 0 << endl;
            continue;
        }
        for(int i = 0 ; i < a.size() ; i++){
            for(int j = i ; j < a.size() ; j++){
                string mid = a.substr(i , j - i + 1);
                if(mp[mid] != ""){
                    string tmp = "";
                    tmp += a.substr(0 , i);
                    tmp += mp[mid];
                    tmp += a.substr(j + 1 , a.size());
                    //cout << tmp << endl;
                    if(tmp == b){
                        ans++;
                    }
                }
            }
        }
        cout << ans << endl;
    }
    return 0;
}
