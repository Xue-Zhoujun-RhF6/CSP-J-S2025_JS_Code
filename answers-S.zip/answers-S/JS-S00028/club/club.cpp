#include <bits/stdc++.h>
using namespace std;
struct node{
    int a[5];
};
int mx(node a){
    return max(a.a[1] , max(a.a[2] , a.a[3]));
}
int mn(node a){
    return min(a.a[1] , min(a.a[2] , a.a[3]));
}
bool cmp(node a , node b){
    return mx(a) * 2 + mn(a) - a.a[1] - a.a[2] - a.a[3] > mx(b) * 2 + mn(b) - b.a[1] - b.a[2] - b.a[3];
}
int t;
int n;
node b[100005];
void solve(){
    scanf("%d" , &n);
    for(int i = 1 ; i <= n ; i++){
        scanf("%d %d %d" , &b[i].a[1] , &b[i].a[2] , &b[i].a[3]);
    }
    sort(b + 1 , b + n + 1 , cmp);
    long long ans = 0;
    int sum[5] = {0 , 0 , 0};
    for(int i = 1 ; i <= n ; i++){
        int f = 1 , s = 1;
        int tmp = mx(b[i]);
        if(tmp == b[i].a[2]){
            f = 2;
        }else if(tmp == b[i].a[3]){
            f = 3;
        }
        if(sum[f] < n / 2){
            sum[f]++;
            ans += tmp;
            continue;
        }
        tmp = b[i].a[1] + b[i].a[2] + b[i].a[3] - mx(b[i]) - mn(b[i]);
        if(tmp == b[i].a[2]){
            s = 2;
        }else if(tmp == b[i].a[3]){
            s = 3;
        }
        sum[s]++;
        ans += tmp;
    }
    cout << ans << endl;
    return;
}
int main(){
    freopen("club.in" , "r" , stdin);
    freopen("club.out" , "w" , stdout);
    scanf("%d" , &t);
    while(t--){
        solve();
    }
    return 0;
}
