#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct edge{
    int u , v , w;
};
bool cmp(edge a , edge b){
    return a.w < b.w;
}
int n , m , k;
int cst[15];
int len[15][10025];
long long mn = 1e18;
int bel[10025];
ll chk(int I , vector<edge> v){
    long long tmp = 0;
    for(int j = 1 ; j <= k ; j++){
        if((I >> (j - 1)) & 1){
            tmp += cst[j];
            for(int i = 1 ; i <= n ; i++){
                edge x;x.u = n + j;x.v = i;x.w = len[j][i];
                v.push_back(x);
            }
        }
    }
    for(int i = 1 ; i <= n + k ; i++){
        bel[i] = i;
    }
    sort(v.begin() , v.end() , cmp);
    int tot = 0;
    for(int i = 0 ; i < v.size() ; i++){
        if(tot == n + I - 1){
            break;
        }
        edge x = v[i];
        if(bel[x.u] == bel[x.v]){
            continue;
        }
        int mx = max(bel[x.u] , bel[x.v]);
        int mn = min(bel[x.u] , bel[x.v]);
        for(int i = 1 ; i <= n + k ; i++){
            if(bel[i] == mx){
                bel[i] = mn;
            }
        }
        tmp += x.w;
        tot++;
    }
    return tmp;
}
int main(){
    freopen("road.in" , "r" , stdin);
    freopen("road.out" , "w" , stdout);
    vector<edge>v;
    scanf("%d %d %d" , &n , &m , &k);
    for(int i = 1 ; i <= m ; i++){
        edge x;
        scanf("%d %d %d" , &x.u , &x.v , &x.w);
        v.push_back(x);
    }
    for(int i = 1 ; i <= k ; i++){
        scanf("%d" , &cst[i]);
        for(int j = 1 ; j <= n ; j++){
            scanf("%d" , &len[i][j]);
        }
    }
    for(int i = 1 ; i <= (1 << k) ; i++){
        mn = min(mn , (long long)chk(i , v));
    }
    cout << mn << endl;
    return 0;
}
