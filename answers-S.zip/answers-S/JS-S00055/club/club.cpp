#include<bits/stdc++.h>
using namespace std;
int t;
int n;
int a[20001][4];
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--)
    {
        cin>>n;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=3;j++)
            {
                cin>>a[i][j];
            }                
        }        
        if(n==2){
            int ans=0,maxn=0;                    
            int b[6]={a[1][1]+a[2][2],a[1][1]+a[2][3],a[1][2]+a[2][1],a[1][2]+a[2][3],a[1][3]+a[2][1],a[1][3]+a[2][2]};
            maxn=b[1];
            for(int k=2;k<=6;k++)
            {
                if(b[k]>maxn) maxn=b[k];
            }
            ans=maxn;  
            cout<<ans<<'\n';
            ans=0,maxn=0;
        }  
    }
    return 0;
}