#include<bits/stdc++.h>
using namespace std;
int a[100005][4];
int f[4];
int t,n;
long long sum=0;
long long maxx=-10;
void fun(int x,int y,int zd)
{
	if(f[y]>zd)return;
	if(x==n)
	{
		maxx=max(maxx,sum);
		return;
	}
	if(f[y]<=zd)
	{
		if(y==1)
		{
			f[y]++;
			sum+=a[x+1][y];
			fun(x+1,y,zd);
			sum-=a[x+1][y];
			f[y]--;
			
			f[y+1]++;
			sum+=a[x+1][y+1];
			fun(x+1,y+1,zd);
			sum-=a[x+1][y+1];
			f[y+1]--;
			
			f[y+2]++;
			sum+=a[x+1][y+2];
			fun(x+1,y+2,zd);
			sum-=a[x+1][y+2];
			f[y+2]--;
		}
		else if(y==2)
		{
			f[y]++;
			sum+=a[x+1][y];
			fun(x+1,y,zd);
			sum-=a[x+1][y];
			f[y]--;
			
			f[y+1]++;
			sum+=a[x+1][y+1];
			fun(x+1,y+1,zd);
			sum-=a[x+1][y+1];
			f[y+1]--;
			
			f[y-1]++;
			sum+=a[x+1][y-1];
			fun(x+1,y-1,zd);
			sum-=a[x+1][y-1];
			f[y-1]--;
		}
		else if(y==3)
		{
			f[y]++;
			sum+=a[x+1][y];
			fun(x+1,y,zd);
			sum-=a[x+1][y];
			f[y]--;
			
			f[y-2]++;
			sum+=a[x+1][y-2];
			fun(x+1,y-2,zd);
			sum-=a[x+1][y-2];
			f[y-2]--;
			
			f[y-1]++;
			sum+=a[x+1][y-1];
			fun(x+1,y-1,zd);
			sum-=a[x+1][y-1];
			f[y-1]--;
		}
	}
	return;
}
int main()
{
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	cin>>t;
	while(t--)
	{
		maxx=-10;
		f[1]=0,f[2]=0,f[3]=0;
		cin>>n;
		int zd=n/2;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i][1]>>a[i][2]>>a[i][3];
		}
		long long maxn=-100;
		f[1]=1;
		sum=a[1][1];
		fun(1,1,zd);
		maxn=max(maxx,maxn);
		f[1]=0;
		f[2]=1;
		sum=a[1][2];
		fun(1,2,zd);
		maxn=max(maxx,maxn);
		f[2]=0;
		f[3]=1;
		sum=a[1][3];
		fun(1,3,zd);
		maxn=max(maxx,maxn);
		cout<<maxn<<endl;
	}
	return 0;
}
