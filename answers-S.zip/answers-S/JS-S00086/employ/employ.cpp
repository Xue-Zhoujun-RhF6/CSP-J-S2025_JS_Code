#include<bits/stdc++.h>
using namespace std;
int n,m,c[506];
string s;
int main()
{
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	cin>>n>>m;
	cin>>s;
	for(int i=1;i<=n;i++)
	{
		cin>>c[i];
	}
	int len=s.size();
	if(m==n)
	{
		for(int i=0;i<len;i++)
		{
			if(s[i]==0 || c[i+1]==0)
			{
				cout<<0;
				return 0;
			}
		}
		cout<<0;
	}
	else if(m==1)
	{
		for(int i=0;i<len;i++)
		{
			if(s[i]==1)
			{
				long long sum=1;
				for(int j=2;j<=n;j++)
				{
					sum=((sum%998244353)*j)%998244353;
				}
				cout<<sum%998244353;
				return 0;
			}
		}
		cout<<0;
	}
	else 
	{
		long long sum=1;
		int k=n;
		for(int i=1;i<=n;i++)
		{
			if(c[i]==0)k--;
		}
		if(k<m)
		{
			cout<<0;
			return 0;
		}
		for(int j=2;j<=k;j++)
		{
			sum=((sum%998244353)*j)%998244353;
		}
		cout<<sum%998244353;
		return 0;
	}
	return 0;
}
