#include<bits/stdc++.h>
using namespace std;
int n,q;
string s[200005],ss[200005],s1s,s2s;
int main()
{
	freopen("replace.in","r",stdin);
	freopen("replace.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++)
	{
		cin>>s[i]>>ss[i];
	}
	for(int i=1;i<=q;i++)
	{
		cin>>s1s>>s2s;
		int sum=0;
		for(int j=1;j<=n;j++)
		{
			int len1=s1s.size();
			for(int k=0;k<len1;k++)
			{
				if(s1s[k]==s[j][0] && s2s[k]==ss[j][0])
				{
					int flag=1;
					for(int ijkl=0;ijkl<k;ijkl++)
					{
						if(s1s[ijkl] != s2s[ijkl]){flag=0;break;}
					}
					if(flag==1){
						int l=0;
						int len2=s[j].size();
						while(s1s[k]==s[j][l] && s2s[k]==ss[j][l] && l<len2)
						{
							k++;
							l++;
						}
						if(l == len2)
						{
							int flag=1;
							for(int ijkl=k;ijkl<len1;ijkl++)
							{
								if(s1s[ijkl] != s2s[ijkl]){flag=0;break;}
							}
							if(flag==1)
								sum++;
						}		
					}
				}
			}
		}
		cout<<sum<<endl;
	}
	return 0;
}
