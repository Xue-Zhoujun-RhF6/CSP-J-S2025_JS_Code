#include<bits/stdc++.h>
using namespace std;
int n,m,k,u[10005],v[10005],w[10005],c[1000005];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>u[i]>>v[i]>>w[i];
	}
	for(int i=1;i<=k;i++)
	{
		cin>>c[i];			
		int a[10005];
		for(int j=1;j<=n;j++)
		{
			cin>>a[i];
		}
	}
	cout<<0;
	return 0;
}
