#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,m,k;
int a,b,c,dis;
int d[11];
struct edge{
    int to;
    int cost;
};
vector <edge> p[10005];
vector <edge> l[10015];
bool val[10015]={};
ll ans=0;
struct e{
    int u,v,w;
    friend bool operator  >  (e a,e b){
        return a.w<b.w;
    }
    friend bool operator < (e a,e b){
        return a.w>b.w;
    }
};
priority_queue <e> q;
void Krusal1(){
    for(int i=0;i<p[1].size();i++)
        q.push({1,p[1][i].to,p[1][i].cost});
    val[1]=1;
    int cnt=1;
    while(!q.empty()){
        e tmp=q.top();
        q.pop();
        if(val[tmp.u]&&val[tmp.v])
            continue;
        l[tmp.u].push_back({tmp.v,tmp.w});
        l[tmp.v].push_back({tmp.u,tmp.w});
        ans+=tmp.w;
        cnt++;
        //printf("%d %d %d %d\n",tmp.u,tmp.v,tmp.w,cnt);
        if(cnt==n)
            break;
        if(!val[tmp.u]){
            for(int i=0;i<p[tmp.u].size();i++){
                edge t=p[tmp.u][i];
                if(!val[t.to])
                    q.push({tmp.u,t.to,t.cost});
            }
            val[tmp.u]=1;
        }else{
            for(int i=0;i<p[tmp.v].size();i++){
                edge t=p[tmp.v][i];
                if(!val[t.to])
                    q.push({tmp.v,t.to,t.cost});
            }
            val[tmp.v]=1;
        }
    }
    return;
}
void Krusal2(int s){
    ll ret=0;
    int cnt=1;
    memset(val,0,sizeof(val));
    for(int i=1;i<=k;i++){
        if(s&1<<(i-1)){
            ret+=d[i];
            cnt--;
        }
        else
            val[n+i]=1;
    }
    while(!q.empty())
        q.pop();
    for(int i=0;i<l[1].size();i++){
        edge t=l[1][i];
        if(!val[t.to])
            q.push({1,t.to,t.cost});
    }
    val[1]=1;
    while(!q.empty()){
        e tmp=q.top();
        q.pop();
        if(val[tmp.u]&&val[tmp.v])
            continue;
        ret+=tmp.w;
        cnt++;
        //printf("%d %d %d %d\n",tmp.u,tmp.v,tmp.w,cnt);
        if(cnt==n)
            break;
        if(!val[tmp.u]){
            for(int i=0;i<l[tmp.u].size();i++){
                edge t=l[tmp.u][i];
                if(!val[t.to])
                    q.push({tmp.u,t.to,t.cost});
            }
            val[tmp.u]=1;
        }else{
            for(int i=0;i<l[tmp.v].size();i++){
                edge t=l[tmp.v][i];
                if(!val[t.to])
                    q.push({tmp.v,t.to,t.cost});
            }
            val[tmp.v]=1;
        }
    }
    ans=min(ans,ret);
    return;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=m;i++){
        scanf("%d%d%d",&a,&b,&c);
        p[a].push_back({b,c});
        p[b].push_back({a,c});
    }
    Krusal1();
    for(int i=1;i<=k;i++){
        scanf("%d",&d[i]);
        for(int j=1;j<=n;j++){
            scanf("%d",&dis);
            l[n+i].push_back({j,dis});
            l[j].push_back({n+i,dis});
        }
    }
    for(int i=1;i<1<<(k-1);i++)
        Krusal2(i);
    printf("%lld\n",ans);
    return 0;
}
