#include <bits/stdc++.h>
using namespace std;
int n,T;
int b[100005],btop;
int cnt[3];
long long ans=0;
struct person{
    int c[3];
    int fpi,spi;
}a[100005];
void init(person &a){
    if(a.c[0]>a.c[1]){
        if(a.c[2]>a.c[0]){
            a.fpi=2;
            a.spi=0;
        }
        else{
            a.fpi=0;
            a.spi=a.c[2]>a.c[1]?2:1;
        }
    }else{
        if(a.c[2]>a.c[1]){
            a.fpi=2;
            a.spi=1;
        }
        else{
            a.fpi=1;
            a.spi=a.c[2]>a.c[0]?2:0;
        }
    }
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%d",&T);
    while(T){
        memset(a,0,sizeof(0));
        memset(cnt,0,sizeof(cnt));
        btop=0;
        ans=0;
        scanf("%d",&n);
        for(int i=0;i<n;i++){
            scanf("%d%d%d",&a[i].c[0],&a[i].c[1],&a[i].c[2]);
            init(a[i]);
            cnt[a[i].fpi]++;
            ans+=a[i].c[a[i].fpi];
        }
        for(int i=0;i<3;i++){
            if(cnt[i]>(n>>1)){
                for(int j=0;j<n;j++){
                    if(a[j].fpi==i)
                        b[btop++]=a[j].c[a[j].fpi]-a[j].c[a[j].spi];
                }
                sort(b,b+btop);
                for(int j=0;j<cnt[i]-(n>>1);j++)
                    ans-=b[j];
                break;
            }
        }
        printf("%lld\n",ans);
        T--;
    }
    return 0;
}
