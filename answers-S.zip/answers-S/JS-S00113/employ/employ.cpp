#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,m;
string s;
int a[501];
ll ans=0,p=998244353;
int f[11]={},c[11]={0};
void dfs(int dep,int cnt){
    if(dep==n+1){
        ans++;
        return;
    }
    if(dep-1-cnt+c[n]-c[dep-1]<m)
        return;
    for(int i=1;i<=n;i++){
        if(!f[i]){
            f[i]=1;
            if(a[i]<=cnt||s[dep-1]=='0'){
                if(cnt<n-m)
                    dfs(dep+1,cnt+1);
            }
            else
                dfs(dep+1,cnt);
            f[i]=0;
        }
    }
    return;
}
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    if(n<=10){
        for(int i=1;i<=n;i++){
            c[i]=c[i-1]+(s[i-1]-'0');
        }
        dfs(1,0);
        cout<<ans;
    }
    else{
        for(int i=0;i<n;i++){
            if(s[i]=='0'){
                cout<<0;
                return 0;
            }
        }
        ans=1;
        for(int j=m;j>1;j--)
            (ans*=j)%=p;
        cout<<ans;
    }
    return 0;
}
