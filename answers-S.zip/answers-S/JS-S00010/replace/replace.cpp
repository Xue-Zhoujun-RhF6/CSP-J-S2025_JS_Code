#include  <bits/stdc++.h>
using namespace std;
const int N = 2e5+8;
int n,q;
string sx[N],sy[N];
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin >> n >> q;
    for(int i = 1; i <= n; i++){
        cin >> sx[i] >> sy[i];
    }

    while(q--){
        string s1,s2;
        cin >> s1 >> s2;
        int ans = 0;
        for(int i = 0; i <= s1.length()-1; i++){
            for(int j = 1; j <= n; j++){
                if(i + sx[j].length() - 1 > s1.length()-1) continue;
                string a = "";
                a = s1.substr(0,i-1 + 1);
                string x = s1.substr(i,sx[j].length());
                string y = s2.substr(i,sy[j].length());
                string c = "";
                c = s1.substr(i+sx[j].length(),s1.length() - (i + sx[j].length()));
                if(x != sx[j]) continue;
                if(a + sy[j] + c == s2){
                    ans++;
                }
            }

        }
        cout << ans << endl;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
