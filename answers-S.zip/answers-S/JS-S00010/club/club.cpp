#include <bits/stdc++.h>
using namespace std;
const int N = 1e5+8;
int n;
int a[N][4];
int cnt[4];
long long ans = 0;
int ch[N];
int love[N];
int T;
bool cmp(int a,int b){
    return a < b;
}


void solve(){
    memset(a,0,sizeof(a));
    memset(cnt,0,sizeof(cnt));
    memset(love,0,sizeof(love));
    ans = 0;
    cin >> n;
    for(int i = 1; i <= n; i++){
        cin >> a[i][1] >> a[i][2] >> a[i][3];
        if(a[i][1] >= a[i][2] && a[i][1] >= a[i][3]){
            cnt[1]++;
            love[i] = 1;
            ans += a[i][1];
        }
        else if(a[i][2] >= a[i][1] && a[i][2] >= a[i][3]){
            cnt[2]++;
            love[i] = 2;
            ans += a[i][2];
        }
        else if(a[i][3] >= a[i][1] && a[i][3] >= a[i][2]){
            cnt[3]++;
            love[i] = 3;
            ans += a[i][3];
        }
    }
    if(cnt[3] <= n/2 && cnt[2] <= n/2 && cnt[1] <= n/2){
        cout << ans << endl;
        return ;
    }
    int mx = max({cnt[1],cnt[2],cnt[3]});
    int pos;
    if(mx == cnt[1]){
        pos = 1;
    }
    else if(mx == cnt[2]){
        pos = 2;
    }
    else{
        pos = 3;
    }
    int idx = 0;
    memset(ch,0x3f3f3f3f,sizeof(ch));
    for(int i = 1; i <= n; i++){
        if(love[i] != pos) continue;
        ++idx;
        for(int j = 1; j <= 3; j++){
            if(j != love[i]) ch[idx] = min(ch[idx],a[i][love[i]] - a[i][j]);
        }
    }
    sort(ch+1,ch+idx+1,cmp);
    int mid = n/2;
    for(int i = 1; i <= mx - mid; i++){
        ans -= ch[i];
    }
    cout << ans << endl;
}

int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin >> T;
    while(T--){
        solve();
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
