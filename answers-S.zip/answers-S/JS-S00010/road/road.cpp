#include <bits/stdc++.h>
using namespace std;
const int N = 1e5+8;
int n,m,k;
struct Edge{
    int v,w;
};
vector <Edge> edges[N];
vector <Edge> tr[N];
int f[N];
void mn_tr(int s){
    queue <int> q;
    priority_queue <array<int,3>,vector<array<int,3> >,greater<array<int,3> > > pq;
    q.push(s);
    f[s] = s;
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(auto [v,w] : edges[u]){
            if(!f[v])
                pq.push({w,u,v});
        }
        int v = pq.top()[2];
        int w = pq.top()[0];
        int fa = pq.top()[1];
        while(f[v]){
            pq.pop();
            v = pq.top()[2];
            w = pq.top()[0];
            fa = pq.top()[1];
        }
        f[v] = fa;
        tr[fa].push_back({v,w});
        tr[v].push_back({fa,w});
        q.push(v);
        pq.pop();
    }
}
int ans = 0;
void dfs(int u,int f){
    for(auto [v,w] : tr[u]){
        if(v == f) continue;
        dfs(v,u);
        ans += w;
    }
}
int main(){
    cin >> n >> m;
    for(int i = 1; i <= m; i++){
        int u,v,w;
        cin >> u >> v >> w;
        edges[u].push_back({v,w});
        edges[v].push_back({u,w});
    }
    /*
    for(int i = 1; i <= k ;i++){
        for(int j = 1; j <= n; j++){
            int v;
            cin >> v;
            edges[j].push_back({n+i,v});
            edges[n+i].push_back({j,v});
        }
    }
    */
    mn_tr(1);
    dfs(1,0);
    cout << ans << endl;
    return 0;
}
