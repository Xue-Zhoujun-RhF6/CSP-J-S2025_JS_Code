#include <bits/stdc++.h>
using namespace std;
const int N = 15;
int n;
int a[N];
int q;
int mod = 998244353;
string s;
long long ans = 0;
bool ch[N];
void dfs(int d,int cnt,int h){
    if(d == n+1){
        if(h >= q) ans++;
        return ;
    }
    for(int i = 1; i <= n; i++){
        if(ch[i]) continue;
        if(cnt >= a[i]) continue;
        ch[i] = 1;
        if(s[d] == '1'){
            dfs(d+1,cnt,h+1);
        }else{
            dfs(d+1,cnt+1,h);
        }
        ch[i] = 0;
    }
    return ;
}
int main(){
    cin >> n >> q;
    cin >> s;
    s = " " + s;
    for(int i = 1; i <= n; i++){
        cin >> a[i];
    }
    if(n <= 10)
    dfs(1,0,0);
    else{
        ans = 1;
        for(int i = 1; i <= n; i++){
            ans = (ans * i) % mod;
        }
    }
    cout << ans << endl;
    return 0;
}
