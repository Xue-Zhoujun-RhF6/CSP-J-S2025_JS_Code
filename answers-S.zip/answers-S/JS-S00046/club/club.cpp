#include<bits/stdc++.h>
using namespace std;
priority_queue<int>qqq;
struct A{
    int num,e;
}first[100005],second[100005],third[100005];
int u,v;
int t;
int n;
int a[100005][4];
int cnt[4];
int h[100005];
long long ans;
int q[100005];
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    for(int i=1;i<=t;i++){
        ans=0;
        cin>>n;
        for(int j=1;j<=n;j++){
            cin>>a[j][1]>>a[j][2]>>a[j][3];
        }
        for(int x=1;x<=n;x++){
            qqq.push(a[x][1]);
        }
        for(int y=1;y<=n/2;y++){
            ans+=qqq.top();
            qqq.pop();
        }
        cout<<ans<<endl;
    }
    return 0;
}
