#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,q;
string s1[200005],s2[200005],pre[200005],bac[200005],pre2[200005],bac2[200005];
map<string,vector<string>>m;
void dddo(string t1,string t2){
    ll len=t1.size()-1,lth=t2.size()-1,ans=0;
    pre[0]=t1[0];
    for(ll i=1;i<t1.size();i++)
        pre[i]=pre[i-1]+t1[i];
    bac[len]=t1[len];
    for(ll i=len-1;i>=0;i--)
        bac[i]=bac[i+1]+t1[i];
    pre2[0]=t2[0];
    for(ll i=1;i<t2.size();i++)
        pre2[i]=pre2[i-1]+t2[i];
    bac2[len]=t2[len];
    for(ll i=len-1;i>=0;i--)
        bac2[i]=bac2[i+1]+t1[i];
    for(ll i=0;i<=len;i++){
        for(ll j=0;j<=len;j++){
            string t="",tt="";
            for(ll k=i;k<=j;k++){
                t+=t1[k];
                tt+=t2[k];
                }
            for(auto l:m[t]){
                if((i==0||pre[i-1]==pre2[i-1])&&(j==len||bac[j+1]==bac2[j+1]))
                    ans+=(l==tt);
            }
        }
    }
    cout<<ans<<"\n";
}
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    for(ll i=1;i<=n;i++){
        cin>>s1[i]>>s2[i];
        m[s1[i]].push_back(s2[i]);
    }
    set<char>s;
    for(ll i=1;i<=q;i++){
        string t1,t2;
        cin>>t1>>t2;
        dddo(t1,t2);
    }
    return 0;
}
