#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m,k,c[15],ans=1e18,fa[10015],cnt,a[15][10005],use;
struct node{
    ll u,v,w;
};
vector<node>e;
bool cmp(node a,node b){
    return a.w<b.w;
}
ll fd(ll x){
    if(fa[x]==x)
        return x;
    return fa[x]=fd(fa[x]);
}
ll solve(){
    ll s=cnt+n,ans2=0,cc=0;
    vector<node>p=e;
    sort(p.begin(),p.end(),cmp);
    for(ll i=1;i<=s;i++)
        fa[i]=i;
    for(auto i:p){
        if(cc==s-1){
            return ans2+use;
        }
        ll vv=i.v,ww=i.w,uu=i.u;
        fd(uu),fd(vv);
        if(fa[uu]!=fa[vv]){
            fa[fa[uu]]=fa[vv];
            ans2+=ww;
            cc++;
        }
    }
}
void ss(ll t){
    if(t==k+1){
        ans=min(ans,solve());
        return;
    }
    cnt++;
    use+=c[t];
    for(ll i=1;i<=n;i++){
        node ne;
        ll tt=n+cnt;
        ne.u=tt;
        ne.v=i,ne.w=a[t][i];
        e.push_back(ne);
    }
    ss(t+1);
    use-=c[t];
    for(ll i=1;i<=n;i++)
        e.pop_back();
    cnt--;
    ss(t+1);
}
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(ll i=1;i<=m;i++){
        ll u,v,w;
        cin>>u>>v>>w;
        e.push_back({u,v,w});
    }
    ll sum=0;
    for(ll i=1;i<=k;i++){
        cin>>c[i];
        sum+=c[i];
        for(ll j=1;j<=n;j++){
            cin>>a[i][j];
            sum+=a[i][j];
        }
    }
    if(sum==0&&k>0){
        cout<<0;
        return 0;
    }
    if(k==0){
        cout<<solve();
        return 0;
    }
    ss(1);
    cout<<ans;
    return 0;
}
/*
4 4 0
1 4 6
2 3 7
4 2 5
4 3 4
*/
