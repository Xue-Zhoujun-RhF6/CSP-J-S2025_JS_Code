#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,use[4],a[100005][4],res=-1e18,dp[105][105][105];
bool vis[100005];
struct node{
    ll s,p;
}aa[100005],bb[100005];
bool cmp1(node a2,node b2){
    if(a2.s!=b2.s)
        return a2.s>b2.s;
    return bb[a2.p].s<bb[b2.p].s;
}
bool cmp2(node a2,node b2){
    if(a2.s!=b2.s)
        return a2.s>b2.s;
    return aa[a2.p].s<aa[b2.p].s;
}
void dfs(ll t,ll sum){
    //cout<<t<<" "<<sum<<"\n";
    if(sum<dp[use[1]][use[2]][use[3]])
        return;
    dp[use[1]][use[2]][use[3]]=sum;
    if(t==n+1){
        res=max(res,sum);
        return;
    }
    if(use[1]!=n/2){
        use[1]++;
        dfs(t+1,sum+a[t][1]);
        use[1]--;
    }
    if(use[2]!=n/2){
        use[2]++;
        dfs(t+1,sum+a[t][2]);
        use[2]--;
    }
    if(use[3]!=n/2){
        use[3]++;
        dfs(t+1,sum+a[t][3]);
        use[3]--;
    }
}
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ll T;
    cin>>T;
    while(T--){
        cin>>n;
        //cout<<"n is "<<n<<"\n";
        res=-1e18;
        memset(dp,0,sizeof(dp));
        dp[0][0][0]=-1;
        use[1]=use[2]=use[3]=0;
        ll sum=0,res1=0,sum2=0;
        for(ll i=1;i<=n;i++){
            vis[i]=0;
            cin>>a[i][1]>>a[i][2]>>a[i][3];
            res1+=a[i][1];
            sum+=(a[i][2]==0&&a[i][3]==0);
            sum2+=(a[i][3]==0);
        }
        if(n<=200){
            dfs(1,0);
            cout<<res<<"\n";
            continue;
        }
        if(sum==n){
            cout<<res1<<"\n";
            continue;
        }
        if(sum2==n){
            sort(aa+1,aa+n+1,cmp1);
            sort(bb+1,bb+n+1,cmp2);
            ll p1=1,p2=1,ans=0;
            for(ll i=1;i<=n;i++){
                while(vis[aa[p1].p])
                    p1++;
                while(vis[bb[p2].p])
                    p2++;
                if(aa[p1].s>bb[p2].s){
                    p1++;
                    ans+=aa[p1].s;
                    vis[aa[p1].p]=1;
                }
                else{
                    p2++;
                    ans+=bb[p2].s;
                    vis[bb[p2].p]=1;
                }
            }
            cout<<ans<<"\n";
        }
    }
    return 0;
}
