#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll ans=0,c[25],n,a[25],m;
char b[25];
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    for(ll i=1;i<=n;i++)
        cin>>b[i];
    for(ll i=1;i<=n;i++)
        cin>>c[i];
    for(ll i=1;i<=n;i++)
        a[i]=i;
    do{
            ll pl=0,l=0;

        for(ll i=1;i<=n;i++){
            if(pl<(c[a[i]])&&b[i]=='1')
                l++;
            else
                pl++;
        }
        ans+=(l>=m);

    }
    while(next_permutation(a+1,a+n+1));
    cout<<ans;
    return 0;
}
