//CSP-S T3 replace
#include <bits/stdc++.h>

#define MAX_M 1000050

using namespace std;

typedef long long ll;
typedef unsigned long long ull;

int n, q;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);

    int i;

    string s1, s2;
    string t1, t2;

    cin>>n>>q;

    for(i=1;i<=n;++i)
        cin>>s1>>s2;

    for(i=1;i<=q;++i)
    {
        cin>>t1>>t2;
        cout<<0<<'\n';
    }

    return 0;
}
