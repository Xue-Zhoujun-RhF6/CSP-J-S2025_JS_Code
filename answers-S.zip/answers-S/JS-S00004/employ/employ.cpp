//CSP-S T4 employ
#include <bits/stdc++.h>

#define MAX_N 550
#define MOD 998244353

using namespace std;

typedef long long ll;
typedef unsigned long long ull;

int n, m;
string s;
int c[MAX_N];

ull ans;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);

    int i, j, k;

    cin>>n>>m;

    cin>>s;

    for(i=1;i<=n;++i)
        cin>>c[i];
    
    for(k=m;k>=1;--k)
    {
        ull t1 = 1, t2 = 1;
        for(i=n;i>=n-k;--i)
            t1 = (t1*i);
        for(i=1;i<=k;++i)
            t1 = (t1/i);
        ans = (ans+(t1%MOD))%MOD;
    }

    cout<<ans<<'\n';

    return 0;
}
