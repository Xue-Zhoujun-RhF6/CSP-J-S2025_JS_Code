//CSP-S T2 road
#include <bits/stdc++.h>

#define MAX_M 1000050

using namespace std;

typedef long long ll;
typedef unsigned long long ull;

int n, m, k;
struct Edge
{
    int u, v;
    ull w;
    bool cr;
    Edge( int u = 0, int v = 0, ull w = 0, bool cr = false )
    {
        this->u = u;
        this->v = v;
        this->w = w;
        this->cr = cr;
    }
};
Edge g[MAX_M];

int cnt;

int c[MAX_M];
int fa[MAX_M];

int Find( int x )
{
    return (fa[x]<0)?x:fa[x]=Find(fa[x]);
}

bool Union( int r1, int r2 )
{
    if(r1 == r2)
        return false;
    fa[r1] += fa[r2];
    fa[r2] = r1;

    return true;
}

bool Cmp( const Edge &a, const Edge &b )
{
    return a.w < b.w;
}

ull ans = 0;

bool ctr[MAX_M];
int m2;

void Kruskal()
{
    memset(fa, -1, sizeof(fa));
    sort(g+1, g+1+m, Cmp);

    int t = 0, i;
    int cnt = 0;
    int n2 = n;
    int u, v;

    for(i=1;i<=m;++i)
    {
        u = g[i].u;
        v = g[i].v;
        int r1 = Find(u);
        int r2 = Find(v);

        if(Union(r1, r2))
        {
            /*
            if(u > m2)
            {
                if(ctr[u] == false)
                    ++n2;
                ctr[u] = true;
            }
            if(v > m2)
            {
                if(ctr[v] == false)
                    ++n2;
                ctr[v] = true;
            }*/
            ++cnt;
            ans += g[i].w;
            if(cnt == n2-1)
                break;
        }
    }

    return ;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);

    int i, j;
    int u, v, w;

    cin>>n>>m>>k;
    m2 = m;
    for(i=1;i<=m;++i)
    {
        cin>>g[i].u>>g[i].v>>g[i].w;
    }

    for(i=1;i<=k;++i)
    {
        cin>>c[i];
        for(j=1;j<=n;++j)
        {
            cin>>w;
            g[++m].u = j;
            g[m].v = i+n;
            g[m].w = w;
        }
    }

    Kruskal();

    cout<<ans<<'\n';

    return 0;
}

/*
4 4 0
1 4 6
2 3 7
4 2 5
4 3 4

15
*/