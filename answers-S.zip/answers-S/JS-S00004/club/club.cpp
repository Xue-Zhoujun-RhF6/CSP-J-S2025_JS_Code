//CSP-S T1 club
#include <bits/stdc++.h>

#define MAX_N 100050

using namespace std;

typedef long long ll;
typedef unsigned long long ull;

int n;
struct Node
{
    int a, b, c;

    Node( int a = 0, int b = 0, int c = 0 )
    {
        this->a = a;
        this->b = b;
        this->c = c;
    }
};
Node t[MAX_N];

bool Cmp( const Node &a, const Node &b )
{
    if(a.a == b.a)
        return a.b > b.b;
    return a.a > b.a;
}
ull ans;

void DFS( int i, ull sum, int cnta, int cntb, int cntc )
{
    if(i == n+1)
    {
        ans = max(ans, sum);
        return ;
    }

    if(cnta < n/2)
        DFS(i+1, sum+t[i].a, cnta+1, cntb, cntc);
    if(cntb < n/2)
        DFS(i+1, sum+t[i].b, cnta, cntb+1, cntc);
    if(cntc < n/2)
        DFS(i+1, sum+t[i].c, cnta, cntb, cntc+1);
    
    return ;
}

int dp[MAX_N][4];

void DP()
{
    int i, j;

    //dp[i][j] = max(dp[i+1][j], dp[i+1][j+1])+a[i][j]; dp[n][i] = a[n][i];
    //dp[i][j] = max(dp[i+1][j])(cntj < n/2) + a[i][j];(1<=j<=3)

}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);

    int T;
    int i, j;
   
    cin>>T;

    while(T--)
    {
        cin>>n;

        bool flag = false;
        for(i=1;i<=n;++i)
        {
            cin>>t[i].a>>t[i].b>>t[i].c;
            if(t[i].c != 0)
                flag = true;
        }
        ans = 0;
        if(flag == true)
            DFS( 1, 0, 0, 0, 0 );
        else
        {
            sort(t+1, t+1+n, Cmp);
            int cnta = 0, cntb = 0, cntc = 0;
            for(i=1;i<=n;++i)
            {
                if(t[i].a > t[i].b)
                {
                    if(cnta < n/2)
                    {
                        ++cnta;
                        ans += t[i].a;
                    }
                    else if(cntb < n/2)
                    {
                        ++cntb;
                        ans += t[i].b;
                    }
                    else
                    {
                        ++cntc;
                        ans += t[i].c;
                    }
                }
                else
                {
                    if(cntb < n/2)
                    {
                        ++cntb;
                        ans += t[i].b;
                    }
                    else if(cnta < n/2)
                    {
                        ++cnta;
                        ans += t[i].a;
                    }
                    else
                    {
                        ++cntc;
                        ans += t[i].c;
                    }
                }
            }
        }
        cout<<ans<<'\n';
    }

    return 0;
}
