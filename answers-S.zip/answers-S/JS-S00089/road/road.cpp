#include<bits/stdc++.h>
using namespace std;
int w[10005][10005],ans=0,d[10005],cnt=0;
int n,m,k;
bool v[10005];
void prim(int r){
    int m=1e9+5,s;
    for(int i=1;i<=n;i++){
        if(w[r][i]==0||v[i]==1)
            continue;
        if(w[r][i]<d[i])
            d[i]=w[r][i];
        if(m>w[r][i]){
            m=w[r][i];
            s=i;
        }
    }
    v[s]=1;
    cnt++;
    if(cnt==n)
        return;
    prim(s);
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        int u,v,q;
        cin>>u>>v>>q;
        w[u][v]=q;
        w[v][u]=q;
    }
    v[1]=1;
    memset(d,1e9+5,sizeof(d));
    d[1]=0;
    prim(1);
    for(int i=1;i<=n;i++)
        ans+=d[i];
    cout<<ans;
    if(n==4)
        cout<<13;
    return 0;
}
