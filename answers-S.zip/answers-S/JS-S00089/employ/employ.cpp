#include<bits/stdc++.h>
using namespace std;
string s;
int n,mo=998244353,m;
int c[505];
bool f(){
    for(int i=0;i<n;i++){
        if(s[i]==0)
            return false;
    }
    return true;
}
bool fl(){
    for(int i=1;i<=n;i++){
        if(c[i]==0)
            return false;
    }
    return true;
}
int main(){
    long long ans=1;
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++)
        cin>>c[i];
    if(m==n){
        if(f()&&fl()){
            for(int i=1;i<=n;i++)
                ans=ans*i%mo;
        }
        else
            ans=0;
    }
    else{
        if(f()||m==1){
            for(int i=1;i<=n;i++)
                ans=ans*i%mo;
        }
    }
    cout<<ans;
    return 0;
}
