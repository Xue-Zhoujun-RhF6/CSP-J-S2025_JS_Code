#include<bits/stdc++.h>
using namespace std;
int a[1000005],b[1000005],c[1000005],l1[1000005],l2[1000005],l3[1000005];
int maxx(int x,int y,int z){
    return max(max(x,y),z);
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin>>t;
    while(t--){
        int n,ans=0,c1=0,c2=0,c3=0;
        cin>>n;
        for(int i=1;i<=n;i++){
            cin>>a[i]>>b[i]>>c[i];
            int m,ma;
            m=maxx(a[i],b[i],c[i]);
            if(m==a[i]){
                ma=max(b[i],c[i]);
                c1++;
                l1[c1]=m-ma;
            }
            if(m==b[i]){
                ma=max(a[i],c[i]);
                c2++;
                l2[c2]=m-ma;
            }
            if(m==c[i]){
                ma=max(a[i],b[i]);
                c3++;
                l3[c3]=m-ma;
            }
            ans+=m;
        }
        int c4=maxx(c1,c2,c3);
        if(c4<=n/2)
            cout<<ans<<'\n';
        else{
            if(c4==c1){
                sort(l1+1,l1+c1+1);
                for(int i=1;i<=(c4-n/2);i++)
                    ans-=l1[i];
            }
            else{
                if(c4==c2){
                sort(l2+1,l2+c2+1);
                for(int i=1;i<=(c4-n/2);i++)
                    ans-=l2[i];
                }
                else{
                    if(c4==c3){
                    sort(l3+1,l3+c3+1);
                    for(int i=1;i<=(c4-n/2);i++)
                        ans-=l3[i];
                    }
                }
            }
            cout<<ans<<'\n';
        }
    }
    return 0;
}
