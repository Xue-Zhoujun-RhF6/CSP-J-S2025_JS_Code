#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e5 + 5;
string repla[N][2], s1, s2, str, strto;
ll num[N], len, lenstr, cnt;
bool judgefind(ll i)
{
    for (ll pos = 0; pos < lenstr; pos++)
        if (i + pos >= len || s1[i + pos] != str[pos])
            return false;
    return true;
}
void myfind(ll x)
{
    cnt = 0;
    len = s1.size();
    str = repla[x][0];
    lenstr = str.size();
    strto = repla[x][1];
    for (ll i = 0; i < len; i++)
    {
        if (judgefind(i))
            num[++cnt] = i;
    }
    return;
}
bool judge(ll x)
{
    string str1 = s1.substr(0, x);
    string str2 = s1.substr(x + lenstr, len - x - lenstr);
    return str1 + strto + str2 == s2;
}
int main()
{
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    ll n, q;
    cin >> n >> q;
    for (ll i = 1; i <= n; i++)
        cin >> repla[i][0] >> repla[i][1];
    while (q--)
    {
        cin >> s1 >> s2;
        ll ans = 0;
        for (ll i = 1; i <= n; i++)
        {
            myfind(i);
            for (ll j = 1; j <= cnt; j++)
                if (judge(num[j]))
                    ans++;
        }
        cout << ans << endl;
    }
    return 0;
}
