#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MOD = 998244353, N = 505;
ll a[N], n, m, c[N];
ll tim(ll n)
{
    ll ans = 1;
    for (ll i = 1; i <= n; i++)
        ans = ans * i % MOD;
    return ans;
}
string s;
bool judge()
{
    ll ou = 0, cnt = 0;
    for (ll i = 1; i <= n; i++)
    {
        if (s[i - 1] == '0' || ou >= c[a[i]])
            ou++;
        else
            cnt++;
    }
    return cnt >= m;
}
int main()
{
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    ll cnt = 0;
    cin >> n >> m >> s;
    ll len = s.size();
    for (ll i = 0; i < len; i++)
        cnt += (s[i] == '1');
    for (ll i = 1; i <= n; i++)
        cin >> c[i];
    ll ans = 0;
    if (n <= 18)
    {
        for (ll i = 1; i <= n; i++)
            a[i] = i;
        do
        {
            if (judge())
                ans++;
        } while (next_permutation(a + 1, a + n + 1));
    }
    else
        ans = 0;
    cout << ans;
    return 0;
}
