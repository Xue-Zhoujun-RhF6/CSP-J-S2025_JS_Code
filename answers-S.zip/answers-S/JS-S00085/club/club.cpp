#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;
ll n, peo[4];
struct Node
{
    ll joy[4];
} a[N];
bool cmp(Node n1, Node n2)
{
    return n1.joy[1] > n2.joy[1];
}
void solve()
{
    for (ll i = 1; i <= n; i++)
    {
        cin >> a[i].joy[1] >> a[i].joy[2] >> a[i].joy[3];
    }
    sort(a + 1, a + n + 1, cmp);
    int sum = 0;
    for (int i = 1; i <= n / 2; i++)
        sum += a[i].joy[1];
    cout << sum << endl;
    return;
}
int main()
{
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    ll t;
    cin >> t;
    while (t--)
    {
        cin >> n;
        solve();
    }
    return 0;
}
