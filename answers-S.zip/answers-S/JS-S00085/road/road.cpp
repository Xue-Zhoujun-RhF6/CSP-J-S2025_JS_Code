#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e4 + 5, K = 15;
vector<pair<ll, ll>> ve[N];
struct Node
{
    ll price_myself, price[N];
} a[K];
ll villa[K];
ll minn = LLONG_MAX, n, m, k;
bool vis[N];
void dfs(ll pri, ll k, ll cnt)
{
    if (pri > minn)
        return;
    if (cnt == n - 1)
    {
        minn = min(minn, pri);
        return;
    }
    for (auto i : ve[k])
    {
        ll du = i.first;
        if (!vis[du])
        {
            vis[du] = true;
            dfs(pri + i.second, du, cnt + 1);
            vis[du] = false;
        }
    }
}
int main()
{
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    cin >> n >> m >> k;
    ll st;
    for (ll i = 1; i <= m; i++)
    {
        ll u, v, w;
        cin >> u >> v >> w;
        ve[u].push_back({v, w});
        ve[v].push_back({u, w});
        st = u;
    }
    for (ll i = 1; i <= k; i++)
    {
        cin >> a[i].price_myself;
        for (ll i = 1; i <= n; i++)
            cin >> a[i].price[i];
    }
    vis[st] = true;
    dfs(0ll, st, 1);
    cout << minn;
    return 0;
}
