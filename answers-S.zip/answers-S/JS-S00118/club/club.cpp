#include<bits/stdc++.h>
using namespace std;
const int maxn=100010;
struct N{
    int s,id;
};
bool cmp(N a,N b){
    return a.s>b.s;
}

int T,n;
N a[maxn],b[maxn],c[maxn];
long long ans=0;
int ca,cb,cc;
void dfs(int now,long long sum){
    if(ca>n/2||cb>n/2||cc>n/2)return;
    if(now==n+1){ans=max(ans,sum);return;}
    ca++;dfs(now+1,sum+a[now].s);ca--;
     cb++;dfs(now+1,sum+b[now].s);cb--;
      cc++;dfs(now+1,sum+c[now].s);cc--;

}
int main(){
freopen("club.in","r",stdin);
freopen("club.out","w",stdout);
ios::sync_with_stdio(0);
cin.tie(0);

cin >> T;
while (T--){
        bool A=1,B=1;
    cin >> n;
    for(int i=1;i<=n;i++){
        cin>>a[i].s>>b[i].s>>c[i].s;
        a[i].id=i,b[i].id=i,c[i].id=i;
        if(b[i].s!=0||c[i].s!=0)A=0;
        if(c[i].s!=0)B=0;
    }
    ans=0;
    if(A){
            sort(a+1,a+1+n,cmp);
     sort(b+1,b+1+n,cmp);

     sort(c+1,c+1+n,cmp);

        for(int i=1;i<=n/2;i++){
            ans+=a[i].s;
        }
    }
    if(n<=30){
            ca=0,cb=0,cc=0;
        dfs(1,0);
    }
    cout<<ans<<'\n';
}

return 0;
}
