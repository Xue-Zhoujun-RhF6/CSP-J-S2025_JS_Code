#include<bits/stdc++.h>
using namespace std;

struct edge{
    long long dis;
    int from,to;

};

bool cmp(edge a,edge b){
 return a.dis<b.dis;
}

int n,m,k;
long long c[11][1005];
long long ed[1005][1005];
edge dist[1000010];
int fa[1005];
int find(int a){
    if(a==fa[a])return a;
    fa[a]=find(fa[a]);
}
bool vis[11];
int main(){
freopen("road.in","r",stdin);
freopen("road.out","w",stdout);
ios::sync_with_stdio(0);
cin.tie(0);
cin>>n>>m>>k;
 for(int x=1;x<=n+k;x++){
    for(int y=1;y<=n+k;y++){
        ed[x][y]=3e9+1;
    }
}
for(int i=1;i<=m;i++){
    int u,v;
    long long w;
    cin>>u>>v>>w;
    ed[v][u]=w;
    ed[u][v]=w;
}
int cnt=0;
for(int i=1;i<=k;i++){
    for(int j=0;j<=n;j++){
        cin>>c[i][j];
    }
    for(int x=1;x<=n;x++){
        ed[x][i+n]=c[i][x];
        ed[i+n][x]=c[i][x];
    }
}
for(int x=1;x<=n+k;x++){
    for(int y=1;y<=n+k;y++){
        if(ed[x][y]==3e9+1)continue;
        cnt++;
        dist[cnt]=edge{ed[x][y],x,y};
    }
}
sort(dist+1,dist+1+cnt,cmp);
for(int i=1;i<=n;i++){
    fa[i]=i;
}
long long ans=0;
for(int i=1;i<=cnt;i++){
    int u,v;
    long long w;
    u=dist[i].from;
    v=dist[i].to;
    w=dist[i].dis;
    int fu=find(u),fv=find(v);
    if(fu==fv)continue;
    if(u>n)vis[u]=1;
    if(v>n)vis[v]=1;
    ans+=w;
    fa[fu]=fv;
}
for(int i=1;i<=k;i++){
    if(vis[i])ans+=c[i][0];
}
cout<<ans<<'\n';
return 0;
}









