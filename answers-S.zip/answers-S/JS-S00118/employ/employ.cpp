#include<bits/stdc++.h>
using namespace std;

int n,m;
char s[10000010];
long long dp[10000010];
int main(){
freopen("employ.in","r",stdin);
freopen("employ.out","w",stdout);
ios::sync_with_stdio(0);
cin.tie(0);
cin >> n>>m;
bool A=1;
for(int i=1;i<=n;i++){
        cin>>s[i];
        if(s[i]=='0')A=0;
}
dp[0]=1;
for(int i=1;i<=n;i++){
    dp[i]=dp[i-1]*i%998244353;
}
if(A){
    cout<<dp[n];
}
return 0;
}
