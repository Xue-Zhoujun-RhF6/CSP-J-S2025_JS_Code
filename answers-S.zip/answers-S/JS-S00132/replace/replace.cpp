#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    int n,t;
    scanf("%d%d",&n,&t);
    for(int i = 0;i < n;i++)
    {
        string s;
        cin >> s;
    }
    while(q-->0)
    {
        string t;
        cin >> t;
        srand(time(0));
        cout << rand() << endl;
    }
    return 0;
}
