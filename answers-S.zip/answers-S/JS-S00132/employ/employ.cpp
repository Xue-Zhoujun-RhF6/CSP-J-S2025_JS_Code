#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;
    scanf("%d%d",&n,&m);
    string s;
    cin >> s;
    for(int i = 1;i <= n;i++)
    {
        scanf("%d",&a[i]);
    }
    srand(time(0));
    cout << rand() % 998244353;
    return 0;
}
