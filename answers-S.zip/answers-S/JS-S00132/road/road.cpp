#include<bits/stdc++.h>
using namespace std;
const int N = 1e4 + 10;
int n,m,k;
vector<pair<int,int>>g[N];
int ret = 0;
int vis[N];
void dfs(int dep)
{
    if(dep == n - 1)
    {
        return;
    }
    else
    {
        for(auto i : g[dep])
        {
            if(!vis[i.first])
            {
                ret += i.second;
                dfs(dep + 1);
                ret -= i.second;
            }
        }
    }
}
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i = 0;i < m;i++)
    {
        int u,v,w;
        scanf("%d%d%d",&u,&v,&w);
        g[u].push_back({v,w});
        g[v].push_back({u,w});
    }
    if(k == 0)
    {
        vis[1] = 1;
        dfs(1);
        printf("%d",ret);
    }
    return 0;
}
