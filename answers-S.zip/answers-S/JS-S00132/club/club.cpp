#include<bits/stdc++.h>
using namespace std;
const int N = 1e5 + 10;
int a[N][3];
int mx1[N];
int mx2[N];
struct people
{
    int mx1,mx2;
    int id1,id2;
};
people q[N];
bool cmp(people lhs,people rhs)
{
    if(lhs.mx1 < rhs.mx1)
    {
        return false;
    }
    else if(lhs.mx1 > rhs.mx1)
    {
        return true;
    }
    else
    {
        if(lhs.mx2 < rhs.mx2)
        {
            return false;
        }
        else return true;
    }
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    scanf("%d",&t);
    while(t-->0)
    {
        int n;
        scanf("%d",&n);
        for(int i = 1;i <= n;i++)
        {
            for(int j = 0;j < 3;j++)
            {
                scanf("%d",&a[i][j]);
            }
        }
        for(int i = 1;i <= n;i++)
        {
            int mx = -1;
            int idx;
            for(int j = 0;j < 3;j++)
            {
                if(mx < a[i][j])
                {
                    idx = j;
                    mx = a[i][j];
                }
            }
            q[i].mx1 = mx;
            q[i].id1 = idx;
            int mxx = -1,idxx;
            for(int j = 0;j < 3;j++)
            {
                if(mxx < a[i][j] && a[i][j] != mx)
                {
                    idxx = j;
                    mxx = a[i][j];
                }
            }
            q[i].mx2 = mxx;
            q[i].id2 = idxx;
        }
        sort(q + 1,q + n + 1,cmp);
        if(n == 2)
        {
            if(q[1].id1 == q[2].id1)
            {
                printf("%d",max(q[1].mx1 + q[2].mx2,q[2].mx1 + q[1].mx2));
            }
            else
            {
                printf("%d",q[1].mx1 + q[2].mx1);
            }
        }
        int ret = 0;
        int ca = 0,cb = 0,cc = 0;
        for(int i = 1;i <= n;i++)
        {
            ret += q[i].mx1;
            if(q[i].id1 == 0)
            {
                ca++;
                if(ca > n / 2)
                {
                    ret -= q[i].mx1;
                    ret += q[i].mx2;
                    if(q[i].id2 == 1)cb++;
                    else if(q[i].id2 == 2)cc++;
                }
            }
            else if(q[i].id1 == 1)
            {
                cb++;
                if(cb > n / 2)
                {
                    ret -= q[i].mx1;
                    ret += q[i].mx2;
                    if(q[i].id2 == 0)ca++;
                    else if(q[i].id2 == 2)cc++;
                }
            }
            else if(q[i].id1 == 2)
            {
                cc++;
                if(cc > n / 2)
                {
                    ret -= q[i].mx1;
                    ret += q[i].mx2;
                    if(q[i].id2 == 0)ca++;
                    else if(q[i].id2 == 1)cb++;
                }
            }
        }
        printf("%d\n",ret);
        //for(int i = 1;i <= n;i++)
        //{
          //  printf("%d %d %d %d\n",q[i].mx1,q[i].id1,q[i].mx2,q[i].id2);
        //}
    }
    return 0;
}
