#include<bits/stdc++.h>
using namespace std;
const int M = 1e6+10,N=1e3+10;
int n,m,k,tot;
long long ans;
int c[15],a[15][N],fa[N];
long long d[N];
int e[N][N];
int ver[N*N*2],nxt[N*N*2],head[N],edge[N*N*2];
int u[M],v[M],w[M];
bool vis[N];
struct Node{
    int u,v,w;
}node[M];
bool flaga=true;
int get(int x){
    if(x==fa[x]) return x;
    return fa[x] = get(fa[x]);
}
bool cmp(Node x,Node y){
    return x.w < y.w;
}
void add(int u,int v,int w){
    ver[++tot] = v;
    edge[tot] = w;
    nxt[tot] = head[u];
    head[u] = tot;
} 
void prim(){
    memset(d,0x3f,sizeof(d));
    d[1]=0;
    for(int i = 1;i<=n;i++){
        int x = i;
        for(int j = 1;j<=n;j++){
            if(!vis[j] && d[j] < d[x]) x = j;
        }
        vis[x] = 1;
        for(int j = head[x];j;j=nxt[j]){
            int y = ver[j],z = edge[j];
            if(d[y] > z&&!vis[y]){
                d[y] = z;
            }
        }
    }
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin >> n >> m >> k;
    memset(e,0x3f,sizeof(e));
    for(int i = 1;i<=m;i++){
        cin >> u[i] >> v[i] >> w[i];
        e[u[i]][v[i]] = w[i];
        e[v[i]][u[i]] = w[i];
    }
    for(int i = 1;i<=k;i++){
        cin >> c[i];
        if(c[i]!=0) flaga = false;
        for(int j = 1;j<=n;j++){
            cin >> a[i][j];
            if(a[i][j]!=0) flaga = false;
        }
    }
    if(flaga&&k!=0){
        ans = 0;
    }else if(k==0){
        for(int i = 1;i<=m;i++){
            node[i].u = u[i];
            node[i].v = v[i];
            node[i].w = w[i];
        }
        for(int i = 1;i<=n;i++){
            fa[i]=i;
        }
        sort(node+1,node+m+1,cmp);
        for(int i = 1;i<=m;i++){
            int x = get(node[i].u);
            int y = get(node[i].v);
            if(x==y) continue;
            ans+=node[i].w;
            fa[x] = y;
        }
    }else{
        for(int i = 1;i<=n;i++){
            for(int j = 1;j<i;j++){
                for(int l = 1;l<=k;l++){
                    e[i][j] = min((long long)e[i][j],(long long)c[l]+a[l][i]+a[l][j]);
                    e[j][i] = min((long long)e[i][j],(long long)c[l]+a[l][i]+a[l][j]);
                }
            }
        }
        for(int i = 1;i<=n;i++){
            for(int j = 1;j<i;j++){
                add(i,j,e[i][j]);
                add(j,i,e[j][i]);
            }
        }
        prim();
        for(int i = 1;i<=n;i++){
            ans += d[i];
        }
    }
    cout << ans;
    fclose(stdin);
    fclose(stdout);
    return 0;
}