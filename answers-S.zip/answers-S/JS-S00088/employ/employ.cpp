#include<bits/stdc++.h>
using namespace std;
const int mod = 998244353;
long long ans;
int n,m,cnt;
int c[510],s[510];
char ch[510];
vector<int> v;
bool flaga = true;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin >> n >> m;
    for(int i = 1;i<=n;i++){
        cin >> ch[i];
        if(ch[i]=='0'){
            flaga = false;
            s[i] = s[i-1] + 1;
        }else{
            s[i] = s[i-1];
        }
    }
    cnt = n;
    for(int i = 1;i<=n;i++){
        cin >> c[i];
        if(c[i] == 0){
            cnt--;
        }
    }
    if(flaga){
        ans = 1;
        for(long long i = 2;i<=n;i++){
            ans = (ans * i) % mod;
        }
        cout << ans;
    }
    if(!flaga&&m==n){
        cout << 0;
    }
    if(m==1){
        sort(c+1,c+n+1);
        for(int i = n;i>=1;i--){
            if(c[i]==0){
                break;
            }
            v.push_back(c[i]);
        }
        for(int i = 1;i<=n;i++){
            if(c[i]=='1'){
                for(int j = v.size()-1;j>=0;j--){
                    if(s[i]>=v[j]){
                        v.pop_back();
                    }
                }

            }
        }
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}