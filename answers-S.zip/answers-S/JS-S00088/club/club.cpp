#include<bits/stdc++.h>
using namespace std;
const int N = 1E5+10;
int t,n;
int cnt[N][4][4],a[N][4],b[N];
long long f[N][4];
long long ans;
struct Node{
    int x,y;
}c[N];
bool flaga=true,flagb=true;
bool cmp(Node x,Node y){
    return abs(x.x-x.y)>abs(y.x-y.y);
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin >> t;
    while(t--){
        memset(f,0,sizeof(f));
        memset(cnt,0,sizeof(cnt));
        cin >> n;
        for(int i = 1;i<=n;i++){
            cin >> a[i][1] >> a[i][2] >> a[i][3];
            if(a[i][2]!=0){
                flaga = false;
            }
            if(a[i][3]!=0){
                flagb = false;
                flaga = false;
            }
        }
        if(flaga){
            ans=0;
            for(int i = 1;i<=n;i++){
                b[i] = a[i][1];
            }
            sort(b+1,b+n+1);
            for(int i = n;i>n/2;i--){
                ans+=b[i];
            }
            cout << ans << "\n";
        }else if(flagb){
            ans=0;
            for(int i = 1;i<=n;i++){
                c[i].x = a[i][1];
                c[i].y = a[i][2];
            }
            sort(c+1,c+n+1,cmp);
            int cnta=0,cntb=0;
            for(int i = 1;i<=n;i++){
                if(cnta>=n/2){
                    ans+=c[i].y;
                }else if(cntb>=n/2){
                    ans+=c[i].x;
                }else if(c[i].x>c[i].y){
                    ans+=c[i].x;
                    cnta++;
                }else{
                    ans+=c[i].y;
                    cntb++;
                }
            }
            cout << ans << "\n";
        }else{
            for(int i = 1;i<=n;i++){
                if(cnt[i-1][1][1]<n/2){
                    f[i][1] = max(f[i][1],f[i-1][1]+a[i][1]);
                }
                if(cnt[i-1][1][2]<n/2){
                    f[i][1] = max(f[i][1],f[i-1][2]+a[i][1]);
                }
                if(cnt[i-1][1][3]<n/2){
                    f[i][1] = max(f[i][1],f[i-1][3]+a[i][1]);
                }
                if(i==1){
                    cnt[1][1][1] = 1;
                }else{
                    if(f[i][1] == f[i-1][1]+a[i][1]){
                        cnt[i][1][1] = cnt[i-1][1][1]+1;
                        cnt[i][1][2] = cnt[i-1][1][2];
                        cnt[i][1][3] = cnt[i-1][1][3];
                    }
                    if(f[i][1] == f[i-1][2]+a[i][1]){
                        cnt[i][1][1] = cnt[i-1][2][1]+1;
                        cnt[i][1][2] = cnt[i-1][2][2];
                        cnt[i][1][3] = cnt[i-1][2][3];
                    }
                    if(f[i][1] == f[i-1][3]+a[i][1]){
                        cnt[i][1][1] = cnt[i-1][3][1]+1;
                        cnt[i][1][2] = cnt[i-1][3][2];
                        cnt[i][1][3] = cnt[i-1][3][3];
                    }
                }
                if(cnt[i-1][2][1]<n/2){
                    f[i][2] = max(f[i][2],f[i-1][1]+a[i][2]);
                }
                if(cnt[i-1][2][2]<n/2){
                    f[i][2] = max(f[i][2],f[i-1][2]+a[i][2]);
                }
                if(cnt[i-1][2][3]<n/2){
                    f[i][2] = max(f[i][2],f[i-1][3]+a[i][2]);
                }
                if(i==1){
                    cnt[1][2][2] = 1;
                }else{
                    if(f[i][2] == f[i-1][1]+a[i][2]||i==1){
                        cnt[i][2][2] = cnt[i-1][1][2]+1;
                        cnt[i][2][1] = cnt[i-1][1][1];
                        cnt[i][2][3] = cnt[i-1][1][3];
                    }
                    if(f[i][2] == f[i-1][2]+a[i][2]){
                        cnt[i][2][2] = cnt[i-1][2][2]+1;
                        cnt[i][2][1] = cnt[i-1][2][1];
                        cnt[i][2][3] = cnt[i-1][2][3];
                    }
                    if(f[i][2] == f[i-1][3]+a[i][2]){
                        cnt[i][2][2] = cnt[i-1][3][2]+1;
                        cnt[i][2][1] = cnt[i-1][3][1];
                        cnt[i][2][3] = cnt[i-1][3][3];
                    }
                }
                if(cnt[i-1][3][1]<n/2){
                    f[i][3] = max(f[i][3],f[i-1][1]+a[i][3]);
                }
                if(cnt[i-1][3][2]<n/2){
                    f[i][3] = max(f[i][3],f[i-1][2]+a[i][3]);
                }
                if(cnt[i-1][3][3]<n/2){
                    f[i][3] = max(f[i][3],f[i-1][3]+a[i][3]);
                }
                if(i==1){
                    cnt[1][3][3] = 1;
                }else{
                    if(f[i][3] == f[i-1][1]+a[i][3]){
                        cnt[i][3][3] = cnt[i-1][1][3]+1;
                        cnt[i][3][1] = cnt[i-1][1][1];
                        cnt[i][3][2] = cnt[i-1][1][2];
                    }
                    if(f[i][3] == f[i-1][2]+a[i][3]){
                        cnt[i][3][3] = cnt[i-1][2][3]+1;
                        cnt[i][3][1] = cnt[i-1][2][1];
                        cnt[i][3][2] = cnt[i-1][2][2];
                    }
                    if(f[i][3] == f[i-1][3]+a[i][3]){
                        cnt[i][3][3] = cnt[i-1][3][3]+1;
                        cnt[i][3][1] = cnt[i-1][3][1];
                        cnt[i][3][2] = cnt[i-1][3][2];
                    }
                }
            }
            cout << max(max(f[n][1],f[n][2]),f[n][3]) << "\n";
        }
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}