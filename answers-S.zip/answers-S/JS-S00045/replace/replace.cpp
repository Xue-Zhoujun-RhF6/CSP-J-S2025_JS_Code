#include<bits/stdc++.h>
using namespace std;
int main(){
    string s1[200000],s2[200000],t1[200000],t2[200000];
    int n,q;
    cin>>n>>q;
    for(int i=1;i<=n;i++)
        cin>>s1[i]>>s2[i];
    for(int j=1;j<=q;j++)
        cin>>t1[i]>>t2[i];
return 0;
}
