#include<bits/stdc++.h>
using namespace std;
int main(){
int n,m,k,money[20],xcmoney[10000];roadmoney[10000];
cin>>n>>m>>k;
for(int i=1;i<=m;i++)
    cin>>x>>y>>money[i];
sort(money,money+m);
for(int i=1;i<=m;i++)
    money=monry[1]+money[2];
for(int j=1;j<=k;j++)
    cin>>xcmoney[j]>>roadmoney[m];
sort(xcmoney,xcmoney+k);
sort(roadmoney,roadmoney+m);
for(int i=1;i<=k;i++)
    xcmoney=xcmoney[1];
    roadmoney=roadmoney[1]+roadmoney[2];
    int sum=money+xcmoney+roadmoney;
    cout<<sum<<endl;
return 0;
}
