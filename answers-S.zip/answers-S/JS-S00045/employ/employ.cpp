#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,m,c[500];
    string s;
    cin>>n>>m;
    cin>>s;
    for(int i=1;i++;i<=n)
        cin>>c[i];
return 0;
}
