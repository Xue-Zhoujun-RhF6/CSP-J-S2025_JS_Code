#include<bits/stdc++.h>
using namespace std;
void qwer(int l,r,mid){
        mid=(l+r)/2;
        if(mid=x)
            return mid;
        else if(mid>x)
            l=mid;
            mid=(l+r)/2;
            return mid;
        else if(mid<x)
            r=mid;
             mid=(l+r)/2;
            return mid;
}
int t,n,a[200],max,sum;
int main(){
    cin>>t;
    for(int i=1;i<=t;i++){
    cin>>n;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=3;j++)
        cin>>a[j];
    max=max(max(a[1],a[2]),a[3]);
    sum+=max;
    if(max==a[1])
       int club1++;
    else if(max==a[2])
       int club2++;
    else if(max==a[3])
        int club3++;
     }
  for(int i=1;i<=3;i++){
    if(club[i]>n/2);
    cout<<qwer(mid);
      else  cout<<sum;
     }
    }
    return 0;
}
