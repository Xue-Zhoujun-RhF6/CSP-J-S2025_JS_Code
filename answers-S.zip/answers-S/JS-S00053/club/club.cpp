#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int t;
int n;
int a[N],b[N],c[N];
int ga[N],gb[N],gc[N];
int cnta,cntb,cntc;
int ans;

int main()
{
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	cin>>t;
	while(t--)
	{
		cnta=cntb=cntc=ans=0;
		cin>>n;
		//cerr<<n<<endl;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i]>>b[i]>>c[i];
			if(a[i]>=b[i]&&a[i]>=c[i])
				ans+=a[i],ga[++cnta]=a[i]-max(b[i],c[i]);
			else if(b[i]>=a[i]&&b[i]>=c[i])
				ans+=b[i],gb[++cntb]=b[i]-max(a[i],c[i]);
			else if(c[i]>=b[i]&&c[i]>=a[i])
				ans+=c[i],gc[++cntc]=c[i]-max(a[i],b[i]);
			//cerr<<t<<":"<<ans<<" "<<cnta<<" "<<cntb<<" "<<cntc<<endl;
		}
		if(cnta>n/2)
		{
			sort(ga+1,ga+1+cnta);
			for(int i=1;i<=cnta-n/2;i++)
				ans-=ga[i];
		}
		if(cntb>n/2)
		{
			sort(gb+1,gb+1+cntb);
			for(int i=1;i<=cntb-n/2;i++)
				ans-=gb[i];
		}
		if(cntc>n/2)
		{
			sort(gc+1,gc+1+cntc);
			for(int i=1;i<=cntc-n/2;i++)
				ans-=gc[i];
		}
		cerr<<"ans:"<<ans<<endl;
		cout<<ans<<endl;
	}
	return 0;
}
