#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e4+15;
const int M=1e6+5;
const int K=15;
int n,m,k;
struct node{
	int u,v,w;
}edge[M];
int fa[N];
int c[K],a[K][N];
int ans=0x3f3f3f3f,anst;

bool cmp(node a,node b)
{
	return a.w<b.w;
}

int Find(int x)
{
	if(fa[x]==x)return x;
	return fa[x]=Find(fa[x]);
}
int kruscal()
{
	sort(edge+1,edge+1+m,cmp);
	for(int i=1;i<=n;i++)fa[i]=i;
	for(int i=1;i<=m;i++)
	{
		int u=Find(edge[i].u),v=Find(edge[i].v);
		if(u==v)continue;
		fa[u]=v,anst+=edge[i].w;
	}
	return anst;
}

/*void kruscal()
{
	sort(edget+1,edget+1+cnt,cmp);
	for(int i=1;i<=n+k;i++)fa[i]=i;
	for(int i=1;i<=cnt;i++)
	{
		int u=Find(edget[i].u),v=Find(edget[i].v);
		if(u==v)continue;
		fa[u]=v,anst+=edget[i].w;
	}
}

void solve(int x)
{
	cnt=m;
	for(int i=1;i<=m;i++)
		edget[i].u=edge[i].u,
		edget[i].v=edge[i].v,
		edget[i].w=edge[i].w;
	for(int i=1,ord=1;i<=x;i*=2,ord++)
	{
		if(!(i&x))continue;
		anst+=c[ord];
		for(int j=1;j<=n;j++)
			edget[++cnt].u=ord+n,
			edget[cnt].v=j,
			edget[cnt].w=a[ord][j];
	}
	kruscal();
}*/

signed main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
		cin>>edge[i].u>>edge[i].v>>edge[i].w;
	for(int i=1;i<=k;i++)
	{
		cin>>c[i];
		for(int j=1;j<=n;j++)
			cin>>a[i][j];
	}
	//cerr<<n<<" "<<m<<" "<<k<<endl;
	//cerr<<(1<<k)-1<<endl;
	/*for(int i=0;i<=(1<<k)-1;i++)
	{
		int j=i,cnt=0;
		while(j)j-=j&(-j),cnt++;
		anst=0;
		solve(i);
		//cerr<<i<<" "<<anst<<endl;
		ans=min(ans,anst);
	}*/
	if(k)cout<<0<<endl;
	else cout<<kruscal()<<endl;
	return 0;
}
