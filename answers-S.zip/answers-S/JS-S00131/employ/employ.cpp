#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=998244353;
vector<int> c;
int ans;
void solve(){
    return ;
}
int d(int n){
    if(n==1)return 1;
    if(n==2)return 2;
    return ((d(n-1)%N)*(n%N))%N;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;
    cin>>n>>m;
    string s;
    cin>>s;
    for(int i=1;i<=n;i++){
        int C;
        cin>>C;
        c.push_back(C);
    }
    string s1=s;
    sort(s.begin(),s.end());
    if(s[0]=='1'){
        ans=d(n)%N;
        cout<<ans;
        return 0;
    }
    solve();
    cout<<ans;
    return 0;
}