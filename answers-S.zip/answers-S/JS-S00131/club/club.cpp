#include<bits/stdc++.h>
#define int long long
#define di dp[i-1]
using namespace std;
struct node{
    signed f=0,s=0,t=0;
};
signed dp[50006][4][5];
void rs(int i,int j,int a){
    dp[i][j][1]=dp[i-1][a][1];
    dp[i][j][2]=dp[i-1][a][2];
    dp[i][j][3]=dp[i-1][a][3];
    return ;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin>>t;
    while(t--){
        int n;
    cin>>n;
    vector<node>A;
    bool t0=true,o0=true;
    for(int i=1;i<=n;i++){
        int a,b,c;
        cin>>a>>b>>c;
        bool flag=false;
        if(a==0&&b==0)flag=true;
        if(a==0&&c==0)flag=true;
        if(c==0&&b==0)flag=true;
        t0=(t0&&flag);
        if(a!=0&&b!=0&&c!=0)o0=false;
        node B;
        B.f=a;
        B.s=b;
        B.t=c;
        A.push_back(B);
    }
    dp[1][1][4]=A[0].f;
    dp[1][2][4]=A[0].s;
    dp[1][3][4]=A[0].t;
    dp[1][1][1]=1;
    dp[1][2][2]=1;
    dp[1][3][3]=1;
    signed ans1=0;
    if(!t0){
          for(int i=2;i<=n;i++){
        for(int j=1;j<=3;j++){
            int now=0;
            if(j==1)now=A[i-1].f;
            if(j==2)now=A[i-1].s;
            if(j==3)now=A[i-1].t;
            int mx=max({di[1][4],di[2][4],di[3][4]});
            if(mx==di[1][4]){
                if(di[1][j]!=n/2){
                    dp[i][j][4]=now+di[1][4];
                    rs(i,j,1);
                    dp[i][j][j]++;
                }else{
                    if(di[2][4]>di[3][4]&&di[2][j]!=n/2){
                        dp[i][j][4]=now+di[2][4];
                        rs(i,j,2);
                    dp[i][j][j]++;
                    }else if(di[3][j]!=n/2&&di[3][4]!=-1){
                        dp[i][j][4]=now+di[3][4];
                        rs(i,j,3);
                    dp[i][j][j]++;
                    }else{
                        dp[i][j][4]=-1;
                    }
                }
            }
            if(mx==di[2][4]){
                if(di[2][j]!=n/2){
                    dp[i][j][4]=now+di[2][4];
                    rs(i,j,2);
                    dp[i][j][j]++;
                }else{
                    if(di[1][4]>di[3][4]&&di[1][j]!=n/2){
                        dp[i][j][4]=now+di[1][4];
                        rs(i,j,1);
                    dp[i][j][j]++;
                    }else if(di[3][j]!=n/2&&di[3][4]!=-1){
                        dp[i][j][4]=now+di[3][4];
                        rs(i,j,3);
                    dp[i][j][j]++;
                    }else{
                        dp[i][j][4]=-1;
                    }
                }
            }
            if(mx==di[3][4]){
                if(di[3][j]!=n/2){
                    
                    dp[i][j][4]=now+di[3][4];
                    rs(i,j,3);
                    dp[i][j][j]++;
                }else{
                    if(di[2][4]>di[1][4]&&di[2][j]!=n/2){
                        dp[i][j][4]=now+di[2][4];
                        rs(i,j,2);
                    dp[i][j][j]++;
                    }else if(di[1][j]!=n/2&&di[1][4]!=-1){
                        dp[i][j][4]=now+di[1][4];
                        rs(i,j,1);
                    dp[i][j][j]++;
                    }else{
                        dp[i][j][4]=-1;
                    }
                }
            }


        }
    }
       cout<<max({dp[n][1][4],dp[n][2][4],dp[n][3][4]})<<endl;
    }else if(!o0){
        vector<signed> l;
        for(int i=1;i<=n;i++){
            signed ds=max({A[i-1].f,A[i-1].s,A[i-1].t});
            l.push_back(ds);
        }
        sort(l.begin(),l.end());
        for(int i=1;i<=n/2;i++){
            ans1+=l[l.size()-i];
        }
        cout<<ans1<<endl;
    }else{
        vector<signed> l,r;
        for(int i=1;i<=n;i++){
            signed ds=A[i-1].f;
            l.push_back(ds);
            ds=A[i-1].s;
            r.push_back(ds);
        }
        sort(l.begin(),l.end());
        sort(r.begin(),r.end());
        for(int i=1;i<=n/2;i++){
            ans1+=l[l.size()-i];
            ans1+=r[r.size()-i];
        }
        cout<<ans1<<endl;
    }
    }
    return 0;
}