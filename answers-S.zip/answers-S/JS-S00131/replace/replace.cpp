#include<bits/stdc++.h>
#define int long long
#define us unsigned
using namespace std;
struct node{
    string s1,s2;
};
vector<node> S;
int ans;int n,q;
bool check(int a,int b,int c,int d,int s1,int s2,int t1,int t2){
    int e=a-b,f=c-d;
    bool F=(e==f);
    int g=t1-a+1,h=t2-b+1,i=s1-c+1,j=s2-d+1;
    bool F2=(g==i&&h==j);
    return F&&F2;
}
void solve(string t1,string t2){
    string a=t1,b=t2;
    sort(a.begin(),a.end());
    sort(b.begin(),b.end());
    if(a[a.size()-1ll]=='b'&&b[b.size()-1ll]=='b'){
        int t1n,t2n;
        for(us int i=0;i<=t1.size()-1ll;i++){
            if(t1[i]=='b')t1n=i;
        }
        for(us int i=0;i<=t2.size()-1ll;i++){
            if(t2[i]=='b')t2n=i;
        }
        for(int i=0;i<=n-1;i++){
            string s1,s2;
            s1=S[i].s1;
            s2=S[i].s2;
            int s1n,s2n;
            for(us int j=0;j<=s1.size()-1ll;j++){
                if(s1[j]=='b')s1n=j;
            }   
            for(us int j=0;j<=s2.size()-1ll;j++){
                if(s2[j]=='b')s2n=j;
            }
            if(check(t1n,t2n,s1n,s2n,s1.size(),s2.size(),t1.size(),t2.size()))ans++;
        }
        return ;
    }
    return ;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        node A;
        cin>>A.s1>>A.s2;
        S.push_back(A);
    }
    while(q--){
        string t1,t2;
        cin>>t1>>t2;
        solve(t1,t2);
        cout<<ans<<endl;
    }
    return 0;
}