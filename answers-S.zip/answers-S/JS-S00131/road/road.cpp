#include<bits/stdc++.h>
#include<ctime>
#define int long long
using namespace std;
const int N=1e9;
struct node{
    int next,w;
};
vector<vector<node> >Q(N);
vector<vector<signed> >a(N);
vector<int> C;
int ans;   
int n,m,k;
void solve(){

    return ;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);

    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        int u,v,w;
        node A;
        A.next=u;
        A.w=w;
        Q[u].push_back(A);
        A.next=v;
        Q[v].push_back(A);
    }
    for(int i=1;i<=k;i++){
        int c;
        cin>>c;
        C.push_back(c);
        for(int j=1;j<=n;j++){
            int w;
            cin>>w;
            a[i].push_back(w);
        }
    }

solve();
cout<<ans;
return 0;
}