#include<iostream>
#include<algorithm>
using namespace std;
const int N=100005,M=2000005;
int n,m,k,fa[N],a[N];long long ans;
struct _{int x,y,z;}o[M];
int getf(int x){return fa[x]=x==fa[x]?x:getf(fa[x]);}
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=n;i++)fa[i]=i;
    for(int i=1,u,v,w;i<=m;i++)
        cin>>u>>v>>w,o[i]={u,v,w};
    for(int i=1;i<=k;i++)
    {
        int p;cin>>p;
        for(int j=1;j<=n;j++)
        {cin>>a[j];if(a[j]==0)p=j;}
        for(int j=1;j<=n;j++)if(j!=p)
            o[++m]={j,p,a[j]};
    }
    sort(o+1,o+m+1,[](_ u,_ v){
        return u.z<v.z;
    });
    for(int i=1;i<=m;i++)
    {
        int u=getf(o[i].x),v=getf(o[i].y);
        if(u!=v)fa[u]=v,ans+=o[i].z;
    }
    cout<<ans;
}