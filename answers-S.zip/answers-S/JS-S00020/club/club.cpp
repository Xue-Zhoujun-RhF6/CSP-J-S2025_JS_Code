#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=100005,M=205;
int n;long long ans,f[M][M];
struct _{int x,y;}o[N];
void work()
{
    cin>>n,ans=0;
    for(int i=1,a,b,c;i<=n;i++)
        cin>>a>>b>>c,ans+=c,o[i]={a-c,b-c};
    if(n<=200)
    {
        memset(f,0xbf,sizeof f);
        f[0][0]=0;
        for(int i=1;i<=n;i++)
            for(int j=n/2;j>=0;j--)
                for(int k=n/2;k>=0;k--)
                {
                    if(j)f[j][k]=max(f[j][k],f[j-1][k]+o[i].x);
                    if(k)f[j][k]=max(f[j][k],f[j][k-1]+o[i].y);
                }
        long long ret=0xbfbfbfbfbfbfbfbfll;
        for(int j=n/2;j>=0;j--)
            for(int k=n/2;k>=0;k--)
                if(j+k>=n/2)ret=max(ret,f[j][k]);
        ans+=ret;
    }
    else
    {
        sort(o+1,o+n+1,[](_ a,_ b){
            return a.x-a.y<b.x-b.y;
        });
        for(int i=1;i<=n/2;i++)ans+=o[i].y;
        for(int i=n/2+1;i<=n;i++)ans+=o[i].x;
    }
    cout<<ans<<endl;
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;cin>>t;while(t--)work();
}