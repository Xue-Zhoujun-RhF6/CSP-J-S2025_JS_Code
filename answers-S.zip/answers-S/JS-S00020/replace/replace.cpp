#include<iostream>
using namespace std;
int main()
{
    ;;;
}
/*
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
It's of no meaning, just to fulfill the code.
*/