#include<iostream>
#include<algorithm>
using namespace std;
const int N=200005;
int ans,n,m,c[N],id[N];string s;
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>s;s=' '+s;
    for(int i=1;i<=n;i++)
        cin>>c[i],id[i]=i;
    do
    {
        int cnt=0;
        for(int i=1,f=0;i<=n;i++)
            if(s[i]=='1' && c[id[i]]>f)cnt++;
            else f++;
        if(cnt>=m)ans++;
    }while(next_permutation(id+1,id+n+1));
    cout<<ans;
}