#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1e5+10;

struct Node{
    int x,num,suf;
    friend bool operator < (Node a,Node b){
        return a.suf == b.suf?a.x < b.x : a.suf > b.suf;
    }
};

struct File{
    int idx,num,suf;
    friend bool operator < (File a,File b){
        return a.num > b.num;
    }
};

File a[MAXN][3], suf[MAXN][3]; int n;

priority_queue <Node> q[3];

void Find(int x){
    for(int k=0;k<=2;k++){
        int idx = a[x][k].idx, num = a[x][k].num, suf = a[x][k].suf;
        if(q[idx].size() >= n/2){
            Node top = q[idx].top();
            if(top.suf < suf){
                Find(top.x);
                q[idx].pop(); q[idx].push((Node){x,num,suf});
                break;
            }
        } else {
            q[idx].push((Node){x,num,suf});
            break;
        }
    }
}

void Solve(){
    cin >> n;
    for(int i=1;i<=n;i++){
        cin >> a[i][0].num >> a[i][1].num >> a[i][2].num;
        for(int k=0;k<=2;k++) a[i][k].idx = k;
    }
    for(int i=1;i<=n;i++){
        sort(a[i],a[i]+3);
    }
    for(int i=1;i<=n;i++){
        a[i][0].suf = a[i][0].num - a[i][1].num;
        a[i][1].suf = a[i][1].num - a[i][2].num;
        a[i][2].suf = 0x7f7f7f7f;
    }
    for(int i=1;i<=n;i++){
        Find(i);
    }
    int ans = 0; Node tmp;
    for(int i=0;i<=2;i++){
        while(!q[i].empty()){
            tmp = q[i].top(); q[i].pop();
            ans += tmp.num;
        }
    }
    cout << ans << '\n';
}

int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int T; cin >> T;
    while(T--){
        Solve();
    }
}