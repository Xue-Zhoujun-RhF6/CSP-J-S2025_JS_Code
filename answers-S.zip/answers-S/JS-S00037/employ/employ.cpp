#include <bits/stdc++.h>

using namespace std;

const int MAXN = 505;

int n,m;
bool vis[MAXN];
int c[MAXN];
int ans = 0;

void dfs(int depth,int x = 0){
    if(depth == n){
        if(x >= m) ans++;
    }
    for(int i=1;i<=n;i++){
        if(vis[i]) continue;
        vis[i] = 1;
        if(depth < c[i]) dfs(depth+1,x+1);
        else dfs(depth+1,x);
        vis[i] = 0;
    }
}

int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin >> n >> m;
    string s; cin >> s;
    for(int i=1;i<=n;i++) cin >> c[i];
    dfs(0);
    cout << ans << '\n';
    return 0;
}