#include <bits/stdc++.h>
#define int long long

using namespace std;

const int MAXN = 1e4+200;

struct Edge{
    int u,v,w,up;
    friend bool operator < (Edge a,Edge b){
        return a.w==b.w?a.u<b.u:a.w > b.w;
    }
};

int cnt[12]; int c[12];
int e[12][MAXN]; bool uped[12];

int fa[MAXN];

int Find(int x){
    if(fa[x] == x){
        return x;
    }
    return fa[x] = Find(fa[x]);
}

void Merge(int a,int b){
    int faa = Find(a), fab = Find(b);
    if(faa != fab) fa[faa] = fab;
    return;
}

priority_queue <Edge> q;

signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m,k; cin >> n >> m >> k;
    for(int i=1;i<=m;i++){
        int u,v,w; cin >> u >> v >> w;
        q.push((Edge){u,v,w,0});
    }
    for(int i=1;i<=n+k;i++){
        fa[i] = i;
    }
    for(int i=1;i<=k;i++){
        cin >> c[i];
        for(int j=1;j<=n;j++){
            cin >> e[i][j];
            q.push((Edge){n+i,j,c[i]+e[i][j],i});
        }
    }
    int ans = 0; int tot = 1;
    while(!q.empty()){
        Edge tmp = q.top(); q.pop();
        int u = tmp.u, v = tmp.v, w = tmp.w, up = tmp.up;
        if(Find(u) != Find(v)){
            Merge(u,v);
            ans += w; tot++;
            cnt[up]++;
            if(up && !uped[up]){
                c[up] = w;
                for(int i=1;i<=n;i++){
                    q.push((Edge){u,i,e[up][i],up});
                }
                uped[up] = 1;
            }
        }
        if(tot == n+k) break;
    }
    for(int i=1;i<=k;i++){
        if(cnt[i] == 1) ans -= c[i];
    }
    cout << ans << '\n';
    return 0;
}