#include<bits/sdc++.h>
using namespace std;
int main()
{

cout<<12;
}
