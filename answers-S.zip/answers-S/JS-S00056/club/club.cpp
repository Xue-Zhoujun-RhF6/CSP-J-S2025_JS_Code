#include<bits/stdc++.h>
using namespace std;
int b(int a,int b,int c)
{
    int maxn=max(a,b);
    if(c>maxn) maxn=c;
    return maxn;

}
int main()
{
    //freopen("club.in","r",stdin);
    //freopen("club.out","w",stdout);
    int t;
    cin>>t;
    while(t--)
    {

        int n;
        cin>>n;
        int sum=0;
        int maxn=0;
        int a[n][3];
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=3;j++){
                cin>>a[i][j];
            }
        }
        if(n==2)
        {
            for(int i=1;i<=3;i++)
            {
                for(int j=1;j<=3;j++)
                {
                    if(i!=j){
                    int w=a[1][i]+a[2][j];
                    maxn=max(w,maxn);
                    }
                }
            }
        }
        cout<<maxn;
    }
return 0;
}




























