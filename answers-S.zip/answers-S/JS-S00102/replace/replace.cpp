#include<bits/stdc++.h>
using namespace std;
long long n,q,v[100005]={1},a,b,ans;
string s1[10005],s2[10005],s,t;
map<string,int>mp;
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>s1[i]>>s2[i];
        a=abs(int(s1[i].find('b')-s2[i].find('b')));
        if(a<100000)v[a]++;
    }
    while(q--){
        cin>>s>>t;
        if(s.size()!=t.size()){
            cout<<0<<endl;
        }else{
            ans=0;
            int len=abs(int(s.find('b')-t.find('b')));
            for(int i=0;i<=len/2;i++){
                ans+=v[i]*v[len-i];
            }
            if(a&&b)cout<<ans+1<<endl;
            else cout<<ans<<endl;
        }
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
