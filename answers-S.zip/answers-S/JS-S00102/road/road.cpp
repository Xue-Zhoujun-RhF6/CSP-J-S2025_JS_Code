#include<bits/stdc++.h>
using namespace std;
long long n,m,k,f[10005],x[10005],cnt,num,c[10005],visA,minn=0x3f3f3f3f3f,num1;
int find(int x){
    if(f[x]==x)return x;
    f[x]=find(f[x]);
    return f[x];
}
struct kk{
    long long u,v,w;
}b[1000005];
bool cmp(kk f,kk g){
    return f.w<g.w;
}
vector<kk>a[10005];
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    cnt=1;
    for(int i=1;i<=n;i++)f[i]=i;
    for(int i=1;i<=m;i++){
        cin>>b[i].u>>b[i].v>>b[i].w;
    }
    sort(b+1,b+m+1,cmp);
    for(int i=1;i<=m;i++)if(find(b[i].u)!=find(b[i].v)){
        f[find(b[i].v)]=find(b[i].u);
        c[cnt]=b[i].w;
        num+=b[i].w,cnt++;
        if(cnt==n)break;
    }
    while(k--){
        num1=0;
        cin>>x[0];
        num1+=x[0];
        if(!x[0])visA=1;
        for(int i=1;i<=n;i++){
            cin>>x[i];
            num1+=x[i];
        }
        minn=min(minn,num1);
    }
    cout<<min(num,minn);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
