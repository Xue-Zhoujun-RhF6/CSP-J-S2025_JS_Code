#include<bits/stdc++.h>
using namespace std;
int n,m,cnt1,cnt2,num=1,mod=998244353;
string s;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>s;
    for(int i=0;i<s.size();i++){
        if(s[i]=='1')cnt2++;
    }
    for(int i=0;i<s.size();i++){
        if(s[i]=='1')cnt1++;
        else break;
    }
    for(int i=1;i<=n;i++){
        num*=i;
        num%=mod;
    }
    if(m==n){
        if(cnt2==n)cout<<num;
        else cout<<0;
    }else if(m==1){
        if(cnt2>=1)cout<<num;
        else cout<<0;
    }else if(cnt1>=m){
        cout<<num;
    }else{
        cout<<0;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
