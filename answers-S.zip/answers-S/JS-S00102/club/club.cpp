#include<bits/stdc++.h>
using namespace std;
long long t,n,dp[205][205][205],vx,vy,vz,v,xx[100005],yy[100005],vis[100005],ans;
struct k{
    long long x,y,z;
}a[100005];
bool cmp(k f,k g){
    return f.x>g.x;
}
bool xmp(int f,int g){
    return a[f].x>a[g].x;
}
bool ymp(int f,int g){
    return a[f].y>a[g].y;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--){
        cin>>n;
        v=0;
        ans=0;
        for(int i=1;i<=n;i++){
            cin>>a[i].x>>a[i].y>>a[i].z;
            if(a[i].y)v=1;
            else if(a[i].z)v=2;
        }
        if(n<=400){
            long long maxn=0;
            for(int i=0;i<=n/2;i++){
                for(int j=0;j<=n/2;j++){
                    for(int k=0;k<=n/2;k++){
                        dp[i][j][k]=0ll;
                    }
                }
            }
            for(int h=0;h<n;h++){
                vx=a[h+1].x,vy=a[h+1].y,vz=a[h+1].z;
                for(int i=0;i<=n/2;i++){
                    for(int j=0;j<=n/2;j++)if(i+j<=h){
                        int k=h-i-j;
                        dp[i+1][j][k]=max(dp[i+1][j][k],dp[i][j][k]+vx);
                        dp[i][j+1][k]=max(dp[i][j+1][k],dp[i][j][k]+vy);
                        dp[i][j][k+1]=max(dp[i][j][k+1],dp[i][j][k]+vz);
                    }
                }
            }
            for(int i=0;i<=n/2;i++){
                for(int j=0;j<=n/2;j++){
                    int k=n-i-j;
                    maxn=max(maxn,dp[i][j][k]);
                }
            }
            cout<<maxn<<endl;
            continue;
        }else if(v==0){
            sort(a+1,a+n+1,cmp);
            for(int i=1;i<=n/2;i++){
                ans+=a[i].x;
            }
        }else if(v==1){
            long long cnt=n,xi=1,yi=1;
            for(int i=1;i<=n;i++){
                xx[i]=yy[i]=1;
                vis[i]=0;
            }
            sort(xx+1,xx+n+1,xmp);
            sort(yy+1,yy+n+1,ymp);
            while(cnt){
                while(vis[xx[xi]])xi++;
                while(vis[yy[yi]])yi++;
                if(a[xx[xi]].x>=a[yy[yi]].y&&xi<(n/2))xi++,ans+=a[xx[xi]].x;
                else if(yi<(n/2))yi++,ans+=a[yy[yi]].y;
                else xi++,ans+=a[xx[xi]].x;
            }
        }else{
            for(int i=1;i<=n;i++){
                ans+=max(a[i].x,max(a[i].y,a[i].z));
            }
        }
        cout<<ans<<endl;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
