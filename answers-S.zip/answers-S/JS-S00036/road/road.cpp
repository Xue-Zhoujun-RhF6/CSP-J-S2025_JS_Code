#include<bits/stdc++.h>
using namespace std;
long long n,m,k,rs=1000000000;
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","r",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        int x,y,z;
        cin>>x>>y>>z;
    }
    for(int i=1;i<=k;i++){
        int f;
        int ans=0;
        cin>>f;
        for(int i=1;i<=n;i++){
            int mo;
            cin>>mo;
            ans+=mo;
        }
        ans+=f;
        if(ans<rs) rs=ans;
    }
    cout<<rs;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
