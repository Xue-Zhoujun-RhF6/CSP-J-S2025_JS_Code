#include<bits/stdc++.h>
using namespace std;
int t,n,p[100005][5];
queue<int> a,b,c;
int big(int i){
    if(p[i][0]>max(p[i][1],p[i][2])) return 0;
    if(p[i][1]>max(p[i][3],p[i][2])) return 1;
    if(p[i][2]>max(p[i][1],p[i][3])) return 2;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","r",stdout);
    cin>>t;
    while(t--){
        cin>>n;
        for(int i=1;i<=n;i++){
            cin>>p[i][0]>>p[i][1]>>p[i][2];
        }
        for(int i=1;i<=n;i++){

            if(big(i)==0){
                if(a.size()<n/2){
                    a.push(i);
                }
                else if(p[i][1]>p[i][2]&&b.size()<=n*2){
                    b.push(i);
                }
                else{
                    c.push(i);
                }
            }
            else if(big(i)==1){
                if(b.size()<n/2){
                    b.push(i);
                }
                else if(p[i][0]>p[i][2]&&b.size()<=n*2){
                    a.push(i);
                }
                else{
                    c.push(i);
                }
            }
            else{
                if(c.size()<n/2){
                    c.push(i);
                }
                else if(p[i][1]>p[i][0]&&b.size()<=n*2){
                    b.push(i);
                }
                else{
                    a.push(i);
                }
            }
        }
        int ans=0;
        while(!a.empty()){
            ans+=p[a.front()][0];
            a.pop();
        }
        while(!b.empty()){
            ans+=p[b.front()][1];
            c.pop();
        }
        while(!c.empty()){
            ans+=p[c.front()][2];
            c.pop();
        }
        cout<<ans<<endl;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
