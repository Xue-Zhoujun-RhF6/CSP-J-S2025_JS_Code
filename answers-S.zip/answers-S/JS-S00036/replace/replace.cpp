#include<bits/stdc++.h>
using namespace std;
long long n,m;
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","r",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        string a,b;
        cin>>a>>b;
    }
    for(int i=1;i<=m;i++){
        string c,d;
        cin>>c>>d;
        cout<<'0'<<endl;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
