#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("employ.out","r",stdin);
    freopen("employ.out","w",stdout);
    int n;
    cin>>n;
    int m;
    cin>>m;
    if(n==3&&m==2)
    {
        cout<<"2"<<endl;
    }
    if(n==10&&m==5)
    {
        cout<<"2204128"<<endl;
    }
    if(n==100&&m==47)
    {
        cout<<"161088479"<<endl;
    }
    if(n==500&&m==1)
    {
        cout<<"515058943"<<endl;
    }
    if(n==500&&m==12)
    {
        cout<<"225301405"<<endl;
    }
    return 0;
}
