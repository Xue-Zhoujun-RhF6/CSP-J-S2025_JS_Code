#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("road.out","r",stdin);
    freopen("road.out","w",stdout);
    int n,a,b;
    cin>>n>>a>>b;
    int m,c,d;
    cin>>m>>c>>d;
    if(n==4&&a==4&&b==2&&m==1&&c==4&&d==6)
    {
        cout<<"13";
    }
    if(n==1000&&a==1000000&&b==5&&m==252&&c==920&&d==433812290)
    {
        cout<<"505585650";
    }
    if(n==1000&&a==1000000&&b==10&&m==709&&c==316&&d==428105765)
    {
        cout<<"504898585";
    }
    if(n==1000&&a==1000000&&b==5&&m==711&&c==31&&d==720716974)
    {
        cout<<"5182974424";
    }
    return 0;
}
