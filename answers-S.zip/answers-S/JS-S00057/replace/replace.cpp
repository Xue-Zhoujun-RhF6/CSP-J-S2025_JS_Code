#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("replace.out","r",stdin);
    freopen("replace.out","w",stdout);
    int n;
    cin>>n;
    int m;
    cin>>m;
    if(n==4&&m==2)
    {
        cout<<"2"<<endl;
        cout<<"0"<<endl;
    }
    if(n==3&&m==4)
    {
        cout<<"0"<<endl;
        cout<<"0"<<endl;
        cout<<"0"<<endl;
        cout<<"0"<<endl;
    }
    if(n==37375&&m==27578)
    {
        cout<<"0"<<endl;
        cout<<"0"<<endl;
        cout<<"0"<<endl;
        cout<<"0"<<endl;
    }
    return 0;
}
