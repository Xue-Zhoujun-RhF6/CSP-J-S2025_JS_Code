#include<bits/stdc++.h>
#define int unsigned long long
using namespace std;
int n,m,c[501],p[501],v[501],ans,cnt;
bool A=true;
const int mod=998244353;
string s;
inline void dfs(int q)
{
    if(q==n+1)
    {
        int cnt=0,f=0;
        for(int i=1;i<=n;i++)
        {
            if(s[i]=='1'&&f<c[p[i]])
                cnt++;
            else if(s[i]=='0'||f>=c[p[i]])
                f++;
        }
        if(cnt>=m)
            ans++;
        ans%=mod;
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(v[i]==false)
        {
            p[q]=i;
            v[i]=true;
            dfs(q+1);
            v[i]=false;
        }
    }
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>s;
    s='@'+s;
    for(int i=1;i<=n;i++)
        cin>>c[i];
    for(int i=1;i<=n;i++)
    {
        if(s[i]!='1')
            A=false;
        else
            cnt++;
    }
    if(cnt<m)
        cout<<0<<'\n';
    else if(A)
    {
        int P=1,Q=1,X;
        for(int i=n;i>=n+1-m;i--)
            P*=i;
        for(int i=m;i>=2;i--)
            Q*=i;
        X=P/Q;
        ans+=X;
        ans%=mod;
        for(int i=m+1;i<=n;i++)
        {
            X=X*(n-i+1)/i;
            ans+=X;
            ans%=mod;
        }
        cout<<ans<<'\n';
    }
    else
    {
        dfs(1);
        cout<<ans<<'\n';
    }
    return 0;
}
