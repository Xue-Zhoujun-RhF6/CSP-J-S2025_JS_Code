#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[100001][4],cnx,cny,cnz,cnx2,cny2,cnz2,ans;
struct X
{
    int id,data,dif;
    char sp;
    bool operator<(const X &p)
    {
        return dif>p.dif;
    }
}x[100001];
struct Y
{
    int id,data,dif;
    char sp;
    bool operator<(const Y &p)
    {
        return dif>p.dif;
    }
}y[100001];
struct Z
{
    int id,data,dif;
    char sp;
    bool operator<(const Z &p)
    {
        return dif>p.dif;
    }
}z[100001];
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin>>t;
    while(t--)
    {
        ans=cnx=cny=cnz=cnx2=cny2=cnz2=0;
        memset(a,0,sizeof a);
        memset(x,0,sizeof x);
        memset(y,0,sizeof y);
        memset(z,0,sizeof z);
        cin>>n;
        for(int i=1;i<=n;i++)
        {
            cin>>a[i][1]>>a[i][2]>>a[i][3];
            int mx=max(max(a[i][1],a[i][2]),a[i][3]);
            if(mx==a[i][1])
            {
                cnx++;
                x[cnx].id=i;
                x[cnx].data=mx;
                x[cnx].dif=a[i][1]-max(a[i][2],a[i][3]);
                x[cnx].sp=(a[i][2]>=a[i][3])?'y':'z';
            }
            else if(mx==a[i][2])
            {
                cny++;
                y[cny].id=i;
                y[cny].data=mx;
                y[cny].dif=a[i][2]-max(a[i][1],a[i][3]);
                y[cny].sp=(a[i][1]>=a[i][3])?'x':'z';
            }
            else if(mx==a[i][3])
            {
                cnz++;
                z[cnz].id=i;
                z[cnz].data=mx;
                z[cnz].dif=a[i][3]-max(a[i][1],a[i][2]);
                z[cnz].sp=(a[i][1]>=a[i][2])?'x':'y';
            }
        }
        sort(x+1,x+cnx+1);
        sort(y+1,y+cny+1);
        sort(z+1,z+cnz+1);
        cnx2=cnx;
        cny2=cny;
        cnz2=cnz;
        if(cnx>(n/2))
        {
            for(int i=n/2+1;i<=cnx;i++)
            {
                if(x[i].sp=='y')
                {
                    cny++;
                    y[cny].id=x[i].id;
                    y[cny].data=a[x[i].id][2];
                    x[i].data=0;
                    cnx2--;
                }
                else
                {
                    cnz++;
                    z[cnz].id=x[i].id;
                    z[cnz].data=a[x[i].id][3];
                    x[i].data=0;
                    cnx2--;
                }
            }
            cnx=cnx2;
            cny2=cny;
            cnz2=cnz;
        }
        else if(cny>(n/2))
        {
            for(int i=n/2+1;i<=cny;i++)
            {
                if(y[i].sp=='x')
                {
                    cnx++;
                    x[cnx].id=y[i].id;
                    x[cnx].data=a[y[i].id][1];
                    y[i].data=0;
                    cny2--;
                }
                else
                {
                    cnz++;
                    z[cnz].id=y[i].id;
                    z[cnz].data=a[y[i].id][3];
                    y[i].data=0;
                    cny2--;
                }
            }
            cny=cny2;
            cnx2=cnx;
            cnz2=cnz;
        }
        else if(cnz>(n/2))
        {
            for(int i=n/2+1;i<=cnz;i++)
            {
                if(z[i].sp=='x')
                {
                    cnx++;
                    x[cnx].id=z[i].id;
                    x[cnx].data=a[z[i].id][1];
                    z[i].data=0;
                    cnz2--;
                }
                else
                {
                    cny++;
                    y[cnz].id=z[i].id;
                    y[cnz].data=a[z[i].id][2];
                    z[i].data=0;
                    cnz2--;
                }
            }
            cnz=cnz2;
            cnx2=cnx;
            cny2=cny;
        }
        for(int i=1;i<=cnx;i++)
            ans+=x[i].data;
        for(int i=1;i<=cny;i++)
            ans+=y[i].data;
        for(int i=1;i<=cnz;i++)
            ans+=z[i].data;
        cout<<ans<<'\n';
    }
    return 0;
}
