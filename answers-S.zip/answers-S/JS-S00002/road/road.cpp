#include<bits/stdc++.h>
using namespace std;
const int MAXM=2e6;
int ans=INT_MAX;
struct node{
    int u;
    int v;
    int w;
};
int power(int a,int x)
{
    int res=1;
    for(int i=1;i<=x;i++)
    {
        res=res*a;
    }
    return res;
}
struct s{
    int f[100100];
    void init(int pos)
    {
        f[pos]=pos;
    }
    int fin(int x)
    {
        if(f[x]==x)return x;
        return fin(f[x]);
    }
    void me(int x,int y)
    {
        if(fin(x)!=fin(y))
        f[fin(x)]=f[y];
    }
}s;
priority_queue<pair<int,int> >p;
int d[100100];
node e[MAXM];
node e_[MAXM];
node be[15][10020];
void c1()
{
    for(int i=0;i<MAXM;i++)
    e_[i]=e[i];
}
void c2()
{
    for(int i=0;i<MAXM;i++)
    e[i]=e_[i];
}
int f(int n)
{
    int cnt=1;
    int res=0;
    while(cnt<n&&!p.empty())
    {
        pair<int,int> q=p.top();
        p.pop();
        node a=e[q.first];
        if(s.fin(a.u)!=s.fin(a.v))
        {
            s.me(a.u,a.v);
            d[a.u]++;
            d[a.v]++;
            res+=a.w;
            cnt++;
        }
    }
    return res;
}
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m,t;
    cin>>n>>m>>t;
    for(int i=1;i<=m;i++)
    {
        cin>>e[2*i].u>>e[i*2].v>>e[2*i].w;
        e[i*2-1]=e[i*2];
        swap(e[i*2-1].u,e[i*2-1].v);
    }
    for(int i=1;i<=t;i++)
    {
        cin>>be[i][0].w;
        for(int j=1;j<=n;j++)
        {
            cin>>be[i][j].w;
            be[i][j].u=i+n;
            be[i][j].v=j;
        }
    }
    c1();
    for(int k=0;k<=power(2,t)-1;k++)
    {
        c2();

        int siz=0,more=0;
        for(int i=1;i<=m;i++)
        {
            p.push({i*2,e[i].w});
            p.push({i*2-1,e[i].w});

        }
        for(int i=1;i<=n;i++)
            s.init(i);
        for(int i=1;i<=t;i++)
        if(k>>(i-1)&1)
        {
            more+=be[i][0].w;
            siz++;
            s.init(n+i);
            for(int j=1;j<=n;j++)
            {
                int d=m+((i-1)*n+j)*2;
                p.push({d,be[i][j].w});
                e[d]=be[i][j];
                p.push({d-1,be[i][j].w});
                e[d-1]=be[i][j];
                swap(e[d-1].u,e[d-1].v);
            }
        }
        ans=min(ans,f(n+siz)+more);
    }
    cout<<ans;
    return 0;
}
/*
4 4 2
1 4 6
2 3 7
4 2 5
4 3 4
1 1 8 2 4
100 1 3 2 4
*/


