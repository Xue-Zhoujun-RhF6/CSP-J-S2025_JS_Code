#include<bits/stdc++.h>
using namespace std;
const int MAX=5e4+10;
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin>>t;
    for(int rp=1;rp<=t;rp++)
    {
        int n;
        cin>>n;
        int dp[n+10][n+10];
        int lst[2*n+10][3];
        for(int i=0;i<=n;i++)
            for(int j=0;j<=n;j++)
            dp[i][j]=0;
        for(int i=1;i<=n;i++)
        {
            cin>>lst[i][0]>>lst[i][1]>>lst[i][2];
        }
        int ans=0;
        for(int i=1;i<=n;i++)
        {
            for(int j=n/2;j>=1;j--)
            {
                for(int k=n/2;k>=1;k--)
                {
                    dp[j][k]=max(max(dp[j-1][k]+lst[i][0],dp[j][k-1]+lst[i][1]),dp[j][k]+lst[i][2]);
                    ans=max(ans,dp[j][k]);
                }
                dp[0][1]=max(dp[0][1]+lst[i][2],dp[0][0]+lst[i][1]);
                dp[1][0]=max(dp[1][0]+lst[i][2],dp[0][0]+lst[i][0]);
                dp[0][0]=dp[0][0]+lst[i][2];
                ans=max(ans,max(dp[0][0],max(dp[0][1],dp[1][0])));
            }
        }
        cout<<ans;
    }
    return 0;
}
