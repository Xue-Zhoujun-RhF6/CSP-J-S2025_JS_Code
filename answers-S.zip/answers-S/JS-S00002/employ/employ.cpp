#include<bits/stdc++.h>
using namespace std;
const int MOD=998244353;
int f(int n,int x)
{
    int res=1;
    for(int i=n;i>=n-x+1;i--)
    {
        res=(res*i)%MOD;
    }
    return res;
}
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n;
    cin>>n;
    cout<<f(n,n);
    return 0;
}
