#include<fstream>
#include<string>
std::ifstream fin("replace.in");
std::ofstream fout("replace.out");
std::string s0[200005][2];
int main(){
    int n,q;
    fin>>n>>q;
    for(int i=0;i<n;++i){
        fin>>s0[i][0]>>s0[i][1];
    }
    while(q-->0){
        std::string s;
        std::string t;
        fin>>s>>t;
        int ans=0;
        if(s.size()!=t.size()){
            fout<<0<<"\n";
            continue;
        }
        for(int i=0;i<n;++i){
            for(int q=0;q<s.size();++q){
                int j=0;
                while(s[q+j]==s0[i][0][j] && j<s0[i][0].size()){
                    ++j;
                }
                if(j==s0[i][0].size()){
                    std::string t1;
                    for(int k=0;k<q;++k){
                        t1+=s[k];
                    }
                    for(int k=q;k<q+j;++k){
                        t1+=s0[i][1][k-q];
                    }
                    for(int k=q+j;k<s.size();++k){
                        t1+=s[k];
                    }
                    if(t1==t){
                        ans++;
                    }
                }
            }
        }
        fout<<ans<<"\n";
    }

}
