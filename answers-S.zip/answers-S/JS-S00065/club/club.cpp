#include<fstream>
#include<algorithm>
std::ifstream fin("club.in");
std::ofstream fout("club.out");
struct nude{
    long bas;
    long max3;
    long long b1,b2,b3;
    long long a1,a2,a3;
    int def;
};
bool used[100005];
nude nd[100005];
bool cmp(nude lhs,nude rhs){
    if(lhs.max3>rhs.max3){
        return true;
    }else if(lhs.max3<rhs.max3){
        return false;
    }else{
        if(lhs.def>rhs.def){
            return true;
        }else{
            return false;
        }
    }
}
int main(){
    int q;
    fin>>q;
    while(q-->0){
        int n;
        fin>>n;
        for(int i=0;i<n;++i){
            long long a1,a2,a3;
            fin>>a1>>a2>>a3;
            int base=std::min(a1,std::min(a2,a3));
            nd[i].bas=base;
            nd[i].b1=a1-base;
            nd[i].b2=a2-base;
            nd[i].b3=a3-base;
            nd[i].a1=a1;
            nd[i].a2=a2;
            nd[i].a3=a3;
            nd[i].max3=std::max(nd[i].b1,std::max(nd[i].b2,nd[i].b3));
            nd[i].def=2*nd[i].max3-(nd[i].b1+nd[i].b2+nd[i].b3);
        }
        std::sort(nd,nd+n,cmp);
        int c[4]={0,0,0,0};
        long long sum=0;
        int now;
        int bao;
        for(int i=0;i<n;++i){
            if(c[1]==n/2){
                now=i;
                bao=1;
                break;
            }else if(c[2]==n/2){
                now=i;
                bao=2;
                break;
            }else if(c[3]==n/2){
                now=i;
                bao=3;
                break;
            }
            int findmax;
            if(nd[i].b1>nd[i].b2 && nd[i].b1>nd[i].b3){
                findmax=1;
            }else if(nd[i].b2>nd[i].b1 && nd[i].b2>nd[i].b3){
                findmax=2;
            }else if(nd[i].b3>nd[i].b1 && nd[i].b3>nd[i].b2){
                findmax=3;
            }else if(nd[i].b1==nd[i].b2 && nd[i].b2==nd[i].b3){
                if(c[1]<=c[2] && c[1]<=c[3]){
                    findmax=1;
                }else if(c[2]<=c[1] && c[2]<=c[3]){
                    findmax=2;
                }else{
                    findmax=3;
                }
            }else if(nd[i].b1==nd[i].b2){
                if(c[1]<c[2]){
                    findmax=1;
                }else{
                    findmax=2;
                }
            }else if(nd[i].b1==nd[i].b3){
                if(c[1]<c[3]){
                    findmax=1;
                }else{
                    findmax=3;
                }
            }else if(nd[i].b2==nd[i].b3){
                if(c[2]<c[3]){
                    findmax=2;
                }else{
                    findmax=3;
                }
            }
            c[findmax]++;
            sum+=nd[i].bas+nd[i].max3;
        }
        for(int i=now;i<n;++i){
            if(bao==1){
                nd[i].max3=std::max(nd[i].a2,nd[i].a3);
            }else if(bao==2){
                 nd[i].max3=std::max(nd[i].a1,nd[i].a3);
            }else{
                 nd[i].max3=std::max(nd[i].a1,nd[i].a2);
            }
        }
        for(int i=now;i<n;++i){
                sum+=nd[i].max3;
        }
        fout<<sum<<"\n";
        for(int i=0;i<n;++i){
            nd[i].b1=0;
            nd[i].b2=0;
            nd[i].b3=0;
            nd[i].bas=0;
            nd[i].max3=0;
            nd[i].a1=0;
            nd[i].a2=0;
            nd[i].a3=0;
            nd[i].def=0;
        }
    }
}
