#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
ll T, n, a[4][100005], dp[205][105][105][105];
bool flag = true;
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	freopen("club.in", "r", stdin);
	freopen("club.out", "w", stdout);
	cin >> T;
	while(T--){
		ll ans = 0;
		for(ll i = 1; i <= n; i++) for(ll j = n / 2; j >= 0; j--) for(ll k = n / 2; k >= 0; k--) for(ll l = n / 2; l >= 0; l--) dp[i][j][k][l] = 0;
		cin >> n;
		for(ll i = 1; i <= n; i++){
			cin >> a[1][i] >> a[2][i] >> a[3][i];
			flag &= a[2][i];
			flag &= a[3][i];
		}
		if(n <= 200){
			for(ll i = 1; i <= n; i++){
				ll maxn = min(i, n / 2);
				for(ll j = maxn; j >= 0; j--){
					for(ll k = maxn; k >= 0; k--){
						for(ll l = maxn; l >= 0; l--){
							// select 1
							if(j) dp[i][j][k][l] = max(dp[i][j][k][l], dp[i - 1][j - 1][k][l] + a[1][i]);
							if(k) dp[i][j][k][l] = max(dp[i][j][k][l], dp[i - 1][j][k - 1][l] + a[2][i]);
							if(l) dp[i][j][k][l] = max(dp[i][j][k][l], dp[i - 1][j][k][l - 1] + a[3][i]);
							if(i == n && j + k + l == n) ans = max(ans, dp[i][j][k][l]);
						}
					}
				}
			}
		} else if(flag){
			sort(a[1] + 1, a[1] + n + 1);
			for(ll i = n; i >= n / 2 + 1; i--) ans += a[1][i];
		}
		cout << ans << endl;
	}
	return 0;
}