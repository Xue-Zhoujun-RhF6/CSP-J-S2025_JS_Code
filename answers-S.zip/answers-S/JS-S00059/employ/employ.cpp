#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
const ll MOD = 998244353;
ll mypow(ll x, ll y){
	ll ret = 1;
	while(y){
		if(y & 1) ret *= x;
		x *= x;
		y >>= 1;
	}
	return ret;
}
ll n, m, c[505], ans, b[505];
bool flg = true, dif[505], vis[505];
char ch;
bool check(){
	ll cnt = 0, fail = 0;
	for(ll i = 1; i <= n; i++){
		// cout << "day" << i << ": " << fail << " " << c[i] << " " << cnt << " " << dif[b[i]] << endl;
		if(fail >= c[b[i]]) fail++;
		else if(!dif[i]) fail++;
		else cnt++;
	}
	// for(ll i = 1; i <= n; i++) cout << b[i] << " ";
	// cout << endl << cnt << endl;
	return cnt >= m;
}
void dfs(ll cur){
	if(cur > n){
		if(check()){
			ans++;
			if(ans >= MOD) ans -= MOD;
		}
		return;
	}
	for(ll i = 1; i <= n; i++){
		if(!vis[i]){
			b[cur] = i;
			vis[i] = true;
			dfs(cur + 1);
			vis[i] = false;
		}
	}
}
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	freopen("employ.in", "r", stdin);
	freopen("employ.out", "w", stdout);
	cin >> n >> m;
	for(ll i = 1; i <= n; i++){
		cin >> ch;
		dif[i] = ch - '0';
		flg &= dif[i];
	}
	for(ll i = 1; i <= n; i++) cin >> c[i];
	if(n <= 10){
		dfs(1);
		cout << ans << endl;
	} else if(flg){

	} else {

	}
	return 0;
}