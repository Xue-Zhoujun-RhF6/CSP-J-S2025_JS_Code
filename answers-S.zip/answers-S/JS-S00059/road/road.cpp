#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
const ll inf = 9e18;
ll Read(){
	char ch = getchar();
	while(ch > '9' || ch < '0') ch = getchar();
	ll ret = 0;
	while(ch >= '0' && ch <= '9'){
		ret = ret * 10 + (ch - '0');
		ch = getchar();
	}
	return ret;
}
ll n, m, k, cnt, a[15][10005], c[15], fa[1000005], ans, d[1005][1005];
bool built[10005];
struct edge{
	ll u, v, w, vlg;
} e[1000005];
bool operator < (edge p, edge q){ return p.w < q.w;}
ll find(ll x){ return x == fa[x] ? x : fa[x] = find(fa[x]);}
void kruskal(){
	ll tot = 0;
	sort(e + 1, e + cnt + 1);
	for(ll i = 1; i <= n; i++) fa[i] = i;
	for(ll i = 1; i <= cnt; i++){
		ll u = e[i].u, v = e[i].v, w = e[i].w, vlg = e[i].vlg;
		ll uu = find(u), vv = find(v);
		if(uu != vv){
			fa[uu] = vv;
			tot++;
			ans += w;
			if(tot >= n - 1) break;
		}
	}
}
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	n = Read();
	m = Read();
	k = Read();
	for(ll i = 1; i <= m; i++){
		ll u, v, w;
		u = Read();
		v = Read();
		w = Read();
		e[i] = edge{u, v, w, 0};
	}
	for(ll i = 1; i <= k; i++){
		c[i] = Read();
		for(ll j = 1; j <= n; j++) a[i][j] = Read();
	}
	if(k == 0){
		cnt = m;
		kruskal();
	} else if(n <= 1000){
		for(ll i = 1; i < n; i++) for(ll j = i + 1; j <= n; j++) d[i][j] = inf;
		for(ll i = 1; i <= m; i++){
			ll u = e[i].u, v = e[i].v, w = e[i].w;
			if(u > v) swap(u, v);
			d[u][v] = min(d[u][v], w);
		}
		for(ll i = 1; i < n; i++){
			for(ll j = i + 1; j <= n; j++){
				ll tmp = 0;
				for(ll o = 1; o <= k; o++){
					ll cur = c[o] + a[o][i] + a[o][j];
					if(cur < d[i][j]){
						d[i][j] = cur;
						tmp = o;
					}
				}
				e[++cnt] = edge{i, j, d[i][j], tmp};
			}
		}
		kruskal();
		for(ll i = 1; i <= k; i++) if(built[i] > 1) ans -= (built[i] - 1) * c[i];
	}
	cout << ans << endl;
	return 0;
}