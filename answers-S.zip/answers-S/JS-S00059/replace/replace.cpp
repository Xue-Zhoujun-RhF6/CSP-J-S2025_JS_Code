#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
ll n, q, ans, len[200005];
string s1[200005], s2[200005], t1, t2;
map<string, string> m;
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	freopen("replace.in", "r", stdin);
	freopen("replace.out", "w", stdout);
	cin >> n >> q;
	for(ll i = 1; i <= n; i++){
		cin >> s1[i] >> s2[i];
		len[i] = s1[i].length();
		m[s1[i]] = s2[i];
	}
	for(ll z = 1; z <= q; z++){
		cin >> t1 >> t2;
		ans = 0;
		ll len2 = t1.length(), l = -1, r = len2 + 1;
		for(ll i = 1; i <= len2; i++){
			if(t1[i - 1] != t2[i - 1]){
				l = i;
				break;
			}
		}
		for(ll i = len2; i >= 1; i--){
			if(t1[i - 1] != t2[i - 1]){
				r = i;
				break;
			}
		}
		string tmp1 = "", tmp2 = "";
		for(ll i = l; i <= r; i++){
			tmp1 += t1[i - 1];
			tmp2 += t2[i - 1];
		}
		for(ll i = l; i >= 1; i--){
			string str1 = tmp1, str2 = tmp2;
			for(ll j = l - 1; j >= i; j--){
				str1 = t1[j - 1] + str1;
				str2 = t2[j - 1] + str2;
			}
			for(ll j = r; j <= len2; j++){
				if(j > r){
					str1 += t1[j - 1];
					str2 += t2[j - 1];
				}
				// cout << str1 << " " << str2 << endl;
				if(m[str1] == str2) ans++;
			}
		}
		cout << ans << endl;
	}
	return 0;
}