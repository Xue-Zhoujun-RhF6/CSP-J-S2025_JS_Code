#include<bits/stdc++.h>
using namespace std;
int n,k;
pair<string,string> re[114514];
int main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>k;
    for(int i=1;i<=n;i++)
    {
        string s1,s2;
        cin>>s1>>s2;
        re[i]=make_pair(s1,s2);
    }
    for(int i=1;i<=k;i++)
    {

        string s1,s2;
        cin>>s1>>s2;
        int ans=0;
        for(int j=1;j<=n;j++)
        {
            if(s1.find(re[j].first)!=string::npos)
            {
                int f=s1.find(re[j].first);
                string s=s1;
                s.replace(f,re[j].second.size(),re[j].second);
                if(s==s2)
                    ans++;
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}
