#include<bits/stdc++.h>
using namespace std;
struct node
{
    int value,idx;
};
node a[114514][4];
bool cmp(node x,node y)
{
    return x.value>y.value;
}
int cnt[4];
int n;
int T;
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%d",&T);
    while(T--)
    {
        cnt[1]=0,cnt[2]=0,cnt[3]=0;
        int ans=0;
        scanf("%d",&n);
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=3;j++)
            {
                cin>>a[i][j].value;
                a[i][j].idx=j;
            }
        }
        for(int i=1;i<=n;i++)
        {
            if(a[i][1].value<a[i+1][1].value) swap(a[i],a[i+1]);
              else if(a[i][2].value<a[i+1][2].value) swap(a[i],a[i+1]);
                else if(a[i][3].value<a[i+1][3].value) swap(a[i],a[i+1]);
        }
        /*for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=3;j++)
                cout<<a[i][j].value<<" ";
            cout<<endl;
        }*/
        for(int i=1;i<=n;i++)
        {
            sort(a[i]+1,a[i]+3+1,cmp);
            for(int j=1;j<=3;j++)
                if(1+cnt[a[i][j].idx]<=n/2)
                {
                    ans+=a[i][j].value;
                    cnt[a[i][j].idx]++;
                    continue;
                }
        }
        cout<<ans<<endl;
    }
    return 0;
}
/*3
4
4 2 1
3 2 4
5 3 4
3 5 1
4
0 1 0
0 1 0
0 2 0
0 2 0
2
10 9 8
4 0 0
*/
