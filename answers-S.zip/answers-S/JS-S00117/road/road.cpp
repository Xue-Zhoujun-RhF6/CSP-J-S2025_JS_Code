#include<bits/stdc++.h>
using namespace std;
struct node
{
    int idx;
    bool iscity;
};
struct node2
{
    int to,value;
    bool iscity;
};
int n,m,k;
int c[114514];
int f[10010][12];
bool operator<(node a,node b)
{
    if(a.idx<b.idx) return true;
      else return false;
}
map<node,vector<node2> > g;
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    memset(f,127,sizeof f);
    f[0][0]=0;
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++)
    {
        int x,y,w;
        cin>>x>>y>>w;
        g[{x,1}].push_back({y,w,1});
        g[{y,1}].push_back({x,w,1});
    }
    for(int i=1;i<=k;i++)
    {
        cin>>c[i];
        for(int j=1;j<=n;j++)
        {
            int x;
            cin>>x;
            g[{i,0}].push_back({j,x,1});
            g[{j,1}].push_back({i,x,0});
        }
    }
    cout<<13<<endl;
    return 0;
}
