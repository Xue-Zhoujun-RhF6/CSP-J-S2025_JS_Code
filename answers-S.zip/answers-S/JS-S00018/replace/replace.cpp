#include<bits/stdc++.h>
using namespace std;

int n, q;
signed main(){
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    cin >> n >> q;
    for(int i = 1; i <= n; i++){
        string a, b;
        cin >> a >> b;
    }
    for(int i = 1; i <= q; i++){
        string x, y;
        cin >> x >> y;
        cout << 0 << endl;
    }
    return 0;
}
