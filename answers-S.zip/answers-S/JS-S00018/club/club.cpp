#include<bits/stdc++.h>
using namespace std;

const int N = 1e5;
int t, n;
struct mem{
    int fa, fb, fc, d, c;
}a[N + 5];
int cnt[N + 5];
int ans = 0;
void dfs(int x, int sum, int cnta, int cntb, int cntc){
    if(x == n + 1){
        ans = max(ans, sum);
        return ;
    }
    if(cnta + 1 <= n / 2) dfs(x + 1, sum + a[x].fa, cnta + 1, cntb, cntc);
    if(cntb + 1 <= n / 2) dfs(x + 1, sum + a[x].fb, cnta, cntb + 1, cntc);
    if(cntc + 1 <= n / 2) dfs(x + 1, sum + a[x].fc, cnta, cntb, cntc + 1);
    return ;
}
bool cmp1(mem x, mem y){
    return x.fa > y.fa;
}
bool cmp2(mem x, mem y){
    if(x.d != y.d) return x.d < y.d;
    return x.fa > y.fa;
}
signed main(){
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    cin >> t;
    while(t--){
        ans = 0;
        bool flag1 = true, flag2 = true;
        cin >> n;
        for(int i = 1; i <= n; i++){
            cin >> a[i].fa >> a[i].fb >> a[i].fc;
            if(a[i].fb!= 0 || a[i].fc != 0) flag1 = false;
            if(a[i].fc != 0) flag2 = false;
        }
        if(flag1){
            sort(a + 1, a + n + 1, cmp1);
            for(int i = 1; i <= n / 2; i++){
                ans += a[i].fa;
            }
            cout << ans << endl;
            continue;
        }
        if(flag2){
                int ca = 0, cb = 0;
            for(int i = 1; i <= n; i++){
                a[i].d = abs(a[i].fa - a[i].fb);
                if(a[i].fa > a[i].fb){
                    a[i].c = 1;
                    ca++;
                }else{
                    a[i].c = 2;
                    cb++;
                }
            }
            if(ca > n / 2){
                sort(a + 1, a + n + 1, cmp2);
                for(int i = 1; i <= n; i++){
                    if(a[i].c == 1){
                        a[i].c = 2;
                        ca--;
                    }
                    if(ca == n / 2) break;
                }
            }else if(cb > n / 2){
                sort(a + 1, a + n + 1, cmp2);
                for(int i = 1; i <= n; i++){
                    if(a[i].c == 2){
                        a[i].c = 1;
                        cb--;
                    }
                    if(cb == n / 2) break;
                }
            }
            for(int i = 1; i <= n; i++){
                if(a[i].c == 2) ans += a[i].fb;
                else ans += a[i].fa;
            }
            cout << ans << endl;
            continue;
        }
        dfs(1, 0, 0, 0, 0);
        cout << ans << endl;
    }
    return 0;
}


