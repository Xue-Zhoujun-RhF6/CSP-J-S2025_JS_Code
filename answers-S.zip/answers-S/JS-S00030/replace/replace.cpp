#include <bits/stdc++.h>
int a;
signed main() {
std::cin >> a >> a;
for (int i = 1; i <= a; ++i)
    std::cout << 0;
}
