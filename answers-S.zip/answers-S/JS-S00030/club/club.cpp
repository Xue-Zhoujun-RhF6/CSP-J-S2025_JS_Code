#include <bits/stdc++.h>
#define int long long
#define max(a, b, c) std::max(a, std::max(b, c))
#define min(a, b, c) std::min(a, std::min(b, c))
int t, n, cnt1, cnt2, cnt3, cnt, cntmp, ans;
struct man {
    int a, b, c;
} m[500005];
signed main() {
    std::freopen("club3.in", "r", stdin), std::freopen("club.out", "w", stdout);
    std::cin >> t;
    while (t--) {
        cnt = cnt1 = cnt2 = cnt3 = ans = 0;
        std::cin >> n;
        for (int i = 1; i <= n; ++i)
            std::cin >> m[i].a >> m[i].b >> m[i].c;
        while (cnt < n) {
            std::sort(m + 1, m + n - cnt + 1, [](man a, man b) {
                return max(a.a, a.b, a.c) > max(b.a, b.b, b.c);
            });
            cntmp = cnt;
            for (int i = 1; i <= n - cnt; ++i) {
                int a = m[i].a, b = m[i].b, c = m[i].c, mx = max(a, b, c);
                if (cnt1 >= n / 2 && mx == a)
                    a = -1;
                if (cnt2 >= n / 2 && mx == b)
                    b = -1;
                if (cnt3 >= n / 2 && mx == c)
                    c = -1;
                if (min(a, b, c) == -1)
                    continue;
                if (max(a, b, c) == a)
                    ++cnt1, ans += a, ++cntmp;
                else if (max(a, b, c) == b)
                    ++cnt2, ans += b, ++cntmp;
                else if (max(a, b, c) == c)
                    ++cnt3, ans += c, ++cntmp;
                m[i] = {-1000, -1000, -1000};
            }
            cnt = cntmp;
        }
        std::cout << ans << '\n';
    }
    return 0;
}
