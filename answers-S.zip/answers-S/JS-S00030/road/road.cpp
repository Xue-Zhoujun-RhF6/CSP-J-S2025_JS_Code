#include <iostream>
#include <set>
#define int long long
int n, m, k, fa[10055], u, v, w, b[15], sum, ok[10055], d[10055], cnt1, cnt2, ans = 0x3f3f3f3f3f3f3f3f;
struct edge{
    int u, v, w;
    friend bool operator < (edge a, edge b) {
        return a.w < b.w;
    }
};
std::set<edge> s;
void myunion(int a, int b) {
    fa[a] = b;
}
int myfind(int a) {
    if (fa[a] == a)
        return a;
    return (fa[a] = myfind(fa[a]));
}
signed main() {
    std::freopen("road2.in", "r", stdin), std::freopen("road.out", "w", stdout);
    std::ios::sync_with_stdio(0), std::cin.tie(0), std::cin >> n >> m >> k;
    for (int i = 0; i < m; ++i)
        std::cin >> u >> v >> w, s.insert({u - 1, v - 1, w});
    for (int i = 0; i < k; ++i) {
        std::cin >> b[i + n];
        for (int j = 0; j < n; ++j)
            std::cin >> w, s.insert({i + n, j, w});
    }
    for (int i = 0; i < n; ++i)
            ok[i] = 1;
    for (int msk = 0; msk < (1 << k); ++msk) {
        sum = 0, cnt1 = n, cnt2 = 0;
        for (int i = 0; i < k; ++i)
            if ((msk >> i) & 1 == 1)
                ok[i + n] = 1, sum += b[i + n], ++cnt1;
            else
                ok[i + n] = 0;
        for (int i = 0; i < n + k; ++i)
            fa[i] = i, d[i] = 0;
        for (edge i : s) {
            if (myfind(i.u) != myfind(i.v) && ok[i.u] && ok[i.v])
                myunion(fa[i.u], fa[i.v]), sum += i.w, ++d[i.u], ++d[i.v], ++cnt2;
            if (cnt2 == cnt1)
                break;
        }

        ans = std::min(ans, sum);
    }
    std::cout << ans;
    return 0;
}
