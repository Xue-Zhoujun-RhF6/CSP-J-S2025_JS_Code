#include <bits/stdc++.h>
using namespace std;
struct man
{
    int a=0,b=0,c=0;
};
man a[100005];
int best(man x)
{
    return max(max(x.a,x.b),x.c);
}
bool cmp(man x,man y)
{
    return best(x)>best(y);
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin >> t;
    for(int m = 1;m<=t;m++)
    {
        int n;
        cin >> n;
        for(int i = 1;i<=n;i++)
            cin >> a[i].a>>a[i].b>>a[i].c;
        sort(a+1,a+n+1,cmp);
        int summ = 0;
        int x=0,y=0,z=0;
        //for(int i = 1;i<=n;i++)
        //{
        //    cout << a[i].a << " " << a[i].b<<" "<<a[i].c<<endl;
        //}
        for(int i = 1;i<=n;i++)
        {
            if(x<n/2&&y<n/2&&z<n/2)
            {
                summ+=best(a[i]);
                if(best(a[i])==a[i].a)
                    x++;
                if(best(a[i])==a[i].b)
                    y++;
                if(best(a[i])==a[i].c)
                    z++;
            }
            else if(x==n/2)
            {
                summ+=max(a[i].b,a[i].c);
            }
            else if(y==n/2)
            {
                summ+=max(a[i].a,a[i].c);
            }
            else if(z==n/2)
            {
                summ+=max(a[i].a,a[i].b);
            }
        }
        cout << summ <<endl;
    }
    return 0;
}
