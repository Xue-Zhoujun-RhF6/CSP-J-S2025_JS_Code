#include <bits/stdc++.h>
using namespace std;
string a[100005],b[100005];
int main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    int n,q;
    cin >> n >> q;
    for(int i = 1;i<=n;i++)
    {
        cin >> a[i] >> b[i];
    }
    for(int i = 1;i<=q;i++)
    {
        string x,y;
        cin >> x >> y;
        int summ = 0;
        for(int j = 1;j<=n;j++)
        {
            if(a[j].length()>x.length())
                continue;
            for(int k = 0;k<=x.length()-a[j].length();k++)
            {
                string x1 =x;
                bool flag=1;
                for(int l = 0;l<a[j].length();l++)
                {
                    if(!x1[l+k]==a[j][l])
                    {
                        flag=0;
                        break;
                    }
                }
                if(flag)
                {
                    for(int l = 0;l<a[j].length();l++)
                    {
                        x1[l+k]=b[j][l];
                    }
                }
                cout << x1<<endl;
                if(x1==y)
                    summ++;
            }
        }
        cout << summ << "\n";
    }
    return 0;
}
