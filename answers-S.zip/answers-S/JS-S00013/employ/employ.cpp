#include <bits/stdc++.h>
using namespace std;
int a[505];
int peo[505];
long long fact(long long x)
{
    if(x > 0)
        return fact(x-1)%998244353*x;
    return 1;
}
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int m ,n;
    cin >> n >> m;
    string t;
    cin >> t;
    int zo=0;
    for(int i = 1;i<=n;i++)
    {
        a[i]=t[i-1]-'0';
        cin >> peo[i];
        if(peo[i]==0)
            zo++;
    }
    int tmp = 0;
    for(int i = 1;i<=n;i++)
    {
        peo[i]-=zo;
        if(peo[i]>0)
            tmp++;
    }
    n = tmp;
    bool flag=1;
    for(int i = 1;i<=n;i++)
        if(!a[i])
            flag=0;
    if(flag) cout << fact(n)%998244353;

    return 0;
}
