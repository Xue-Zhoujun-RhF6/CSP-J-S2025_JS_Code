#include <bits/stdc++.h>
using namespace std;
const int N = 10005;
priority_queue <pair<int,pair<int,int> > > que;
int fa[N];
int dis[N][N],w[N][N],diss[N][N];
int n,m,x,y,z,k;
int isk[20];
long long ans,minans;
int find(int u)
{
    if (fa[u] == u)
    {
        return u;
    }
    else
    {
        fa[u] = find(fa[u]);
    }
    return fa[u];
}
int main()
{

    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    cin >> n >> m >> k;
    if (k == 0)
    {
        for (int i = 1;i <= n;i++)
        {
            fa[i] = i;
        }
        for (int i = 1;i <= m;i++)
        {
            cin >> x >> y >> z;
            que.push({-z,{x,y}});
        }
        while(!que.empty())
        {
            if (find(que.top().second.first) == find(que.top().second.second))
            {
                que.pop();
                continue;
            }
            fa[que.top().second.first] = que.top().second.second;
            ans -= que.top().first;
            que.pop();
        }
        cout << ans;
        return 0;
    }

    for (int a = 1;a <= n;a++)
    {
        for (int b = a+1;b <= n;b++)
        {
            dis[a][b] = INT_MAX;
        }
    }
    //k > 0
    int tp;
    for (int i = 1;i <= m;i++)
    {
        cin >> x >> y >> z;
        if (x > y)
        {
            tp=x;x=y;y=tp;
        }
        dis[x][y] = z;
    }
    for (int i = 1;i <= k;i++)
    {
        for (int j = 0;j <= n;j++)
        {
            cin >> w[i][j];
        }
    }
    ans = 0;minans=LLONG_MAX;
                        //cout << l1 << endl;

                                for (int a = 1;a <= n;a++)
                                {
                                    for (int b = a+1;b <= n;b++)
                                    {
                                        diss[a][b] = dis[a][b];
                                    }
                                }

                        for (int i = 1;i <= n;i++)
                        {
                            fa[i] = i;
                        }
                        for (int a = 1;a <= n;a++)
                        {
                            for (int b = a+1;b <= n;b++)
                            {
                                que.push({-diss[a][b],{a,b}});
                            }
                        }
                        while(!que.empty())
                        {
                            if (find(que.top().second.first) == find(que.top().second.second))
                            {
                                que.pop();
                                continue;
                            }
                            fa[que.top().second.first] = que.top().second.second;
                            ans -= que.top().first;
                            que.pop();
                        }
                        minans = min(minans,ans);

    for (int l1 = 1;l1 <= k;l1++)
    {
        //cout << 1;
        isk[l1] = 1;
        for (int l2 = l1+1;l2 <= k;l2++)
        {
            if (k >= 2)
                isk[l2] = 1;
            else
                l2 = k-1;
            //cout << "aaa";
            for (int l3 = l2+1;l3 <= k;l3++)
            {
                if (k >= 3)
                    isk[l3] = 1;
                else
                    l3 = k-1;
                    //cout << "aaa";
                for (int l4 = l3+1;l4 <= k;l4++)
                {
                    if (k >= 4)
                        isk[l4] = 1;
                    else
                        l4 = k-1;
                    for (int l5 = l4+1;l5 <= k;l5++)
                    {
                        if (k >= 5)
                            isk[l5] = 1;
                        ans = 0;
                        //cout << l1 << endl;
                        for (int j = 1;j <= k;j++)
                        {
                            if (isk[j])
                            {
                                ans += w[j][0];
                                for (int a = 1;a <= n;a++)
                                {
                                    for (int b = a+1;b <= n;b++)
                                    {
                                        diss[a][b] = min(dis[a][b],w[j][a] + w[j][b]);
                                    }
                                }
                            }
                        }

                        for (int i = 1;i <= n;i++)
                        {
                            fa[i] = i;
                        }
                        for (int a = 1;a <= n;a++)
                        {
                            for (int b = a+1;b <= n;b++)
                            {
                                que.push({-diss[a][b],{a,b}});
                            }
                        }
                        while(!que.empty())
                        {
                            if (find(que.top().second.first) == find(que.top().second.second))
                            {
                                que.pop();
                                continue;
                            }
                            fa[que.top().second.first] = que.top().second.second;
                            ans -= que.top().first;
                            que.pop();
                        }
                        minans = min(minans,ans);
                        isk[l1]=0;isk[l2]=0;isk[l3]=0;isk[l4]=0;isk[l5]=0;

                    }

                }

            }

        }

    }
    cout << minans;

    return 0;
}
