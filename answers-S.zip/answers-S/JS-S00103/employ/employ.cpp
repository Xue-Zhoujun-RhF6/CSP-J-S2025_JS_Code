#include <bits/stdc++.h>
using namespace std;
const int MOD = 998244353;
char s[505];
int n,m;
int vis[505],c[505];
long long ans = 0;
void dfs(int p,int a,int b)//a 未录取
{
    if (p == n+1)
    {
        //cout << b << endl;
        if (b >= m)
        {
            ans++;
            ans %= MOD;
        }
        return;
    }
    for (int i = 1;i <= n;i++)
    {
        if (vis[i])
            continue;
        vis[i] = 1;
        //cout << p << " " << i << " " << endl;
        if (s[p] == '1' && c[i] > a)
        {
            dfs(p+1,a,b+1);
            //cout << s[i] << endl;
        }
        else
        {
            dfs(p+1,a+1,b);
        }
        vis[i] = 0;
    }
}
int main()
{

    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    cin >> n >> m;
    cin >> (s + 1);
    for (int i = 1;i <= n;i++)
    {
        cin >> c[i];
    }
    dfs(1,0,0);
    cout << ans;
    /*
    sort(c+1,c+n+1);
    for (int i = 1;i <= m;i++)
    {
        for (int j = 1;j <= n;j++)
        {
            if (i <= c[j])
            {
                d[i]++;
            }
        }
    }
    */
    return 0;
}
