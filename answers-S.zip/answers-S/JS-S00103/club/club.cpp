#include <bits/stdc++.h>
using namespace std;
const int N = 100005;
int a[N][5];
priority_queue <pair<int,int> > a1,a2,a3;
int n,t,cmax[5],amax[N][5],dea[N];
long long ans;
bool cmp(int a,int b)
{
    return a > b;
}
void addmax(int i)
{
    if (a[i][1] == a[i][2] && a[i][1] == a[i][3])
    {
        amax[i][1] = 1;amax[i][2] = 1;amax[i][3] = 1;
        cmax[1]++;cmax[2]++;cmax[3]++;
        return;
    }
    if (a[i][1] == a[i][2] && a[i][1] > a[i][3])
    {
        amax[i][1] = 1;amax[i][2] = 1;
        cmax[1]++;cmax[2]++;
        return;
    }
    if (a[i][1] == a[i][3] && a[i][1] > a[i][2])
    {
        amax[i][1] = 1;amax[i][3] = 1;
        cmax[1]++;cmax[3]++;
        return;
    }
    if (a[i][2] == a[i][3] && a[i][2] > a[i][1])
    {
        amax[i][2] = 1;amax[i][3] = 1;
        cmax[2]++;cmax[3]++;
        return;
    }
    if (a[i][1] > a[i][2] && a[i][1] > a[i][3])
    {
        amax[i][1] = 1;
        cmax[1]++;
        return;
    }
    if (a[i][2] > a[i][1] && a[i][2] > a[i][3])
    {
        amax[i][2] = 1;
        cmax[2]++;
        return;
    }
    if (a[i][3] > a[i][1] && a[i][3] > a[i][2])
    {
        amax[i][3] = 1;
        cmax[3]++;
        return;
    }
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    cin >> t;
    while(t--)
    {
        memset(a,0,sizeof(a));memset(amax,0,sizeof(amax));
        memset(cmax,0,sizeof(cmax)); memset(dea,0,sizeof(dea));
        n = 0;ans = 0;
        //cout << " " << cmax[1] << endl;
        cin >> n;
        int nn = n/2;
        for (int i = 1;i <= n;i++)
        {
            cin >> a[i][1] >> a[i][2] >> a[i][3];
            addmax(i);
        }

        for (int i = 1;i <= n;i++)
        {
            for (int j = 1;j <= 3;j++)
            {
                if (amax[i][j])
                {
                    ans += a[i][j];
                    break;
                }
            }
        }
        //cout << endl << cmax[1] << endl << cmax[2] << endl << cmax[3] << endl << ans << endl << endl;
        if (cmax[1] <= nn && cmax[2] <= nn && cmax[3] <= nn)
        {
            cout << ans << endl;
            continue;
        }
        if (cmax[1] > nn)//1
        {
            for (int i = 1;i <= n;i++)
            {
                if (!amax[i][1])
                    dea[i] = -INT_MAX;
                else
                    dea[i] = max(a[i][2] - a[i][1],a[i][3] - a[i][1]);
            }
            sort(dea + 1,dea + n + 1,cmp);
            for (int i = 1;i <= cmax[1]-nn;i++)
            {
                //cout << " " <<dea[i] << " " << endl;
                ans += dea[i];
            }
            cout << ans << endl;
            continue;
        }
        if (cmax[2] > nn)//2
        {
            for (int i = 1;i <= n;i++)
            {
                if (!amax[i][2])
                    dea[i] = -INT_MAX;
                else
                    dea[i] = max(a[i][1] - a[i][2],a[i][3] - a[i][2]);
            }
            sort(dea + 1,dea + n + 1,cmp);
            for (int i = 1;i <= cmax[2]-nn;i++)
            {
                //cout << " " <<dea[i] << " " << endl;
                ans += dea[i];
            }
            cout << ans << endl;
            continue;
        }
        if (cmax[3] > nn)//3
        {
            for (int i = 1;i <= n;i++)
            {
                if (!amax[i][3])
                    dea[i] = -INT_MAX;
                else
                    dea[i] = max(a[i][1] - a[i][3],a[i][2] - a[i][3]);
            }
            sort(dea + 1,dea + n + 1,cmp);
            for (int i = 1;i <= cmax[3]-nn;i++)
            {
                //cout << " " <<dea[i] << " " << endl;
                ans += dea[i];
            }
            cout << ans << endl;
            continue;
        }
    }
    return 0;
}
