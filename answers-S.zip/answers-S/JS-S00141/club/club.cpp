#include<bits/stdc++.h>
using namespace std;
long long t,n;
long long ans;
long long a[500086][5];
vector<int> d,b,c;
void dfs(vector<int> x,vector<int> y,vector<int> z,int k){
    if(x.size()>n/2||y.size()>n/2||z.size()>n/2)return;
    if(k==n+1){
        long long sum=0;
        for(auto i:x)sum+=i;
        for(auto i:y)sum+=i;
        for(auto i:z)sum+=i;
        ans=max(ans,sum);
        return;
    }
    vector<int> xx,yy,zz;
    xx=x,yy=y,zz=z;
    xx.push_back(a[k][1]);
    dfs(xx,yy,zz,k+1);
    xx=x;
    yy.push_back(a[k][2]);
    dfs(xx,yy,zz,k+1);
    yy=y;
    zz.push_back(a[k][3]);
    dfs(xx,yy,zz,k+1);
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%lld",&t);
    while(t--){
        scanf("%lld",&n);
        for(auto i=1;i<=n;i++){
            scanf("%lld%lld%lld",&a[i][1],&a[i][2],&a[i][3]);
        }
        ans=0;
        dfs(d,b,c,1);
        printf("%lld\n",ans);
    }
    return 0;
}
