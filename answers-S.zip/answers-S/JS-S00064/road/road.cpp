#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+5;
int n,m,k,f[N];
struct node{
    int u,v,w;
    bool operator < (const node &x)  const {
        return w<x.w;
    }
}e[N];
void init() {
    for(int i=1; i<=n; i++) f[i]=i;
}

int fd(int x) {
    return f[x] = (f[x]==x)?x:fd(f[x]);
}

void mg(int x,int y) {
    f[fd(x)]=fd(y);
}
long long ans;
int main() {
    freopen("road.in", "r", stdin);
    freopen("road.out","w",stdout);

    cin >> n >> m >> k;
    if(k!=0) {
        cout << 0 << endl;
        return 0;
    }
    init();

    for(int i=1; i<=m; i++) cin >> e[i].u>>e[i].v>>e[i].w;
    sort(e+1,e+m+1);
    for(int i=1; i<=m; i++) {
        int u=e[i].u,v=e[i].v,w=e[i].w;
        if(fd(u)==fd(v)) continue;
        mg(u,v);
        ans+=e[i].w;
    }
    cout << ans << endl;
    return 0;
}
/*
5 7 0
1 2 1
1 3 6
1 4 8
1 5 7
2 3 4
2 4 5
4 5 9

*/
