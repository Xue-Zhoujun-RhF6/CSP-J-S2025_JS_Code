#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int t,n,cnta,cntb,cntc;
long long ans;
struct node {
    int a,b,c,d,idx;
    bool operator < (const node& x) const {
        return d<x.d;
    }
}p[N];
int main() {
    freopen("club.in", "r", stdin);
    freopen("club.out","w",stdout);
    cin >> t;
    while(t--) {
        cnta=cntb=cntc=0;
        ans=0;
        cin >> n;
        for(int i=1; i<=n; i++) {
            cin >> p[i].a >> p[i].b >> p[i].c;
            p[i].d=0;
            int mx=max(p[i].a, max(p[i].b,p[i].c) );
            if(mx == p[i].a) {
                //a
                p[i].d=p[i].a-max(p[i].b,p[i].c);
                cnta++,ans+=p[i].a,p[i].idx=1;

            }else if(mx == p[i].b) {
                //b
                p[i].d=p[i].b-max(p[i].a,p[i].c);
                cntb++,ans+=p[i].b,p[i].idx=2;

            }else {
                //c
                p[i].d=p[i].c-max(p[i].b,p[i].a);
                cntc++,ans+=p[i].c,p[i].idx=3;

            }
        }
        int cntmx=max(cnta,max(cntb,cntc));
        if(cntmx <=n/2) {
            cout << ans << endl;
        }else {
            sort(p+1,p+n+1);
            if(cntmx == cnta) {
                for(int i=1; i<=n&&cnta > n/2; i++) {
                    if(p[i].idx==1) cnta--,ans-=p[i].d;
                }
            }else if(cntmx==cntb) {
                for(int i=1; i<=n&&cntb > n/2; i++) {
                    if(p[i].idx==2) cntb--,ans-=p[i].d;
                }
            }else {
                for(int i=1; i<=n&&cntc > n/2; i++) {
                    if(p[i].idx==3) cntc--,ans-=p[i].d;
                }
            }
            cout << ans << endl;
        }
    }
    return 0;
}
