#include<bits/stdc++.h>
using namespace std;
const int N=5e6+5;
int fd(string a,string b) {
    if(a.length() < b.length()) return -1;
    int alen=a.length(),blen=b.length();
    for(int i=0; i+blen<=alen; i++) {
        for(int j=0; j<blen;j++) {
            if(a[i+j]!=b[j]) break;
            return i;
        }
    }
    return -1;
}
string rep(string a,string b,int idx) {
    int blen=b.length();
    for(int i=idx; i<idx+blen; i++) {
        a[i]=b[i-idx];
    }
    return a;
}
int n,q;
string t1,t2,s1[N],s2[N];
int main() {
    freopen("replace.in", "r", stdin);
    freopen("replace.out","w",stdout);
    //cout << rep("xabcx","xadex",fd("xabcx","xabcx")) <<' ' << fd("xadex","de") << endl;
    cin >> n >> q;
    for(int i=1; i<=n; i++) cin >> s1[i] >> s2[i];
    for(int i=1; i<=q; i++) {
        cin >> t1 >> t2;
        int len=t1.length();
        long long ans=0;
        for(int j=1; j<=n; j++) {
            int a=fd(t1,s1[j]);
            int b=fd(t2,s2[j]);
            int slen=s1[j].length();
            if(a==b&&a!=-1) {
                //cout << rep(t1,s2[j],a) << ' ' << s1[j] << endl;
                if(rep(t1,s2[j],a)==t2) ans++;
            }
        }
        cout << ans << endl;
    }
    return 0;
}
