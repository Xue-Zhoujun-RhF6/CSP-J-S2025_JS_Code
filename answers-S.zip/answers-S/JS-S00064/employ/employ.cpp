#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=505;
const ll P=998244353;
int n,m,s[N],c[N],fc[N];
bool vis[N];
long long ans;

void dfs(int idx, ll cnt, ll q, ll t) {
    if(idx > n) {
        if(cnt>=m) ans+=fc[t];
        ans%=P;
        return;
    }
    if(s[idx]==0) {
        dfs(idx+1,cnt,q+1,t+1);
        return;
    }
    for(int i=1; i<=n; i++) {
        if(vis[i]) continue;
        vis[i]=1;
        if(q>=c[i]) dfs(idx+1,cnt,q+1,t);
        else dfs(idx+1,cnt+1,q,t);
        vis[i]=0;
    }
}

int main() {
    fc[0]=1;
    for(int i=1; i<=100; i++)fc[i]=fc[i-1]*i,fc[i]%=P;
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin >> n>>m;
    ll cnt1=0;
    for(int i=1; i<=n; i++) {
        char x;cin>>x;
        s[i]=x-'0';
    }
    if(m==n) {
        if(cnt1<n) cout << 0;
        else {
            ll res=1;
            for(int i=1; i<=n; i++)
                res*=i,res%=P;
            cout << res;
        }
        return 0;
    }

    for(int i=1; i<=n; i++) cin >> c[i];
    dfs(1,0,0,0);
    cout << ans << endl;
    return 0;
}
