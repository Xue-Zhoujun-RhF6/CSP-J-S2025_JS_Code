#include<bits/stdc++.h>
using namespace std;
int t,n;
long long ans=0;
int a[100010][4];
struct club
{
    int num;
    int f;
};
bool cmp(club x,club y)
{
    if(x.f!=y.f) return x.f<y.f;
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--)
    {
        ans=0;
        cin>>n;
        club a1[210],a2[210],a3[210];
        int cnt1=0,cnt2=0,cnt3=0;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=3;j++)
            {
                scanf("%d",&a[i][j]);
            }
        }
        for(int i=1;i<=n;i++)
        {
            int maxn=max((a[i][1],a[i][2]),a[i][3]);
            if(cnt1<n/2&&cnt2<n/2&&cnt3<n/2)
            {
               ans+=maxn;
               if(maxn==a[i][1])
               {
                   a1[++cnt1].f=a[i][1];
                   a1[cnt1].num=i;
               }
               if(maxn==a[i][2])
               {
                   a2[++cnt2].f=a[i][2];
                   a2[cnt2].num=i;
               }
               if(maxn==a[i][3])
               {
                   a3[++cnt3].f=a[i][3];
                   a3[cnt3].num=i;
               }
            }
            else
            {
                if(cnt1>=n/2&&maxn==a[i][1])
                {
                    sort(a1+1,a1+cnt1+1,cmp);
                    int p=a1[1].num;
                    int s=ans;
                    ans=max(ans-a[p][1]+max(a[p][2],a[p][3])+a[i][1],ans+max(a[i][2],a[i][3]));
                    if(s-a[p][1]+max(a[p][2],a[p][3])+a[i][1]>s+max(a[i][2],a[i][3]))
                       {
                           a1[p].f=a[i][1];
                           a1[p].num=i;
                       }
                }
                 if(cnt2>=n/2&&maxn==a[i][2])
                {
                    sort(a2+1,a2+cnt2+1,cmp);
                    int p=a2[1].num;
                    int s=ans;
                    ans=max(ans-a[p][2]+max(a[p][1],a[p][3])+a[i][2],ans+max(a[i][1],a[i][3]));
                    if(s-a[p][2]+max(a[p][1],a[p][3])+a[i][2]>s+max(a[i][1],a[i][3]))
                       {
                           a2[p].f=a[i][2];
                           a2[p].num=i;
                       }
                }
                 if(cnt3>=n/2&&maxn==a[i][3])
                {
                    sort(a3+1,a3+cnt3+1,cmp);
                    int p=a3[1].num;
                    int s=ans;
                    ans=max(ans-a[p][3]+max(a[p][2],a[p][1])+a[i][3],ans+max(a[i][2],a[i][1]));
                    if(s-a[p][3]+max(a[p][1],a[p][2])+a[i][3]>s+max(a[i][1],a[i][2]))
                       {
                           a3[p].f=a[i][3];
                           a3[p].num=i;
                       }
                }
                else
                {
                    ans+=maxn;
                }
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}
