#include<bits/stdc++.h>
using namespace std;
int const N=998244353;
int n,m;
long long ans=1;
string s;
int a[505];
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++) scanf("%d",&a[i]);
    for(int i=1;i<=n;i++)
    {
        ans=(ans*i)%N;
    }
    cout<<ans;
    return 0;
}
