#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int dp[10010][10010];
int t[10010];
int ans=0;
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++)
    {
        int x,y,p;
        scanf("%d %d %d",&x,&y,&p);
        dp[x][y]=p;
        dp[y][x]=p;
        ans+=p;
    }
    for(int i=1;i<=k;i++)
    {
        int r;
        cin>>r;
        for(int i=1;i<=n;i++)
        {
            scanf("%d",&t[i]);
        }
    }
    cout<<ans;
    return 0;
}
