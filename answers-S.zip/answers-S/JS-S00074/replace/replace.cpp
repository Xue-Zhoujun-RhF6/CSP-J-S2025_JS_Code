#include <bits/stdc++.h>
using namespace std;

int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    //bie xiao wo wo shi zai bu hui le!!!
}
