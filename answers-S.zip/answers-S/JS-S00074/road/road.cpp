#include  <bits/stdc++.h>
using namespace std;
int n,m,k;
vector<int> vec[10005];

int main(){
    freopen("road.in","r",stdin);
    freopen("rode.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        int u,v,w;
        cin>>u>>v>>w;
        vec[u].push_back(v);
        vec[v].push_back(u);
    }
    for(int i=1;i<=kn;i++){
        for(int j=1;j<=n+1;j++){
            int a;
            cin>>a;
        }

    }

}
