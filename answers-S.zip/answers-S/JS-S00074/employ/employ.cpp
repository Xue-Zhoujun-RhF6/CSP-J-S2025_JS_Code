#include <bits/stdc++.h>
using namespace std;

int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    //bie xiao wo wo shi zai bu hui le!!!
}
