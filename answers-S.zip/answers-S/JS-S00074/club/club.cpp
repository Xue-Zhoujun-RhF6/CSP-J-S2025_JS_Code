#include <bits/stdc++.h>
using namespace std;
struct Node{
    int a1;
    bool f=1;
}a[100005],b[100005],c[100005];
bool cmp(Node x,Node y){
    return x.a1>y.a1;
}

int T;
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>T;
    while(T--){
        int n;
        cin>>n;
        for(int i=1;i<=n;i++){
            cin>>a[i].a1>>b[i].a1>>c[i].a1;
        }
        int sum=0;
        sort(a+1,a+1+n,cmp);
        sort(b+1,b+1+n,cmp);
        sort(c+1,c+1+n,cmp);
        int x=1,y=1,z=1;
        int x1=0,y1=0,z1=0;
        for(int i=1;i<=n;i++){
            if(x1>n)x=0;
            if(y1>n)y=0;

            if(z1>n)z=0;
            int aa=a[x].a1;
            int bb=b[y].a1;
            int cc=c[z].a1;
            if(a[x].f==0){x++;n++;continue;}
            if(b[y].f==0){y++;n++;continue;}
            if(c[z].f==0){z++;n++;continue;}
            if(aa>bb&&aa>cc){
                sum+=aa;
                x++;
            }
            else if(bb>aa&&bb>cc){
                sum+=bb;
                y++;
            }
            else z++,sum+=cc;

        }
        cout<<sum<<endl;

    }

    return 0;
}
