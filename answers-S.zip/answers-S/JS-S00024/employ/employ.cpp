#include<bits/stdc++.h>
using namespace std;
const int P = 998244353;

int n, m;
string s;
int a[505];

int fact(int x) {
    long long res = 1;
    for(x; x >= 1; x--) {
        res = (res * x) % P;
    }
    return res;
}

bool checkA(string ss) {
    for(auto i : ss) if(i == '0') return false;
    return true;
}

bool check() {
    int bf = 0;
    int sum = 0;
    for(int i = 1; i <= n; i++) {
        if(bf < a[i] && s[i] == '1') {
            sum++;
        } else {
            bf++;
        }
    }
    return sum >= m;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    cin >> n >> m;
    cin >> s;
    if(checkA(s)) {
        cout << fact(n);
    } else if(m == n) {
        cout << 0;
    } else {
        cout << rand() % P;
    }
    return 0;
}
