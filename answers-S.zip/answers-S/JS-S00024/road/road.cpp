#include<bits/stdc++.h>
using namespace std;

int n, m, k; 
vector<pair<int, long long> > g[10015];
vector<long long> cnt[15];
long long ans;
int z;
bool f[15];
struct edge {
    int u, v;
    long long w;
    bool operator<(const edge& a) const {
        return w > a.w;
    }
};

int fa[10015];
int find_fa(int a) {
    return fa[a] == a? a : fa[a] = find_fa(fa[a]);
}
void unite(int a, int b) {
    a = find_fa(a), b = find_fa(b);
    fa[a] = b;
}
bool check(int a, int b) {
    return find_fa(a) == find_fa(b);
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    cin >> n >> m >> k;
    for(int i = 1; i <= n + k; i++) {
        fa[i] = i;
    }
    for(int i = 1; i <= m; i++) {
        int u, v;
        long long w;
        cin >> u >> v >> w;
        g[u].push_back({v, w});
        g[v].push_back({u, w});
    }
    for(int i = 1; i <= k; i++) {
        int u = i + n;
        long long c;
        cin >> c;
        for(int v = 1; v <= n; v++) {
            long long w;
            cin >> w;
            g[u].push_back({v, w});
            g[v].push_back({u, w + c});
        }
    }
    priority_queue<edge> q;
    for(auto i : g[1]) {
        q.push({1, i.first, i.second});
    }
    while(!q.empty()) {
        edge e = q.top();
        q.pop();
        if(check(e.u, e.v)) continue;
        // cout << e.u << ' ' << e.v << ' ' << e.w << '\n';
        unite(e.u, e.v);
        if(e.v <= n) z++;
        ans += e.w;
        if(e.u > n) f[e.u - n] = 1;
        if(e.v > n) cnt[e.v - n].push_back(e.w);
        if(z == n) break;
        for(auto i : g[e.v]) {
            if(!check(e.v, i.first)) q.push({e.v, i.first, i.second});
        }
    }
    for(int i = 1; i <= k; i++) {
        if(!f[i]) {
            ans -= cnt[i][0];
        }
    }
    cout << ans;
    return 0;
}
