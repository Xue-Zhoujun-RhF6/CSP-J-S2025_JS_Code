#include<bits/stdc++.h>
using namespace std;

void solve() {
    int n = 0;
    int a1 = 0, a2 = 0, a3 = 0, n1 = 0, n2 = 0, n3 = 0, nn = 0;
    long long sum = 0;
    vector<long long> v, v1, v2, v3;
    cin >> n;
    for(int i = 1; i <= n; i++) {
        cin >> a1 >> a2 >> a3;
        sum += max({a1, a2, a3});
        if(a1 >= a2 && a2 >= a3) {
            n1++;
            v1.push_back(a1 - a2);
        } else if(a1 >= a3 && a3 >= a2) {
            n1++;
            v1.push_back(a1 - a3);
        } else if(a2 >= a1 && a1 >= a3) {
            n2++;
            v2.push_back(a2 - a1);
        } else if(a2 >= a3 && a3 >= a1) {
            n2++;
            v2.push_back(a2 - a3);
        } else if(a3 >= a2 && a2 >= a1) {
            n3++;
            v3.push_back(a3 - a2);
        } else if(a3 >= a1 && a1 >= a2) {
            n3++;
            v3.push_back(a3 - a1);
        }
    }
    if(n1 >= n2 && n1 >= n3) {
        v = v1;
        nn = n1;
    } else if(n2 >= n1 && n2 >= n3) {
        v = v2;
        nn = n2;
    } else if(n3 >= n1 && n3 >= n2) {
        v = v3;
        nn = n3;
    }
    sort(v.begin(), v.end());
    for(int i = 0; i < nn - (n >> 1); i++) {
        sum -= v[i];
    }
    cout << sum << '\n';
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    int t; cin >> t;
    while(t--) solve();
    return 0;
}
