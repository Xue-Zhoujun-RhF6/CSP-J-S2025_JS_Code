#include<bits/stdc++.h>
using namespace std;

int n, q;

void solve1() {
    string s[200005][3];
    for(int i = 1; i <= n; i++) {
        cin >> s[i][1] >> s[i][2];
    }
    while(q--) {
        string t1, t2;
        cin >> t1 >> t2;
        int m = t1.length();
        if(t1.length() != t2.length()) {
            cout << "0\n";
            continue;
        }
        int ans = 0;
        for(int k = 1; k <= n; k++) {
            int nn = s[k][1].length();
            for(int j = 0; j <= m - nn; j++) {
                bool f = 1;
                for(int i = 0; i < j; i++)
                    if(t1[i] != t2[i]) {
                        f = 0;
                        break;
                    }
                for(int i = j + nn; i < m; i++)
                    if(t1[i] != t2[i]) {
                        f = 0;
                        break;
                    }
                for(int i = 0; i < nn; i++) {
                    if(s[k][1][i] != t1[j + i] || s[k][2][i] != t2[j + i]) {
                        f = 0;
                        break;
                    }
                }
                if(f) {
                    ans++;
                    break;
                }
            }
        }
        cout << ans << '\n';
    }
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    cin >> n >> q;
    solve1();
    return 0;
}
