#include<bits/stdc++.h>
using namespace std;

int main() {
    freopen("road.in",r,stdin);
    freopen("road.out",w,stdout);
    cin.tie(0);
    cout.tie(0);
    int n,m,k;
    cin >> n >> m >> k;
    for (int i = 1;i <= n;i++) {
        int t1,t2,t3;
        cin >> t1,t2,t3;

    }
    for (int i = 1;i <=m+1;i++) {
            for (int j = 1;j <= n+1;j++) {
                int u;
        cin >> u;
            }

    }
    cout << 0;





    return 0;
}
