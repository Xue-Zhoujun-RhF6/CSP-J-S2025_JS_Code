#include <bits/stdc++.h>
using namespace std;
int n,a[109000]={0},b[100090]={0},c[100090]={0};

int main() {
    freopen("club.in",r,stdin);
    freopen("club.out",w,stdout);
    cin.tie(0);
    cout.tie(0);
    int an=0,bn=0,cn=0,t;
    //int n,a[100900],b[100090],c[100090],t;
    long long ans = 0;
    cin >> t;
    while(t--) {
        an=bn=cn=0;
        cin >> n;
        for (int i = 0;i < n;i++) {
            cin >> a[i] >> b[i] >> c[i];
            int temp = max(c[i],max(a[i],b[i]));
            if (temp == a[i]) {
                if(an * 2 < n) {
                    ans+=a[i];
                    an++;
                }
                else {
                    int min1 = 100009999;
                    int key = 0;
                    for(int j = 0;j < i;j++) {
                        if(a[j] < min1) {
                            min1 = a[j];
                            key = j;
                        }

                    }
                    int min2=max((a[key],b[key]),c[key]);
                    if(min2==a[key]) {
                        if(min2>a[i]+b[key]||min2>a[i]+c[key]) {
                            if(a[i] <= min2){
                                ans+=min2;
                                a[key] = 100009999;
                            }
                        }
                        if (a[i] > min2) {
                            ans = ans+a[i]-a[key];
                        }
                    }
                    else if(min2==b[key]) {
                            bn++;
                            ans=a[i]+b[key]+ans-a[key];
                    }
                    else if(min2==c[key]) {
                            cn++;
                            ans=a[i]+c[key]+ans-a[key];
                    }
                }
            }
            if (temp == b[i]) {
                if(bn * 2 < n) {
                    ans+=b[i];
                    bn++;
                }
                else {
                    int min1 = 100009999;
                    int key = 0;
                    for(int j = 0;j < i;j++) {
                        if(b[j] < min1) {
                            min1 = b[j];
                            key = j;
                        }

                    }
                    int min2=max((a[key],b[key]),c[key]);
                    if(min2==b[key]) {
                        if(min2>b[i]+a[key]||min2>b[i]+c[key]) {
                            if(b[i] <= min2){
                                ans+=min2;
                                b[key] = 100009999;
                            }
                        }
                        if (b[i] > min2) {
                            ans = ans+b[i]-b[key];
                        }
                    }
                    else if(min2==a[key]) {
                            an++;
                            ans=b[i]+a[key]+ans-b[key];
                    }
                   else if(min2==c[key]) {
                            cn++;
                            ans=b[i]+c[key]+ans-b[key];
                    }
                }
            }
            if (temp == c[i]) {
                if(cn * 2 < n) {
                    ans+=c[i];
                    cn++;
                }
                else {
                    int min1 = 100009999;
                    int key = 0;
                    for(int j = 0;j < i;j++) {
                        if(c[j] < min1) {
                            min1 = c[j];
                            key = j;
                        }

                    }
                    int min2=max((a[key],b[key]),c[key]);

                    if(min2==c[key]) {
                        if(min2>=c[i]+b[key]||min2>=c[i]+a[key]) {
                            if(c[i] <= min2){
                                ans+=min2;
                                c[key] = 100009999;
                            }
                        }
                        if (c[i] > min2) {
                            ans = ans+c[i]-c[key];
                        }
                    }
                    else if(min2==b[key]) {
                            bn++;
                            ans=c[i]+b[key]+ans-c[key];
                    }
                    else if(min2==a[key]) {
                            cn++;
                            ans=c[i]+a[key]+ans-c[key];
                    }
                }
            }

        }

        cout << ans << "\n";
        ans = 0;
    }


    return 0;
}
