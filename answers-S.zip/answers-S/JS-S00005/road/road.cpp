#include<bits/stdc++.h>
#define i64 long long 
using namespace std;

const int subN=1e3+10,N=1e4+10,maxn=2e6+10;

int n,m,k,cnt=0;
i64 ans=0;
int a[20][N],c[20],head[N],fa[N],dis[subN][subN];

struct node{
    int val,to,cost,nxt;
}edge[maxn];

bool operator <(const node &x,const node &y){
    return x.cost<y.cost;
}

void add(const int &u,const int &v,const int &w){
    for(int i=head[u];i;i=edge[i].nxt){
        int nowv=edge[i].to;
        if(nowv==v){
            edge[i].cost=min(edge[i].cost,w);
            return ;
        }
    }
    edge[++cnt]={u,v,w,head[u]},head[u]=cnt;
    return ;
}

int find(int x){
    if(fa[x]==x) return x;
    return fa[x]=find(fa[x]);
}

void merge(const int &u,const int &v){
    int fu=find(u),fv=find(v);
    if(fu!=fv) fa[fv]=fu;
    return ;
}

int getedge(const int &u,const int &v){
    for(int i=head[u];i;i=edge[i].nxt){
        int nowv=edge[i].to;
        if(nowv==v) return i;
    }
    return 0;
}

inline void work(int x){
    for(int i=1;i<=n;i++)
        for(int j=i+1;j<=n;j++){
            int nw=a[x][i]+a[x][j];
            if(a[x][i]+a[x][j]);
        }
    return ;
}

inline void subtask1(){
    memset(dis,0x3f,sizeof dis);
    for(int i=1;i<=cnt;i++){
        int u=edge[i].val,v=edge[i].to,w=edge[i].cost;
        dis[u][v]=w;
    } 
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            for(int k=1;k<=n;k++) dis[i][j]=dis[i][j]<(dis[i][k]+dis[k][j])?dis[i][j]:(dis[i][k]+dis[k][j]);
    for(int i=1;i<=k;i++) work(i);
}

inline void kruskal(){
    for(int i=1;i<=n+k;i++) fa[i]=i;
    sort(edge+1,edge+1+(m<<1));
    for(int i=1;i<=(m<<1);i++){
        int u=edge[i].val,v=edge[i].to,w=edge[i].cost;
        int fu=find(u),fv=find(v);
        if(fu!=fv){
            merge(u,v); ans+=w;
        }
    }
    return ;
}

int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        int u,v,w; cin>>u>>v>>w;
        add(u,v,w); add(v,u,w);
    }
    for(int i=1;i<=k;i++){
        cin>>c[i]; 
        for(int j=1;j<=n;j++) cin>>a[i][j];
    }
    // for(int i=1;i<=k;i++) work(i);
    if(k==0){
        kruskal();
        cout<<ans<<'\n';
        return 0;
    }
    if(n<=1000){
        subtask1();
    }
    kruskal();
    cout<<ans<<'\n';
    return 0;
}