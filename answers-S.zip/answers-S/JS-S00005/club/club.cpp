#include<bits/stdc++.h>
#define int long long 
using namespace std;

const int N=1e5+10;

int T,n,ans=0;
int a[N][4];
vector<int> vec[4]; 

struct nodeq{
    int val,pos,pos1;  
};

bool operator <(const nodeq &x,const nodeq &y){
    return x.val<y.val;
}

int findmx(int x,int p){
    int mx=0,pos=0;
    for(int i=1;i<=3;i++){
        if(i==p) continue;
        if(a[x][i]>mx){
            mx=a[x][i];
            pos=i;
        }
    }
    return pos;
}

int getother(int x,int y){
    int isused[4]; 
    memset(isused,0,sizeof isused);
    isused[x]=true,isused[y]=true;
    for(int i=1;i<=3;i++) 
        if(!isused[i]) return i;
    return 0;
}

void solve(int x,vector<int> b){
    priority_queue<nodeq> q;
    for(int i=0;i<b.size();i++){
        int cur=b[i],p=findmx(cur,x);
        q.push({-a[cur][x]+a[cur][p],cur,p});
    }
    int now=0;
    while(now<b.size()-(n>>1)){
        auto cur=q.top(); q.pop();
        if(vec[cur.pos1].size()>=(n>>1)){
            int oth=getother(x,cur.pos1);
            q.push({-a[cur.pos][x]+a[cur.pos][oth],cur.pos,oth});
        }
        else{
            vec[cur.pos1].push_back(cur.pos);
            ans+=cur.val; now++;
        }
    }
    return ;
}

void _init(){
    ans=0;
    for(int i=1;i<=3;i++) vec[i].clear();
    return ;
}

void work(){
    cin>>n; _init();
    for(int i=1;i<=n;i++)
        for(int j=1;j<=3;j++) cin>>a[i][j];
    for(int i=1;i<=n;i++) vec[findmx(i,0)].push_back(i);
    for(int i=1;i<=n;i++) ans+=a[i][findmx(i,0)];
    for(int i=1;i<=3;i++)
        if(vec[i].size()>(n>>1)) solve(i,vec[i]);
    cout<<ans<<'\n';
    return ;
}

signed main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    cin>>T;
    while(T--) work();
    return 0;
}