#include<bits/stdc++.h>
using namespace std;

const int N=510;

int n,m,ans=0;
string s;
int c[N],a[N];

int check(){
    int now=0,res=0;
    for(int i=1;i<=n;i++){
        int cur=a[i];
        if(c[cur]<=now) now++;
        else{
            if(s[i]=='0') now++;
            else res++;
        }
    }
    // cout<<res<<'\n';
    return res>=m;
}

void subtask1(){
    for(int i=1;i<=n;i++) a[i]=i;
    do{
        ans+=check();
        // for(int i=1;i<=n;i++) cout<<a[i]<<" \n"[i==n];
    }while(next_permutation(a+1,a+1+n));
    cout<<ans<<'\n';
    return ;
}

int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    cin>>n>>m>>s; s=" "+s;
    for(int i=1;i<=n;i++) cin>>c[i];
    if(n<=100){
        subtask1();
        return 0;
    }
    return 0;
}