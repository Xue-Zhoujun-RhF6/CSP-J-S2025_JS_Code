#include<bits/stdc++.h>
#define pss pair<string,string>
#define fi first
#define se second 
using namespace std;

const int N=2e5+10;

int n,q,ans=0;
pss s[N],t;

inline void subtask1(){
    ans=0;
    for(int i=1;i<=n;i++){
        int len=s[i].fi.size();
        if(len>t.fi.size()) continue;
        for(int j=0;j<t.fi.size()-len+1;j++){
            string tmp=t.fi,now=t.fi.substr(j,len);
            if(now!=s[i].fi) continue;
            for(int k=j;k<j+len;k++) tmp[k]=s[i].se[k-j];
            if(tmp==t.se) ans++;
        }
    }
    cout<<ans<<'\n';
    return ;
}

int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    cin>>n>>q;
    for(int i=1;i<=n;i++) cin>>s[i].fi>>s[i].se;
    while(q--){
        cin>>t.fi>>t.se;
        // if(n<=1000){
            subtask1();
            continue;
        // }
    }
    return 0;
}