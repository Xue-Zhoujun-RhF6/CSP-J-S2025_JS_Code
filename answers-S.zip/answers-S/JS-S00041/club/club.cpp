#include<bits/stdc++.h>
using namespace std;
//int b[100005];
//int c[100005];
struct Node{
	int a;
	int n;
}a[100005];
int f[5];
int sum[5];

int mid(int x,int y,int z){
	if((x>=y&&y>=z)||(y>=x&&y<=z)){
		return 2;
	}
	if((x>=y&&x<=z)||(x<=y&&x>=z)){
		return 1;
	}
	if((z>=x&&z<=y)||(z>=y&&z<=x)){
		return 3;
	}
	return 0;
}
int maxx(int x,int y,int z){
	if(x>=y&&x>=z){
		return 1;
	}
	if(y>=x&&y>=z){
		return 2;
	}
	if(z>=x&&z>=y){
		return 3;
	}
	return 0;
}
bool cmp(Node a,Node b){
	return a.a>b.a;
}
int main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		int n;
		scanf("%d",&n);
		int ans=0;
		sum[1]=0;
		sum[2]=0;
		sum[3]=0;
		for(int i=1;i<=n;i++){
			int num;
			scanf("%d%d%d",&f[1],&f[2],&f[3]);
			num=mid(f[1],f[2],f[3]);
			//ans+=f[num];
			ans+=max(f[1],max(f[2],f[3]));
			a[i].a=max(f[1],max(f[2],f[3]))-f[num];
			a[i].n=maxx(f[1],f[2],f[3]);
			sum[maxx(f[1],f[2],f[3])]++;
		}
		sort(a+1,a+n+1,cmp);
		/*
		for(int i=1;i<=n;i++){
			cout<<a[i].a<<' ';
		}
		cout<<'\n';*/
		//cout<<"--------\n";
		//cout<<ans<<'\n';
		int sum0=0;
		for(int i=1;i<=3;i++){
			if(sum[i]>n/2){
				//cout<<sum[i]<<"asfdsadf\n";
				//cout<<i<<"asdfasdf";
				for(int j=n;j>=1;j--){
					if(sum0==sum[i]-n/2){
						break;
					}
					if(a[j].n==i){
						ans-=a[j].a;
						sum0++;
					}
				}
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}
