#include <bits/stdc++.h>
using namespace std;
struct shetuan{
    int id1, id2, id3, maxn, maxn2;
};
shetuan arr[100010];
struct xy{
    int zhi, num;
};
xy club1[100010], club2[100010], club3[100010];
int main() {
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    int T;
    cin >> T;
    while(T--) {
        memset(arr, 0, sizeof(arr));
        memset(club1, 0, sizeof(club1));
        memset(club2, 0, sizeof(club2));
        memset(club3, 0, sizeof(club3));
        int n;
        cin >> n;
        int xianzhi = n / 2;
        for(int i = 1; i <= n; i++) {
            cin >> arr[i].id1 >> arr[i].id2 >> arr[i].id3;
            arr[i].maxn = max(max(arr[i].id1, arr[i].id2), arr[i].id3);
            if(arr[i].maxn == arr[i].id1) {
                arr[i].maxn2 = max(arr[i].id2, arr[i].id3);
            }
            if(arr[i].maxn == arr[i].id2) {
                arr[i].maxn2 = max(arr[i].id1, arr[i].id3);
            }
            if(arr[i].maxn == arr[i].id3) {
                arr[i].maxn2 = max(arr[i].id1, arr[i].id2);
            }
        }

        int sum = 0, sum2 = 0, sum3 = 0, ans = 0;
        for(int i = 1; i <= n; i++) {
            if(arr[i].maxn == arr[i].id1) {
                if(sum + 1 > xianzhi) {
                    for(int j = 1; j <= sum; j++) {
                        if(club1[j].zhi < arr[i].id1) {

                            if(arr[club1[j].num].maxn2 == arr[club1[j].num].id2) {
                                club2[sum + 1].zhi = arr[club1[j].num].id2;
                                club2[sum + 1].num = j;
                            }
                            if(arr[club1[j].num].maxn2 == arr[club1[j].num].id3) {
                                club3[sum + 1].zhi = arr[club1[j].num].id3;
                                club3[sum + 1].num = j;
                            }
                            club1[j].zhi = arr[i].id1;
                            sum++;
                            break;
                        }
                    }
                }
                else {
                    club1[sum + 1].zhi = arr[i].id1;
                    club1[sum + 1].num = i;
                    sum++;
                }
            }
            if(arr[i].maxn == arr[i].id2) {
                if(i == 4) cout << "Yes" << endl;
                if(sum2 + 1 > xianzhi) {
                    for(int j = 1; j <= sum2; j++) {
                        if(club2[j].zhi < arr[i].id2) {

                            if(arr[club2[j].num].maxn2 == arr[club2[j].num].id1) {
                                club1[sum + 1].zhi = arr[club2[j].num].id1;
                                club1[sum + 1].num = j;
                            }
                            if(arr[club2[j].num].maxn2 == arr[club2[j].num].id3) {
                                club3[sum + 1].zhi = arr[club2[j].num].id3;
                                club3[sum + 1].num = j;
                            }
                            club2[j].zhi = arr[i].id2;
                            sum2++;
                            break;
                        }
                    }
                }
                else {
                    club2[sum + 1].zhi = arr[i].id2;
                    club2[sum + 1].num = i;
                    sum2++;
                }
            }
            if(arr[i].maxn == arr[i].id3) {
                if(sum3 + 1 > xianzhi) {
                    for(int j = 1; j <= sum3; j++) {
                        if(club3[j].zhi < arr[i].id3) {

                            if(arr[club3[j].num].maxn2 == arr[club2[j].num].id2) {
                                club2[sum + 1].zhi = arr[club3[j].num].id2;
                                club2[sum + 1].num = j;
                            }
                            if(arr[club3[j].num].maxn2 == arr[club2[j].num].id1) {
                                club1[sum + 1].zhi = arr[club3[j].num].id1;
                                club1[sum + 1].num = j;
                            }
                            club3[j].zhi = arr[i].id3;
                            sum3++;
                            break;
                        }
                    }
                }
                else {
                    club3[sum + 1].zhi = arr[i].id3;
                    club3[sum + 1].num = i;
                    sum3++;
                }
            }
        }
        for(int i = 1; i <= n; i++) {
            ans += club1[i].zhi + club2[i].zhi + club3[i].zhi;
        }
        cout << ans << endl;
    }

    return 0;
}
