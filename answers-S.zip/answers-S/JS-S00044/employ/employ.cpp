#include<bits/stdc++.h>
#define N 600
#define ll long long
#define Mod 998244353
using namespace std;
int n,m;
string s;
int a[N],na[N];
bool f=0;
int main (){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);
    cin>>n>>m;
    cin>>s;
    int l=s.size();
    for(int i=1;i<=l;i++){
        a[i]=s[i-1]-'0';
        if(a[i]==0)f=1;
    }
    for(int i=1;i<=n;i++){
        cin>>na[i];
    }
    if(m==n&&f==1){
        cout<<0;
        return 0;
    }
    else if(m==n&&f==0){
        int cnt=1;
        for(int i=1;i<=n;i++){
            cnt*=i;
            cnt%=Mod;
        }
        cout<<cnt;
        return 0;
    }
    else if(m==1){
        int d;
        int cnt=n,ans=1;
        for(int i=1;i<=l;i++){
            if(a[i]==1){
                d=i;
                break;
            }
        }
        for(int i=1;i<=n;i++){
            if(na[i]<d)cnt--;
        }
        for(int i=1;i<=cnt;i++){
            ans*=i;
            ans%=Mod;
        }
        cout<<ans;
        return 0;
    }
    if(f==0){
        int cnt=1;
        for(int i=1;i<=m;i++){
            cnt*=i;
            cnt%=Mod;
        }
        cout<<cnt;
        return 0;
    }
    else{
        cout<<0;
    }
    return 0;
}

