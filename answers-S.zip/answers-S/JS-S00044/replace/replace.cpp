#include<bits/stdc++.h>
#define N 600
#define ll long long
using namespace std;
int t;
int main (){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);
    cin>>t;
    while(t--)
    cout<<0<<endl;
    return 0;
}

