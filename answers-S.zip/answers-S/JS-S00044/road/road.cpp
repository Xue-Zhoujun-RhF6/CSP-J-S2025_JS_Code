#include<bits/stdc++.h>
#define N 10010
#define ll long long
using namespace std;
int n,m,k;
ll c[N];
ll a[N][N];
ll d[N][N];
bool f=0;
ll ans=0;

int main (){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);
    cin>>n>>m>>k;
    int u,v,val;
    for(int i=1;i<=m;i++){
        cin>>u>>v>>val;
        d[u][v]=val;
        d[v][u]=val;
        ans+=val;
    }
    for(int i=1;i<=k;i++){
        cin>>c[i];
        if(c[i]!=0)f=1;
        for(int j=1;j<=n;j++){
            cin>>a[j][i];
        }
    }
    if(!f){
    }
    else{
        cout<<val;
    }
    return 0;
}
