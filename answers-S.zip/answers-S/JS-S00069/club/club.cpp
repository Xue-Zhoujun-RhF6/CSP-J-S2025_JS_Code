#include<fstream>
#include<algorithm>
std::ifstream fin("club.in");
std::ofstream fout("club.out");
struct peo{
    int a;int ga;
    int b;int gb;
    int c;int gc;
};
bool mmm(peo l,peo r){
    if(l.a-l.b>r.a-r.c)
        return false;
    return true;
}
void solve(){
        int n;
        peo a[100001];
        int c[3];
        fin>>n;
        for(int i=0;i<n;i++){
            a[i].a=0;a[i].b=0;a[i].c=0;
            a[i].ga=0;a[i].gb=0;a[i].gc=0;
        }
        c[0]=0;c[1]=0;c[2]=0;
        for(int i=0;i<n;i++){
            fin>>a[i].a>>a[i].b>>a[i].c;
            a[i].ga=1;a[i].gb=2;a[i].gc=3;
            if(a[i].b>a[i].a){
                int t=a[i].a;a[i].a=a[i].b;a[i].b=t;
                t=a[i].ga;a[i].ga=a[i].gb;a[i].gb=t;
            }
            if(a[i].c>a[i].b){
                int t=a[i].c;a[i].c=a[i].b;a[i].b=t;
                t=a[i].gc;a[i].gc=a[i].gb;a[i].gb=t;
            }
            if(a[i].b>a[i].a){
                int t=a[i].a;a[i].a=a[i].b;a[i].b=t;
                t=a[i].ga;a[i].ga=a[i].gb;a[i].gb=t;
            }
        }
        std::sort(a,a+n,mmm);
        long long sum=0;
        for(int i=0;i<n;i++){
            c[a[i].ga]++;
            sum+=a[i].a;
        }
        int club_max=n/2;
        for(int j=0;j<3;j++){
            int i=0;
            while(c[j]>club_max&&i<n){
                if(a[i].ga==j){
                    c[a[i].ga]--;
                    c[a[i].gb]++;
                    sum=sum-a[i].a+a[i].b;
                }
                i++;
            }
        }
        fout<<sum<<"\n";
}
int main(){
    int T;
    fin>>T;
    while(T--){
        solve();
    }
}
