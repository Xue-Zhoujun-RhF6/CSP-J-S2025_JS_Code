#include<iostream>
#include<fstream>
#include<vector>
std::ifstream fin("road.in");
std::ofstream fout("road.out");
struct road{
    int v,w;
};
void solve(){
    int n,m,k;
    std::vector<road>a;
    std::cin>>n>>m>>k;
    for(int i=0;i<m;i++){
        int u,v,m;
        std::cin>>u>>v>>m;

    }
}
int main(){

}
