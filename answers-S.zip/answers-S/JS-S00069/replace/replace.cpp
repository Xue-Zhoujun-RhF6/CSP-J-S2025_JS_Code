#include<iostream>//(T^T)
#include<fstream>
#include<string>
std::ifstream fin("replace.in");
std::ofstream fout("replace.out");
int n,q;
int ls1[200001]={0},rs1[200001]={0};
int ls2[200001]={0},rs2[200001]={0};
int main(){
    std::cin>>n>>q;
    for(int i=0;i<n;i++){
        std::string a,b;
        std::cin>>a>>b;
        bool bbb=true;
        for(int j=0;j<a.size();j++){
            if(a[i]=='b'){
                bbb=false;
            }
            else if(bbb){
                ls1[i]++;
            }
            else{
                rs1[i]++;
            }
        }
        bbb=true;
        for(int j=0;j<a.size();j++){
            if(b[i]=='b'){
                bbb=false;
            }
            else if(bbb){
                ls2[i]++;
            }
            else{
                rs2[i]++;
            }
        }
    }
    for(int i=0;i<q;i++){
        std::string a,b;
        std::cin>>a>>b;
        int pa,pb;
        for(int j=0;j<a.size();j++){
            if(a[j]=='b')
                pa=j;
            if(b[j]=='b')
                pb=j;
            if(pa!=0&&pb!=0)
                break;
        }
        int ans=0;
        for(int j=0;j<n;j++){
            if((ls1[j]-ls2[j])==(pa-pb)){
                ans++;
            }
        }
        std::cout<<ans<<"\n";
    }
}
