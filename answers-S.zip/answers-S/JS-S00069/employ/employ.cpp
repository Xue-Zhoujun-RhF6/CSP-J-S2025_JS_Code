#include<fstream>
std::ifstream fin("employ.in");
std::ofstream fout("employ.out");
const int mod=998244353;
int main(){
    int n,m;
    long long ans=1;
    for(int i=1;i<n;i++){
        ans=ans*i%mod;
    }
    fout<<ans;
}
