#include <bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=1e6+1145;
int n,m,k,fa[maxn];

int find(int x)
{
    return fa[x]==x?x:fa[x]=find(fa[x]);
}
void merge(int x,int y)
{
    x=find(x);
    y=find(y);
    if(x!=y) fa[x]=y;
}

struct node
{
    int to,w;
};
vector<node> e[maxn],e1[maxn];

struct node1
{
    int u,v,bq;
}bi[maxn];
int fy[15][maxn],b[15];

bool cmp(node1 x,node1 y)
{
    return x.bq<y.bq;
}

signed main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);

    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int cnt1=0;
    cin>>n>>m>>k;
    for(int i=1,a,b,c;i<=m;i++)
    {
        cin>>a>>b>>c;
        e[a].push_back({b,c});
        e[b].push_back({a,c});
        bi[++cnt1]={a,b,c};
    }

    if(k==0)
    {
        int ans2=0;
        for(int i=1;i<=n;i++) fa[i]=i;
        sort(bi+1,bi+cnt1+1,cmp);
        int t=0,in=0;
        set<int> s1;
        while(s1.size()<n)
        {
            t++;
            int u=bi[t].u;
            int v=bi[t].v;
            int w=bi[t].bq;
            if(find(u)!=find(v))
            {
                merge(u,v);
                ans2+=w;
                s1.insert(u);
                s1.insert(v);
            }
        }
        cout<<ans2;
    }
    else
    {
        for(int i=1;i<=k;i++)
        {
            for(int j=1,g;j<=n+1;j++)
            {
                cin>>g;
                if(j==1) b[i]=g;
                else fy[i][j-1]=g;
            }
        }

        //1111=2^4-1
        //1011
        int cnt2;
        int cnt,ans=0x3f3f3f3f3f3f3f3f,ans1;
        set<int> s;
        for(int i=0;i<(1<<k);i++)
        {
            //cout<<"i="<<i<<":\n";
            cnt2=cnt1;
            cnt=0,ans1=0;
            for(int j=1;j<=n;j++) e1[j]=e[j];
            for(int j=0;(1<<j)<=i;j++)
            {
                if((i>>j)&1)
                {
                    cnt++;
                    //cout<<"ans+="<<b[j+1]<<"\n";
                    ans1+=b[j+1];
                    for(int l=1;l<=n;l++)
                    {
                        e1[n+cnt].push_back({l,fy[j+1][l]});
                        e1[l].push_back({n+cnt,fy[j+1][l]});
                        bi[++cnt2]={l,n+cnt,fy[j+1][l]};
                    }
                }
            }
            //cout<<"Step 1,ans=:"<<ans1<<"\n";
            for(int j=1;j<=n+cnt;j++) fa[j]=j;
            sort(bi+1,bi+cnt2+1,cmp);
            s.clear();
            int h=0;
            while(s.size()<n)
            {
                h++;
                int u=bi[h].u,v=bi[h].v,w=bi[h].bq;
                if(find(u)!=find(v))
                {
                    merge(u,v);
                    ans1+=w;
                    if(u>=1&&u<=n) s.insert(u);
                    if(v>=1&&v<=n) s.insert(v);
                }
            }
            ans=min(ans,ans1);
            //cout<<"i="<<i<<",ans="<<ans<<"\n";
            for(int j=1;j<=n+cnt;j++) e1[j].clear();
        }
        cout<<ans;
    }
    return 0;
}
