#include <bits/stdc++.h>
#define ull unsigned long long
#define ll long long
using namespace std;
const int maxn=1e5+10;
int f[205][205][205];
int T;

void solve()
{
    //cout<<"T="<<T<<"\n";
    int a[maxn][3]={0};
    memset(f,0,sizeof(f));//f[i][j][k]=max(f[i-1][j-1][k]+a[i][0],f[i-1][j][k-1]+a[i][1],f[i-1][j][k]+a[i][2])
    int n,res=-1;
    cin>>n;
    if(n<=200)
    {
        for(int i=1;i<=n;i++) cin>>a[i][0]>>a[i][1]>>a[i][2];
        f[1][1][0]=a[1][0];
        f[1][0][1]=a[1][1];
        f[1][0][0]=a[1][2];
        for(int i=2;i<=n;i++)
        {
            for(int j=0;j<=min(i,n/2);j++)
            {
                for(int k=0;k<=min(i-j,n/2);k++)
                {
                    int l=i-j-k,ans=-1;
                    if(j) ans=max(ans,f[i-1][j-1][k]+a[i][0]);
                    if(k) ans=max(ans,f[i-1][j][k-1]+a[i][1]);
                    if(l&&l<=n/2) ans=max(ans,f[i-1][j][k]+a[i][2]);
                    f[i][j][k]=ans;
                }
            }
        }

        for(int i=0;i<=n/2;i++)
        {
            for(int j=0;j<=n/2;j++) res=max(res,f[n][i][j]);
        }
        cout<<res<<"\n";
    }
    else
    {
        bool ling2=true,ling3=true;
        for(int i=1;i<=n;i++)
        {
            cin>>a[i][0]>>a[i][1]>>a[i][2];
            if(a[i][1]) ling2=false;
            if(a[i][2]) ling3=false;
        }
        if(ling2&&ling3)
        {
            int ans;
            priority_queue<int> q;
            for(int i=1;i<=n;i++) q.push(a[i][0]);
            int cnt=0;
            while(cnt<n/2&&!q.empty())
            {
                ans+=q.top();
                q.pop();
                cnt++;
            }
            cout<<ans<<"\n";
        }
    }
}

int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);

    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin>>T;
    while(T--) solve();
    return 0;
}
