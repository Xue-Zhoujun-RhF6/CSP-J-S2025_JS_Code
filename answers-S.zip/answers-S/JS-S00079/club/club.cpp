#include<bits/stdc++.h>
using namespace std;
int t,n;
long long ans;
struct node{
    int a;
    int b;
    int c;
    int club;
    int cha;
}s[100005];
int e[5];
bool cmp(node a,node b){
    return a.cha<b.cha;
}
void clean(){
    for(int i=1;i<=100000;i++){
        s[i].a=0;
        s[i].b=0;
        s[i].c=0;
        s[i].cha=0;
        s[i].club=0;
    }
    for(int i=1;i<=4;i++){
        e[i]=0;
    }
    ans=0;n=0;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--){
        cin>>n;
        for(int i=1;i<=n;i++){
            cin>>s[i].a>>s[i].b>>s[i].c;
            if(s[i].a>=s[i].b&&s[i].a>=s[i].c){
                e[1]++;
                s[i].club=1;
                s[i].cha=s[i].a-max(s[i].b,s[i].c);
                ans+=s[i].a;
            }
            else if(s[i].b>=s[i].a&&s[i].b>=s[i].c){
                e[2]++;
                s[i].club=2;
                s[i].cha=s[i].b-max(s[i].a,s[i].c);
                ans+=s[i].b;
            }
            else if(s[i].c>=s[i].a&&s[i].c>=s[i].b){
                e[3]++;
                s[i].club=3;
                s[i].cha=s[i].c-max(s[i].a,s[i].b);
                ans+=s[i].c;
            }
        }
        if(e[1]>n/2||e[2]>n/2||e[3]>n/2){
            sort(s+1,s+n+1,cmp);
            if(e[1]>n/2){
                int d=e[1]-n/2;
                for(int i=1;i<=n&&d;i++){
                    if(s[i].club==1){
                        ans-=s[i].cha;
                        d--;
                    }
                }
            }
            if(e[2]>n/2){
                int d=e[2]-n/2;
                for(int i=1;i<=n&&d;i++){
                    if(s[i].club==2){
                        ans-=s[i].cha;
                        d--;
                    }
                }
            }
            if(e[3]>n/2){
                int d=e[3]-n/2;
                for(int i=1;i<=n&&d;i++){
                    if(s[i].club==3){
                        ans-=s[i].cha;
                        d--;
                    }
                }
            }
        }
        cout<<ans<<endl;
        clean();
    }
    return 0;
}
