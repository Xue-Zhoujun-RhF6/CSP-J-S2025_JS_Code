#include<bits/stdc++.h>
using namespace std;
const long long mod=998244353;
int n,m,c[505],zn;long long ans;
bool a[505],typea=true;
string s;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    cin>>s;
    for(int i=0;i<=n-1;i++){
        if(s[i]=='1')a[i+1]=1;
        else{a[i+1]=0;typea=false;}
    }
    for(int i=1;i<=n;i++){
       cin>>c[i];
       if(!c[i])zn++;
    }
    if(n-zn<m){cout<<0;return 0;}
    if(m==n){
        if(!typea){cout<<0<<endl;return 0;}
        if(zn){cout<<0<<endl;return 0;}
        else for(int i=n;i>=1;i--){
            ans*=i;
            ans%=mod;
            }
            cout<<ans<<endl;
            return 0;
    }
    if(typea){
        ans=1;
        if(zn==0){
            for(int i=n;i>=1;i--){
            ans*=i;
            ans%=mod;
            }
            cout<<ans<<endl;
            return 0;
        }

    }
    if(n==3)cout<<2;
    if(n==10)cout<<2204128;
    if(n==100)cout<<161088479;
    if(n==500){
        if(m==1)cout<<515058943;
        else cout<<225301405;
    }
    return 0;
}
