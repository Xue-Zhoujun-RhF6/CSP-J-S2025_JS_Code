#include<bits/stdc++.h>
using namespace std;
int q,n,ans;
string s[1003][2],s1,s2;
int a[200005],loc1[200005],loc2[200005],loc3[200005],loc4[200005];
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    if(n<=1000&&q<=1000){
    for(int i=1;i<=n;i++){
        cin>>s[i][0];
        cin>>s[i][1];
    }
    while(q--){
        ans=0;
        cin>>s1; cin>>s2;
        if(s1.length()!=s2.length()){
            cout<<0<<endl;continue;
        }
        int t=0;
        while(s1[t]==s2[t]&&t<=s1.length())++t;
        int p=t;
        while(s1[p]!=s2[p]&&p<=s1.length())++p;
        --p;
        for(int i=1;i<=n;i++){
            bool fg=true;
            int j=0;
            while(s[i][0][j]==s[i][1][j])j++;
            int u=j;
            --u;
            while(s[i][0][u]!=s[i][1][u])u++;
            if(t-p!=u-j||j>p||s[i][0].length()-t>s1.length())continue;
            for(int k=1;k<=p-t+1;k++){
                if(s[i][0][j+k-1]!=s1[t+k-1]||s[i][1][j+k-1]!=s2[t+k-1])fg=false;
            }
            if(fg)ans++;
        }
        cout<<ans<<endl;
        s1.clear();s2.clear();
    }
    }
    else{
        string s3,s4;
        for(int i=1;i<=n;i++){
            cin>>s3;
            cin>>s4;
            int t1=0,t2=0;
            while(s3[t1]=='a')t1++;while(s4[t2]=='a')t2++;cout<<t1<<" "<<t2<<endl;
            a[i]=t2-t1;loc1[i]=t1;loc2[i]=t2;loc3[i]=s3.length()-t1+1;loc3[i]=s3.length()-t1+1;

        }
        while(q--){
                if(s1.length()!=s2.length()){
            cout<<0<<endl;continue;
        }
            ans=0;
            int ex=0;
            cin>>s1>>s2;
            int o1=0,o2=0;
            while(s1[o1]=='a')o1++;while(s2[o2]=='a')o2++;
            ex=o2-o1;
            for(int i=1;i<=n;i++){
                if(ex==a[i]&&loc2[i]<=o2&&loc1[i]<=o1&&loc3[i]<=s1.length()-o1+1&&loc1[i]<=s1.length()-o2+1)ans++;
            }
            cout<<ans<<endl;
        }
    }
    return 0;
}
