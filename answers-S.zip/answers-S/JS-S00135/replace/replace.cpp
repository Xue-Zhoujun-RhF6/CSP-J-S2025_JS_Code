#include <bits/stdc++.h>
using namespace std;
string s[200003][2];
int main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    long long n,q,ans=0;
    string sa,sb,sc;
    cin>>n>>q;
    for(int i=1;i<=n;i++)
    {
        cin>>s[i][0]>>s[i][1];
    }
    for(int i=1;i<=q;i++)
    {
        cin>>sa>>sb;
        ans=0;
        for(int j=1;j<=n;j++)
        {
            if(sa.size()<s[j][0].size())continue;
            for(int k=0;k<=sa.size()-s[j][0].size();k++)
            {
                sc=sa;
                if(sc.replace(sc.begin()+k,sc.begin()+k+s[j][0].size(),s[j][0])==sa)
                {
                    sc.replace(sc.begin()+k,sc.begin()+k+(s[j][0].size()),s[j][1]);
                    if(sb==sc)ans++;
                }
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}
