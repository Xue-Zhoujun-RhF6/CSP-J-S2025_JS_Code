#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct s
{
    ll x,cha,fir;
}a[100006];
ll b[4],d[4],c[100006],cnt[4];
ll ans;
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int t,n;
    cin>>t;
    for(int o=1;o<=t;o++)
    {
        cin>>n;
        memset(cnt,0,sizeof cnt);
        ans=0;
        for(int i=1;i<=n;i++)
        {
            cin>>b[1]>>b[2]>>b[3];
            for(int j=1;j<=3;j++)d[j]=b[j];
            sort(b+1,b+4);
            for(int j=1;j<=3;j++)
            {
                if(d[j]==b[3])a[i].fir=j;
            }
            a[i].x=b[3];
            a[i].cha=b[3]-b[2];
            ans+=b[3];
            cnt[a[i].fir]++;
        }
        for(int i=1;i<=3;i++)
        {
            if(cnt[i]>(n/2))
            {
                int ct=1;
                for(int j=1;j<=n;j++)
                {
                    if(a[j].fir==i)
                    {
                        c[ct]=a[j].cha;
                        ct++;
                    }
                }
                sort(c+1,c+ct);
                for(int j=1;j<=ct-(n/2)-1;j++)ans-=c[j];
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}
