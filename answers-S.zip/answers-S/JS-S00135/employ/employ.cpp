#include <bits/stdc++.h>
using namespace std;
long long M=998244353;
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    long long n,m,t,ans=1,cnt=0;
    cin>>n>>m;
    string s;
    cin>>s;
    for(int i=1;i<=n;i++)cin>>t;
    cout<<"0";
    return 0;
}
