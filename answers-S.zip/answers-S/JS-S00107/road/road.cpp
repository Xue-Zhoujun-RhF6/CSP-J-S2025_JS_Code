#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int MAXN=1e6+15;
int n,m,k;
struct node
{
    ll v,w;
    bool operator < (const node &A)const
    {
        return A.w<w;
    }
};
vector<node> mp[MAXN];
ll kc[MAXN],kc2[15][MAXN];
void solve()
{
    ll ans=0;
    int vis[MAXN]={};
    vis[1]=1;
    priority_queue<node> q;
    for(int i=0;i<mp[1].size();i++)
    {
        if(!vis[mp[1][i].v])q.push((node){mp[1][i].v,mp[1][i].w});
    }
    for(int i=1;i<n;i++)
    {
        ll t=q.top().v,c=q.top().w;
        q.pop();
        while(vis[t])
        {
            t=q.top().v;
            c=q.top().w;
            q.pop();
        }
        vis[t]=1;
        ans+=c;
        for(int j=0;j<mp[t].size();j++)
        {
            if(!vis[mp[t][j].v])
            {
                q.push((node){mp[t][j].v,mp[t][j].w});
            }
        }
    }
    cout<<ans;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    int u,v,w;
    for(int i=1;i<=m;i++)
    {
        cin>>u>>v>>w;
        mp[u].push_back((node){v,w});
        mp[v].push_back((node){u,w});
    }
    int y=0;
    for(int i=1;i<=k;i++)
    {
        cin>>kc[i];
        for(int j=1;j<=n;j++)
        {
            cin>>kc2[i][j];
            if(kc2[i][j]==0)
            {
                y=j;
            }
        }
        for(int j=1;j<=n;j++)
        {
            if(y!=j)
            {
                mp[y].push_back((node){j,kc2[i][j]});
                mp[j].push_back((node){y,kc2[i][j]});
            }
        }
    }
    solve();
    /*
4 4 1
1 4 6
2 3 7
4 2 5
4 3 4
0 0 0 0 0
    */
    return 0;
}

