#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int MAXN=1e5+5;
int T;
ll n,nxtmax[MAXN],ans;
ll a[MAXN][5];
struct node2
{
    int num,id;
};
ll anum,bnum,cnum;
priority_queue<ll,vector<ll>,greater<ll> > q[4];
void cmp(int xa,int xb,int xc,int i)
{
    if(xa>=xb&&xa>=xc)
    {
        anum++;
        ans+=xa;
        q[1].push(xa-a[i][nxtmax[i]]);
    }
    else if(xb>=xa&&xb>=xc)
    {
        bnum++;
        ans+=xb;
        q[2].push(xb-a[i][nxtmax[i]]);
    }
    else
    {
        cnum++;
        ans+=xc;
        q[3].push(xc-a[i][nxtmax[i]]);
    }
    return;
}
void solve()
{
    ans=0;
    anum=bnum=cnum=0;
    for(int i=1;i<=3;i++)while(!q[i].empty())q[i].pop();
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i][1]>>a[i][2]>>a[i][3];
        if(a[i][1]>=a[i][2]&&a[i][1]<=a[i][3])nxtmax[i]=1;
        if(a[i][1]>=a[i][3]&&a[i][1]<=a[i][2])nxtmax[i]=1;

        if(a[i][2]>=a[i][1]&&a[i][2]<=a[i][3])nxtmax[i]=2;
        if(a[i][2]>=a[i][3]&&a[i][2]<=a[i][1])nxtmax[i]=2;

        if(a[i][3]>=a[i][2]&&a[i][3]<=a[i][1])nxtmax[i]=3;
        if(a[i][3]>=a[i][1]&&a[i][3]<=a[i][2])nxtmax[i]=3;
    }
    for(int i=1;i<=n;i++)
    {
        cmp(a[i][1],a[i][2],a[i][3],i);
        //print();
    }
    while(anum>n/2)
    {
        ans-=q[1].top();
        q[1].pop();
        anum--;
    }
    while(bnum>n/2)
    {
        ans-=q[2].top();
        q[2].pop();
        bnum--;
    }
    while(cnum>n/2)
    {
        ans-=q[3].top();
        q[3].pop();
        cnum--;
    }
    cout<<ans<<'\n';
    return;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>T;
    while(T--)
    {
        solve();
    }
    return 0;
}
