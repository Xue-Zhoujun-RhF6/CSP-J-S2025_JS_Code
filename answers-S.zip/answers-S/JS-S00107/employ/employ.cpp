#include<bits/stdc++.h>
using namespace std;
const int MAXN=515;
const int P=998244353;
int n,m,c[MAXN];
string s;
int vis[MAXN],cnt[MAXN],ans;
void dfs(int d)
{
    if(d==n)
    {
        int sum1=0,sum2=0;
        for(int i=1;i<=n;i++)
        {
            if(s[i]=='0')sum1++;
            else if(sum1>=c[cnt[i]])sum1++;
            else sum2++;
        }
        if(sum2>=m)ans++;
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(!vis[i])
        {
            vis[i]=1;
            cnt[d+1]=i;
            dfs(d+1);
            vis[i]=0;
        }
    }
}
void solve1()
{
    dfs(0);
    cout<<ans;
}
void solveA()
{

}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    cin>>s;
    s=" "+s;
    for(int i=1;i<=n;i++)cin>>c[i];
    if(n<=10)
    {
        solve1();
    }
    else
    {
        solveA();
    }
    return 0;
}
/*
3 2
101
1 1 2

10 5
1101111011
6 0 4 2 1 2 5 4 3 3
*/

