#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

namespace sol {
using ll = long long;
const int mx = 12;
int n, m, c[mx], x[mx];
bool diffi[mx];
int main() {
  cin >> n >> m;
  string difff;
  cin >> difff;
  for (int i = 1; i <= n; ++i)
    diffi[i] = difff[i] == '1';
  for (int i = 1; i <= n; ++i)
    cin >> c[i];
  for (int i = 1; i <= n; ++i)
    x[i] = i;
  int cnt = 0;
  do {
    int cnt_rej = 0, cnt_ac = 0;
    for (int day = 1; day <= n; day++) {
      if (cnt_rej >= c[x[day]] || diffi[day])
        cnt_rej++;
      else
        cnt_ac++;
    }
    if (cnt_ac >= m)
      cnt++;
    // cout << cnt_ac << '\n';
  } while (next_permutation(x + 1, x + 1 + n));
  cout << cnt << endl;
  return 0;
}
} // namespace sol

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  cout.tie(nullptr);
  freopen("employ.in", "r", stdin);
  freopen("employ.out", "w", stdout);
  return sol::main();
}