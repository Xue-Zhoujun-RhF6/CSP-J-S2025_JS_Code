#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;
int n, q;
const int mxn = 5e6 + 3;
string from[mxn], to[mxn];

namespace sol {
using ll = long long;
int next[mxn];

// str start with a '$' or so to make it 1-indexed
void cal_border(int cnext[], string str) {
  for (int i = 2; i < str.size(); i++) {
    int cur = cnext[i - 1];
    while (cur) {
      if (str[cur + 1] == str[i])
        break;
      cur = cnext[cur];
    }
    if (str[cur + 1] == str[i])
      cur++;
    cnext[i] = cur;
  }
}
vector<int> get_(string pa, string b) {
  string nw = '%' + pa + '|' + b;
  vector<int> aaa;
  cal_border(next, nw);
  // cout << nw.substr(1) << '\n';
  // for (int i = 1; i < nw.size(); i++)
  //   cout << next[i] << ' ';
  // cout << endl;
  for (int i = pa.size() * 2; i < nw.size(); i++) {
    if (next[i] == pa.size())
      aaa.push_back(i - pa.size() - 2);
  }
  return aaa;
}

int main() {
  for (int i = 1; i <= q; i++) {
    string a, b;
    cin >> a >> b;
    int l = -1, r = a.size();
    while (a[l + 1] == b[l + 1])
      l++;
    while (a[r - 1] == b[r - 1])
      r--;
    l++, r--;
    int cnt = 0;
    for (int j = 1; j <= n; j++) {
      auto aa = get_(from[j], a);
      auto bb = get_(to[j], b);
      for (int ii = 0, jj = 0; ii < aa.size() && jj < bb.size(); ii++) {
        while (jj < bb.size() && bb[jj] < aa[ii])
          jj++;
        if (aa[ii] == bb[jj]) {
          int R = aa[ii];
          int L = R - from[j].size() + 1;
          // cout << L << ' ' << R << ',' << l << ' ' << r << '\n';
          if (L <= l && r <= R) {
            cnt++;
            break;
          }
        }
      }
    }
    cout << cnt << '\n';
  }

  return 0;
}
} // namespace sol

namespace sol_bru {
using ll = long long;
int main() {
  for (int i = 1; i <= q; i++) {
    string a, b;
    cin >> a >> b;
    int cnt = 0;
    for (int j = 1; j <= n; j++) {
      for (int pos = 0; pos + from[j].size() - 1 < a.size(); pos++) {
        if (a.substr(pos, from[j].size()) == from[j]) {
          string nw = a.substr(0, pos) + to[j] + a.substr(pos + from[j].size());
          // cout << from[j] << '\n';
          if (nw == b)
            cnt++;
        }
      }
    }
    cout << cnt << '\n';
  }

  return 0;
}
} // namespace sol_bru

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  cout.tie(nullptr);
  freopen("replace.in", "r", stdin);
  freopen("replace.out", "w", stdout);
  cin >> n >> q;
  int siz = 0;
  for (int i = 1; i <= n; i++)
    cin >> from[i] >> to[i],
        siz = max({siz, (int)from[i].size(), (int)to[i].size()});
  if (n <= 100 && q <= 100 && siz <= 200)
    return sol_bru::main();
  else
    return sol::main();
}