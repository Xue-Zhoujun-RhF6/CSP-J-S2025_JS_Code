#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

namespace sol {
using ll = long long;
const int mxn = 1e4 + 30;
const int mxk = 12;
const int mxm = 1.5e6 + 3;
struct edge {
  int u, v, w;
  friend bool operator<(edge a, edge b) { return a.w < b.w; }
};
vector<edge> edges;
int price_open[mxk];
int n, m, k;
struct _dsu {
  int fa[mxn];
  int find(int x) {
    if (fa[x] == x)
      return x;
    return fa[x] = find(fa[x]);
  }
  bool merge(int x, int y) {
    x = find(x);
    y = find(y);
    if (x == y)
      return false;
    fa[x] = y;
    return true;
  }
  void init() {
    for (int i = 1; i <= n + k; i++)
      fa[i] = i;
  }
} dsu;
ll ans = 1e18;
int price_sum;
int main() {
  cin >> n >> m >> k;
  for (int i = 0; i < m; i++) {
    edge cur;
    cin >> cur.u >> cur.v >> cur.w;
    edges.emplace_back(cur);
  }
  for (int i = 0; i < k; i++) {
    cin >> price_open[i];
    price_sum |= price_open[i];
    for (int j = 1; j <= n; j++) {
      edge cur;
      cur.u = i + n + 1;
      cur.v = j;
      cin >> cur.w;
      edges.emplace_back(cur);
    }
  }
  sort(edges.begin(), edges.end());

  if (!price_sum) {
    dsu.init();
    ll cur_ans = 0;
    for (auto cur : edges) {
      if (!dsu.merge(cur.u, cur.v))
        continue;
      cur_ans += cur.w;
    }
    cout << cur_ans << '\n';
    return 0;
  }

  for (int i = 0; i < (1 << k); i++) {
    dsu.init();
    int cnt = 0;
    ll cur_ans = 0;
    for (int j = 0; j < k; j++)
      if ((1 << j) & i)
        cur_ans += price_open[j];
    for (auto cur : edges) {
      if (cur.u > n && !((1 << (cur.u - n - 1)) & i))
        continue;
      if (!dsu.merge(cur.u, cur.v))
        continue;
      cur_ans += cur.w;
      if (++cnt == __builtin_popcount(i) + n)
        break;
    }
    ans = min(ans, cur_ans);
  }
  cout << ans << '\n';
  return 0;
}
} // namespace sol

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  cout.tie(nullptr);
  freopen("road.in", "r", stdin);
  freopen("road.out", "w", stdout);
  return sol::main();
}