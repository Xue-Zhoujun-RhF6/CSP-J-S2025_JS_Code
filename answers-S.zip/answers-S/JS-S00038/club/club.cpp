#include <algorithm>
#include <cassert>
#include <iostream>
#include <queue>
#include <vector>

using namespace std;

namespace sol {
using ll = long long;
using pp = pair<ll, int>;
const int mx = 1e5 + 4;
struct person {
  pp choice[3];
  int att;
  friend bool operator<(person a, person b) { return a.att < b.att; }
} people[mx];

int n;
int cnt[3];
bool finished() {
  return cnt[0] <= n / 2 && cnt[1] <= n / 2 && cnt[2] <= n / 2;
}

void solve() {
  for (int i = 0; i < 3; i++)
    cnt[i] = 0;
  cin >> n;
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < 3; j++) {
      cin >> people[i].choice[j].first;
      people[i].choice[j].second = j;
    }
    sort(people[i].choice, people[i].choice + 3, greater<pp>());
    cnt[people[i].choice[0].second]++;
    people[i].att = people[i].choice[0].first - people[i].choice[1].first;
  }

  sort(people, people + n);
  for (int i = 0; i < n; i++) {
    if (cnt[people[i].choice[0].second] <= n / 2)
      continue;
    cnt[people[i].choice[0].second]--;
    swap(people[i].choice[0], people[i].choice[1]);
    cnt[people[i].choice[0].second]++;
    // assert(cnt[people[i].choice[0].second] <= n / 2);
  }
  ll ans = 0;
  for (int i = 0; i < n; i++)
    ans += people[i].choice[0].first;
  cout << ans << '\n';
}

int main() {
  int t;
  cin >> t;
  while (t--)
    solve();
  return 0;
}
} // namespace sol

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  cout.tie(nullptr);
  freopen("club.in", "r", stdin);
  freopen("club.out", "w", stdout);
  return sol::main();
}