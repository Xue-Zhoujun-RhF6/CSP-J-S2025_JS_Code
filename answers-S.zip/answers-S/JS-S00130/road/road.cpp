#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e4 + 5;
const int M = 2e6 + 5;
inline int read() {
    int x = 0, f = 1;
    char c = getchar();
    while (c < '0' || c > '9') {if (c == '-') f = -1; c = getchar();}
    while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}
struct node{
    int u, v, w;
};
int n, m ,k;
int a[10][N], fa[N], c[10];
node G[M];
bool vis[10];
ll ans;
inline void init() {
    memset(vis,false,sizeof vis);
    for (int i = 1; i <= n; i++) fa[i] = i;
}
inline int get(int x) {
    if (fa[x] == x) return x;
    return fa[x] = get(fa[x]);
}
inline void merge(int x, int y) {
    x = get(x), y = get(y);
    if (x != y) fa[x] = y;
}
inline bool cmp(node x, node y) {
    return x.w < y.w;
}
int minw = 1e9;
signed main(void) {
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    n = read(), m = read(), k = read();
    init();
    for (int i = 1; i <= m; i++) {
        int u = read(), v = read(), w = read();
        G[i].u = u, G[i].v = v, G[i].w = w;
        minw = min(w, minw);
    }
    bool spe = false;
    int cnt = 0;
    for (int j = 1; j <= k; j++) {
        c[j] = read();
        if (c[j] != 0)  spe = true;
        for (int i = 1; i <= n; i++) {
            a[j][i] = read();
            if (a[j][i] == 0) cnt++;
        }
    }
    if (cnt == 0) spe = true;
    if (!spe) {
        for (int i = 1; i < n; i++) {
            for (int j = i + 1; j <= n; j++) {
                for (int l = 1; l <= k; l++) {
                    if (minw >= a[l][i] + a[l][j]) {
                        m++;
                        G[m].u = i, G[m].v = j, G[m].w = a[l][i] + a[l][j];
                    }
                }
            }
        }
        sort(G + 1, G + m + 1, cmp);
        for (int i = 1; i <= m; i++) {
            int x = get(G[i].u), y = get(G[i].v);
            if (x != y) {
                merge(x, y);
                ans += G[i].w;
            }
        }
        cout << ans << "\n";
        return 0;
    }
    sort(G + 1, G + m + 1, cmp);
    if (k == 0) {
        for (int i = 1; i <= m; i++) {
            int x = get(G[i].u), y = get(G[i].v);
            if (x != y) {
                merge(x, y);
                ans += G[i].w;
            }
        }
        cout << ans << "\n";
        return 0;
    }
    for (int i = 1; i <= m; i++) {
        int x = get(G[i].u), y = get(G[i].v);
        if (x != y) {
            int mini = G[i].w;
            int t = 0;
            for (int j = 1; j <= k; j++) {
                int cun = a[j][G[i].u] + a[j][G[i].v] + (vis[j]==1?c[j]:0);
                if (cun < mini) {
                    mini = cun, t = j;
                }
                if (cun == mini) {
                    if (vis[j] == 0) t = j;
                }
            }
            if (t != 0) {
                vis[t] = true;
            }
            merge(x, y);
            ans += mini;
        }
    }
    cout << ans << "\n";
    return 0;
}
