#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 998244353;
const int N = 505;
int n, m;
ll ans;
int c[N];
string s;
bool speA, speB;
signed main(void) {
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    cin >> n >> m >> s;
    for (int i = 1; i <= n; i++) {
        cin >> c[i];
    }
    for (int i = 0; i < s.size(); i++) {
        if (s[i] - '0' != 1) speA = true;
    }
    if (!speA) {
        ans = 1;
        for (int i = 1; i <= n; i++) {
            ans = (ans * i) % mod;
        }
        cout << ans << "\n";
        return 0;
    }
    if (m == 1) {
        ans = 1;
        for (int i = 1; i <= n; i++) {
            ans = (ans * i) % mod;
        }
        cout << ans << "\n";
        return 0;
    }
    if (m == n) {
        for (int i = 0; i < s.size(); i++) {
            if (s[i] - '0' != 1) return cout << 0 << "\n", 0;
        }
    }
    return 0;
}
