#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;
inline int read() {
    int x = 0, f = 1;
    char c = getchar();
    while (c < '0' || c > '9') {if (c == '-') f = -1; c = getchar();}
    while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
    return x * f;
}
struct node{
    int id, x;
};
int T, n;
node a[N], b[N], c[N];
ll ans;
bool vis[N];
inline bool cmp(node x, node y) {
    return x.x >= y.x;
}
inline void check() {
    for (int i = 1; i <= n; i++) cout << a[i].id << ":" << a[i].x << "\n";
    for (int i = 1; i <= n; i++) cout << b[i].id << ":" << b[i].x << "\n";
    for (int i = 1; i <= n; i++) cout << c[i].id << ":" << c[i].x << "\n";
}
signed main(void) {
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    T = read();
    while (T--) {
        memset(vis, false, sizeof vis);
        bool vis_b = 0, vis_c = 0;
        ans = 0;
        n = read();
        for (int i = 1; i <= n; i++) {
            a[i].x = read(), b[i].x = read(), c[i].x = read();
            if (b[i].x != 0) vis_b = 1;
            if (c[i].x != 0) vis_c = 1;
            a[i].id = b[i].id = c[i].id = i;
        }
        if (!vis_b && !vis_c) {
            sort(a + 1, a + n + 1, cmp);
            for (int i = 1; i <= n/2; i++) {
                ans += a[i].x;
            }
            cout << ans << "\n";
            continue;
        } else if (!vis_c) {
            //cout << "YES" << '\n';
            sort(a + 1, a + n + 1, cmp);
            sort(b + 1, b + n + 1, cmp);
            int cnt = 0, _a = 1, _b = 1, cnt_a = 0, cnt_b = 0;
            while (cnt < n) {
                while(vis[a[_a].id]) _a++;
                while(vis[b[_b].id]) _b++;
                if (a[_a].x >= b[_b].x && cnt_a < n/2) {
                    ans += a[_a].x;
                    vis[a[_a].id] = true;
                    cnt++;
                    _a++;
                    cnt_a++;
                } else if (cnt_b < n/2) {
                    ans += b[_b].x;
                    vis[b[_b].id] = true;
                    cnt++;
                    _b++;
                    cnt_b++;
                    //cout << b[_b].id << " " << a[_b].x << " " << cnt_b << "\n";
                } else {
                    ans += a[_a].x;
                    _a++;
                    cnt++;
                    cnt_a++;
                }
            }
            cout << ans << "\n";
            continue;
        }
        sort(a + 1, a + n + 1, cmp);
        sort(b + 1, b + n + 1, cmp);
        sort(c + 1, c + n + 1, cmp);
        int cnt = 0, _a = 1, _b = 1, _c = 1;
        int cnt_a = 0, cnt_b = 0, cnt_c = 0;
        while (cnt < n) {
            while(vis[a[_a].id]) _a++;
            while(vis[b[_b].id]) _b++;
            while(vis[c[_c].id]) _c++;
            if (a[_a].x >= b[_b].x && a[_a].x >= c[_c].x && cnt_a < n/2) {
                //cout << "NO" << endl;
                if (b[_b].x >= c[_c].x) {
                    if (a[_a+1].id == b[_b+1].id) {
                        if (a[_a].x + b[_b+1].x < a[_a+1].x + b[_b].x) {
                            ans += a[_a+1].x + b[_b].x;
                        }
                    }
                } else {

                }
                ans += a[_a].x;
                vis[a[_a].id] = true;
                cnt++;
                _a++;
                cnt_a++;
                if (cnt_a == n/2) {
                    for (int i = _a; i <= n; i++)
                        a[i].x = -1;
                }
            } else if (b[_b].x >= a[_a].x && b[_b].x >= c[_c].x && cnt_b < n/2){
                ans += b[_b].x;
                vis[b[_b].id] = true;
                cnt++;
                _b++;
                cnt_b++;
                if (cnt_b == n/2) {
                    //cout << "yes" << endl;
                    for (int i = _b; i <= n; i++)
                        b[i].x = -1;
                }
            } else if (cnt_c < n/2){
                ans += c[_c].x;
                vis[c[_c].id] = true;
                cnt++;
                _c++;
                cnt_c++;
                if (cnt_c == n/2) {
                    for (int i = _c; i <= n; i++)
                        c[i].x = -1;
                }
            }
            //cout << cnt << " " << cnt_a << " " << cnt_b << " " << cnt_c << "\n";
        }
        cout << ans << "\n";
    }
    return 0;
}
