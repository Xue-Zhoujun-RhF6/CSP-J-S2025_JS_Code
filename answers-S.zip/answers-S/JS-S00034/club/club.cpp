#include <iostream>
#define ll long long
using namespace std;
const int N=100005;
int a[N][10],num[4];
bool full[4];

int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        for(int i=1;i<=n;i++){
            cin>>a[i][1]>>a[i][2]>>a[i][3];
        }
        for(int i=1;i<=n;i++){
            int chose=1;
            if(a[i][1]<a[i][2] && !full[2]){
                chose=2;
            }
        }
    }


    fclose(stdin);
    fclose(stdout);
    return 0;
}
