#include <iostream>
#define ll long long
using namespace std;
const int N=10005,M=20000005;
int c[13],a[13][N],fa[N],tot=0;
ll ans=0;
struct e{
    int u;
    int v;
    int w;
}edges[M];


bool cmp(e a,e b){
    return a.w<b.w;
}
void sort(){
    for(int i=1;i<=tot;i++){
        for(int j=i+1;j<=tot;j++){
            if(edges[i].w>edges[j].w){
                e tem=edges[j];
                edges[j]=edges[i];
                edges[i]=tem;
            }
        }
    }
}
int get(int a){
    if(fa[a]==a) return a;
    return fa[a]=get(fa[a]);
}
void merg(int a,int b){
    fa[get(a)]=get(b);
}
int main()
{
    freopen("road4.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n,m,k;
    cin>>n>>m>>k;
    cout<<n<<m<<k<<endl;
    for(int i=1;i<=n;i++){
        fa[i]=i;
    }

    for(int i=1;i<=m;i++){
        int x,y,z;
        cin>>x>>y>>z;
        edges[++tot]={x,y,z};//from 1 as start
        edges[++tot]={y,x,z};
    }

    for(int j=1;j<=k;j++){
        cin>>c[j];
        for(int i=1;i<=n;i++){
            cin>>a[j][i];
        }
    }

    for(int i=1;i<=k;i++){
        for(int j=1;j<=n-1;j++){
            for(int o=j+1;o<=n;o++){
                int neww=c[i]+a[i][j]+a[i][o];
                edges[++tot]={j,o,neww};
                edges[++tot]={o,j,neww};
            }
        }
    }
    sort();
    for(int i=1;i<=tot;i++){
        int x=get(edges[i].u);
        int y=get(edges[i].v);
        if(x!=y){
            merg(x,y);
            ans+=edges[i].w;

        }
    }
    cout<<ans;
    //fclose(stdin);
    //fclose(stdout);
}
