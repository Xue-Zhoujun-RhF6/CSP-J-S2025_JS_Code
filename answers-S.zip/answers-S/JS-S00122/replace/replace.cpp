#include<bits/stdc++.h>
using namespace std;
struct node{
	string s1,s2;
};
node e1[200001],e2[200001];
int n,ans=0,q;
int main()
{
	freopen("replace.in","r",stdin);
	freopen("replace.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>q;
	for(int i=1;i<=n;i++)
	{
		string r1,r2;
		cin>>r1>>r2;
		e1[i].s1=r1;
		e1[i].s2=r2;
	}
	for(int i=1;i<=q;i++)
	{
		string d1,d2;
		cin>>d1>>d2;
		e2[i].s1=d1;
		e2[i].s2=d2;
	}
	for(int i=1;i<=q;i++)
	{
		for(int j=1;j<=n;j++)
	{
		string a1=e1[j].s1,a2=e1[j].s2,a3=e2[i].s1,a4=e2[i].s2,b1,b2;
		b1=a3;
		b2=a3;
		int tmp=b2.find(a1);
		while(tmp!=string::npos)
		{
			a3=a3.replace(tmp,a1.size(),a2);
			if(a3==a4) ans++;
			
			a3=b1;
			b2=b2.substr(tmp+1,a3.size());
		
			tmp=b2.find(a1);
		}
	}		
	    cout<<ans<<'\n';
	    ans=0;
	}
	return 0;
}
