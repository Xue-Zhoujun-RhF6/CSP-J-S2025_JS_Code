#include<bits/stdc++.h>
using namespace std;
int fa[10001],si[10001],c[11],a[10001],d[1001][1001],ans=0,tmp=1;
struct node{
	int x,y,z;
}e[1000001];
int find(int x)
{
	if(x==fa[x]) return x;
	return fa[x]=find(fa[x]);
}
void Union(int u,int v)
{
	u=find(u);
	v=find(v);
	if(si[u]>si[v]) swap(u,v);
	
	fa[u]=v;
	si[v]+=si[u];
}
bool cmp(node a,node b)
{
	return a.z<b.z;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ios::sync_with_stdio(false);
	memset(d,1e9+1,sizeof d);
	int n,m,k;
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)
	{
		si[i]=1;
		fa[i]=i;
	}
	for(int i=1;i<=m;i++)
	{
		 cin>>e[i].x>>e[i].y>>e[i].z;
		 d[e[i].x][e[i].y]=e[i].z;
	}
	for(int i=1;i<=k;i++)
	{
		cin>>c[i];
		for(int j=1;j<=n;j++) cin>>a[i];
		
		for(int a1=1;a1<=n;a1++)
		for(int b=a1+1;b<=n;b++)
		{
			if(d[a1][b]>a[a1]+a[b])
			{
				e[n+tmp]=(node){a1,b,a[a1]+a[b]};
				tmp++;
			}
		}
	}
	sort(e+1,e+1+n+k,cmp);
	for(int i=1,a1,a2,a3;i<=n;i++)
	{
		a1=e[i].x;
		a2=e[i].y;
		a3=e[i].z;
		if(find(a1)!=find(a2))
		{
			ans+=a3;
			Union(a1,a2);
		}
	}
	cout<<ans<<'\n';
	return 0;
}
