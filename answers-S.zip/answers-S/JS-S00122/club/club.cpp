#include<bits/stdc++.h>
using namespace std;
struct node{
	int a1,a2,a3;
}e[100001];
bool cmp(node a,node b)
{
	return a.a1-a.a2>b.a1-b.a2;
}
int main()
{
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	ios::sync_with_stdio(false);
	int t;
	cin>>t;
	for(int o=1;o<=t;o++)
	{
		int n,m,ans=0;
		cin>>n;
		m=n/2;
		for(int i=1;i<=n;i++)
		{
			cin>>e[i].a1>>e[i].a2>>e[i].a3;
			
		}
		sort(e+1,e+1+n,cmp);
		for(int i=1;i<=m;i++) ans+=e[i].a1;
		
		for(int i=m+1;i<=n;i++) ans+=e[i].a2;
		
		cout<<ans<<'\n';
	}
	return 0;
}
