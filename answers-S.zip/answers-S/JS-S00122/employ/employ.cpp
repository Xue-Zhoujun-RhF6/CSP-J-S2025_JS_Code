#include<bits/stdc++.h>
using namespace std;
int per(int n)
{
	if(n==1) return 1;
	return (n*per(n-1))%998244353;
}
int main()
{
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	ios::sync_with_stdio(false);
	int n,m,tmp,c[501];
	string s;
	cin>>n>>m;
	cin>>s;
	tmp=n;
	for(int i=1;i<=n;i++)
	{
		cin>>c[i];
		if(c[i]==0) tmp--;
	}
	if(tmp<m) cout<<0<<'\n';
	else cout<<per(n)<<'\n';
	return 0;
}
