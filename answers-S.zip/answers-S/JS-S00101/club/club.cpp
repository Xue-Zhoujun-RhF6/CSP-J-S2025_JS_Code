#include <bits/stdc++.h>
using namespace std;
int q,n,b1,b2,b3;
long long ans;
struct str{
    int m1,m2,m3,num;
}a[100001],b[100001],c[100001];
bool cmpa(const str &A,const str &B){
    return A.m1>B.m1;
}
bool cmpb(const str &A,const str &B){
    return A.m2>B.m2;
}
bool cmpc(const str &A,const str &B){
    return A.m3>B.m3;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%d",&q);
    for(;q--;){
        ans=0;
        scanf("%d",&n);
        for(int i=1;i<=n;i++){
            scanf("%d%d%d",&a[i].m1,&a[i].m2,&a[i].m3);
            c[i].m1=b[i].m1=a[i].m1,c[i].m2=b[i].m2=a[i].m2,c[i].m3=b[i].m3=a[i].m3,c[i].num=b[i].num=a[i].num=i;
        }
        sort(a+1,a+n+1,cmpa);
        sort(b+1,b+n+1,cmpb);
        sort(c+1,c+n+1,cmpc);
        int suma=0,sumb=0,sumc=0;
        for(int i=1;i<=n/2;i++){
            suma+=a[i].m1;
        }
        for(int i=1;i<=n/4;i++){
            sumb+=b[i].m2;
        }
        for(int i=1;i<=n-n/4;i++){
            sumc+=c[i].m3;
        }
        ans+=suma*1LL+sumb*1LL+sumc*1LL;
        printf("%lld\n",ans);
    }
}
