#include <bits/stdc++.h>
using namespace std;
int n,q;
char a[2][5000001],t1[5000001],t2[5000001];
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++){
        scanf("%s %s",&a[0]+1,&a[1]+1);
    }
    for(int i=1;i<=q;i++){
        scanf("%s %s",t1+1,t2+1);
        printf("0\n");
    }
}
