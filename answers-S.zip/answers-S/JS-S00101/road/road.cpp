#include <bits/stdc++.h>
using namespace std;
int n,m,k,ans;
struct road{
    int citya,cityb,money;
}a[1000001];
struct country{
    int menoy,road[1000001];
}b[11];
bool cmp(const road &A,const road &B){
    return A.money<B.money;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=m;i++){
        scanf("%d%d%d",a[i].citya,a[i].cityb,a[i].money);
        ans+=a[i].money;
    }
    printf("%d",ans);
}
