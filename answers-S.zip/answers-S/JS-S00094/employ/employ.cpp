#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int N = 5e2+2;
const ll mod = 998244353;

int n,m;
string s;
int c[N];
ll dp[1<<18][18];

void brt(){
    dp[0][0]=1;
    for (int i=0; i<(1<<18); i++){
        for (int x=0; x<18; x++){
            if (!dp[i][x]) continue;
            int bt=__builtin_popcount(i)+1;
            if (s[bt]=='0'){
                for (int j=0; j<18; j++){
                    if (!(i>>j&1)){
                        dp[i^(1<<j)][x+1]=(dp[i^(1<<j)][x+1]+dp[i][x])%mod;
                    }
                }
            }
            else{
                for (int j=0; j<18; j++){
                    if (!(i>>j&1)){
                        if (c[j+1]<=x) dp[i^(1<<j)][x+1]=(dp[i^(1<<j)][x+1]+dp[i][x])%mod;
                        else dp[i^(1<<j)][x]=(dp[i^(1<<j)][x]+dp[i][x])%mod;
                    }
                }
            }
        }
    }
    ll ans=0;
    for (int i=0; i<=n-m; i++){
        ans=(ans+dp[(1<<n)-1][i])%mod;
    }
    cout<<ans<<"\n";
}

void spe1(){
    int fl=1;
    for (int i=1; i<=n; i++){
        if (s[i]=='0') fl=0;
        if (c[i]==0) fl=0;
    }
    if (fl){
        ll ans=1;
        for (int i=1; i<=n; i++){
            ans=ans*i%mod;
        }
        cout<<ans<<"\n";
    }
    else{
        cout<<"0\n";
    }
}

int cnt[N];

void spe2(){
    for (int i=0; i<=n; i++){
        cnt[i]=0;
    }
    for (int i=1; i<=n; i++){
        cnt[c[i]]++;
    }
    ll f=1,j=0,cur=0;
    for (int i=1; i<=n; i++){
        cur+=cnt[i-1];
        if (s[i]=='1') f=f*(cur-j)%mod,j++;
    }
    for (int i=1; i<=n-j; i++) f=f*i%mod;
    ll ans=1;
    for (int i=1; i<=n; i++){
        ans=ans*i%mod;
    }
    ans=(ans-f+mod)%mod;
    cout<<ans<<"\n";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);

    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>s;
    for (int i=1; i<=n; i++) cin>>c[i];
    s=" "+s;
    if (n<=18){
        brt();
        return 0;
    }
    if (m==n){
        spe1();
        return 0;
    }
    if (m==1){
        spe2();
        return 0;
    }
    return 0;
}

/*
- check int and long long
- check mod (+mod)%mod
- check the return value
- think carefully then code
- do not overkill
- be patient (i.e. constructive)
- freopen
- the memory limit and the size of arrays
- corner cases (obj <0 : max(0,x))
*/