#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int N = 1e5+5;

ll n,a[N][3];
vector<int> g[3];

void solve(){
    cin>>n;
    for (int i=0; i<3; i++) g[i].clear();
    ll ans=0;
    for (int i=1; i<=n; i++){
        ll mx=0;
        for (int j=0; j<3; j++){
            cin>>a[i][j];
            mx=max(mx,a[i][j]);
        }
        for (int j=0; j<3; j++){
            if (mx==a[i][j]){
                g[j].push_back(i);
                break;
            }
        }
        ans+=mx;
    }
    int lm=n/2,p=-1;
    for (int i=0; i<3; i++){
        if (g[i].size()>lm) p=i;
    }
    if (p==-1){
        cout<<ans<<"\n";
        return;
    }
    vector<ll> vc;
    for (auto u : g[p]){
        sort(a[u],a[u]+3);
        vc.push_back(a[u][2]-a[u][1]);
    }
    sort(vc.begin(),vc.end());
    int nd=g[p].size()-lm;
    for (int i=0; i<nd; i++){
        ans-=vc[i];
    }
    cout<<ans<<"\n";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);

    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin>>t;
    while (t--){
        solve();
    }
    return 0;
}

/*
- check int and long long
- check mod (+mod)%mod
- check the return value
- think carefully then code
- do not overkill
- be patient (i.e. constructive)
- freopen
- the memory limit and the size of arrays
- corner cases (obj <0 : max(0,x))
*/