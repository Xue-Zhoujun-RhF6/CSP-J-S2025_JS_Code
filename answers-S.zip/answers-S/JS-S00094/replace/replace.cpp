#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using ull = unsigned long long;

ull idx(char c,char d){
    return (c-'a'+1)*26+d-'a'+1;
}

const int N = 2e5+5;
const int M = 5e6+6;
const ull bs = 853ull;

struct node {
    ull hs;
    map<int,int> ch;
} t[M];

int cnt=1;

ull ad(ull hs,char c,char d){
    return hs*bs+idx(c,d);
}

int n,q,ed[M];
vector<int> g[M];
unordered_map<ull,int> mp;

void ins(string a,string b){
    int l=a.size(),cur=1;
    for (int i=0; i<l; i++){
        int f=idx(a[i],b[i]);
        if (!t[cur].ch.count(f)){
            t[cur].ch[f]=++cnt;
            g[cur].push_back(cnt);
        }
        int pre=cur;
        cur=t[cur].ch[f];
        t[cur].hs=ad(t[pre].hs,a[i],b[i]);
    }
    ed[cur]++;
}

int ln,dif[M];
ull H[M],pw[M];
string S,T;

void init(){
    H[0]=0;
    for (int i=1; i<=ln; i++){
      //  cout<<S[i]<<","<<T[i]<<endl;
        H[i]=H[i-1]*bs+idx(S[i],T[i]);
    }
    for (int i=1; i<=ln; i++){
        if (S[i]!=T[i]) dif[i]=1;
        else dif[i]=0;
    }
}

ull qy(int l,int r){
    return H[r]-H[l-1]*pw[r-l+1];
}

void dfs(int u){
    for (auto v : g[u]){
        ed[v]+=ed[u];
        dfs(v);
    }
}

int BS(int p){
    int l=p-1,r=ln+1;
    while (l+1<r){
        int mid=l+r>>1;
     //   cout<<qy(p,mid)<<","<<p<<"~"<<mid<<","<<mp[qy(p,mid)]<<endl;
        if (mp[qy(p,mid)]) l=mid;
        else r=mid;
    }
    return l;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);

    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    for (int i=1; i<=n; i++){
        string a,b;
        cin>>a>>b;
        ins(a,b);
    }
    pw[0]=1;
    for (int i=1; i<M; i++){
        pw[i]=pw[i-1]*bs;
    }
    for (int i=1; i<=cnt; i++){
      //  cout<<t[i].hs<<","<<i<<endl;
        mp[t[i].hs]=i;
    }
    dfs(1);
    while (q--){
        cin>>S>>T;
        if (S.size()!=T.size()){
            cout<<"0\n";
            continue;
        }
        ln=S.size();
        S=" "+S,T=" "+T;
        init();
        int mn=1e9,mx=0;
        for (int i=1; i<=ln; i++){
            if (dif[i]){
                mn=min(mn,i);
                mx=max(mx,i);
            }
        }
        ll ans=0;
        for (int i=1; i<=mn; i++){
            ull fr=qy(i,mx-1);
            if (!mp[fr]) continue;
            int cn=BS(i);
         //   cout<<cn<<endl;
            if (cn>=mx){
                ull to=qy(i,cn);
                int A=mp[fr],B=mp[to];
                ans+=ed[B]-ed[A];
              //  cout<<i<<":"<<ed[A]<<"~"<<ed[B]<<endl;
            }
        }
        cout<<ans<<"\n";
    }
    return 0;
}

/*
- check int and long long
- check mod (+mod)%mod
- check the return value
- think carefully then code
- do not overkill
- be patient (i.e. constructive)
- freopen
- the memory limit and the size of arrays
- corner cases (obj <0 : max(0,x))
*/