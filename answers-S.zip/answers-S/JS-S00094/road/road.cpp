#include <bits/stdc++.h>

using namespace std;

using ll = long long;

const int N = 1e4+4+20;
const int M = 1e6+6;

int n,m,k,c[N],fr[15],ed[15],lg[N];

struct edge {
    int u,v,w;
    bool operator < (const edge &b) {
        return w<b.w;
    }
} e[M+N*10];

int ym[N],Ct;
int g[1<<10][N]; // useful
int ct[1<<10];

int fa[N];

inline int ff(int x){
    return x==fa[x]?x:fa[x]=ff(fa[x]);
}

bool mer(int x,int y){
    x=ff(x),y=ff(y);
    if (x==y) return 0;
    fa[x]=y;
    return 1;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);

    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for (int i=1; i<=m; i++){
        cin>>e[i].u>>e[i].v>>e[i].w;
    }
    for (int i=2; i<N; i++) lg[i]=lg[i/2]+1;
    int cnt=m;
    for (int i=1; i<=k; i++){
        cin>>c[i];
        int st=cnt+1;
        fr[i]=st;
        for (int j=1; j<=n; j++){
            cnt++;
            cin>>e[cnt].w;
            e[cnt].u=i+n,e[cnt].v=j;
        }
        ed[i]=cnt;
        sort(e+st,e+1+cnt);
    }
    sort(e+1,e+1+m);
    for (int i=1; i<=n; i++) fa[i]=i;
    for (int i=1; i<=m; i++){
        int u=e[i].u,v=e[i].v,w=e[i].w;
        if (mer(u,v)) ym[++Ct]=i;
    }
    //cout<<"OK"<<endl;
    //cout<<k<<endl;
    for (int i=1; i<(1<<k); i++){
        for (int j=1; j<=n+k; j++) fa[j]=j;
        int it=i&-i,ms=i^it;
        it=lg[it]+1;
        int pl=0,pr=fr[it];
        while (pl<=ct[ms] || pr<=ed[it]){
            if (pr>ed[it] || (pl<=ct[ms] && e[g[ms][pl]].w<e[pr].w)){
                auto p=g[ms][pl];
                if (mer(e[p].u,e[p].v)) g[i][++ct[i]]=p;
                pl++;
            }
            else{
                if (mer(e[pr].u,e[pr].v)) g[i][++ct[i]]=pr;
                pr++;
            }
        }
    }
  //  cout<<"DONE useful"<<endl;
    ll ans=1e18;
    for (int i=0; i<(1<<k); i++){
        for (int j=1; j<=n+k; j++) fa[j]=j;
        int pl=0,pr=0;
        ll sum=0;
        for (int j=0; j<k; j++){
            if (i>>j&1) sum+=c[j+1];
        }
        while (pl<=ct[i] || pr<=Ct){
            if (pr>Ct || (pl<=ct[i] && e[g[i][pl]].w<e[ym[pr]].w)){
                auto p=g[i][pl];
                if (mer(e[p].u,e[p].v)) sum+=e[p].w;
                pl++;
            }
            else{
                auto p=ym[pr];
                if (mer(e[p].u,e[p].v)) sum+=e[p].w;
                pr++;
            }
        }
      //  cout<<i<<":"<<sum<<endl;
        ans=min(ans,sum);
    }
    cout<<ans<<"\n";
    return 0;
}

/*
- check int and long long
- check mod (+mod)%mod
- check the return value
- think carefully then code
- do not overkill
- be patient (i.e. constructive)
- freopen
- the memory limit and the size of arrays
- corner cases (obj <0 : max(0,x))
*/