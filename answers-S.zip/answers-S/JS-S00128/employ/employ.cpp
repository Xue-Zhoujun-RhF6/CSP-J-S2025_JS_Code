#include <iostream>
#include <cstring>
using namespace std;
int n,m;
string s;
int a[1010];
long long ans1;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    for(int i=1;i<=n;i++){
        ans1=ans1*i%998244353;
    }
    if(m==1){
        cout<<ans1;
        return 0;
    }
    cout<<0;
    return 0;
}
