#include <iostream>
#include <algorithm>
#include <queue>
#include <cmath>
using namespace std;
int n,m,k;
long long money;
struct node{
    int u,v;
    long long w;
}a[11000100];
int fa[100100];
bool cmp(node x,node y){
    return x.w<=y.w;
}
int find(int x){
    if(x!=fa[x])
        fa[x]=find(fa[x]);
    return fa[x];
}
void un(int x,int y){
    fa[x]=y;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        cin>>a[i].u>>a[i].v>>a[i].w;
    }
    for(int i=1;i<=k;i++){
        int x;
        cin>>x;
        for(int i=1;i<=n;i++){
            cin>>a[n+i*k].w;
            a[n+i*k].u=1;
            a[n+i*k].v=n+k;
        }
    }
    sort(a+1,a+n+k*n+1,cmp);
    for(int i=1;i<=n*k+n;i++)
        fa[i]=i;
    for(int i=1;i<=n+k*n+1;i++){
        int fl=0;
        for(int j=1;j<=n;j++){
            if(fa[j]==j)
                fl++;
        }
        if(fl<=1){
            cout<<money;
            return 0;
        }
        if(find(a[i].u)!=find(a[i].v)){
            un(fa[a[i].u],a[i].v);
            money+=a[i].w;
        }
    }
    return 0;
}
