#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
int t,num[4],n,x,y,z;
int a[101000],b[101000],c[101000];
long long ans;
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--){
        cin>>n;
        ans=0;
        num[1]=num[2]=num[3]=0;
        for(int i=1;i<=n;i++)
        a[i]=b[i]=c[i]=0;
        for(int i=1;i<=n;i++){
            cin>>x>>y>>z;
            if(x>=y){
                if(x>=z)
                    num[1]++,ans+=x,a[num[1]]=x-max(y,z);
                else
                    num[3]++,ans+=z,c[num[3]]=z-max(x,y);
            }
            else{
                if(y>=z)
                    num[2]++,ans+=y,b[num[2]]=y-max(x,z);
                else
                    num[3]++,ans+=z,c[num[3]]=z-max(x,y);
            }
        }
        if(num[1]>n/2){
            sort(a+1,a+num[1]+1);
            for(int i=num[1]-n/2;i>=1;i--)
                ans-=a[i];
        }
        else if(num[2]>n/2){
            sort(b+1,b+num[2]+1);
            for(int i=num[2]-n/2;i>=1;i--)
                ans-=b[i];
        }
        else if(num[3]>n/2){
            sort(c+1,c+num[3]+1);
            for(int i=num[3]-n/2;i>=1;i--)
                ans-=c[i];
        }
        cout<<ans<<endl;
    }
    return 0;
}
