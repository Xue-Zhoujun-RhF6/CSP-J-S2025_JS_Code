#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
const int N = 1e6+5;
unordered_map<string,string> key;

ll dif(string x,string y){
	if(x.length()!=y.length()) return 0;
	int cnt = 0;
	for(auto it:key){
		if(it.first.length()>x.length()) continue;
		size_t pos = x.find(it.first);
		while(pos!=string::npos){
			string tmp = x;
			tmp.replace(pos,it.second.length(),it.second);
			if(tmp==y) ++cnt;
			pos = x.find(it.first,pos+it.first.length());
		}
	}
	return cnt;
}

int main(){
	freopen("replace.in","r",stdin);			//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	freopen("replace.out","w",stdout);			//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	
	int n,q;
	cin>>n>>q;
	for(int i=0;i<n;i++){
		string x,y;
		cin>>x>>y;
		key[x] = y;
	}
	for(int i=0;i<q;i++){
		string x,y;
		cin>>x>>y;
		printf("%lld\n",dif(x,y));
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
