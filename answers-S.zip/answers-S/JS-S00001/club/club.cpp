#include<bits/stdc++.h>
//competition ends at 02:33
#define ll long long
#define endl '\n'
using namespace std;
const int N = 1e5+5;
const int NN = 5e4+5;
int a[15][5];


int main(){
	freopen("club.in","r",stdin);			//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	freopen("club.out","w",stdout);			//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		for(int i=0;i<n;i++){
			cin>>a[i][1]>>a[i][2]>>a[i][3];
		}
		int maxn = 0;
		if(n==2){
			for(int i=1;i<=3;i++){
				for(int j=1;j<=3;j++){
					if(i==j) continue;
					maxn = max(a[0][i]+a[1][j],maxn);
				}
			}
		}
		if(n==4){
			int mapp[5] = {0};
			for(int i=1;i<=3;i++){
				mapp[i]++;
				for(int j=1;j<=3;j++){
					mapp[j]++;
					for(int k=1;k<=3;k++){
						if(mapp[k]>2) continue;
						mapp[k]++;
						for(int l=1;l<=3;l++){
							if(mapp[l]>2) continue;
							mapp[l]++;
							maxn = max(maxn,a[0][i]+a[1][j]+a[2][k]+a[3][l]);
							mapp[l]--;
						}
						mapp[k]--;
					}
					mapp[j]--;
				}
				mapp[i]--;
			}
		}
		cout<<maxn<<endl;
		memset(a,0,sizeof a);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
