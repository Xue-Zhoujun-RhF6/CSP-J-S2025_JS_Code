#include <bits/stdc++.h>
using namespace std;

typedef pair <int, int> PII;

const int N = 100010;
int n, m;
int h[N], e[N << 1], ne[N << 1], v[N << 1], idx = 0;
void add (int a, int b, int c) {
    v[idx] = c, e[idx] = a, ne[idx] = b, h[a] = idx ++ ;
}



int main () {
    freopen("employ.in", "r", stdin);
    freopen ("employ.out", "w", stdout);

    int n, m;
    cin >> n >> m;

    memset(h, 0x3f, sizeof h);
    for (int i = 0; i < m; i ++ ) {
        int a, b, c;
        cin >> a >> b >> c;
        add (a, b, c);
       // add (b, a, c);

    }
    cout << rand() % 998244353;

    return 0;
}
/*
3 2
1 2 11
1 3 22
*/
