#include <bits/stdc++.h>
using namespace std;

const int N = 100010;



int main () {
    freopen("replace.in", "r", stdin);
    freopen ("replace.out", "w", stdout);

    //
    int n, m, k;
    cin >> n >> m;



    return 0;
}
