#include <bits/stdc++.h>
using namespace std;

const int N = 100010;
int ww, n;
int a[N][5], f[N], ans;
int v, m[5];

int A = 1, B = 1;

void dfs (int d) {
    if (d == n + 1) {
        ans = max(ans, v);

        return ;
    }
    for (int i = 1; i <= 3; i ++ ) {
        if (m[i] == (n >> 1)) continue;
        m[i] ++ ;
        v += a[d][i];
        dfs (d + 1);
        v -= a[d][i];
        m[i] -- ;
    }
}

int main () {
    freopen("club.in", "r", stdin);
    freopen ("club.out", "w", stdout);

    cin >> ww;
    while (ww -- ) {
        cin >> n;
        for (int i = 1; i <= n; i ++ ) {
            cin >> a[i][1] >> a[i][2] >> a[i][3];
            if (a[i][2] != 0 || a[i][3] != 0) A = 0;
            if (a[i][3] != 0) B = 0;
        }

        if (A) {
            for (int i = 1; i <= n; i ++ ) f[i] = a[i][1];
            sort (f, f + n + 1);
            for (int i = 1; i <= (n >> 1); i ++ ) ans += f[i];
            cout << ans;
            return 0;
        }
        if (B) {

        }
        dfs (1);

        cout << ans << endl;

        //update
        v = ans = 0;
        m[1] = m[2] = m[3] = 0;
        memset(f, 0, sizeof f);
        for (int i = 1; i <= n; i ++ ) a[i][1] = a[i][2] = a[i][3] = 0;

    }
    return 0;
}

