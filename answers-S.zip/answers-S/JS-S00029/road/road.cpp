#include <bits/stdc++.h>
using namespace std;

const int N = 10010; // city
const int M = 1000010;

int n, m, kk;
int d[N][N];

int st[N]; // if add int the tree

struct E {
    int a, b, c;
}e[M];
int idx;



int main () {
    freopen("road.in", "r", stdin);
    freopen ("road.out", "w", stdout);
    for (int i = 0; i < N; i ++ )
        for (int j = 0; j < N; j ++ ) d[i][j] = -1;
    cin >> n >> m >> kk;

    for (int i = 0; i < m; i ++ ) {
        int a, b, c;
        cin >> a >> b >> c;

        if (d[a][b] != -1)
            d[a][b] = min (d[a][b], c);
        else d[a][b] = c;

        d[b][a] = d[a][b];
    }

    int ch;
    while (kk -- ) {
        cin >> ch; // ch = 0 特殊
        for (int i = 1; i <= n; i ++ ) {
            int c;
            cin >> c;
            if (d[ch][i] != -1) {
                d[ch][i] = min (d[ch][i], c);
            else d[ch][i] = c;

            d[i][ch] = d[ch][i];
        }
    }
    for (int i = 1; i <= n; i ++ ) d[i][i] = 0;

    for (int i = 1; i <= n; i ++ )
        for (int j = 1; j <= i - 1; j ++ ) {
            if (d[i][j] == -1) continue;
            e[idx ++ ] = {i, j, d[i][j]};

        }



    return 0;
}
