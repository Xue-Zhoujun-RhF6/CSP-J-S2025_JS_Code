#include<bits/stdc++.h>
#define N 100005
#define pii pair<int,int>
#define fst first
#define sec second
using namespace std;
int T,n,ans;
struct node{
    pii a[4];
}A[N];
bool cmp(node x,node y){
    if(x.a[3].fst-x.a[2].fst!=y.a[3].fst-y.a[2].fst){
        return x.a[3].fst-x.a[2].fst<y.a[3].fst-y.a[2].fst;
    }
}
vector<node> rec[4];
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    cin>>T;
    while(T--){
        cin>>n;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=3;j++){
                cin>>A[i].a[j].fst;
                A[i].a[j].sec=j;
            }
            sort(A[i].a+1,A[i].a+4);
        }
        ans=0;
        for(int i=1;i<=3;i++){
            vector<node>().swap(rec[i]);
        }
        for(int i=1;i<=n;i++){
            rec[A[i].a[3].sec].push_back(A[i]);
            ans+=A[i].a[3].fst;
        }
        for(int i=1;i<=3;i++){
            sort(rec[i].begin(),rec[i].end(),cmp);
            if(rec[i].size()>n/2){
                for(int j=0;j<rec[i].size()-n/2;j++){
                    node x=rec[i][j];
                    ans-=x.a[3].fst-x.a[2].fst;
                }
            }
        }
        cout<<ans<<"\n";
    }
    return 0;
}
