#include<bits/stdc++.h>
#define int long long
#define N 2000005
using namespace std;
int n,m,k,tot,fa[N];
int u,v,w,ans;
int c[N],a[N],deg[15],rec[15];
struct node{
    int u,v,w;
}edge[N];
bool cmp(node x,node y){
    return x.w<y.w;
}
int find(int x){
    return x==fa[x]?x:fa[x]=find(fa[x]);
}
void merge(int u,int v,int w){
    int fu=find(u),fv=find(v);
    if(fu==fv) return;
    fa[fu]=fv,ans+=w;
    if(u>n) deg[u-n]++,rec[u-n]+=w;
}
signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        cin>>u>>v>>w;
        edge[++tot]={u,v,w};
    }
    for(int i=1;i<=k;i++){
        cin>>c[i],deg[i]=rec[i]=0;
        for(int j=1;j<=n;j++){
            cin>>w;
            edge[++tot]={n+i,j,w+c[i]};
        }
    }
    sort(edge+1,edge+tot+1,cmp);
    ans=0;
    for(int i=1;i<=n+k;i++) fa[i]=i;
    for(int i=1;i<=tot;i++){
        merge(edge[i].u,edge[i].v,edge[i].w);
    }
    for(int i=1;i<=k;i++){
        if(deg[i]==1) ans-=rec[i];
        ans-=(deg[i]-1)*c[i];
    }
    cout<<ans;
    return 0;
}
