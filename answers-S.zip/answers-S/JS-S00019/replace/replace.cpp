#include<bits/stdc++.h>
#define int long long
#define N 200005
#define M 5000005
using namespace std;
const int base=13331,mod=998244353;
int n,q,nxt[M],ans;
string s1,s2;
vector<string> A,B;
vector<int> rec1[N],rec2[N];
vector<int> hsh1,hsh2;
bool vis[M];
int power(int n,int m){
    int res=1;
    while(m){
        if(m&1) res=res*n%mod;
        n=n*n%mod,m>>=1;
    }
    return res;
}
int gethsh1(int l,int r){
    return (hsh1[r]-hsh1[l-1]*power(base,r-l+1)%mod+mod)%mod;
}
int gethsh2(int l,int r){
    return (hsh2[r]-hsh2[l-1]*power(base,r-l+1)%mod+mod)%mod;
}
void KMP(string s1,string s2,int id){
    s1=" "+s1;
    rec1[id].push_back(0);
    rec1[id].push_back(0);
    for(int i=1;i<s1.size();i++) nxt[i]=0;
    for(int i=2,j=0;i<s1.size();i++){
        while(j&&s1[i]!=s1[j+1]) j=nxt[j];
        if(s1[i]==s1[j+1]) j++;
        nxt[i]=j,rec1[id].push_back(j);
    }

    s2=" "+s2;
    rec2[id].push_back(0);
    rec2[id].push_back(0);
    for(int i=1;i<s2.size();i++) nxt[i]=0;
    for(int i=2,j=0;i<s2.size();i++){
        while(j&&s2[i]!=s2[j+1]) j=nxt[j];
        if(s2[i]==s2[j+1]) j++;
        nxt[i]=j,rec2[id].push_back(j);
    }
}
int solve(string s1,string s2,int id){
    s1=" "+s1;
    s2=" "+s2;
    vector<int>().swap(hsh1);
    vector<int>().swap(hsh2);
    hsh1.push_back(0);
    for(int i=1,sum=0;i<s1.size();i++){
        sum=(sum*base%mod+s1[i]-'a')%mod;
        hsh1.push_back(sum);
    }
    hsh2.push_back(0);
    for(int i=1,sum=0;i<s2.size();i++){
        sum=(sum*base%mod+s2[i]-'a')%mod;
        hsh2.push_back(sum);
    }
    int res=0;
    string t=" "+A[id];

    for(int i=1;i<t.size();i++){
        nxt[i]=rec1[id][i];
        vis[i]=0;
    }
    for(int i=1,j=0;i<s1.size();i++){
        while(j&&s1[i]!=t[j+1]) j=nxt[j];
        if(s1[i]==t[j+1]) j++;
        if(j==t.size()-1) vis[i]=1,j=nxt[j];
    }

    t=" "+B[id];
    int len=t.size()-1;
    for(int i=1;i<t.size();i++){
        nxt[i]=rec2[id][i];
    }
    for(int i=1,j=0;i<s2.size();i++){
        while(j&&s2[i]!=t[j+1]) j=nxt[j];
        if(s2[i]==t[j+1]) j++;
        if(j==t.size()-1){
            j=nxt[j];
            if(gethsh1(1,i-len)==gethsh2(1,i-len)&&gethsh1(i+1,len)==gethsh2(i+1,len))
                res+=vis[i];
        }
    }
    return res;
}
signed main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    cin>>n>>q;
    for(int i=0;i<n;i++){
        cin>>s1>>s2;
        A.push_back(s1);
        B.push_back(s2);
        KMP(s1,s2,i);
    }
    while(q--){
        cin>>s1>>s2;
        ans=0;
        for(int i=0;i<n;i++){
            ans+=solve(s1,s2,i);
        }
        cout<<ans<<"\n";
        //cout<<endl;
    }
    return 0;
}
