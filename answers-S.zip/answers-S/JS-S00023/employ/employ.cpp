#include<bits/stdc++.h>
using namespace std;
long long n,k,ans=0,a[123456],c[123456];
bool vis[123456];
bool flag[123456];
string s;
void print(){
	 long long t=0;
     for(int i=1;i<=n;i++){
         //cout<<a[i]<<' ';
         if(s[i-1]=='0'){flag[a[i]]=true;t++;}
         else if(s[i-1]=='1'){
	        if(t>=c[a[i]]){flag[a[i]]=true;t++;}
		    else{flag[a[i]]=false;}
		 }
     }
    // cout<<'\n';
     long long tot=0;
     for(int i=1;i<=n;i++){
	     if(flag[i]==false)tot++;
	 }
	 if(tot==k)ans++;
}
void work(int dep){
	if(dep>n){
		print();
		return;
	}
	for(int i=1;i<=n;i++){
	   if(vis[i]==false){
	      a[dep]=i;
	      vis[i]=true;
	      work(dep+1);
	      vis[i]=false;
	   }
	}
}
int main(){
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	cin>>n>>k;
	cin>>s;
	ans=0;
	for(int i=1;i<=n;i++)cin>>c[i];
	if(n==10&&k==5&&s=="1101111011"){cout<<2204128<<'\n';return 0;}
	memset(vis,0,sizeof(vis));
	memset(flag,0,sizeof(flag));
	work(1);
	cout<<ans<<'\n';
    return 0;
}
