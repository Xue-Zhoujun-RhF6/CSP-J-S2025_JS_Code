#include<bits/stdc++.h>
using namespace std;
string st1[123456],st2[123456];
int main(){
	freopen("replace.in","r",stdin);
	freopen("replace.out","w",stdout);
    int n,q;
    cin>>n>>q;
    for(int i=1;i<=n;i++){
	    cin>>st1[i]>>st2[i];
	}
	for(int i=1;i<=q;i++){
		int ans=0;
		string s1,s2;
		cin>>s1>>s2;
		if(s1.size()!=s2.size()){
		    cout<<0<<'\n';
		    continue;
		}
	    int len=s1.size();
	    for(int j=0;j<len;j++){
		    for(int k=0;k<=len-j;k++){
			    //cout<<j<<' '<<k<<' '<<'\n';
			    string s3=s1.substr(0,j),s4=s2.substr(0,j);
			    string s5=s1.substr(j,k),s6=s2.substr(j,k);
			    string s7=s1.substr(j+k,len-j-k),s8=s2.substr(j+k,len-j-k);
			    if(s3=="")s3="*";
			    if(s4=="")s4="*";
			    if(s5=="")s5="*";
			    if(s6=="")s6="*";
			    if(s7=="")s7="*";
			    if(s8=="")s8="*";
			    //cout<<s3<<' '<<s5<<' '<<s7<<'\n';
			    //cout<<s4<<' '<<s6<<' '<<s8<<'\n';
			    for(int o=1;o<=n;o++){
				    if(st1[o]==s5&&st2[o]==s6&&s3==s4&&s7==s8){
					   ans++;
					}
				}
				//cout<<"ANS:"<<ans<<'\n';
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}
