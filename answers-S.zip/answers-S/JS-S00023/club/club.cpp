#include<bits/stdc++.h>
using namespace std;
struct node{
	int x,y,z,t;
}a[123456];
bool cmp(node u,node v){
    if(max(max(u.x,u.y),u.z)==u.x)u.t=u.x-max(u.y,u.z);
    if(max(max(u.x,u.y),u.z)==u.y)u.t=u.y-max(u.x,u.z);
    if(max(max(u.x,u.y),u.z)==u.z)u.t=u.z-max(u.x,u.y);
    if(max(max(v.x,v.y),v.z)==v.x)v.t=v.x-max(v.y,v.z);
    if(max(max(v.x,v.y),v.z)==v.y)v.t=v.y-max(v.x,v.z);
    if(max(max(v.x,v.y),v.z)==v.z)v.t=v.z-max(v.x,v.y);
    return u.t>v.t;
}
int main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	int T;
	cin>>T;
	while(T--){
		memset(a,0,sizeof(a));
		int n;
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>a[i].x>>a[i].y>>a[i].z;
		}
		int ans=0,s1=0,s2=0,s3=0;
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;i++){
			//cout<<a[i].x<<' '<<a[i].y<<' '<<a[i].z<<'\n';
			if(max(max(a[i].x,a[i].y),a[i].z)==a[i].x){
			   if(s1<n/2){
				   ans=ans+a[i].x;
				   s1++;
			   }
			   else{
				   ans=ans+max(a[i].y,a[i].z);
			   }
			}
			else if(max(max(a[i].x,a[i].y),a[i].z)==a[i].y){
			   if(s2<n/2){
				   ans=ans+a[i].y;
				   s2++;
			   }
			   else{
				   ans=ans+max(a[i].x,a[i].z);
			   }
			}
			else if(max(max(a[i].x,a[i].y),a[i].z)==a[i].z){
			   if(s3<n/2){
				   ans=ans+a[i].z;
				   s3++;
			   }
			   else{
				   ans=ans+max(a[i].x,a[i].y);
			   }
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}
