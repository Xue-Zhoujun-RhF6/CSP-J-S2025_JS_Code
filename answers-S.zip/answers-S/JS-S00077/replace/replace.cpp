#include <bits/stdc++.h>
#define int long long
using namespace std;
int n, q;
int rand(int l, int r)
{
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<int> dis(l,r);
    return dis(gen);
}
struct node{
    string l ,r;
};
signed main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin >> n >> q;
    for (int i = 1; i <= n ; i ++)
    {
        cin >> s.l >> s.r;
    }
    while(q--){
        string t1, t2;cin >> t1 >> t2;
        cout << rand(1,100) << endl;
    }
    return 0;
}
