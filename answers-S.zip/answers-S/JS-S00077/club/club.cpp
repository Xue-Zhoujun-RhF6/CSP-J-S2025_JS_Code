#include <bits/stdc++.h>
#define int long long
using namespace std;
struct node{
    int a, b, c;
}num[100005];
int vis[4005][202];
int t;int cnt1,cnt2,cnt3;
int dfs(int sum,int i, int n)
{
    if(i > n)return sum;
    int res1 = 0, res2 = 0, res3 = 0;
    if(cnt1<n/2)
    {
        cnt1++;
        res1 = dfs(sum + num[i].a,i+1,n);
        cnt1 --;
    }
    if(cnt2<n/2) {
        cnt2 ++;
        res2 = dfs(sum + num[i].b,i+1,n);
        cnt2--;
    }
    if(cnt3<n/2) {
        cnt3 ++;
        res3 = dfs(sum + num[i].c,i+1,n);
        cnt3 --;
    }
    return max(max(res1,res2),res3);
}
signed main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%lld",&t);while(t--){
        int n;scanf("%lld",&n);
        for (int i = 1; i <= n; i ++){
            scanf("%lld%lld%lld",&num[i].a,&num[i].b,&num[i].c);
        }
        printf("%lld\n",dfs(0,1,n));
    }
    return 0;
}
