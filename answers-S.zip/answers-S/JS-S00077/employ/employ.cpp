#include <bits/stdc++.h>
#define int long long
const int MOD = 998244353;
using namespace std;
int c[502], n, m;
bool p[502];
string s;
vector<int> path;
bool check(vector<int> path)
{
    int pass = 0, got = 0;
    for (int i = 0; i < path.size(); i ++)
    {
        if(s[i] == '0' || pass >= c[path[i]]){
            pass++;
        }
        else got ++;
    }
    return got >= m;
}
int ans = 0;
void dfs()
{
    if(path.size() == n){
        if(check(path)){
            ans = (ans+1)%MOD;
            //for (int i = 0; i < n; i ++)cout << path[i] << ' ';
        }
        return ;
    }
    for (int i = 1; i <= n; i ++)
    {
        if(p[i] == 0){
            p[i] = 1;
            path.push_back(i);
            dfs();
            path.pop_back();
            p[i] = 0;
        }
    }
}
signed main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    scanf("%lld%lld",&n,&m);
   cin >> s;
    for (int i = 1; i <= n; i ++)
    {
        scanf("%lld",&c[i]);
    }
    dfs();
    printf("%lld",ans);
    return 0;
}
