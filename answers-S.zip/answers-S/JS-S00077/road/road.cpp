#include <bits/stdc++.h>
#define int long long
using namespace std;
int rand(int l, int r)
{
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<int> dis(l,r);
    return dis(gen);
}
struct node{
    int u, v,w;
}a[1000006];
signed main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n, m, k;scanf("%lld%lld%lld",&n,&m,&k);
    for (int i = 1; i <= m; i ++)
    {
        cin >> a[i].u >> a[i].v >> a[i].w;
    }
    cout << rand(100,1001000);
    return 0;
}
