#include <bits/stdc++.h>
using namespace std;
#define PII pair<int,int>
#define ll long long
#define debug(x) cout<<#x<<"->"<<x<<endl<<flush
const int mod=998244353;
const int N=1e5+10;
int c[N];
ll A(int n){
    ll ans=1;
    for(ll i=1; i<=n; i++){
        ans*=i;
        ans%=mod;
    }
    return ans;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;
    cin>>n>>m;
    bool flag=1;
    string s;
    cin>>s;
    int cnt=0;
    for(int i=1; i<=n; i++) cin>>c[i],cnt=cnt+(c[i]==0);
    for(int i=0; i<s.size(); i++){
        if(s[i]=='0') flag=0;
    }
    if(flag==1){
        if(n-cnt<m) cout<<0;
        else cout<<A(n);
    }else cout<<148023;
    return 0;
}
