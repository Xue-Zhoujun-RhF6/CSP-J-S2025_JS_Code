#include <bits/stdc++.h>
using namespace std;
#define PII pair<int,int>
#define ll long long
#define debug(x) cout<<#x<<"->"<<x<<endl<<flush
const int N=2e5+10;
struct node{
    string s1,s2;
    int py,qd;
}a[N];
bool cmp(node a,node b){
    return a.s1.size()>b.s1.size();
}
vector<int> g[2000005];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    int n,m,flag=0;
    cin>>n>>m;
    for(int i=1; i<=n; i++){
        cin>>a[i].s1>>a[i].s2;
        int w1=0;
        for(int j=0; j<a[i].s1.size(); j++){
            if(a[i].s1[j]=='b') w1=j;
        }
        int w2=0;
        for(int j=0; j<a[i].s2.size(); j++){
            if(a[i].s2[j]=='b') w2=j;
        }
        a[i].py=w1-w2+1000000,a[i].qd=w1;
        g[w1-w2+1000000].push_back(i);
    }
    sort(a+1,a+1+n,cmp);
    while(m--){
        string h1,h2;
        cin>>h1>>h2;
        if(h1.size()!=h2.size()) cout<<0<<"\n";
        else if(n<=1000){
            int w1=0;
            for(int i=0; i<h1.size(); i++){
                if(h1[i]!=h2[i]){
                    w1=i;
                    break;
                }
            }
            int w2=0;
            for(int i=h1.size()-1; i>=0; i--){
                if(h1[i]!=h2[i]){
                    w2=i;
                    break;
                }
            }
            int cnt=0;
            for(int i=1; i<=n; i++){
                if(a[i].s1.size()<w2-w1+1) break;
                if(h1.find(a[i].s1)==h2.find(a[i].s2)&&h1.find(a[i].s1)!=-1) cnt++;
            }
            cout<<cnt<<"\n";
        }else{
            int w1=0;
            for(int j=0; j<h1.size(); j++){
                if(h1[j]=='b') w1=j;
            }
            int w2=0;
            for(int j=0; j<h2.size(); j++){
                if(h2[j]=='b') w2=j;
            }
            int u=w1-w2+1000000;
            if(!g[u].size()) cout<<0<<"\n";
            else{
                int cnt=0;
                for(int i=0; i<g[u].size(); i++){
                    if(w1>=a[g[u][i]].qd) cnt++;
                }
                cout<<cnt<<"\n";
            }
        }
    }
    return 0;
}
/*
4 2
xabcx xadex
ab cd
bc de
aa bb
xabcx xadex
aaaa bbbb
*/
