#include <bits/stdc++.h>
using namespace std;
#define PII pair<int,int>
#define ll long long
#define debug(x) cout<<#x<<"->"<<x<<endl<<flush
const int N=1e5+10;
const int M=1e6+10;
int n,m,k;
vector<PII> g[N];
int fa[N+15];
int get(int u){
    if(fa[u]==u) return u;
    return fa[u]=get(fa[u]);
}
void Merge(int u,int v){
    int fu=get(u),fv=get(v);
    fa[fu]=fv;
}
struct node{
    int u,v;
    ll w;
}e[M];
bool cmp(node a,node b){return a.w<b.w;}
void kruskal(){
    ll ans=0,cnt=0;
    for(int i=1; i<=n; i++) fa[i]=i;
    sort(e+1,e+1+m,cmp);
    for(int i=1; i<=m; i++){
        int fu=get(e[i].u),fv=get(e[i].v);
        if(fu==fv) continue;
        fa[fu]=fv;
        ans+=e[i].w;
        cnt++;
        if(cnt==n-1) break;
    }
    cout<<ans;
}
ll c[15],a[15][N],op[N];
bool vis[N];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    if(k==0){
        for(int i=1; i<=m; i++) cin>>e[i].u>>e[i].v>>e[i].w;
        kruskal();//It is right!
    }else{
        for(int i=1; i<=m; i++){
            int u,v,w;
            cin>>u>>v>>w;
            g[u].push_back(make_pair(v,w));
            g[v].push_back(make_pair(u,w));
        }
        for(int i=1; i<=n+15; i++) fa[i]=i;
        bool flag=0;
        int ans=0;
        for(int i=1; i<=k; i++){
            cin>>c[i];
            ans+=c[i];
            if(c[i]!=0) flag=1;
            for(int j=1; j<=n; j++) cin>>a[i][j];
        }

            for(int i=1; i<=k; i++){
                for(int j=1; j<=n; j++){
                    if(i==1) op[j]=a[i][j];
                    else op[j]=min(op[j],a[i][j]);
                }
            }
            //make more
            queue<int> q;
            for(int i=1; i<=n; i++){
                if(op[i]==0) Merge(i,n+1),vis[i]=1,q.push(i);
            }
            while(!q.empty()){
                int i=q.front();
                q.pop();
                for(int j=0; j<g[i].size(); j++){
                    int v=g[i][j].first,w=g[i][j].second;
                    if(vis[v]) continue;
                    if(w>op[v]) Merge(v,n+1),ans+=op[v];
                    else Merge(i,v),ans+=w;
                    q.push(v);
                    vis[v]=1;
                }
            }
            cout<<ans;
    }
    return 0;
}
/*
4 4 2
1 4 6
2 3 7
4 2 5
4 3 4
1 1 8 2 4
100 1 3 2 4
*/
