#include <bits/stdc++.h>
using namespace std;
#define PII pair<int,int>
#define ll long long
#define debug(x) cout<<#x<<"->"<<x<<endl<<flush
const int N=1e5+10;
int dp[2][205][205];
struct npde{
    int num,op;
};
struct node{
    int a1,a2,a3;
    npde p[4];
}a[N];
bool cmp1(node a,node b){
    return a.a1>b.a1;
}
bool cmp2(npde a,npde b){
    return a.num>b.num;
}
bool cmp(node a,node b){
    if(a.p[1].num>b.p[1].num||(a.p[1].num==b.p[1].num&&a.p[2].num>b.p[2].num)||(a.p[1].num==b.p[1].num&&a.p[2].num==b.p[2].num&&a.p[3].num>b.p[3].num)) return 1;
    return 0;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        bool f2=0,f3=0;
        for(int i=1; i<=n; i++){
            cin>>a[i].a1>>a[i].a2>>a[i].a3;
            a[i].p[1].num=a[i].a1,a[i].p[2].num=a[i].a2,a[i].p[3].num=a[i].a3;
            a[i].p[1].op=1,a[i].p[2].op=2,a[i].p[3].op=3;
            sort(a[i].p+1,a[i].p+1+3,cmp2);
            if(a[i].a2!=0) f2=1;
            if(a[i].a3!=0) f3=1;
        }
        if(n<=200){
            memset(dp,0,sizeof(dp));
            for(int k=1; k<=n; k++){
                int k1=k&1;
                int k2=(k-1)&1;
                for(int i=0; i<=n/2; i++){
                    for(int j=0; j<=n/2; j++){
                        if(i+j>k) break;
                        if(i>0) dp[k1][i][j]=max(dp[k1][i][j],dp[k2][i-1][j]+a[k].a1);
                        if(j>0) dp[k1][i][j]=max(dp[k1][i][j],dp[k2][i][j-1]+a[k].a2);
                        if(k-i-j>0) dp[k1][i][j]=max(dp[k1][i][j],dp[k2][i][j]+a[k].a3);
                    }
                }
            }
            int ans=0;
            for(int i=0; i<=n/2; i++){
                for(int j=n/2-i; j<=n/2; j++){
                    ans=max(ans,dp[(n&1)][i][j]);
                }
            }
            cout<<ans<<"\n";
        }else if(f2==0&&f3==0){
            sort(a+1,a+1+n,cmp1);
            int ans=0;
            for(int i=1; i<=n/2; i++){
                ans+=a[i].a1;
            }
            cout<<ans<<"\n";
        }else{
            //choose the max to sort!
            sort(a+1,a+1+n,cmp);
            int o[10],ans=0;
            memset(o,0,sizeof(o));
            for(int i=1; i<=n; i++){
                int t1=a[i].p[1].num,t2=a[i].p[2].num,t3=a[i].p[3].num;
                int p1=a[i].p[1].op,p2=a[i].p[2].op,p3=a[i].p[3].op;
                if(o[p1]<n/2) ans+=t1;
                else if(o[p2]<n/2) ans+=t2;
                else ans+=t3;
            }
            cout<<ans<<"\n";
        }
    }
    return 0;
}
/*
3
4
4 2 1
3 2 4
5 3 4
3 5 1
4
0 1 0
0 1 0
0 2 0
0 2 0
2
10 9 8
4 0 0
*/
