#include<bits/stdc++.h>

using namespace std;

const int mod = 998244353;

char c[505];
int x[505];
int dp[262222][19];

signed main() {
	freopen("employ.in", "r", stdin);
	freopen("employ.out", "w", stdout);
	int n, m;
	scanf("%d %d %s", &n, &m, c + 1);
	int c1 = 0, c2 = 0;
	for (int i = 1; i <= n; i++) {
		scanf("%d", x + i);
		c1 += (x[i] > 0);
		c2 += (c[i] != '0');
	}
	if (n <= 18) {
		dp[0][0] = 1;
		for (int i = 0; i < (1 << n); i++) {
			int j = __builtin_popcount(i);
			for (int k = 0; k < n; k++)
				if (!((i >> k) & 1))
					for (int l = 0; l <= j; l++) {
						int bk = j - l;
						if (bk >= x[k + 1] or c[j + 1] == '0')
							(dp[i | (1 << k)][l] += dp[i][l]) %= mod;
						else
							(dp[i | (1 << k)][l + 1] += dp[i][l]) %= mod;
					}
		}
		int ans = 0;
		for (int i = m; i <= n; i++) (ans += dp[(1 << n) - 1][i]) %= mod;
		cout << ans;
	} else if (min(c1, c2) >= m) {
		long long ans = 1;
		for (int i = 1; i <= n; i++)
			(ans *= i) %= mod;
		cout << ans;
	} else cout << 0;
}