#include<bits/stdc++.h>

using namespace std;

struct edge {
	int u, v, w;
} f[1000005], nw[10005], tmp[110005];

vector<edge> v[15];
int c[15];
int fa[10015];

bool operator <(edge coo, edge kie) {
	return coo.w < kie.w;
}

int ff(int x) {
	if (fa[x] == x) return x;
	return fa[x] = ff(fa[x]);
}

signed main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	int n, m, k;
	scanf("%d %d %d", &n, &m, &k);
	for (int i = 0; i < m; i++) scanf("%d %d %d", &f[i].u, &f[i].v, &f[i].w);
	sort(f, f + m);
	int cnt = 0;
	for (int i = 1; i <= n + k; i++) fa[i] = i;
	for (int i = 0; i < m; i++) {
		int fx = ff(f[i].u), fy = ff(f[i].v);
		if (fx != fy) {
			fa[fx] = fy;
			nw[cnt++] = f[i];
		}
	}
	for (int i = 0; i < k; i++) {
		scanf("%d", c + i);
		v[i].resize(n);
		for (int j = 0; j < n; j++)
			scanf("%d", &v[i][j].w), v[i][j].u = n + i + 1, v[i][j].v = j + 1;
		sort(v[i].begin(), v[i].end());
	}
	long long ans = 1e18;
	for (int i = 0; i < (1 << k); i++) {
		int tnc = 0;
		long long res = 0;
		for (int j = 0; j < k; j++)
			if ((i >> j) & 1) {
				res += c[j];
				merge(f, f + tnc, v[j].begin(), v[j].end(), tmp);
				tnc += n;
				memcpy(f, tmp, 12 * tnc);
			}
		merge(f, f + tnc, nw, nw + cnt, tmp);
		tnc += cnt;
		memcpy(f, tmp, 12 * tnc);
		for (int j = 1; j <= n + k; j++) fa[j] = j;
		for (int j = 0; j < tnc; j++) {
			int fx = ff(f[j].u), fy = ff(f[j].v);
			if (fx != fy) {
				fa[fx] = fy;
				res += f[j].w;
			}
		}
		ans = min(ans, res);
	}
	cout << ans;
	return 0;
}