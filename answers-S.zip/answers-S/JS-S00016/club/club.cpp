#include<bits/stdc++.h>

using namespace std;

signed main() {
	freopen("club.in", "r", stdin);
	freopen("club.out", "w", stdout);
	int _;
	scanf("%d", &_);
	while (_--) {
		int n;
		scanf("%d", &n);
		long long ans = 0;
		multiset<int> ma, mb, mc;
		for (int i = 0; i < n; i++) {
			int a, b, c;
			scanf("%d %d %d", &a, &b, &c);
			int mx = max({a, b, c});
			if (a == mx) ma.insert(max(b, c) - a), ans += a;
			else if (b == mx) mb.insert(max(a, c) - b), ans += b;
			else mc.insert(max(a, b) - c), ans += c;
		}
		while (ma.size() > n / 2) ans += *ma.rbegin(), ma.erase(--ma.end());
		while (mb.size() > n / 2) ans += *mb.rbegin(), mb.erase(--mb.end());
		while (mc.size() > n / 2) ans += *mc.rbegin(), mc.erase(--mc.end());
		printf("%lld\n", ans);
	}
	return 0;
}