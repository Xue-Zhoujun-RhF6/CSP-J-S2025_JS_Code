#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int mod = 998244353;
const int bs = 12345677;

struct shushu {
	string l, r;
	ll hsh;
	int l1, r1, l2, r2;
	int pos;
};

struct shvshv {
	int up, pos, vl;
};

map<ll, vector<shushu> > mp;
int ans[200005];
char ss[5000005];
int id[5000005];
int tor[5000005];
int c[5000005];
vector<shvshv> to[5000005];

shushu calc(string x, string y) {
	int n = x.size();
	int l = -1, r = -1;
	for (int i = 0; i < n; i++)
		if (x[i] != y[i]) {
			if (l == -1) l = i;
			r = i;
		}
	ll hsh = 0;
	for (int i = l; i <= r; i++) hsh = (hsh * bs + x[i]) % mod;
	for (int i = l; i <= r; i++) hsh = (hsh * bs + y[i]) % mod;
	return {x.substr(0, l), x.substr(r + 1), hsh};
}

string input() {
	scanf("%s", ss);
	return ss;
}

bool cmp1(shushu x, shushu y) {
	return x.l < y.l;
}

bool cmp2(shushu x, shushu y) {
	return x.r < y.r;
}

bool operator <(shvshv x, shvshv y) {
	return x.pos < y.pos;
}

void upd(int x, int d) {
	while (x < 5000005) {
		c[x] += d;
		x += x & -x;
	}
}

int qry(int x) {
	int res = 0;
	while (x) {
		res += c[x];
		x &= x - 1;
	}
	return res;
}

signed main() {
	freopen("replace.in", "r", stdin);
	freopen("replace.out", "w", stdout);
	int n, m;
	scanf("%d %d", &n, &m);
	for (int i = 0; i < n; i++) {
		string s = input(), t = input();
		if (s == t) continue;
		shushu shu = calc(s, t);
		shu.pos = 0;
		mp[shu.hsh].push_back(shu);
	}
	for (int i = 1; i <= m; i++) {
		string s = input(), t = input();
		if (s.size() != t.size()) continue;
		shushu shu = calc(s, t);
		shu.pos = i;
		mp[shu.hsh].push_back(shu);
	}
	memset(id, -1, sizeof(id));
	for (const auto &p: mp) {
		auto v = p.second;
		for (shushu &shu: v) reverse(shu.l.begin(), shu.l.end());
		sort(v.begin(), v.end(), cmp1);
		int cnt = 1;
		string lst;
		int dep = 0;
		for (int i = 0; i < v.size(); i++) {
			shushu shu = v[i];
			while (dep and (dep >= shu.l.size() or shu.l[dep - 1] != lst[dep - 1])) {
				if (~id[dep]) {
					tor[id[dep]] = cnt;
					id[dep] = -1;
				}
				dep--;
			}
			dep = shu.l.size();
			cnt += (shu.l != lst);
			v[i].l1 = id[dep] = cnt;
			lst = shu.l;
		}
		while (~dep) {
			if (~id[dep]) {
				tor[id[dep]] = cnt;
				id[dep] = -1;
			}
			dep--;
		}
		int xxx = cnt;
		lst = "", dep = 0, cnt = 1;
		for (shushu &shu: v) shu.r1 = tor[shu.l1];
		sort(v.begin(), v.end(), cmp2);
		for (int i = 0; i < v.size(); i++) {
			shushu shu = v[i];
			while (dep and (dep >= shu.r.size() or shu.r[dep - 1] != lst[dep - 1])) {
				if (~id[dep]) {
					tor[id[dep]] = cnt;
					id[dep] = -1;
				}
				dep--;
			}
			dep = shu.r.size();
			cnt += (shu.r != lst);
			v[i].l2 = id[dep] = cnt;
			lst = shu.r;
		}
		while (~dep) {
			if (~id[dep]) {
				tor[id[dep]] = cnt;
				id[dep] = -1;
			}
			dep--;
		}
		for (shushu &shu: v) shu.r2 = tor[shu.l2];
		for (const shushu &shu: v) {
			if (!shu.pos) {
				to[shu.l1].push_back({shu.l2, 0, 1});
				to[shu.l1].push_back({shu.r2 + 1, 0, -1});
				to[shu.r1 + 1].push_back({shu.l2, 0, -1});
				to[shu.r1 + 1].push_back({shu.r2 + 1, 0, 1});
			} else to[shu.l1].push_back({shu.l2, shu.pos, 0});
		}
		for (int i = 1; i <= xxx + 1; i++) {
			sort(to[i].begin(), to[i].end());
			for (shvshv shv: to[i]) {
				if (shv.pos) ans[shv.pos] = qry(shv.up);
				else upd(shv.up, shv.vl);
			}
			to[i].clear();
		}
	}
	for (int i = 1; i <= m; i++) printf("%d\n", ans[i]);
	return 0;
}