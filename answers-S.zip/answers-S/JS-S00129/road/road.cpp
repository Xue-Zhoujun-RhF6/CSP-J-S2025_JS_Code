#include <bits/stdc++.h>
using namespace std;
struct road{
    int u;
    int v;
    int w;
    bool through_country = 0;
    int countrycode = 0;
    int country_w = 0;
};
bool cmp(road a,road b){
    return a.w < b.w;
}
bool j(bool list[],int n){
    for (int i = 0;i < n;i++){
        if (list[i] == 0){
            return 0;
        }
    }
    return 1;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m,k;
    cin >> n >> m >> k;
    road rd[m+k*n];
    bool city[m+k] = {};
    for (int i = 0;i < m;i++){
        cin >> rd[i].u >> rd[i].v >> rd[i].w;
    }
    for (int i = 0;i < k;i++){
        int cw;
        cin >> cw;
        for (int j = 0;j < n;j++){
            rd[j+n*(i+1)].country_w = cw;
            rd[j+n*(i+1)].countrycode = i + 1;
            cin >> rd[j+n*(i+1)].w;
            rd[j+n*(i+1)].u = n + 1 + i;
            rd[j+n*(i+1)].v = j + 1;
            rd[j+n*(i+1)].through_country = 1;
        }
    }
    sort(rd,rd+m+k*n,cmp);
    int cnt = 0,i = 0;
    while (j(city,n) == 0){
        if (city[rd[i].u] != 1 || city[rd[i].v] != 1){
            city[rd[i].u] = 1;
            city[rd[i].v] = 1;
            cnt+=rd[i].w;
            if (rd[i].through_country == 1){
                cnt+=rd[i].country_w;
            }
        }
        i++;
        if (i >= m+k*n)break;
    }
    cout << cnt;
    fclose(stdin);
    fclose(stdout);
    return 0;
}