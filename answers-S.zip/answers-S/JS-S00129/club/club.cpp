#include <bits/stdc++.h>
using namespace std;
struct satisfied{
    long long s1,s2,s3;
    long long h1,h2,h3;
    long long c1,c2,c3;
    long long j1,j2,j3;
};
typedef struct satisfied cs;
bool cmp(cs a,cs b){
    return a.c1 < b.c1;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin >> t;
    for (int z = 0;z < t;z++){
        int n;
        cin >> n;
        cs s[n],s1[n],s2[n],s3[n];
        long long c1 = 0,c2 = 0,c3 = 0;
        long long cnt1 = 0,cnt2 = 0,cnt3 = 0;
        for (int i = 0;i < n;i++){
            cin >> s[i].s1 >> s[i].s2 >> s[i].s3;
            if (s[i].s1 > s[i].s2){
                if (s[i].s1 > s[i].s3){
                    s[i].h1 = s[i].s1;
                    s[i].j1 = 1;
                    if (s[i].s2 > s[i].s3){
                        s[i].h2 = s[i].s2;
                        s[i].j2 = 2;
                        s[i].h3 = s[i].s3;
                        s[i].j3 = 3;
                    }
                    else{
                        s[i].h2 = s[i].s3;
                        s[i].j2 = 3;
                        s[i].h3 = s[i].s2;
                        s[i].j3 = 2;
                    }
                }
                else{
                    s[i].h1 = s[i].s3;
                    s[i].j1 = 3;
                    s[i].h2 = s[i].s1;
                    s[i].j2 = 1;
                    s[i].h3 = s[i].s2;
                    s[i].j3 = 2;
                }
            }
            else{
                if (s[i].s2 > s[i].s3){
                    s[i].h1 = s[i].s2;
                    s[i].j1 = 2;
                    if (s[i].s1 > s[i].s3){
                        s[i].h2 = s[i].s1;
                        s[i].j2 = 1;
                        s[i].h3 = s[i].s3;
                        s[i].j3 = 3;
                    }
                    else{
                        s[i].h2 = s[i].s3;
                        s[i].j2 = 3;
                        s[i].h3 = s[i].s1;
                        s[i].j3 = 1;
                    }
                }
                else{
                    s[i].h1 = s[i].s3;
                    s[i].j1 = 3;
                    s[i].h2 = s[i].s2;
                    s[i].j2 = 2;
                    s[i].h3 = s[i].s1;
                    s[i].j3 = 1;
                }
            }
            s[i].c1 = s[i].h1 - s[i].h2;
            s[i].c2 = s[i].h2 - s[i].h3;
            s[i].c3 = (long long)2147483647*(long long)2147483647;
            if(s[i].j1 == 1){
                cnt1 += s[i].h1;
                s1[c1] = s[i];
                c1++;
            }
            else if(s[i].j1 == 2){
                cnt2 += s[i].h1;
                s2[c2] = s[i];
                c2++;
            }
            else{
                cnt3 += s[i].h1;
                s3[c3] = s[i];
                c3++;
            }
        }
        j:sort(s1,s1+c1,cmp);
        sort(s2,s2+c2,cmp);
        sort(s3,s3+c3,cmp);
        if (c1 > n / 2){
            long long tmp = c1 - n / 2;
            for (long long i = 0;i < tmp;i++){
                cnt1 -= s1[i].s1;
                s1[i].h1 = s1[i].h2;
                s1[i].h2 = s1[i].h3;
                s1[i].c1 = s1[i].c2;
                s1[i].c2 = s1[i].c3;
                s1[i].j1 = s1[i].j2;
                s1[i].j2 = s1[i].j3;
                if (s1[i].j1 = 2){
                    cnt2 += s1[i].s2;
                    s2[c2] = s1[i];
                    c2++;
                }
                else{
                    cnt3 += s1[i].s3;
                    s3[c3] = s1[i];
                    c3++;
                }
            }
            c1 -= tmp;
            goto j;
        }
        else if(c2 > n / 2){
            long long tmp = c2 - n / 2;
            for (long long i = 0;i < tmp;i++){
                cnt2 -= s2[i].s2;
                s2[i].h1 = s2[i].h2;
                s2[i].h2 = s2[i].h3;
                s2[i].c1 = s2[i].c2;
                s2[i].c2 = s2[i].c3;
                s2[i].j1 = s2[i].j2;
                s2[i].j2 = s2[i].j3;
                if (s1[i].j1 = 1){
                    cnt1 += s2[i].s1;
                    s1[c1] = s2[i];
                    c1++;
                }
                else{
                    cnt3 += s2[i].s3;
                    s3[c3] = s2[i];
                    c3++;
                }
            }
            c2 -= tmp;
            goto j;
        }
        else if(c3 > n / 2){
            long long tmp = c3 - n / 2;
            for (long long i = 0;i < tmp;i++){
                cnt1 -= s1[i].s1;
                s3[i].h1 = s3[i].h2;
                s3[i].h2 = s3[i].h3;
                s3[i].c1 = s3[i].c2;
                s3[i].c2 = s3[i].c3;
                s3[i].j1 = s3[i].j2;
                s3[i].j2 = s3[i].j3;
                if (s3[i].j1 = 2){
                    cnt2 += s3[i].s2;
                    s2[c2] = s3[i];
                    c2++;
                }
                else{
                    cnt1 += s3[i].s1;
                    s1[c1] = s3[i];
                    c1++;
                }
            }
            c3 -= tmp;
            goto j;
        }
        else cout << cnt1 + cnt2 + cnt3 << endl;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
