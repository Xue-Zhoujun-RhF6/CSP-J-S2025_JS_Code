#include<bits/stdc++.h>
#define ll long long
#define int long long
using namespace std;
/*ll n,m,k;
ll used[10005];
ll mans=1e10+1e9+5,ans=0;

struct node{
    ll w;
    ll tow[10005];
}town[15];
struct node2{
    int st,to,w;
};
ll g[10005][10005];
int mnum=0;
void dfs(int x,int num,){
    if(x==n){
        if(num<mnum){
            mnum=num;
        }
    }
    for(int i=1;i<=n;i++){
        if(!used[i]){
            used[i]=1;
            num+=
        }
    }
}*/
signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    /*scanf("%lld%lld%lld",&n,&m,&k);
    for(ll i=1,st,en,w;i<=m;i++){
        scanf("%lld%lld%lld",&st,&en,&w);
        g[st][en]=w;
        g[en][st]=w;
    }
    auto g2=g;
    for(ll i=1;i<=k;i++){
        scanf("%lld",&town[i].w);
        for(ll j=1;j<=n;j++){
            scanf("%lld",&town[i].tow[i]);
        }
    }
    for(ll i=1;i<=k;i++){
        ans=0;
        mnum=1e10+1e9+5;
        memset(used,0,sizeof(used));
        ans+=town[i].w;
        for(int j=1;j<n;j++){
            for(int k=j+1;k<=n;k++){
                g[j][k]=g[k][j]=min(g[j][k],town[i].tow[j]+town[i].tow[k]);
            }
        }
        dfs(0,0);
        ans+=mnum;
        if(ans<mans){
            mans=ans;
        }
        for(int j=1;j<=n;j++){
            for(int k=1;k<=n;k++){
                g[j][k]=g2[j][k];
            }
        }
    }
    printf("%lld",mans);*/
    return 0;
}
