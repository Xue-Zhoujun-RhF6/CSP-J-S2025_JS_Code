#include<bits/stdc++.h>
//#define int long long
using namespace std;
struct member{
    int sc[4];
}mem[100005];
bool cmp1(member x,member y){
    return min(x.sc[1]-x.sc[2],x.sc[1]-x.sc[3])>min(y.sc[1]-y.sc[2],y.sc[1]-y.sc[3]);
}
bool cmp2(member x,member y){
    return (x.sc[2]-x.sc[3])>(y.sc[2]-y.sc[3]);
}
signed main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int T;
    int n;
    long long ans=0;
    member one[100005];
    member two[100005];
    member three[100005];
    int tot1=0;
    int tot2=0;
    int tot3=0;
    scanf("%lld",&T);
    while(T--){
        ans=0;
        tot1=0;
        tot2=0;
        tot3=0;
        scanf("%lld",&n);
        for(int i=1;i<=n;i++){
            scanf("%lld%lld%lld",&mem[i].sc[1],&mem[i].sc[2],&mem[i].sc[3]);
            if(mem[i].sc[1]>=mem[i].sc[2]&&mem[i].sc[1]>=mem[i].sc[3]){
                one[++tot1]=mem[i];
            }
            else if(mem[i].sc[2]>=mem[i].sc[1]&&mem[i].sc[2]>=mem[i].sc[3]){
                two[++tot2]=mem[i];
            }
            else{
                three[++tot3]=mem[i];
            }
        }
        sort(one+1,one+tot1+1,cmp1);
        member x;
        while(tot1>n/2){
            x=one[tot1];
            tot1--;
            two[++tot2]=x;
        }
        sort(two+1,two+tot2+1,cmp2);

        while(tot2>n/2){
            x=two[tot2];
            tot2--;
            three[++tot3]=x;
        }
        for(int i=1;i<=tot1;i++){
            ans+=one[i].sc[1];
        }
        for(int i=1;i<=tot2;i++){
            ans+=two[i].sc[2];
        }
         for(int i=1;i<=tot3;i++){
            ans+=three[i].sc[3];
        }
        cout<<ans<<endl;
    }

    return 0;
}
