#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
string s;
int a[505];
signed main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    return 0;
}
