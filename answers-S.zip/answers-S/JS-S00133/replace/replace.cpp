#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);

    return 0;
}
