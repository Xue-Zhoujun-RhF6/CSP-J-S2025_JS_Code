#include<bits/stdc++.h>
using namespace std;
int q,n;
int main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>q;
    while(q--)
    {
        cout<<0<<"\n";
    }
    return 0;
}
