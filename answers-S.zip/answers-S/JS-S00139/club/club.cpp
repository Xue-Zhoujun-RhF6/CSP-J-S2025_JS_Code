#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
long long t,n,a1[N],a2[N],a3[N],cnt1,cnt2,cnt3,ans,max1,max2,maxx1,maxx2,maxxn;
stack<long long>cl1,cl2,cl3;
long long cmp(int x,int y)
{
    return x>y;
}
struct a
{
    long long l1,l2,l3;
    bool f=0;
}a[N];
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin>>t;
    while(t--)
    {
        cin>>n;
        for(int i=1;i<=n;i++)
        {
            cin>>a[i].l1>>a[i].l2>>a[i].l3;
            a1[i]=a[i].l1;
            a2[i]=a[i].l2;
            a3[i]=a[i].l3;
        }
        if(n==2)
        {
            max1=max(a[1].l1,max(a[1].l2,a[1].l3));
            max2=max(a[2].l1,max(a[2].l2,a[2].l3));
            if(max1==a[1].l1&&max2==a[2].l1)
            {
                maxx1=max(a[1].l2,a[1].l3);
                maxx2=max(a[2].l2,a[2].l3);
                maxxn=max(max1+maxx2,max2+maxx1);
                cout<<maxxn<<"\n";
                continue;
            }
            if(max1==a[1].l2&&max2==a[2].l2)
            {
                maxx1=max(a[1].l1,a[1].l3);
                maxx2=max(a[2].l1,a[2].l3);
                maxxn=max(max1+maxx2,max2+maxx1);
                cout<<maxxn<<"\n";
                continue;
            }
            if(max1==a[1].l3&&max2==a[2].l3)
            {
                maxx1=max(a[1].l2,a[1].l1);
                maxx2=max(a[2].l2,a[2].l1);
                maxxn=max(max1+maxx2,max2+maxx1);
                cout<<maxxn<<"\n";
                continue;
            }
            cout<<max1+max2<<"\n";
            continue;
        }
        sort(a1+1,a1+1+n,cmp);
        sort(a2+1,a2+1+n,cmp);
        sort(a3+1,a3+1+n,cmp);
        for(int i=1;i<=n/2;i++)
        {
            if(a1[1]>a2[1]&&a1[1]>a3[1])
            {
                ans+=a1[1];
                for(int j=1;j<=n;j++)
                {
                    if(a[j].l1==a1[1])
                    {
                        a[0].l2=a[j].l2;
                        a[0].l3=a[j].l3;
                        break;
                    }
                }
                for(int j=1;j<=n;j++)
                {
                    if(a2[j]==a[0].l2)
                    {
                        a2[j]=0;
                        break;
                    }
                }
                for(int j=1;j<=n;j++)
                {
                    if(a3[j]==a[0].l3)
                    {
                        a3[j]=0;
                        break;
                    }
                }
                a1[1]=0;
                sort(a1+1,a1+1+n,cmp);
                sort(a2+1,a2+1+n,cmp);
                sort(a3+1,a3+1+n,cmp);
            }
            if(a2[1]>a1[1]&&a2[1]>a3[1])
            {
                ans+=a2[1];
                for(int j=1;j<=n;j++)
                {
                    if(a[j].l2==a2[1])
                    {
                        a[0].l1=a[j].l1;
                        a[0].l3=a[j].l3;
                        break;
                    }
                }
                for(int j=1;j<=n;j++)
                {
                    if(a1[j]==a[0].l1)
                    {
                        a1[j]=0;
                        break;
                    }
                }
                for(int j=1;j<=n;j++)
                {
                    if(a3[j]==a[0].l3)
                    {
                        a3[j]=0;
                        break;
                    }
                }
                a2[1]=0;
                sort(a1+1,a1+1+n,cmp);
                sort(a2+1,a2+1+n,cmp);
                sort(a3+1,a3+1+n,cmp);
            }
            if(a3[1]>a2[1]&&a3[1]>a1[1])
            {
                ans+=a3[1];
                for(int j=1;j<=n;j++)
                {
                    if(a[j].l3==a3[1])
                    {
                        a[0].l2=a[j].l2;
                        a[0].l1=a[j].l1;
                        break;
                    }
                }
                for(int j=1;j<=n;j++)
                {
                    if(a2[j]==a[0].l2)
                    {
                        a2[j]=0;
                        break;
                    }
                }
                for(int j=1;j<=n;j++)
                {
                    if(a1[j]==a[0].l1)
                    {
                        a1[j]=0;
                        break;
                    }
                }
                a3[1]=0;
                sort(a1+1,a1+1+n,cmp);
                sort(a2+1,a2+1+n,cmp);
                sort(a3+1,a3+1+n,cmp);
            }
        }
        cout<<ans<<"\n";
    }
    return 0;
}
