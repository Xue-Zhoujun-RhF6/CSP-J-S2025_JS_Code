#include<bits/stdc++.h>
using namespace std;
unsigned long long n,m,a[505],cnt,ans=1;
string s;
const int m1=998244353;
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
    }
    for(int i=0;i<n;i++)
    {
        if(s[i]=='1')
        {
            cnt++;
        }
    }
    if(cnt==n)
    {
        for(int i=1;i<=n;i++)
        {
            ans=ans*i;
        }
        cout<<ans%m1;
    }
    return 0;
}
