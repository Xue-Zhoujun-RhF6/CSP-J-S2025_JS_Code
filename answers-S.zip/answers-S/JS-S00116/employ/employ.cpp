#include<bits/stdc++.h>
using namespace std;
const int MOD = 998244353, N = 510;
int n, m, c[N];
int sum1, sum0;
string s;
int main() {
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    cin >> n >> m;
    cin >> s;
    for(int i = 0;i < n;i ++) {
        cin >> c[i];
        if(s[i] == '0') {
            sum0 ++;
        }else {
            sum1 ++;
        }
    }
    if(sum1 < m) {
        cout << 0;
        return 0;
    }
    long long tmp = 1;
    for(int i = 1;i <= n;i ++) {
        tmp *= i;
        tmp %= MOD;
    }
    cout << tmp;
    return 0;
}
