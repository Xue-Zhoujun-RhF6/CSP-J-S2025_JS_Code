#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 10210;
struct EDGE{
    ll len, v, u;
};
vector<EDGE> e;
ll cost[N];
vector<EDGE> edge[11];
int n, m, k;
vector<EDGE> mp;
int f[N];
bool cmp(EDGE x, EDGE y) {
    return x.len < y.len;
}
int find(int x) {
    return f[x] == x?x : x = find(f[x]);
}
ll mi = 1e15;
int main() {
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    cin >> n >> m >> k;
    while(m --) {
        int u, v, len;
        scanf("%d%d%d", &u, &v, &len);
        e.push_back({len, u, v});
    }
    for(int i = 1;i <= k;i ++) {
        scanf("%d", &cost[i]);
        for(int j = 1;j <= n;j ++) {
            int tmp;
            scanf("%d", &tmp);
            edge[i].push_back({tmp, j, n + i});
        }
    }
    for(int i = 0;i < 1 << k;i ++) {
        mp.clear();
        mp = e;
        ll sum = 0, ans = 0;
        int tmp = i, cnt = 0, tot = 1;
        while(tmp) {
            if(tmp % 2 == 1) {
                for(int j = 0;j < edge[tot].size();j ++) {
                    mp.push_back(edge[tot][j]);
                }
                ans += cost[tot];
            }
            tot ++;
            cnt += tmp % 2;
            tmp /= 2;
        }
       // for(int j = 0;j < e.size();j ++) {
       //     mp.push_back(e[j]);
        //}

        for(int j = 1;j <= n + k;j ++) {
            f[j] = j;
        }
        sort(mp.begin(), mp.end(), cmp);
        for(int j = 0;j < mp.size();j ++) {
            if(find(mp[j].u) != find(mp[j].v)) {
                sum ++;
                ans += mp[j].len;
                f[find(mp[j].u)] = find(mp[j].v);
            }
            if(sum == cnt + n - 1) {
                break;
            }
        }
        mi = min(mi, ans);
    }
    cout << mi;
    return 0;
}
