#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5 + 10;
int t;
int n, a[N][3], cost[N];
struct node{
    int v, id;
}tmp[3];
bool cmp(node x, node y) {
    return x.v > y.v;
}
ll ans;
vector<int> d[3];
int main() {
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    cin >> t;
    while(t --) {
        cin >> n;
        d[0].clear();
        d[1].clear();
        d[2].clear();
        ans = 0;
        for(int i = 1;i <= n;i ++) {
            cin >> a[i][0] >> a[i][1] >> a[i][2];
            tmp[0] = {a[i][0], 0};
            tmp[1] = {a[i][1], 1};
            tmp[2] = {a[i][2], 2};
            sort(tmp, tmp + 3, cmp);
            d[tmp[0].id].push_back(tmp[0].v - tmp[1].v);
            ans += tmp[0].v;
        }
        if(d[0].size() > n / 2) {
            sort(d[0].begin(), d[0].end());
            for(int i = 0;i < d[0].size() - n / 2;i ++) {
                ans -= d[0][i];
            }
        }
        if(d[1].size() > n / 2) {
            sort(d[1].begin(), d[1].end());
            for(int i = 0;i < d[1].size() - n / 2;i ++) {
                ans -= d[1][i];
            }
        }
        if(d[2].size() > n / 2) {
            sort(d[2].begin(), d[2].end());
            for(int i = 0;i < d[2].size() - n / 2;i ++) {
                ans -= d[2][i];
            }
        }
        cout << ans << "\n";
    }
    return 0;
}
