#include<bits/stdc++.h>
using namespace std;
int n, q;
struct node {
    string s, s2;
};
map<string, map<string, int> > mp;
int main() {
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    cin >> n >> q;
    for(int i = 0;i < n;i ++) {
        string s, s2;
        cin >> s >> s2;
        mp[s][s2] ++;
    }
    while(q --) {
        string s, s2;
        cin >> s >> s2;
        int l = s.length();
        int R = 0, L = l - 1;
        int ans = 0;
        while(s[R] == s2[R]) {
            R ++;
        }
        while(s[L] == s2[L]) {
            L --;
        }
        string tmp = "", tmp2 = "";
        for(int i = R + 1;i < L;i ++) {
            tmp += s[i];
            tmp2 += s2[i];
        }
        for(int i = R;i >= 0;i --) {
            tmp = s[i] + tmp, tmp2 = s2[i] + tmp2;
            string m = tmp, m2 = tmp2;
            for(int j = L;j < l;j ++) {
                m += s[j], m2 += s2[j];
                ans += mp[m][m2];
            }
        }
        cout << ans <<"\n";
    }
    return 0;
}
