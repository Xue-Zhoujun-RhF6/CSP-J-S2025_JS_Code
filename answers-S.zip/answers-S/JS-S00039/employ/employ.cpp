#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int MAXN(505), MOD(998244353);
ll c[MAXN];

int main(){
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    cin.tie(0), cout.tie(0);
    ios::sync_with_stdio(false);
    ll n, m;
    cin >> n >> m;
    string s;
    cin >> s;
    s = ' ' + s;
    for(int i = 1; i <= n; i++) cin >> c[i];
    if(n == 1){
        if(c[i] >= 1 && s[1] == '1'){
            cout << 1;
            return 0;
        }else{
            cout << 0;
            return 0;
        }
    }else if(n == 2){
        if(c[1] >= 2 && c[2] >= 2 && m == 1 && s == "11"){
            cout << 2;
            return 0;
        }else if(c[1] >= 2 && c[2] >= 2 && m == 2 && s == "11"){
            cout << 1;
            return 0;
        }else if(c[1] == 1 || c[2] == 1 && m == 1 && s != "00"){
            cout << 1;
            return 0;
        }else{
            cout << 0;
            return 0;
        }
    }
    if(m == n){
        bool flag = true;
        for(int i = 1; i <= n; i++){
            if(s[i] == 0){
                flag = false;
            }
        }
        sort(c + 1, c + n + 1);
        for(int i = 1; i <= n; i++){
            if(c[i] <= i) flag = false;
        }
        if(!falg){
            cout << 0;
            return 0;
        }else{
            ll ans(1);
            for(int i = 2; i <= n; i++){
                ans = ans * i % MOD;
            }
            cout << ans % MOD;
            return 0;
        }
    }
    cout << 0;
    return 0;
}
