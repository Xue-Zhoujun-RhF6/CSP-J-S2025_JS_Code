#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
    ll x, y, z;
}a[100005];
int main(){
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    cin.tie(0), cout.tie(0);
    ios::sync_with_stdio(false);
    int T; cin >> T;
    while(T--){
        ll n; cin >> n;
        bool A = true;
        for(int i = 1; i <= n; i++){
            cin >> a[i].x >> a[i].y >> a[i].z;
            if(a[i].y != 0 || a[i].z != 0) A = false;
        }
        if(n == 2) cout << max({
            a[1].x + a[2].y, a[1].x + a[2].z, a[1].y + a[2].z,
            a[2].x + a[1].y, a[2].x + a[1].z, a[2].y + a[1].z}) << '\n';
        else if(n == 4) cout << max({
            a[1].x + a[2].x + a[3].y + a[4].y,
            a[1].x + a[2].y + a[3].x + a[4].y,
            a[1].y + a[2].x + a[3].y + a[4].x,
            a[1].y + a[2].y + a[3].x + a[4].x,

            a[1].x + a[2].x + a[3].z + a[4].z,
            a[1].x + a[2].z + a[3].x + a[4].z,
            a[1].z + a[2].x + a[3].z + a[4].x,
            a[1].z + a[2].z + a[3].x + a[4].x,

            a[1].z + a[2].z + a[3].y + a[4].y,
            a[1].z + a[2].y + a[3].z + a[4].y,
            a[1].y + a[2].z + a[3].y + a[4].z,
            a[1].y + a[2].y + a[3].z + a[4].z,


            a[1].x + a[2].x + a[3].y + a[4].z,
            a[1].x + a[2].x + a[3].z + a[4].y,
            a[1].x + a[3].x + a[2].y + a[4].z,
            a[1].x + a[3].x + a[2].z + a[4].y,
            a[1].x + a[4].x + a[2].y + a[3].z,
            a[1].x + a[4].x + a[2].z + a[3].y,
            a[2].x + a[3].x + a[1].y + a[4].z,
            a[2].x + a[3].x + a[1].z + a[4].y,
            a[2].x + a[4].x + a[1].y + a[3].z,
            a[2].x + a[4].x + a[1].z + a[3].y,
            a[3].x + a[4].x + a[1].y + a[2].z,
            a[3].x + a[4].x + a[1].z + a[2].y,

            a[1].y + a[2].x + a[3].y + a[4].z,
            a[1].y + a[2].x + a[3].z + a[4].y,
            a[1].y + a[3].x + a[2].y + a[4].z,
            a[1].y + a[3].x + a[2].z + a[4].y,
            a[1].y + a[4].x + a[2].y + a[3].z,
            a[1].y + a[4].x + a[2].z + a[3].y,
            a[2].y + a[3].x + a[1].y + a[4].z,
            a[2].y + a[3].x + a[1].z + a[4].y,
            a[2].y + a[4].x + a[1].y + a[3].z,
            a[2].y + a[4].x + a[1].z + a[3].y,
            a[3].y + a[4].x + a[1].y + a[2].z,
            a[3].y + a[4].x + a[1].z + a[2].y,

            a[1].x + a[2].z + a[3].y + a[4].z,
            a[1].x + a[2].z + a[3].z + a[4].y,
            a[1].x + a[3].z + a[2].y + a[4].z,
            a[1].x + a[3].z + a[2].z + a[4].y,
            a[1].x + a[4].z + a[2].y + a[3].z,
            a[1].x + a[4].z + a[2].z + a[3].y,
            a[2].x + a[3].z + a[1].y + a[4].z,
            a[2].x + a[3].z + a[1].z + a[4].y,
            a[2].x + a[4].z + a[1].y + a[3].z,
            a[2].x + a[4].z + a[1].z + a[3].y,
            a[3].x + a[4].z + a[1].y + a[2].z,
            a[3].x + a[4].z + a[1].z + a[2].y}) << '\n';
        else if(A){
            sort(a + 1, a + n + 1, [&](Node u, Node v){ return u.x > v.x;});
            ll sum(0); n /= 2;
            for(int i = 1; i <= n; i++) sum += a[i].x;
            cout << sum << '\n';
        }
    }
    return 0;
}
