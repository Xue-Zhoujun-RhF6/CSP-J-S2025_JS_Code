#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int MAXM(1e6 + 5), MAXN(1e4 + 5);
struct Node{
    ll m, w; // m daoda
};
vector<Node> g[MAXM];
ll a[15][MAXN];
bool vis[MAXN];

bool dfs(ll x, ll y){

}

int main(){
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    cin.tie(0), cout.tie(0);
    ios::sync_with_stdio(false);
    ll n, m, k;
    cin >> n >> m >> k;
    ll sum(0);
    for(int i = 1; i <= m; i++){
        ll u, v, w;
        cin >> u >> v >> w;
        g[u].push_back(Node{v, w});
        g[v].push_back(Node{u, w});
        sum += w;
    }
    bool flag = true;
    for(int j = 1; j <= k; j++){
        for(int i = 0; i <= n; i++){
            cin >> a[j][i];
            if(a[j][0] != 0) flag = false;
        }
    }
    if(k == 0){
        //sort(g + 1, g + n + 1, [&](Node u, Node v){ return g[u].w < g[v].w;});
        cout << sum;
        return 0;
    }else if(flag){
        cout << 0;
        return 0;
    }
    cout << 0;
    return 0;
}
