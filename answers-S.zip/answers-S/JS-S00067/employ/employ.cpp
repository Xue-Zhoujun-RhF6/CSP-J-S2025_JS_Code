#include <bits/stdc++.h>
using namespace std;
const int N=505;
int n,m,ans;
char s[N];
int c[N];
int a[N];
bool v[N];
void dfs(int dep){
    if(dep==n+1){
        int cnt=0,res=0;
        for(int i=1;i<=n;i++){
            if(s[i]=='1'&&c[a[i]]>res){
                cnt++;
            }
            else{
                res++;
            }
        }
        if(cnt>=m)ans++;
    }
    else{
        for(int i=1;i<=n;i++){
            if(v[i]==0){
                a[dep]=i;
                v[i]=1;
                dfs(dep+1);
                v[i]=0;
            }
        }
    }
}
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        cin>>s[i];
    }
    for(int i=1;i<=n;i++){
        cin>>c[i];
    }
    if(n<=20){
        dfs(1);
        cout<<ans;
        return 0;
    }
    cout<<0;
    return 0;
}
