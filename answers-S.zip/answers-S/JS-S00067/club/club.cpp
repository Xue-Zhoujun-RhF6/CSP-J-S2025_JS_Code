#include <bits/stdc++.h>
#define fir first
#define sec second
using namespace std;
const int N=1e5+5;
int T;
bool cmp(pair<int,int> a,pair<int,int> b){
    return a.fir>b.fir;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%d",&T);
    while(T--){
        long long ans=0;
        int n=0;
        int x=0,y=0,z=0;
        int cnt[4]={0,0,0,0};
        pair<int,int> p[4]{{0,0},{0,0},{0,0},{0,0}};
        priority_queue<int,vector<int>,greater<int> > q[4];
        scanf("%d",&n);
        for(int i=1;i<=3;i++){
            if(!q[i].empty())q[i].pop();
        }
        for(int i=1;i<=n;i++){
            scanf("%d%d%d",&x,&y,&z);
            p[1]={x,1};
            p[2]={y,2};
            p[3]={z,3};
            sort(p+1,p+4,cmp);
            ans+=p[1].fir;
            q[p[1].sec].push(p[1].fir-p[2].fir);
            cnt[p[1].sec]++;
        }
        for(int i=1;i<=3;i++){
            if(cnt[i]>n/2){
                for(int j=n/2+1;j<=cnt[i];j++){
                    ans-=q[i].top();
                    q[i].pop();
                }
                break;
            }
        }
        printf("%lld\n",ans);
    }

}
