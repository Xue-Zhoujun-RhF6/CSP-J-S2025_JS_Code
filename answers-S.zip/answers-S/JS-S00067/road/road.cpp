#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int M=2e6+5,N=1e4+100;
int n,m,k,pos;
struct edge{
    int x,y,w;
}g[M];
bool cmp(edge a,edge b){
    return a.w<b.w;
}
int fa[N];
int find(int x){
    if(x==fa[x])return x;
    return fa[x]=find(fa[x]);
}
void Kruskal(){
    ll cnt=0,res=0;
    for(int i=1;i<=pos;i++){
        if(cnt==n-1)break;
        int p=find(g[i].x);
        int q=find(g[i].y);
        if(p==q)continue;
        res+=g[i].w;
        cnt++;
        fa[p]=q;
    }
    printf("%lld",res);
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=m;i++){
        int x,y,w;
        scanf("%d%d%d",&x,&y,&w);
        g[++pos].x=x;
        g[pos].y=y;
        g[pos].w=w;
    }
    int c;
    for(int i=1;i<=k;i++){
        scanf("%d",&c);
        for(int j=1;j<=n;j++){
            scanf("%d",&c);
            g[++pos]={n+i,j,c};
        }
    }
    n+=k;
    for(int i=1;i<=n;i++)fa[i]=i;
    sort(g+1,g+pos+1,cmp);
    Kruskal();
    return 0;
}
