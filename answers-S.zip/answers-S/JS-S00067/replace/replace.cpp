#include <bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n,q;
pair<string,string> s1[N];
bool pan(string a,string b){
    if(a.size()!=b.size())return 0;
    for(int i=a.size()-1;i>=0;i--){
        if(a[i]!=b[i])return 0;
    }
    return 1;
}
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    scanf("%d%d",&n,&q);
    string a,b;
    int bg,nd;
    for(int i=1;i<=n;i++){
        cin>>a>>b;
        bg=0,nd=0;
        for(int j=0;j<a.size();j++){
            if(a[j]!=b[j]){
                bg=j;
                break;
            }
        }
        for(int j=a.size()-1;j>=0;j--){
            if(a[j]!=b[j]){
                nd=j;
                break;
            }
        }
        for(int j=bg;j<=nd;j++){
            s1[i].first.push_back(a[j]);
            s1[i].second.push_back(b[j]);
        }
    }
    string ac,bc;
    for(int i=1;i<=q;i++){
        int ans=0;
        ac="",bc="";
        cin>>a>>b;
        bg=0,nd=0;
        for(int j=0;j<a.size();j++){
            if(a[j]!=b[j]){
                bg=j;
                break;
            }
        }
        for(int j=a.size()-1;j>=0;j--){
            if(a[j]!=b[j]){
                nd=j;
                break;
            }
        }
        for(int j=bg;j<=nd;j++){
            ac.push_back(a[j]);
            bc.push_back(b[j]);
        }
        for(int j=1;j<=n;j++){
            if(pan(ac,s1[j].first)&&pan(bc,s1[j].second)){
                ans++;
            }
        }
        printf("%d\n",ans);
    }
}
