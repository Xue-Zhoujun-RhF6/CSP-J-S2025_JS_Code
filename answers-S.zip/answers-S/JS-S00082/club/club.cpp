#include <bits/stdc++.h>
using namespace std;
#define int long long
int t;
int n;
int clubb[4][500005];
int topp[4];
int ms, md;
int k;
int kk;
int ans;
struct People{
    int mos, mosi, mid, midi;
    int man[4];
} a[500005];
bool cmpp (int x, int y){
    int valx = a[x].mos - a[x].mid;
    int valy = a[y].mos - a[y].mid;
    return valx <= valy;
}
signed main (){
    freopen ("club.in", "r", stdin);
    freopen ("club.out", "w", stdout);
    cin >> t;
    while (t --){
        topp[1] = topp[2] = topp[3] = 0;
        k = 0;
        a[0].man[1] = a[0].man[2] = a[0].man[3] = 0;
        ans = 0;
        cin >> n;
        for (int i = 1; i <= n; i ++){
            cin >> a[i].man[1] >> a[i].man[2] >> a[i].man[3];
            if (a[i].man[1] >= a[i].man[2] && a[i].man[2] >= a[i].man[3]){ms = 1; md = 2; }
            else if (a[i].man[1] >= a[i].man[3] && a[i].man[3] >= a[i].man[2]){ms = 1; md = 3; }
            else if (a[i].man[2] >= a[i].man[1] && a[i].man[1] >= a[i].man[3]){ms = 2; md = 1; }
            else if (a[i].man[2] >= a[i].man[3] && a[i].man[3] >= a[i].man[1]){ms = 2; md = 3; }
            else if (a[i].man[3] >= a[i].man[1] && a[i].man[1] >= a[i].man[2]){ms = 3; md = 1; }
            else if (a[i].man[3] >= a[i].man[2] && a[i].man[2] >= a[i].man[1]){ms = 3; md = 2; }
            a[i].mos = a[i].man[ms]; a[i].mosi = ms;
            a[i].mid = a[i].man[md]; a[i].midi = md;
            clubb[ms][++ topp[ms]] = i;
        }
        sort (clubb[1] + 1, clubb[1] + topp[1] + 1, cmpp);
        sort (clubb[2] + 1, clubb[2] + topp[2] + 1, cmpp);
        sort (clubb[3] + 1, clubb[3] + topp[3] + 1, cmpp);
        if (topp[1] > n / 2) k = 1;
        if (topp[2] > n / 2) k = 2;
        if (topp[3] > n / 2) k = 3;
        if (k != 0){
            for (int i = 1; i <= topp[k] - n / 2; i ++){
                kk = a[clubb[k][i]].midi;
                clubb[kk][++ topp[kk]] = clubb[k][i];
                clubb[k][i] = 0;
            }
        }
        for (int i = 1; i <= 3; i ++){
            for (int j = 1; j <= topp[i]; j ++){
                ans += a[clubb[i][j]].man[i];
            }
        }
        cout << ans << endl;
    }
    return 0;
}
