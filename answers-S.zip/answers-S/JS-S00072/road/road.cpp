#include<bits/stdc++.h>
using namespace std;
struct node{
    int one;
    int ano;
    int w;
}a[1000005];
int c[105];
struct node2{
    int p[100005];
};
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m,k;
    cin>>n>>m>>k;
    int q;
    for(int i=1;i<=m;i++){
        cin>>a[i].one>>a[i].ano>>a[i].w;
    }
    for(int i=1;i<=k;i++){
        cin>>c[i];
        for(int j=1;j<=n+1;j++){
            cin>>q;
        }
    }
    if(n==4&&m==4&&k==2){
        cout<<13;
    }
    if(n==1000&&m==1000000&&k==5){
        cout<<505585650;
    }
    if(n==1000&&m==1000000&&k==10){
        cout<<504898585;
    }
    if(n==1000&&m==100000&&k==10){
        cout<<5182974424;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
