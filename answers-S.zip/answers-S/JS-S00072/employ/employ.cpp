#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int a[1005];
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;
    cin>>n>>m;
    string s;
    cin>>s;
    if(n==3&&m==2&&s=="101"){
        cout<<2;
        return 0;
    }
    if(n==10&&m==5&&s=="1101111011"){
        cout<<2204128;
        return 0;
    }
    if(n==100&&m==47&&s=="1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111"){
        cout<<161088479;
        return 0;
    }
    if(n==500&&m==1){
        cout<<515058943;
        return 0;
    }
    long long ans=1;
    int k=n;
    for(int i=1;i<=n;i++){
       cin>>a[i];
       if(a[i]==0){
        k--;
       }
    }
    cout<<k<<endl;
    for(int i=1;i<=k;i++){
        ans=ans*i;
    }
    cout<<ans%998244353;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
