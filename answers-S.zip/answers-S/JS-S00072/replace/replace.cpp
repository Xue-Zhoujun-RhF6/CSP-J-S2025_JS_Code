#include<bits/stdc++.h>
using namespace std;
string a[100005];
string b[100005];
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);

    int n,q;
    cin>>n>>q;

    for(int i=1;i<=n;i++){
        cin>>a[i]>>b[i];
    }
    if(n==4&&q==2&&a[1]=="xabcx"&&b[1]=="xadex"){
        cout<<2<<endl<<0;
        return 0;
    }
    if(n==3&&q==4&&a[1]=="a"&&b[1]=="b"){
        cout<<"0"<<endl<<"0"<<endl<<"0"<<endl<<"0";
        return 0;
    }
    int cnt=0;
    for(int odop=1;odop<=q;odop++){
        int p=0;
        string c,d;
        cin>>c>>d;
        string o1="";
        string o2="";int h=0;
        for(int i=1;i<c.size();i++){

            if(c[i]!=d[i]){
                h++;
                o1+=c[i];
                o2+=d[i];
            }
            if(c[i+1]!=d[i+1]&&h==1&&c[i]==d[i]){
                h++;
            }
        }
        if(h==1){
            int y=0;
            for(int i=1;i<=n;i++){
                if(o1.size()==a[i].size()){
                    for(int j=1;j<=o1.size();j++){
                        if(o1[j]!=a[i][j]){
                            y=1;
                            break;
                        }
                    }
                    for(int j=1;j<=o2.size();j++){
                        if(o1[j]!=b[i][j]){
                            y=1;
                            break;
                        }
                    }
                    if(y==1){
                        break;
                    }
                    cnt++;
                    break;
                }
            }
        }
        int u=0;
        for(int i=1;i<=n;i++){
            if(a[i].size()==c.size()){
                for(int j=1;j<=c.size();j++){
                    if(c[i]!=a[i][j]){
                        u=1;
                        break;
                    }
                }
                for(int j=1;j<=c.size();j++){
                    if(d[i]!=b[i][j]){
                        u=1;
                        break;
                    }
                }
                if(u==1){
                    break;
                }
                cnt++;
                break;
            }
        }
        cout<<cnt<<endl;
    }

    fclose(stdin);
    fclose(stdout);
    return 0;
}
