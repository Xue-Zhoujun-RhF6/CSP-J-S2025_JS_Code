#include<bits/stdc++.h>
using namespace std;
struct node{
    int dy;
    int de;
    int ds;
    int sx1;
    int sx2;
    int sx3;
}a[100005];
struct node2{
    int dy;
    int de;
    int ds;
}diy[100005],die[100005],dis[100005];
long long pp[7];
int q,w,e;
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int T;
    cin>>T;
    for(int oo=1;oo<=T;oo++){
        int n;
        cin>>n;
        q=0,w=0,e=0;
        for(int i=1;i<=n;i++){
            cin>>a[i].dy>>a[i].de>>a[i].ds;
            if(a[i].dy>a[i].de){
                if(a[i].de>a[i].ds){
                    a[i].sx1=1;
                    a[i].sx2=2;
                    a[i].sx3=3;
                }
                else{
                    if(a[i].ds>a[i].dy){
                        a[i].sx1=3;
                        a[i].sx2=1;
                        a[i].sx3=2;
                    }
                    else{
                        a[i].sx1=1;
                        a[i].sx2=3;
                        a[i].sx3=2;
                    }
                }
            }
            else{
                if(a[i].dy>a[i].ds){
                    a[i].sx1=2;
                    a[i].sx2=1;
                    a[i].sx3=3;
                }
                else{
                    if(a[i].ds>a[i].de){
                        a[i].sx1=3;
                        a[i].sx2=2;
                        a[i].sx3=1;
                    }
                    else{
                        a[i].sx1=2;
                        a[i].sx2=3;
                        a[i].sx3=1;
                    }

                }
            }
        }
        int k=n/2;
        for(int i=1;i<=n;i++){
            if(a[i].sx1==1){
                q++;
                diy[q].dy=a[i].dy;
                diy[q].de=a[i].de;
                diy[q].ds=a[i].ds;
            }
            else{
                if(a[i].sx1==2){
                    w++;
                    die[w].dy=a[i].dy;
                    die[w].de=a[i].de;
                    die[w].ds=a[i].ds;
                }
                else{
                    e++;
                    dis[e].dy=a[i].dy;
                    dis[e].de=a[i].de;
                    dis[e].ds=a[i].ds;
                }
            }
            if(q>k){
                for(int j=1;j<q;j++){
                    int qq=0,ww=0;
                    qq=diy[q].dy+max(diy[j].de,diy[j].ds);
                    ww=diy[j].dy+max(diy[q].de,diy[q].ds);
                    if(qq>ww){
                        diy[q+1].dy=diy[j].dy;
                        diy[q+1].de=diy[j].de;
                        diy[q+1].ds=diy[j].ds;
                        diy[j].dy=diy[q].dy;
                        diy[j].de=diy[q].de;
                        diy[j].ds=diy[q].ds;
                        diy[q].dy=diy[q+1].dy;
                        diy[q].de=diy[q+1].de;
                        diy[q].ds=diy[q+1].ds;
                    }
                }
                if(diy[q].de>diy[q].ds){
                    w++;
                    die[w].dy=diy[q].dy;
                    die[w].de=diy[q].de;
                    die[w].ds=diy[q].ds;
                }
                else{
                    e++;
                    dis[e].dy=diy[q].dy;
                    dis[e].de=diy[q].de;
                    dis[e].ds=diy[q].ds;
                }
                q--;
            }
            if(w>k){
                for(int j=1;j<w;j++){
                    int qq=0,ww=0;
                    qq=die[w].de+max(die[j].dy,die[j].ds);
                    ww=die[j].de+max(die[w].dy,die[w].ds);
                    if(qq>ww){
                        die[w+1].dy=die[j].dy;
                        die[w+1].de=die[j].de;
                        die[w+1].ds=die[j].ds;
                        die[j].dy=die[w].dy;
                        die[j].de=die[w].de;
                        die[j].ds=die[w].ds;
                        die[w].dy=die[w+1].dy;
                        die[w].de=die[w+1].de;
                        die[w].ds=die[w+1].ds;
                    }
                }
                if(die[w].dy>die[w].ds){
                    q++;
                    diy[q].dy=die[w].dy;
                    diy[q].de=die[w].de;
                    diy[q].ds=die[w].ds;
                }
                else{
                    e++;
                    dis[e].dy=die[w].dy;
                    dis[e].de=die[w].de;
                    dis[e].ds=die[w].ds;
                }
                w--;
            }
            if(e>k){
                for(int j=1;j<e;j++){
                    int qq=0,ww=0;
                    qq=dis[e].ds+max(dis[j].de,dis[j].dy);
                    ww=dis[j].ds+max(dis[e].de,dis[e].dy);
                    if(qq>ww){
                        dis[e+1].dy=dis[j].dy;
                        dis[e+1].de=dis[j].de;
                        dis[e+1].ds=dis[j].ds;
                        dis[j].dy=dis[e].dy;
                        dis[j].de=dis[e].de;
                        dis[j].ds=dis[e].ds;
                        dis[e].dy=dis[e+1].dy;
                        dis[e].de=dis[e+1].de;
                        dis[e].ds=dis[e+1].ds;
                    }
                }
                if(dis[e].dy>dis[e].de){
                    q++;
                    diy[q].dy=dis[e].dy;
                    diy[q].de=dis[e].de;
                    diy[q].ds=dis[e].ds;
                }
                else{
                    w++;
                    die[w].dy=dis[e].dy;
                    die[w].de=dis[e].de;
                    die[w].ds=dis[e].ds;
                }
                e--;
            }
        }
        long long ans=0;
        for(int i=1;i<=q;i++){
            ans+=diy[i].dy;
        }
        for(int i=1;i<=w;i++){
            ans+=die[i].de;
        }
        for(int i=1;i<=e;i++){
            ans+=dis[i].ds;
        }
        pp[oo]=ans;
        ans=0;
    }
    for(int i=1;i<=T;i++){
        cout<<pp[i]<<endl;
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
