#include <bits/stdc++.h>
using namespace std;
ofstream fout("replace.out");
ifstream fin("replace.in");
struct DOUBchara
{
	string a;
	string b;//<5000000
};
int main()
{
    int doub_num,ask_num;//<200000
    fin>>doub_num>>ask_num;
    //cout<<"num over\n";
    int f,s,d=0,g;
    DOUBchara doubC[doub_num];
    for(f=0;f<doub_num;f++)
	{
		string a;
		string b;
		fin>>a>>b;
		bool x=true;
		for(s=0;s<f;s++)
		{
			if(doubC[s].a==a && doubC[s].b==b)
			{
				x=false;break;
			}
		}
		if(x)
		{
			doubC[d].a=a,doubC[d].b=b;
			//cout<<"doubC["<<d<<"] OK\n";
			d++;
		}
	}
	doub_num=d;
	for(f=0;f<ask_num;f++)
	{
		int sum=0;
		string aska;
		string askb;
		fin>>aska>>askb;
		if(aska.size()==askb.size())
		{
			for(s=0;s<doub_num;s++)
			{
				//doubC[s].a.c_str();
				//doubC[s].b.c_str();
				int asklen=aska.size();
				int doublen=doubC[s].a.size();
				for(d=0;asklen>=doublen && d<=asklen-doublen;d++)
				{
					//bool x=true;
					//for(g=0;g<doublen;g++)
					//{
					//	if(doubC[s].a[g]!=aska[d+g])
					//	{
					//		x=false;break;
					//	}
					//}
					if(doubC[s].a==aska.substr(d,doublen))
					{
						string aska1=aska;
						for(g=0;g<doublen;g++)
						{
							aska1[d+g]=doubC[s].b[g];
						}
						//bool y=true;
						//for(g=0;g<asklen;g++)
						//{
						//	if(aska1[g]!=askb[g])
						//	{
						//		y=false;break;
						//	}
						//}
						if(aska1==askb)
						{
							sum++;
						}
					}
				}
			}
		}
		//cout<<endl<<sum;
		fout<<sum<<endl;
	}
    return 0;
}
