#include <bits/stdc++.h>
using namespace std;
ofstream fout("club.out");
ifstream fin("club.in");
bool isSpeA,isSpeB;
int sumALL,sum,guys;
//best_like,every_dfs_sum,guys_num
int AA[100005],BB[100005],CC[100005];
//every_guy's_like
int A,B,C;//group_guys_num_total
//char testg[100005];
//char testg1[100005];
inline bool ADE(int a,int b)
{
	return a>b;
}
void dfs(int guynow)
{
	if(guynow==guys)
	{
		if(sum>sumALL)
		{
			//for(int g=0;g<100005;g++)testg[g]=testg1[g];
			sumALL=sum;
		}
		return;
	}
	if(A<guys/2)
	{
		//testg1[guynow]='A';
		A++;
		sum=sum+AA[guynow];
		dfs(guynow+1);
		sum=sum-AA[guynow];
		A--;
	}
	if(B<guys/2)
	{
		//testg1[guynow]='B';
		B++;
		sum=sum+BB[guynow];
		dfs(guynow+1);
		sum=sum-BB[guynow];
		B--;
	}
	if(C<guys/2)
	{
		//testg1[guynow]='C';
		C++;
		sum=sum+CC[guynow];
		dfs(guynow+1);
		sum=sum-CC[guynow];
		C--;
	}
}
void dfs2(int guynow)
{
	if(guynow==guys)
	{
		if(sum>sumALL)
		{
			sumALL=sum;
		}
		return;
	}
	if(A<guys/2)
	{
		//testg1[guynow]='A';
		A++;
		sum=sum+AA[guynow];
		dfs(guynow+1);
		sum=sum-AA[guynow];
		A--;
	}
	if(B<guys/2)
	{
		//testg1[guynow]='B';
		B++;
		sum=sum+BB[guynow];
		dfs(guynow+1);
		sum=sum-BB[guynow];
		B--;
	}
}
void fun()
{
	isSpeA=isSpeB=true;
	sum=sumALL=-1;
	A=B=C=0;
	fin>>guys;
	int f;
	for(f=0;f<guys;f++)
	{
		fin>>AA[f]>>BB[f]>>CC[f];
		//SpeA: BB=CC=0
		if(BB[f]==0 && CC[f]==0)
		{

		}
		else
		{
			isSpeA=false;
		}
		//SpeB: CC=0
		if(CC[f]==0)
		{

		}
		else
		{
			isSpeB=false;
		}
	}
	if(isSpeA)//BB=CC=0
	{
		//cout<<"ABABABABAB";
		sort(AA,AA+guys,ADE);
		int sumar=0;
		for(f=0;f<guys/2;f++)
		{
			sumar+=AA[f];
		}
		fout<<sumar<<endl;
	}
	else if(isSpeB)//CC=0
	{
		dfs2(0);
		fout<<sumALL+1<<endl;
	}
	else
	{
		dfs(0);
		//fout<<testg<<endl;
		//sumALL=0;
		//for(f=0;f<guys;f++)
		//{
		//	if(testg[f]=='A')sumALL+=AA[f];
		//	else if(testg[f]=='B')sumALL+=BB[f];
		//	else if(testg[f]=='C')sumALL+=CC[f];
		//}
		fout<<sumALL+1<<endl;
	}
	return;
}
int main()
{
    int a;
    fin>>a;
    for(int f=0;f<a;f++)
	{
		fun();
	}
    return 0;
}
