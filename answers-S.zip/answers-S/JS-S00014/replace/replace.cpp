#include <bits/stdc++.h>
#define F(i,x,y) for(int i=(x);i<=(y);i++)
#define DF(i,x,y) for(int i=(x);i>=(y);i--)
#define ms(x,y) memset(x,y,sizeof(x))
#define all(x) x.begin(),x.end()
#define SZ(x) (int)x.size()-1
#define pb push_back
using namespace std;
typedef long long LL;
typedef unsigned long long ull;
typedef pair<int,int> pii;
template<typename T> void chkmin(T &x,T y){ x=min(x,y);}
template<typename T> void chkmax(T &x,T y){ x=max(x,y);}
const int N=200010,L=5000010;
const int base1=1331,mod1=1e9+9,base2=233,mod2=1926081717;
int n,q,fps[N],lps[N],fpt[N],lpt[N],lens[N],lent[N],ans[N];
string s0[N],s1[N],t0[N],t1[N];
struct Info{ int h1,h2,h3,h4,id,tp;}qwq[N*2];
int tr1[L][26],idx1,tr2[L][26],idx2,sum[L],fa[L];
vector<int> ins[L];
vector<pii> qry[L];
void dfs(int x){
    for(int y:ins[x]) sum[y]++;
    for(pii t:qry[x]){
        int y=t.first,id=t.second;
        while(true){
            ans[id]+=sum[y];
            if(!y) break;
            y=fa[y];
        }
    }
    F(i,0,25) if(tr1[x][i]) dfs(tr1[x][i]);
    for(int y:ins[x]) sum[y]--;
}
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
    cin>>n>>q;
    int cnt=0;
    F(i,1,n){
        cin>>s0[i]>>s1[i];
        lens[i]=s0[i].size();fps[i]=-1;
        F(j,0,lens[i]-1) if(s0[i][j]!=s1[i][j]){ fps[i]=j;break;}
        if(fps[i]==-1) continue;
        DF(j,lens[i]-1,0) if(s0[i][j]!=s1[i][j]){ lps[i]=j;break;}
        int h1=0,h2=0,h3=0,h4=0;
        F(j,fps[i],lps[i]){
            h1=(1ll*h1*base1+s0[i][j])%mod1;
            h2=(1ll*h2*base2+s0[i][j])%mod2;
            h3=(1ll*h3*base1+s1[i][j])%mod1;
            h4=(1ll*h4*base2+s1[i][j])%mod2;
        }
        qwq[++cnt]={h1,h2,h3,h4,i,0};
    }
    F(i,1,q){
        cin>>t0[i]>>t1[i];
        if(t0[i].size()!=t1[i].size()) continue;
        lent[i]=t0[i].size();fpt[i]=-1;
        F(j,0,lent[i]-1) if(t0[i][j]!=t1[i][j]){ fpt[i]=j;break;}
        DF(j,lent[i]-1,0) if(t0[i][j]!=t1[i][j]){ lpt[i]=j;break;}
        int h1=0,h2=0,h3=0,h4=0;
        F(j,fpt[i],lpt[i]){
            h1=(1ll*h1*base1+t0[i][j])%mod1;
            h2=(1ll*h2*base2+t0[i][j])%mod2;
            h3=(1ll*h3*base1+t1[i][j])%mod1;
            h4=(1ll*h4*base2+t1[i][j])%mod2;
        }
        qwq[++cnt]={h1,h2,h3,h4,i,1};
    }
    sort(qwq+1,qwq+cnt+1,[&](Info o1,Info o2){
        if(o1.h1!=o2.h1) return o1.h1<o2.h1;
        if(o1.h2!=o2.h2) return o1.h2<o2.h2;
        if(o1.h3!=o2.h3) return o1.h3<o2.h3;
        if(o1.h4!=o2.h4) return o1.h4<o2.h4;
        if(o1.tp!=o2.tp) return o1.tp>o2.tp;
        return o1.id<o2.id;});
    F(i,1,cnt){
        int j=i;
        while(j<cnt&&qwq[i].h1==qwq[j+1].h1&&qwq[i].h2==qwq[j+1].h2&&qwq[i].h3==qwq[j+1].h3&&qwq[i].h4==qwq[j+1].h4) j++;
        F(k,i,j) if(!qwq[k].tp){
            int x=qwq[k].id,cur=0;
            DF(_,fps[x]-1,0){
                int c=s0[x][_]-'a';
                if(!tr1[cur][c]) tr1[cur][c]=++idx1;
                cur=tr1[cur][c];
            }
            int rc=cur;cur=0;
            F(_,lps[x]+1,lens[x]-1){
                int c=s0[x][_]-'a';
                if(!tr2[cur][c]) tr2[cur][c]=++idx2,fa[idx2]=cur;
                cur=tr2[cur][c];
            }
            ins[rc].pb(cur);
        }
        F(k,i,j) if(qwq[k].tp){
            int x=qwq[k].id,cur=0;
            DF(_,fpt[x]-1,0){
                int c=t0[x][_]-'a';
                if(!tr1[cur][c]) break;
                cur=tr1[cur][c];
            }
            int rc=cur;cur=0;
            F(_,lpt[x]+1,lent[x]-1){
                int c=t0[x][_]-'a';
                if(!tr2[cur][c]) break;
                cur=tr2[cur][c];
            }
            qry[rc].pb({cur,qwq[k].id});
        }
        dfs(0);
        F(i,0,idx1) qry[i].clear(),ins[i].clear(),ms(tr1[i],0);idx1=0;
        F(i,0,idx2) ms(tr2[i],0);idx2=0;
        i=j;
    }
    F(i,1,q) cout<<ans[i]<<'\n';
    return 0;
}
