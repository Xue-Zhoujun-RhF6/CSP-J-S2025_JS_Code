#include <bits/stdc++.h>
#define F(i,x,y) for(int i=(x);i<=(y);i++)
#define DF(i,x,y) for(int i=(x);i>=(y);i--)
#define ms(x,y) memset(x,y,sizeof(x))
#define all(x) x.begin(),x.end()
#define SZ(x) (int)x.size()-1
#define pb push_back
using namespace std;
typedef long long LL;
typedef unsigned long long ull;
typedef pair<int,int> pii;
template<typename T> void chkmin(T &x,T y){ x=min(x,y);}
template<typename T> void chkmax(T &x,T y){ x=max(x,y);}
template<typename T> void read(T &x){
    x=0;int r=1;char ch=getchar();
    for(;!isdigit(ch);ch=getchar()) if(ch=='-') r=-1;
    for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+ch-48;
    x*=r;
}
const int N=100010;
int n,a[N][3],cho[N],cnt[3];
void work(){
    read(n);
    F(i,1,n) F(j,0,2) read(a[i][j]);
    ms(cnt,0);
    int ans=0;
    F(i,1,n){
        int mx=0;
        F(j,1,2) if(a[i][j]>a[i][mx]) mx=j;
        cnt[mx]++,cho[i]=mx,ans+=a[i][mx];
    }
    int bn=-1;
    F(i,0,2) if(cnt[i]>n/2) bn=i;
    if(~bn){
        vector<int> dt;
        F(i,1,n) if(cho[i]==bn){
            int t=0;
            F(j,0,2) if(j!=bn) chkmax(t,a[i][j]);
            dt.pb(t-a[i][bn]);
        }
        sort(all(dt),greater<int>());
        F(i,1,cnt[bn]-n/2) ans+=dt[i-1];
    }
    printf("%d\n",ans);
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int T;read(T);
    while(T--) work();
    return 0;
}
