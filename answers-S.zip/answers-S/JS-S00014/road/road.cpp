#include <bits/stdc++.h>
#define F(i,x,y) for(int i=(x);i<=(y);i++)
#define DF(i,x,y) for(int i=(x);i>=(y);i--)
#define ms(x,y) memset(x,y,sizeof(x))
#define all(x) x.begin(),x.end()
#define SZ(x) (int)x.size()-1
#define pb push_back
using namespace std;
typedef long long LL;
typedef unsigned long long ull;
typedef pair<int,int> pii;
template<typename T> void chkmin(T &x,T y){ x=min(x,y);}
template<typename T> void chkmax(T &x,T y){ x=max(x,y);}
template<typename T> void read(T &x){
    x=0;int r=1;char ch=getchar();
    for(;!isdigit(ch);ch=getchar()) if(ch=='-') r=-1;
    for(;isdigit(ch);ch=getchar()) x=(x<<1)+(x<<3)+ch-48;
    x*=r;
}
const int N=10100,M=1000010;
const LL inf=1e18;
int n,m,k,c[15],fa[N];
struct edge{ int z,x,y;}edg[M],e[11][N];
int gfa(int x){ return x==fa[x]?x:fa[x]=gfa(fa[x]);}
int len[1<<10];
edge use[1<<10][N];
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    read(n),read(m),read(k);
    F(i,1,m){
        int x,y,z;read(x),read(y),read(z);
        edg[i]={z,x,y};
    }
    F(i,1,k){
        read(c[i]);
        F(j,1,n){ int x;read(x);e[i][j]={x,i+n,j};}
        sort(e[i]+1,e[i]+n+1,[&](edge o1,edge o2){ return o1.z<o2.z;});
    }
    sort(edg+1,edg+m+1,[&](edge o1,edge o2){ return o1.z<o2.z;});
    F(i,1,n) fa[i]=i;
    LL ans=0;
    F(i,1,m){
        int fx=gfa(edg[i].x),fy=gfa(edg[i].y);
        if(fx!=fy) fa[fx]=fy,use[0][++len[0]]={edg[i].z,edg[i].x,edg[i].y},ans+=edg[i].z;
    }
    F(S,1,(1<<k)-1){
        int p1;F(i,0,k-1) if(S>>i&1){ p1=i;break;}
        LL res=0;F(i,0,k-1) if(S>>i&1) res+=c[i+1];
        F(i,1,n+k) fa[i]=i;
        int i=1,j=1,T=S^(1<<p1);p1++;
        while(i<=len[T]||j<=n){
            if(j>n||(i<=len[T]&&use[T][i].z<e[p1][j].z)){
                int fx=gfa(use[T][i].x),fy=gfa(use[T][i].y);
                if(fx!=fy) fa[fx]=fy,res+=use[T][i].z,use[S][++len[S]]=use[T][i];
                i++;
            }
            else{
                int fx=gfa(e[p1][j].x),fy=gfa(e[p1][j].y);
                if(fx!=fy) fa[fx]=fy,res+=e[p1][j].z,use[S][++len[S]]=e[p1][j];
                j++;
            }
        }
        chkmin(ans,res);
    }
    printf("%lld\n",ans);
    return 0;
}
