#include <bits/stdc++.h>
#define F(i,x,y) for(int i=(x);i<=(y);i++)
#define DF(i,x,y) for(int i=(x);i>=(y);i--)
#define ms(x,y) memset(x,y,sizeof(x))
#define all(x) x.begin(),x.end()
#define SZ(x) (int)x.size()-1
#define pb push_back
using namespace std;
typedef long long LL;
typedef unsigned long long ull;
typedef pair<int,int> pii;
template<typename T> void chkmin(T &x,T y){ x=min(x,y);}
template<typename T> void chkmax(T &x,T y){ x=max(x,y);}
const int N=510,P=998244353;
int n,m,c[N],cnt[N],sum[N],C[N][N],fac[N],f[2][N][N];
inline void inc(int &x,LL y){ x=(x+y)%P;}
string s;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
    cin>>n>>m>>s;s=" "+s;
    F(i,1,n) cin>>c[i];
    F(i,1,n) cnt[c[i]]++;
    sum[0]=cnt[0];F(i,1,n) sum[i]=sum[i-1]+cnt[i];
    F(i,0,n){ C[i][0]=1;F(j,1,i) C[i][j]=(C[i-1][j-1]+C[i-1][j])%P;}
    fac[0]=1;F(i,1,n) fac[i]=1ll*fac[i-1]*i%P;
    f[0][0][0]=1;
    F(i,1,n){
        int p=i&1,q=!p;
        F(j,0,i) F(k,0,i) f[p][j][k]=0;
        if(s[i]=='1')
            F(j,0,i-1) F(k,0,i-1){
                int v=f[q][j][k];if(!v) continue;
                F(t,0,min(i-k-1,cnt[j+1])) inc(f[p][j+1][k+1+t],1ll*v*(sum[j]-k)%P*C[cnt[j+1]][t]%P*C[i-1-k][t]%P*fac[t]);
                inc(f[p][j][k],v);
            }
        else
            F(j,0,i-1) F(k,0,i-1){
                int v=f[q][j][k];if(!v) continue;
                F(t,0,min(i-k-1,cnt[j+1])) inc(f[p][j+1][k+1+t],1ll*v*(sum[j]-k)%P*C[cnt[j+1]][t]%P*C[i-1-k][t]%P*fac[t]);
                F(t,0,min(i-k,cnt[j+1])) inc(f[p][j+1][k+t],1ll*v*C[cnt[j+1]][t]%P*C[i-k][t]%P*fac[t]);
            }
    }
    int ans=0;
    F(i,0,n-m) inc(ans,1ll*f[n&1][i][sum[i]]*fac[n-sum[i]]);
    cout<<ans<<'\n';
    return 0;
}
