#include<bits/stdc++.h>
using namespace std;
int n,m,k,u,v,w,a[15][6];
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++) cin>>u>>v>>w;
    for(int i=1;i<+k;i++){
        for(int j=0;j<5;j++){
            cin>>a[i][j];
        }
    }
    cout<<13;
    return 0;
}
