#include<bits/stdc++.h>
using namespace std;
const int N=2e5+3;
int t,n,a[N][4],mx1[N],mx2[N],res[4],diff1[N],diff2[N],diff3[N],ans;
int dif1,dif2,dif3,id,mid,maxn;
void cmp(int x,int a,int b,int c){
    int d=max(b,c);
    if(a>=d){
        mx1[x]=a;
        res[1]++;
        mx2[x]=(b>=c?b:c);
        diff1[++dif1]=mx1[x]-mx2[x];
    }else{
        if(b>=c){
            mx1[x]=b;
            res[2]++;
            mx2[x]=(a>=c?a:c);
            diff2[++dif2]=mx1[x]-mx2[x];
        }else{
            mx1[x]=c;
            res[3]++;
            mx2[x]=(a>=b?a:b);
            diff3[++dif3]=mx1[x]-mx2[x];
        }
    }
    return;
}
void cmp1(int a,int b,int c){
    int d=max(b,c);
    if(a>=d){
        maxn=a;
        id=1;
    }else{
        if(b>=c){
            maxn=b;
            id=2;
        }else{
            maxn=c;
            id=3;
        }
    }
    return;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>t;
    while(t--){
        cin>>n;
        ans=0;
        dif1=dif2=dif3=0;
        memset(res,0,sizeof(res));
        for(int i=1;i<=n;i++){
            cin>>a[i][1]>>a[i][2]>>a[i][3];
            cmp(i,a[i][1],a[i][2],a[i][3]);
        }
        sort(diff1+1,diff1+dif1+1);
        sort(diff2+1,diff2+dif2+1);
        sort(diff3+1,diff3+dif3+1);
        //for(int i=1;i<=n;i++) cout<<mx1[i]<<" "<<mx2[i]<<"\n";
        //for(int i=1;i<=n;i++) cout<<diff1[i]<<" "<<diff2[i]<<" "<<diff3[i]<<"\n";
        mid=n/2;
        cmp1(res[1],res[2],res[3]);
        //cout<<"\n"<<maxn<<"\n";
        if(maxn<=mid){
            for(int i=1;i<=n;i++) ans+=mx1[i];
        }else{
            for(int i=1;i<=n;i++) ans+=mx1[i];
            //cout<<ans<<"\n";
            for(int i=1;i<=maxn-mid;i++){
                if(id==1) ans-=diff1[i];
                if(id==2) ans-=diff2[i];
                if(id==3) ans-=diff3[i];
            }
        }
        cout<<ans<<"\n";
    }
    return 0;
}
