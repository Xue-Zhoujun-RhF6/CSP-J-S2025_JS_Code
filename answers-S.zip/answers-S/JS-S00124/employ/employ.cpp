#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int n,m,c[503],cnt,num;
string s;
long long solve1(int k){
    long long ans=1;
    for(int i=k;i>=1;i--){
        ans=ans*i%mod;
    }
    return ans;
}
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    scanf("%d%d",&n,&m);
    char ch;
    s+=' ';
    bool flag=true;
    ch=getchar();
    ch=getchar();
    while(ch=='0'||ch=='1'){
        s+=ch;
        if(ch=='0') flag=false;
        if(ch=='1') cnt++;
        ch=getchar();
    }
    for(int i=1;i<=n;i++) scanf("%d",c+i);
    sort(c+1,c+n+1);
    if(flag){
        printf("%lld",solve1(n));
        return 0;
    }else if(m>cnt){
        printf("%d",0);
        return 0;
    }else if(m==1){
        int i=1,j=1;
        while(s[i]=='0') i++;
        while(c[j]<i) j++;
        printf("%lld",solve1(n-j+1));
        return 0;
    }else if(m==n){
        int i=1,j=1;
        while(i<=n){
            while(s[i]=='0') i++;
            if(c[j]<i){
                printf("%d",0);
                return 0;
            }
            while(s[i]=='1') i++;
            j=i;
        }
        printf("%d",1);
    }else{
        printf("%d",2);
    }
    return 0;
}
