#include<bits/stdc++.h>
using namespace std;
int a[10005];
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m,k;
    cin>>n>>m>>k;
    while(m--)
    {
        int u,v,w;
        cin>>u>>v>>w;
    }
    while(k--)
    {
        int c;
        cin>>c;
        for(int i=1;i<=n;i++)
            cin>>a[i];
    }
    cout<<0;
    return 0;
}
