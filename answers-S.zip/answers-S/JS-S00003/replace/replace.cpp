#include<bits/stdc++.h>
using namespace std;
string s[200005][3];
map<string,int>mp,mp2;
int main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    int n,q;
    cin>>n>>q;
    for(int i=1;i<=n;i++)
    {
        cin>>s[i][1]>>s[i][2];
        mp[s[i][1]]=1;
        mp2[s[i][2]]=1;
    }
    for(int i=1;i<=q;i++)
    {
        string t1,t2;
        cin>>t1>>t2;
        int ans=0;
        for(int j=0;j<t1.size();j++)
        {
            for(int k=j+1;k<t1.size();k++)
            {
                if(mp[t1.substr(j,k-j+1)]==1&&mp2[t2.substr(j,k-j+1)]==1)
                    ans++;
            }
        }
        cout<<ans<<endl;
    }

    return 0;
}
