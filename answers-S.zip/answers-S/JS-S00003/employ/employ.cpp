#include<bits/stdc++.h>
using namespace std;
const int Mod=998244353;
int a[505];
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m,cnt=1,sum=0;
    cin>>n>>m;
    string s;
    cin>>s;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        if(a[i]!=0) sum++;
    }
    if(sum<m)
    {
        cout<<0;
        return 0;
    }
    for(int i=1;i<=sum;i++)
    {
        cnt=cnt*i%Mod;
    }
    cout<<cnt;
    return 0;
}
