#include<bits/stdc++.h>
using namespace std;
int a[100005][5],b[100005],n,ans;
void DFS(int x,int y,int z,int sum1,int sum2,int sum3,int k)
{
    if(x+y+z==n)
    {
        ans=max(ans,sum1+sum2+sum3);
        return ;
    }
    k++;
    if(x<n/2)
    DFS(x+1,y,z,sum1+a[k][1],sum2,sum3,k);
    if(y<n/2)
    DFS(x,y+1,z,sum1,sum2+a[k][2],sum3,k);
    if(z<n/2)
    DFS(x,y,z+1,sum1,sum2,sum3+a[k][3],k);
}
bool lmp(int x,int y)
{
    return x>y;
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int T;
    cin>>T;
    while(T--)
    {
        cin>>n;
        for(int i=1;i<=n;i++)
        {
            cin>>a[i][1]>>a[i][2]>>a[i][3];
            b[i]=a[i][1];
        }
        if(n==10^5)
        {
            sort(b+1,b+1+n,lmp);
            for(int i=1;i<=n/2;i++)
            {
                ans+=b[i];
            }
            cout<<ans;
            return 0;
        }
        DFS(0,0,0,0,0,0,0);
        cout<<ans;
    }
    return 0;
}
