#include <bits/stdc++.h>
#define ll long long
#define pii std::pair<int,int>

using std::cin;
using std::cout;
using std::endl;

struct Edge{
    int fm;
    int to;
    int cst;
    bool operator<(const Edge oth)const{
        return cst<oth.cst;
    }
};

std::vector<int> a[10025];
std::vector<int> w[10025];
std::vector<Edge> eg;
std::vector<bool> eok;
std::vector<Edge> ad;

int fa[10025];
int getfa(int p){
    if(fa[p]==p)return p;
    else return fa[p]=getfa(fa[p]);
}
void merge(int A,int B){
    A=getfa(A);B=getfa(B);
    if(A!=B)fa[A]=B;
}

ll MST(std::vector<Edge>& Eg,int n){

    eok.resize(Eg.size());
    std::fill(eok.begin(),eok.end(),0);
    for(int i=1;i<=n;i++)fa[i]=i;
    ll res=0;

    for(int i=0;i<(int)Eg.size();i++){
        int x=Eg[i].fm,y=Eg[i].to;
        if(getfa(x)!=getfa(y)){
            merge(x,y);
            res+=(ll)Eg[i].cst;
            eok[i]=true;
        }
    }

    return res;

}

void eraserest(std::vector<Edge>& Eg,std::vector<bool>& Eok){
    std::vector<Edge> tmp;
    for(int i=0;i<(int)Eok.size();i++){
        if(Eok[i])tmp.push_back(Eg[i]);
    }
    std::swap(tmp,Eg);
    return;
}

int pcst[15];
std::vector<Edge> exeg[10005];

std::vector<Edge> tmp;

Edge mneg[15][15];

int main(void){

    assert(freopen("road.in","r",stdin));
    assert(freopen("road.out","w",stdout));
    std::ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);

    int n,m,k;
    ll ans=0;
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        int u,v,c;
        cin>>u>>v>>c;
        eg.push_back({u,v,c});
    }

    std::sort(eg.begin(),eg.end());
    ans=MST(eg,n);
    eraserest(eg,eok);

    for(int i=1;i<=k;i++){
        cin>>pcst[i];
        for(int j=1;j<=n;j++){
            int c;cin>>c;
            exeg[j].push_back({j,n+i,c});
        }
    }
    for(int i=1;i<=n;i++)std::sort(exeg[i].begin(),exeg[i].end());

    ad.reserve(n+n+k);
    for(int msk=1;msk<(1<<k);msk++){
        bool ok[15]={0};
        ll cur=0;
        ad=eg;
        int yuan=(int)eg.size();
        for(int i=0;i<k;i++){
            if((msk>>i)&1){
                ok[i+1]=true;
                cur+=(ll)pcst[i+1];
            }
        }
        for(int i=1;i<=k;i++){
            for(int j=1;j<=k;j++){
                mneg[i][j]={0,0,(int)1e9};
            }
        }
        for(int i=1;i<=n;i++){
            int p=0,bg=0;
            while(p<(int)exeg[i].size()&&(!ok[exeg[i][p].to-n]))p++;
            ad.push_back(exeg[i][p]);bg=p++;
            while(p<(int)exeg[i].size()){
                while(p<(int)exeg[i].size()&&(!ok[exeg[i][p].to-n]))p++;
                if(p>=(int)exeg[i].size())break;
                mneg[exeg[i][bg].to-n][exeg[i][p].to-n]=std::min(mneg[exeg[i][bg].to-n][exeg[i][p].to-n],exeg[i][p]);
                p++;
            }
        }
        tmp.clear();
        for(int i=1;i<=k;i++){
            if(!ok[i])continue;
            for(int j=1;j<=k;j++){
                if(!ok[j])continue;
                tmp.push_back({i,j,mneg[i][j].cst});
            }
        }
        std::sort(tmp.begin(),tmp.end());
        MST(tmp,k);
        for(int i=0;i<(int)tmp.size();i++){
            if(!eok[i])continue;
            ad.push_back(mneg[tmp[i].fm][tmp[i].to]);
        }
        std::sort(ad.begin()+yuan,ad.end());

        std::inplace_merge(ad.begin(),ad.begin()+yuan,ad.end());

        ans=std::min(ans,cur+MST(ad,n+k));

    }

    cout<<ans<<endl;

    return 0;
    
    

}//chennie bless me