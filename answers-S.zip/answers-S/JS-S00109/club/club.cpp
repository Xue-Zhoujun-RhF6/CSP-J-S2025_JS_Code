#include <bits/stdc++.h>
#define ll long long

using std::cin;
using std::cout;
using std::endl;

ll a[100005][5];
std::vector<ll> b[5];

int main(void){

    assert(freopen("club.in","r",stdin));
    assert(freopen("club.out","w",stdout));
    std::ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);

    // assert(freopen("club5.in","r",stdin));
    // assert(freopen("club.out","w",stdout));

    ll t;
    cin>>t;
    while(t--){
        ll n,ans=0;
        cin>>n;

        for(ll i=1;i<=3;i++)b[i].clear();

        for(ll i=1;i<=n;i++){
            ll curmx=0;
            for(ll j=1;j<=3;j++){
                cin>>a[i][j];
                if(a[i][j]>a[i][curmx])curmx=j;
            }
            ans+=a[i][curmx];
            std::sort(a[i]+1,a[i]+3+1);
            ll cz=a[i][3]-a[i][2];
            b[curmx].push_back(cz);
        }
        for(ll i=1;i<=3;i++){
            if((ll)b[i].size()>(n/2)){
                std::sort(b[i].begin(),b[i].end());
                for(ll j=0;j<(ll)b[i].size()-(n/2);j++){
                    ans-=b[i][j];
                }
                break;
            }
        }
        cout<<ans<<endl;

    }

    return 0;

}