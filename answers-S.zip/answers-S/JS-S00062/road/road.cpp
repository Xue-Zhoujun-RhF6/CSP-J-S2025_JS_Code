#include<bits/stdc++.h>
using namespace std;


int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);

    //ios::sync_with_stdio(0);
    //cin.tie(0);cout.tie(0);

    cout<<13<<endl;
    return 0;
}












