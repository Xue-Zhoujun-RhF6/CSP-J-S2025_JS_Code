#include<bits/stdc++.h>
using namespace std;

int a[100086][3],b[100086],c[100086];
int mz[100086];
int n,t;
int tt[100086],pp=0;



int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);


    int t;
    cin>>t;
    while(t--){

        cin>>n;
        for(int i=1;i<=n;i++){


            cin>>a[i][0]>>a[i][1]>>a[i][2];

            int sum=max(max(a[i][0],a[i][1]),a[i][2]);

            if(sum==a[i][0]) mz[i]=0;
            else if(sum==a[i][1]) mz[i]=1;
            else mz[i]=2;
        }

        int ccc[3]={0,0,0};

        for(int i=1;i<=n;i++) ccc[mz[i]];

        int sum=max(max(mz[0],mz[1]),mz[2]);

        int mzx=0;

        long long r=0;

        for(int i=1;i<=n;i++){
            r+=a[i][mz[i]];

        }
        if(sum==ccc[0]) mzx=0;
        else if(sum==ccc[1]) mzx=1;
        else mzx=2;

        if(sum<=n/2){

            cout<<r<<"\n";
        }else{
            pp=0;
            for(int i=1;i<=n;i++){
                if(mz[i]==mzx){
                    sort(a[i],a[i]+3);
                    tt[pp++]=a[i][1]-a[i][2];
                }
            }

            sort(tt+1,tt+pp+1,greater<int>());

            for(int i=1;i<=sum-n/2;i++){
                r+=tt[i];

            }

            cout<<r<<"\n";

        }
    }
    return 0;
}

