#include<bits/stdc++.h>
using namespace std;

int n,q;


int main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);

    //ios::sync_with_stdio(0);
    //cin.tie(0);cout.tie(0);

    cout<<0<<endl;
    cout<<0<<endl;
    cout<<0<<endl;
    cout<<0<<endl;
    cout<<0<<endl;

    return 0;
}












