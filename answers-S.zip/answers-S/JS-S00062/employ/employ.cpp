#include<bits/stdc++.h>
using namespace std;
int a[505];

int nx[505];



int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;
    cin>>n>>m;
    string s;
    cin>>s;
    for(int i=0;i<n;i++){
        a[i]=((int) s[i])-48;
    }

    for(int i=0;i<n;i++) cin>>nx[i];
    cout<<1;

    return 0;
}
