#include<bits/stdc++.h>
using namespace std;
long long mo=998244353;
long long n,m;
string s;
long long xx;
long long countt;
long long summ=1;
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    scanf("%lld%lld",&n,&m);
    cin>>s;
    for(long long i=1;i<=n;i++)
    {
        scanf("%lld",&xx);
        if(xx==0) countt++;
    }
    if(n-countt<m)
    {
            for(long long i=1;i<=n-1;i++)
        {
            summ=(summ*i)%mo;
        }
        summ=(summ*countt)%mo;
    }
    else{
        for(long long i=1;i<=n;i++)
        {
            summ=(summ*i)%mo;
        }
    }

    printf("%lld",summ);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
