#include<bits/stdc++.h>
using namespace std;
int fa[10015];
struct tt
{
    int a,b,s;
}l[1100005];
int n,m,k;
int nn;
int xx;
long long summ;
bool cmp(tt aaa,tt bbb)
{
    return aaa.s<bbb.s;
}
int findfa(int kkk)
{
    if(fa[kkk]==kkk)
    {
        return kkk;
    }
    else{
        fa[kkk]=findfa(fa[kkk]);
        return fa[kkk];
    }
}
int main()
{
   freopen("road.in","r",stdin);
   freopen("road.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d%d",&l[i].a,&l[i].b,&l[i].s);
    }

    for(int i=1;i<=k;i++)
    {
        scanf("%d",&xx);
         int pp=n+i;
        for(int j=1;j<=n;j++)
        {
            m++;
            l[m].a=pp;
            l[m].b=j;
            scanf("%d",&l[m].s);
        }
    }
    nn=n+k;
    //readin
    sort(l+1,l+m+1,cmp);
    for(int i=1;i<=nn;i++)
    {
        fa[i]=i;
    }
    //build_the least tree
    for(int i=1;i<=m;i++)
    {
        if(findfa(l[i].a)!=findfa(l[i].b))
        {
            summ+=l[i].s;
            fa[fa[l[i].b]]=fa[l[i].a];
        }
    }
    printf("%lld",summ);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
