#include<bits/stdc++.h>
using namespace std;
struct abc
{
    int a,b,c,inn;
}stu[100005];
int o[100005];
long long summ=0;
int numa,numb,numc;
int n,t;
int cnt;
bool cmp(int aa,int bb)
{
    return aa<bb;
}
void gott(int m)
{
    for(int i=1;i<=m;i++)
    {
        summ-=o[i];
    }
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%d",&t);
    for(int ii=1;ii<=t;ii++)
    {
        summ=0;
        numa=0;numb=0;numc=0;
        scanf("%d",&n);
        for(int i=1;i<=n;i++)
        {
             scanf("%d%d%d",&stu[i].a,&stu[i].b,&stu[i].c);
             if(stu[i].a>stu[i].b)
             {
                 if(stu[i].a>stu[i].c)
                 {
                     numa++;
                     summ+=stu[i].a;
                     stu[i].inn=1;
                 }
                 else
                    {
                    numc++;
                    summ+=stu[i].c;
                    stu[i].inn=3;
                 }
             }
             else
                {
                if(stu[i].b>=stu[i].c)
                {
                    numb++;
                    summ+=stu[i].b;
                    stu[i].inn=2;
                }
                else{
                    numc++;
                    summ+=stu[i].c;
                    stu[i].inn=3;
                }
            }
        }
        int midd=n/2;
        cnt=0;
        if(numa>midd)
        {
            int keyof=numa-midd;
            for(int i=1;i<=n;i++)
            {
                if(stu[i].inn==1)
                {
                    o[++cnt]=min(stu[i].a-stu[i].b,stu[i].a-stu[i].c);
                }

            }
            sort(o+1,o+cnt+1,cmp);
            gott(keyof);
        }
        if(numb>midd)
        {
            int keyof=numb-midd;
            for(int i=1;i<=n;i++)
            {
                if(stu[i].inn==2)
                {
                    o[++cnt]=min(stu[i].b-stu[i].a,stu[i].b-stu[i].c);
                }

            }
            sort(o+1,o+cnt+1,cmp);
            gott(keyof);
        }
        if(numc>midd)
        {
            int keyof=numc-midd;
            for(int i=1;i<=n;i++)
            {
                if(stu[i].inn==3)
                {
                    o[++cnt]=min(stu[i].c-stu[i].b,stu[i].c-stu[i].a);
                }

            }
            sort(o+1,o+cnt+1,cmp);
            gott(keyof);
        }
        printf("%lld\n",summ);
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}
