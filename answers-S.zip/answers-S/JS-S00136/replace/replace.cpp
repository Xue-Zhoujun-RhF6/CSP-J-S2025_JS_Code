#include<bits/stdc++.h>
using namespace std;
long long n,m,sum;
string x,y,p,q;
struct ery{
    string a;
    string b;
}zfc[20001];
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    for(int i=1;i<=n;i++){
        cin>>zfc[i].a>>zfc[i].b;
    }
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        if(x.size()!=y.size()){
            cout<<0<<endl;
            continue;
        }
        for(int j=1;j<m;j++){
            for(int k=m;k>=j;k--){

            }
        }
    }
    return 0;
}
