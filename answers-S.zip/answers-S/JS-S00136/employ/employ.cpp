#include<bits/stdc++.h>
using namespace std;
long long n,m,s[501],sum=1,cnt;
string a;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>a;
    cnt=n;
    for(int i=1;i<=n;i++){
        cin>>s[i];
    }
    if(m==n){
        cout<<0;
        return 0;
    }
    for(int i=1;i<=cnt;i++){
        sum*=i;
        sum%=998244353;
    }
    cout<<sum;
    return 0;
}
