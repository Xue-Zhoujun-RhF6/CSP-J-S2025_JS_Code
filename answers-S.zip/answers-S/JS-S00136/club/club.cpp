#include<bits/stdc++.h>
using namespace std;
int n,m;
struct ne{
    int a;
    int b;
    int c;
}stu[100001];
int f(int a1,int b1,int c1,int cnt,long long sum){
    if(a1>m/2||b1>m/2||c1>m/2){
        return 0;
    }
    if(cnt>m){
        return sum;
    }
    return max(f(a1+1,b1,c1,cnt+1,sum+stu[cnt].a),max(f(a1,b1+1,c1,cnt+1,sum+stu[cnt].b),f(a1,b1,c1+1,cnt+1,sum+stu[cnt].c)));
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>m;
        for(int j=1;j<=m;j++){
            cin>>stu[j].a>>stu[j].b>>stu[j].c;
        }
        cout<<f(0,0,0,1,0)<<endl;
    }
    return 0;
}
