#include<bits/stdc++.h>
using namespace std;
long long n,m,k,sum,t;
struct road{
    int u;
    int v;
    long long money;
}a[10000000001];
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        cin>>a[i].u>>a[i].v>>a[i].money;
    }
    for(int i=1;i<=k;i++){
        cin>>t;
    }
    return 0;
}
