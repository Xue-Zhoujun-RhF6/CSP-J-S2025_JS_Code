#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>
#include <map>

#define lowbit(x) ((x) & -(x))

#define L 5000000

char tmp[5000006];

struct node{
    int d, l, r;

    friend bool operator<(node a, node b){
        return a.l < b.l;
    }

};

node solve(std::string s, std::string t){
    int a = -1;

    for (int i=0; i<s.length(); ++i){
        if (s[i] == 'b')
            a = i;
    }

    int b = -1;

    for (int i=0; i<t.length(); ++i){
        if (t[i] == 'b')
            b = i;
    }

    return (node){a-b, std::min(a, b), s.length()-std::max(a, b)};
}

std::vector<node> a[200005], b[200005];

std::string re[200005], st[200005];

std::string replace(std::string s, std::string t){
    std::string res;

    int n = s.length();

    int fg = 0;

    for (int i=0; i<n; ++i){
        if (s[i]==t[i]){
            if (!fg)
                continue;
            res.push_back('#');
            res.push_back('#');
        } else{
            fg = 1;
            res.push_back(s[i]);
            res.push_back(t[i]);
        }
    }

    while (res.back() == '#')
        res.pop_back();
    
    return res;
}

bool check(std::string s, std::string t){
    for (int i=0; i<s.length(); ++i){
        for (int j=0; j<t.length(); ++j){
            if (s[i+j] != t[j])
                goto brk;
        }
        return true;
        brk:;
    }
    return false;
}

int c[5000006];

void add(int p, int x, int n){
    ++p;

    for (; p<=n; p+=lowbit(p))
        c[p] += x;
    
    return;
}

int query(int p){
    ++p;

    int res = 0;

    for (; p; p-=lowbit(p))
        res += c[p];

    return res;
}

int res[200005];

int main(){
    freopen("replace.in" , "r", stdin );
    freopen("replace.out", "w", stdout);

    int n, q;
    scanf("%d %d", &n, &q);

    std::map<int, int> id;

    int m = 0;

    for (int i=1; i<=n; ++i){
        std::string s, t;

        scanf("%s", tmp);
        s = tmp;

        scanf("%s", tmp);
        t = tmp;

        node x = solve(s, t);

        if (!id[x.d])
            id[x.d] = ++m;
        
        a[id[x.d]].push_back(x);
        // fprintf(stderr, "%d: %lld\n", id[x.d], a[id[x.d]].size());

        if (q <= 100){
            re[i] = replace(s, t);
            st[i] = s;
        }


    }

    for (int i=1; i<=m; ++i)
        std::sort(a[i].begin(), a[i].end());
    
    for (int i=1; i<=q; ++i){
        std::string s, t;

        scanf("%s", tmp);
        s = tmp;

        scanf("%s", tmp);
        t = tmp;

        if (s.length() != t.length())
            continue;

        node x = solve(s, t);

        if (!id[x.d])
            id[x.d] = ++m;
        
        b[id[x.d]].push_back({i, x.l, x.r});

        if (q <= 100){
            std::string r = replace(s, t);

            for (int j=1; j<=n; ++j)
                if (re[j]==r && check(s, st[j]))
                    ++res[i];

        }
        
    }

    for (int i=1; i<=m; ++i)
        std::sort(b[i].begin(), b[i].end());

    if (q <= 100){
        for (int i=1; i<=q; ++i)
            printf("%d\n", res[i]);

        return 0;
    }

    for (int i=1; i<=m; ++i){//fprintf(stderr, "%d: %lld %lld\n", i, a[i].size(), b[i].size());
        int j = -1;
        for (auto x:b[i]){
            while (j+1<a[i].size() && a[i][j+1].l<=x.l){
                add(a[i][j+1].r, 1, L);
                ++j;
            }
            res[x.d] = query(x.r);
        }
        for (int k=0; k<=j; ++k)
            add(a[i][k].r, -1, L);
    }

    for (int i=1; i<=q; ++i)
        printf("%d\n", res[i]);

    return 0;
}