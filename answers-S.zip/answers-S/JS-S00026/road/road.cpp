#include <cstdio>
#include <algorithm>

#define lowbit(x) ((x) & -(x))

#define INF 0x3f3f3f3f3f3f3f3fll

struct edge{
    int u, v, w;

    friend bool operator<(edge a, edge b){
        return a.w < b.w;
    }

} e[2000006], t[2000006];

int a[20][10004];

long long res[2000];
int fg[2000];

int f[20004];

int getf(int p){
    return f[p] = (f[p]==p ? p : getf(f[p]));
}

int merge(int u, int v, int w){
    int a = getf(u),
        b = getf(v);
    
    if (a == b)
        return 0;
    
    f[a] = b;

    return w;
}

long long kruskal(int n, int m){
    for (int i=1; i<=n; ++i)
        f[i] = i;
    
    std::sort(t+1, t+m+1);

    long long res = 0;

    for (int i=1; i<=m; ++i)
        res += merge(t[i].u, t[i].v, t[i].w);
    
    return res;
}

int main(){
    freopen("road.in" , "r", stdin );
    freopen("road.out", "w", stdout);

    int n, m, k;
    scanf("%d %d %d", &n, &m, &k);

    for (int i=1; i<=m; ++i){
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);
        e[i] = {u, v, w};
    }

    int flag = 1;

    for (int i=1; i<=k; ++i){
        scanf("%d", a[i]+0);
        flag &= (a[i][0]==0);
        int tfg = 0;
        for (int j=1; j<=n; ++j){
            scanf("%d", a[i]+j);
            tfg |= (a[i][j]==0);
        }
        flag &= tfg;
    }

    long long ans = INF;

    if (flag){

        long long res = 0;
            
        int cnt = 0;

        for (int i=1; i<=m; ++i)
            t[++cnt] = e[i];

        for (int i=1; i<=k; ++i){
            for (int j=1; j<=n; ++j)
                t[++cnt] = {n+i, j, a[i][j]};
        }

        res += kruskal(n+k, cnt);

        ans = std::min(ans, res);

    } else{
        for (int s=0; s<(1<<k); ++s){
            if (fg[s-lowbit(s)]){
                fg[s] = 1;
                continue;
            }
            
            int cnt = 0;

            for (int i=1; i<=m; ++i)
                t[++cnt] = e[i];

            for (int i=1; i<=k; ++i){
                if (!(s & (1<<i-1)))
                    continue;
                res[s] += a[i][0];
                for (int j=1; j<=n; ++j)
                    t[++cnt] = {n+i, j, a[i][j]};
            }

            res[s] += kruskal(n+k, cnt);

            if (res[s] > res[s-lowbit(s)])
                fg[s] = 1;

            ans = std::min(ans, res[s]);

        }
    }

    printf("%lld\n", ans);

    return 0;
}