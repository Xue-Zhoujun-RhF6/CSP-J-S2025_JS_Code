#include <cstdio>
#include <algorithm>

#define P 998244353

char s[1000];
int c[1000];

int sum[1000];

long long fact[1000];

int a[1000];

int main(){
    freopen("employ.in" , "r", stdin );
    freopen("employ.out", "w", stdout);

    int n, m;
    scanf("%d %d", &n, &m);

    scanf("%s", s+1);
    
    for (int i=1; i<=n; ++i)
        scanf("%d", c+i);
    
    fact[0] = 1;
    
    for (int i=1; i<=n; ++i)
        fact[i] = fact[i-1]*i % P;
    
    if (m == n){
        int fg = 0;

        for (int i=1; i<=n; ++i)
            fg |= (c[i]==0);
        
        for (int i=1; i<=n; ++i)
            fg |= (s[i]=='0');

        printf("%d\n", fg ? 0: (int)fact[n]);

    } else{
        for (int i=1; i<=n; ++i)
            a[i] = i;
        
        int res = 0;
        
        do {
            int cnt = 0;
            for (int i=1; i<=n; ++i){
                if (c[a[i]] <= cnt){
                    ++cnt;
                    continue;
                }
                if (s[i] == '0'){
                    ++cnt;
                }
            }
            if (n-cnt >= m)
                ++res;
        } while (std::next_permutation(a+1, a+n+1));

        printf("%d\n", res);

    }

    return 0;
}