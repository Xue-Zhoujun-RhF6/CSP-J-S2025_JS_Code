#include <cstdio>
#include <vector>
#include <algorithm>

int a[3][100005], f[100005];

int solve(int n){
    int res = 0;

    int cnt[3] = {0, 0, 0};

    for (int i=1; i<=n; ++i){
        scanf("%d %d %d", a[0]+i, a[1]+i, a[2]+i);
        int mx = std::max({a[0][i], a[1][i], a[2][i]});
        res += mx;
        if (mx == a[0][i])
            ++cnt[0], f[i] = 0;
        else if (mx == a[1][i])
            ++cnt[1], f[i] = 1;
        else if (mx == a[2][i])
            ++cnt[2], f[i] = 2;
    }

    int t = -1;

    if (cnt[0] > n/2)
        t = 0;
    
    if (cnt[1] > n/2)
        t = 1;
    
    if (cnt[2] > n/2)
        t = 2;
    
    if (~t){
        std::vector<int> dif;

        for (int i=1; i<=n; ++i){
            if (f[i] != t)
                continue;
            int mx = 0;
            for (int j=0; j<3; ++j)
                if (j != t)
                    mx = std::max(mx, a[j][i]);
            dif.push_back(std::max({a[0][i], a[1][i], a[2][i]})-mx);
        }

        std::sort(dif.begin(), dif.end());

        for (int i=n/2+1; i<=cnt[t]; ++i)
            res -= dif[i-(n/2+1)];
        
    }

    return res;
}

int main(){
    freopen("club.in" , "r", stdin );
    freopen("club.out", "w", stdout);

    int t;
    scanf("%d", &t);

    while (t--){
        int n;
        scanf("%d", &n);

        printf("%d\n", solve(n));

    }

    return 0;
}