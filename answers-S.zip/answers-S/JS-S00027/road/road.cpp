#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main() {
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    cout << "0\n";
    return 0;
}
