#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 10;
int t;
struct num{
    int t1, t2, t3, maxn, maxb;
    bool x;
}a[N];
bool cmp(num a, num b) {
    if (a.maxb == b.maxb)
        return a.maxn > b.maxn;
    return a.maxb < b.maxb;
}
signed main() {
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    cin >> t;
    while(t--) {
        int n;
        cin >> n;
        int s1, s2, s3, ans;
        ans = s1 = s2 = s3 = 0;
        for (int i = 1; i <= n; i++) {
            cin >> a[i].t1 >> a[i].t2 >> a[i].t3;
            a[i].x = false;
            if (a[i].t1 > a[i].t2 && a[i].t1 > a[i].t3) {
                a[i].maxn = a[i].t1;
                a[i].maxb = 1;
                s1++;
            }
            if (a[i].t2 > a[i].t1 && a[i].t2 > a[i].t3) {
                a[i].maxn = a[i].t2;
                a[i].maxb = 2;
                s2++;
            }
            if (a[i].t3 > a[i].t2 && a[i].t3 > a[i].t1) {
                a[i].maxn = a[i].t3;
                a[i].maxb = 3;
                s3++;
            }
        }
        sort(a + 1, a + 1 + n, cmp);
        if (s1 <= n / 2 && s2 <= n / 2 && s3 <= n / 2) {
            for (int i = 1; i <= n; i++) {
                ans += a[i].maxn;
            }
        }
        else if (s1 > n / 2 && s2 <= n / 2 && s3 <= n / 2) {
            for (int i = 1; i <= n / 2; i++) {
                ans += a[i].maxn;
            }
            for (int i = s1 + 1; i <= n; i++) {
                ans += a[i].maxn;
            }
        }
        else if (s1 <= n / 2 && s2 > n / 2 && s3 <= n / 2) {
            for (int i = 1; i <= s1; i++) {
                ans += a[i].maxn;
            }
            for (int i = s1 + 1; i <= n / 2; i++) {
                ans += a[i].maxn;
            }
            for (int i = s2 + 1; i <= n; i++) {
                ans += a[i].maxn;
            }
        }
        else if (s1 <= n / 2 && s2 <= n / 2 && s3 > n / 2) {
            for (int i = 1; i <= s2; i++) {
                ans += a[i].maxn;
            }
            for (int i = s2 + 1; i <= n / 2; i++) {
                ans += a[i].maxn;
            }
        }
        cout << ans << endl;
    }
    return 0;
}
