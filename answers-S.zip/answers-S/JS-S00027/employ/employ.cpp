#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N = 5e2 + 10, M = 998244353;
int c[N];
signed main() {
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    int n, m;
    string s;
    cin >> n >> m;
    cin >> s;
    if (m == 0) {
        cout << "0\n";
        return 0;
    }
    bool f = false;
    for (int i = 1; i <= n; i++) {
        cin >> c[i];
        if (c[i] != 0)
            f = true;
    }
    if (f == false) {
        cout << "0\n";
        return 0;
    }
    for (int i = 0; i < s.size(); i++) {
        if (s[i] != 0) {
            f = false;
        }
    }
    if (f == true) {
        cout << "0\n";
        return 0;
    }
    int sum = 0;
    for (int i = 0; i < s.size(); i++) {
        if (s[i] == 0) {
            sum++;
        }
    }
    int ans = 1;
    for (int i = 1; i <= n - ans; i++) {
        ans = ans * i;
    }
    cout << ans % M << endl;
    return 0;
}
