#include<iostream>
#include<algorithm>
using namespace std;
int t,n,a[100005][4];
int dfs(int now,int k,int a1,int b1,int c1)
{
    if(now==n+1) return 0;
    int ans=-1;
    if(a1) ans=max(dfs(now+1,1,a1-1,b1,c1)+a[k][now],ans);
    if(b1) ans=max(dfs(now+1,2,a1,b1-1,c1)+a[k][now],ans);
    if(c1) ans=max(dfs(now+1,3,a1,b1,c1-1)+a[k][now],ans);
    return ans;
}
struct node
{
    int p,ca;
}b[100005];
bool cmp(node x,node y)
{
    if(x.ca==y.ca)
    {
        return max(a[1][x.p],a[2][x.p])<=max(a[1][y.p],a[2][y.p]);
    }
    return x.ca<=y.ca;
}

int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--)
    {
        int ans=0,shi1=0,shi2=0;
        cin>>n;
        for(int i=1;i<=n;i++)
        {
            cin>>a[1][i]>>a[2][i]>>a[3][i];
            if(!a[2][i]) shi1++;
            if(!a[3][i]) shi2++;
        }
        if(n<=10)
        {
            cout<<dfs(0,0,n/2,n/2,n/2)<<endl;
        }
        if(shi1==n&&shi2==n)
        {
            sort(a[1]+1,a[1]+1+n);
            for(int i=n;i>n/2;i--)
                ans+=a[1][i];
            cout<<ans<<endl;
        }
        else if(shi2==n)
        {
            for(int i=1;i<=n;i++)
            {
                b[i].p=i;
                b[i].ca=a[1][i]-a[2][i];
            }
            sort(b+1,b+n+1,cmp);
            for(int i=1;i<=n/2;i++) ans+=a[2][b[i].p];
            for(int i=n;i>n/2;i--) ans+=a[1][b[i].p];
            cout<<ans<<endl;
        }
    }
    return 0;
}
