#include<bits/stdc++.h>
using namespace std;
int n,m,c[550];
char s[550];
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdin);
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++)
    {
        cin>>c[i];
    }
    sort(c+1,c+n+1);
    int ans=1;
    for(int i=1;i<=n;i++)
    {
        ans=i*ans;
    }
    cout<<ans;
    return 0;
}
