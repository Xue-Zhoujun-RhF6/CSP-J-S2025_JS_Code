#include<bits/stdc++.h>
using namespace std;
int u[1000005],v[1000005],va[1000005],Nxt[1000005],head[1000005],tot=0;
int d[1000005],n,m,k,c[100005],a[12][100005];
void add(int x,int y,int w)
{
    u[++tot]=x;v[tot]=y;va[tot]=w;
    Nxt[tot]=head[x],head[x]=tot;
}
void solve(int x)
{
    for(int i=head[x];i;i=Nxt[i])
    {
        int y=v[i];
        if(d[y]+va[i]>d[x])
        {
            d[x]=d[y]+va[i];
        }
    }
}
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++)
    {
        int x,y,w;
        cin>>x>>y>>w;
        add(x,y,w);
        add(y,x,w);
    }

    for(int i=1;i<=k;i++)
    {
        cin>>c[i];
        for(int j=1;j<=n;j++)
        {
             cin>>a[i][j];
             add(i,j,0);
             add(j,i,0);
        }
    }
    for(int i=1;i<=k;i++)
    {
        for(int j=1;j<=m;j++)
        {
            if(u[j]==i) va[j]==0;
            if(v[j]==i) va[j]==0;
        }
    }
    solve(1);
    cout<<0;
    return 0;
}
