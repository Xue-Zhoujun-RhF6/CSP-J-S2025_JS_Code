#include<bits/stdc++.h>
using namespace std;
int dp[100005][7];
struct node {
   int a,b,c;
}member[200005];
int cnt[4],n,m,t,ans;
void solve(int x)
{
    if(x==n+1) return;
    if(cnt[1]<m)
    {
        dp[x][1]=max(dp[x-1][1]+member[x].a,max(dp[x-1][2]+member[x].a,max(dp[x-1][3]+member[x].a,max(dp[x-1][4]+member[x].a,max(dp[x-1][5]+member[x].a,dp[x-1][6]+member[x].a)))));
        cnt[1]++;
        solve(x+1);
        dp[x][2]=max(dp[x-1][1],max(dp[x-1][2],max(dp[x-1][3],max(dp[x-1][4],max(dp[x-1][5],dp[x-1][6])))));
        cnt[1]--;
    }
    if(cnt[2]<m)
    {
        dp[x][3]=max(dp[x-1][1]+member[x].b,max(dp[x-1][2]+member[x].b,max(dp[x-1][3]+member[x].b,max(dp[x-1][4]+member[x].b,max(dp[x-1][5]+member[x].b,dp[x-1][6]+member[x].b)))));
        cnt[2]++;
        solve(x+1);
        dp[x][4]=max(dp[x-1][1],max(dp[x-1][2],max(dp[x-1][3],max(dp[x-1][4],max(dp[x-1][5],dp[x-1][6])))));
        cnt[2]--;
    }
    if(cnt[3]<m)
    {
        dp[x][5]=max(dp[x-1][1]+member[x].c,max(dp[x-1][2]+member[x].c,max(dp[x-1][3]+member[x].c,max(dp[x-1][4]+member[x].c,max(dp[x-1][5]+member[x].c,dp[x-1][6]+member[x].c)))));
        cnt[3]++;
        solve(x+1);
        dp[x][6]=max(dp[x-1][1],max(dp[x-1][2],max(dp[x-1][3],max(dp[x-1][4],max(dp[x-1][5],dp[x-1][6])))));
        cnt[3]--;
    }
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    for(int i=1;i<=t;i++)
    {
        memset(member,0,sizeof(member));
        memset(dp,0,sizeof(dp));
        ans=0;
        cin>>n;
        for(int j=1;j<=n;j++)
        {
            cin>>member[j].a>>member[j].b>>member[j].c;
        }
        m=n>>1;
        solve(1);
        ans=max(ans,max(dp[n][1],max(dp[n][3],dp[n][5])));
        cout<<ans<<endl;
    }
    return 0;
}
