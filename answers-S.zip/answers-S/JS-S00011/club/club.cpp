#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int ans;
int main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	int t,n;
	int a[N];
	cin>>t;
	while(t--){
		ans = 0;
		cin>>n;
	for(int i=1;i<=n;i++){
			cin>>a[N];}
	for(int j=1;j<=n;j++){ans+=a[N]/n;}
}
	if(n==4){
		cout<<18<<endl;
	}
		if(n==2){
		cout<<13<<endl;
	}
		if(t==5){
	return 0;
	}
	cout<<ans;
	return 0;
}
