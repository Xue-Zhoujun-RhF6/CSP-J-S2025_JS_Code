#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn = 2e6 + 10;
int n,k,m,fa[maxn],a[12][maxn],c[maxn];
int head[maxn],tot,dep[maxn],f[maxn][33],sum[maxn],ans;
struct node
{
    int v,w,nxt;
}e[maxn << 1];
void add(int u,int v,int w)
{
    e[++tot].v = v;
    e[tot].nxt = head[u];
    e[tot].w = w;
    head[u] = tot;
    return ;
}
int find(int x)
{
    while(fa[x] != fa[fa[x]])
    {
        fa[x] = fa[fa[x]];
    }
    return fa[x];
}
struct node1
{
    int u,v,w;
}g[maxn];
bool cmp (node1 x,node1 y)
{
    return x.w < y.w;
}
void kru(int s)
{
    int cnt1 = 0;
    sort(g + 1,g + s + 1,cmp);
    for(int i = 1;i <= s;i++)
    {
        int x = g[i].u,y = g[i].v,z = g[i].w;
        int fx = find(x),fy = find(y);
        if(fx != fy && cnt1 < s)
        {
            cnt1++;
            ans += z;
            add(x,y,z);
            add(y,x,z);
            fa[fx] = fy;
        }
    }
}
/*void kru1(int s)
{
    int cnt1 = 0;
    vector<int>ve;
    sort(g + 1,g + s + 1,cmp);
    for(int i = 1;i <= s && ve.size() < n;i++)
    {
        int x = g[i].u,y = g[i].v,z = g[i].w;
        int fx = find(x),fy = find(y);
        if(fx != fy)
        {
            if(x <= n)
            {
                ve.push_back(x);
            }
            if(y <= n)
            {
                ve.push_back(y);
            }
            ans += z;
            fa[fx] = fy;
        }
    }
}*/
void dfs(int u,int fa)
{
    dep[u] = dep[fa] + 1,f[u][0] = fa;
    for(int i = 1;i <= 30;i++)
    {
        f[u][i] = f[f[u][i - 1]][i - 1];
    }
    for(int i = head[u];i;i = e[i].nxt)
    {
        int v = e[i].v,w = e[i].w;
        if(v == fa)
            continue;
        sum[v] = sum[u] + w;
        dfs(v,u);
    }
    return ;
}
int lca(int x,int y)
{
    if(dep[x] < dep[y])
        swap(x,y);
    for(int i = 30;i >= 0;i--)
    {
        if(dep[f[x][i]] >= dep[y])
        {
            x = f[x][i];
        }
    }
    if(x == y)
        return x;
    for(int i = 30;i >= 0;i--)
    {
        if(f[x][i] != f[y][i])
        {
            x = f[x][i],y = f[y][i];
        }
    }   
    return f[x][0];
}
signed main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    cin >> n >> m >> k;
    for(int i = 1;i <= m;i++)
    {
        cin >> g[i].u >> g[i].v >> g[i].w;
    }
    for(int i = 1;i <= n + k;i++)
    {
        fa[i] = i;
    }
    if(k == 0)
    {
        kru(m);
        cout << ans << endl;
        return 0;
    }
    bool flag = 0;
    int cnt = m,idx = n;
    //dfs(1,0);
    for(int i = 1;i <= k;i++)
    {
        cin >> c[i];
        if(c[i] != 0)
        {
            flag = 1;
        }
        for(int j = 1;j <= n;j++)
        {
            cin >> a[i][j];
            g[++cnt].u = ++idx;
            g[cnt].v = j;
            g[cnt].w = a[i][j];
        }
    }
    if(!flag)
    {
        ans = 0;
        kru(cnt);
        cout << ans << endl;
    }
    return 0;
}