#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn = 1e5 + 10;
int n,q;
string s1[maxn],t1[maxn],s2[maxn],t2[maxn];
signed main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    cin >> n >> q;
    for(int i = 1;i <= n;i++)
    {
        cin >> s1[i] >> s2[i];
    }
    for(int i = 1;i <= q;i++)
    {
        int ans = 0;
        cin >> t1[i] >> t2[i];
        int k = 0,k1 = t1[i].size() - 1;
        while(t1[i][k] == t2[i][k])
        {
            k++;
        }
        while(t1[i][k1] == t1[i][k1])
        {
            k1--;
        }
        for(int j = 1;j <= n;j++)
        {
            int x,x1;
            x = t1[i].find(s1[j]);
            x1 = t1[i].find(s1[j],k);
            string a;
            if(x <= 1e15 && x1 <= 1e15)
            {
                a.replace(x1,x1 + s1[j].size(),s2[j]);
                if(a == t2[i])
                {
                    ans ++;
                }
            }
            else if(x <= 1e15 && x1 >= 1e15)
            {
                a.replace(x,x + s1[j].size(),s2[j]);
                if(a == t2[i])
                {
                    ans ++;
                }
            }
        }
        cout << ans << "\n";
    }
    return 0;
}