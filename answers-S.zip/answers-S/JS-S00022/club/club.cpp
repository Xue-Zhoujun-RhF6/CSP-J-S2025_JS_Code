#include <bits/stdc++.h>
#define int long long
using namespace std;
const int maxn = 1e5 + 10;
int T,a[maxn][3],n;
bool vis[maxn];
vector<int> cnt[3];
signed main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0);
    cout.tie(0),cin.tie(0);
    cin >> T;
    while(T--)
    {
        int sum = 0,lim,num;
        cin >> n;
        memset(vis,0,sizeof(vis));
        vector<pair<int,int> > v;
        memset(cnt,0,sizeof(cnt));
        lim = n / 2;
        for(int i = 1;i <= n;i++)
        {
            int max1 = -1,id;
            for(int j = 0;j < 3;j++)
            {
                cin >> a[i][j];
                if(max1 < a[i][j])
                {
                    id = j;
                    max1 = a[i][j];
                }
            }
            cnt[id].push_back(i);
            sum += max1;
        }
        for(int i = 0;i < 3;i++)
        {
            if(cnt[i].size() > lim)
            {
                num = cnt[i].size() - lim;
                for(auto j : cnt[i])
                {
                    for(int k = 0;k < 3;k++)
                    {
                        if(k != i)
                        {
                            v.push_back(make_pair(a[j][i] - a[j][k],j));
                        }
                    }
                }
            }
        }
        sort(v.begin(),v.end());
        int top = 0;
        for(int i = 0;i < v.size() && top < num;i++)
        {
            int id = v[i].second,cost = v[i].first;
            if(!vis[id])
            {
                vis[id] = 1;
                sum -= cost;
                top++;
            }
        }
        cout << sum << "\n";
    }
    return 0;
}