#include<bits/stdc++.h>
#define LL long long
using namespace std;

const int N = 100005;
LL a[N],b[N],c[N];
LL max1[N],max2[N],cha[N],maap[N] = {-1},js[N];

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    //freopen("club.in","r",stdin);
    //freopen("club.out","w",stdout);
    int n,t,w;
    cin >> t;
    while(t--){
        int sum;
        memset(a,0,sizeof(a));
        memset(b,0,sizeof(b));
        memset(c,0,sizeof(c));
        cin >> n;
        w = n / 2;
        for(int i=1; i<=n; i++){
            cin >> a[i] >> b[i] >> c[i];
            if(a[i] >= b[i] && a[i] >= c[i]){
                max1[i] = a[i];
                if(b[i] >= c[i]) max2[i] = b[i];
                else max2[i] = c[i];
            }
            else if(b[i] >= c[i] && b[i] >= a[i]){
                max1[i] = b[i];
                if(a[i] >= c[i]) max2[i] = a[i];
                else max2[i] = c[i];
            }
            else if(c[i] >= b[i] && c[i] >= a[i]){
                max1[i] = c[i];
                if(a[i] >= b[i]) max2[i] = a[i];
                else max2[i] = b[i];
            }
            cha[i] = max1[i] - max2[i];
            if(maap[cha[i]] == -1) maap[cha[i]] = i;
            else js[cha[i]]++; // you js[cha[i]]+1 ge cha[i] shiyiyangde
        }
        sort(1,cha+n+1);
        for(int i=1; i<=w; i++){
            if(js[cha[i]] == 0) sum += max1[maap[cha[i]]];
            else{
                while(js[cha[i]] && i <= w){
                    sum += max1[maap[cha[i]]];
                    js[cha[i]]--;
                    i++;
                }
            }
        }
        for(int i=w+1; i<=n; i++){
            if(js[cha[i]] == 0) sum += max2[maap[cha[i]]];
            else{
                while(js[cha[i]] && i <= n){
                    sum += max2[maap[cha[i]]];
                    js[cha[i]]--;
                    i++;
                }
            }
        }
        cout << sum << "\n";
    }



    return 0;
}