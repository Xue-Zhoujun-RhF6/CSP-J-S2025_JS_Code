#include<bits/stdc++.h>
#define ll long long
#define endl "\n"
#define fi first
#define se second
using namespace std;
struct node{
	int a[3];
	void input(){
		cin >> a[0] >> a[1] >> a[2];
	}
	bool operator <(const node &Node){
		return a[0]-a[1]==Node.a[0]-Node.a[1]?a[0]==Node.a[0]:a[0]-a[1]>Node.a[0]-Node.a[1];
	}
}a[100005];
int dp[101][101][101][101];
int main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	int t; cin >> t;
	while(t--){
		int n; cin >> n;
		for(int i = 1;i <= n;i++){
			a[i].input();
		}
		int ans = 0;
		if(n<=100){
			for(int i = 1;i <= n;i++){
				for(int j1 = 0;j1 <= min(i,n/2);j1++){
					for(int j2 = 0;j2 <= n/2&&j2<=i-j1;j2++){
						int j3 = i-j1-j2;
						if(j3>n/2)	continue;
						dp[i][j1][j2][j3]=0;
						//cout << j1 << " " << j2 << " " << j3 << endl;
						if(j1>0)	dp[i][j1][j2][j3]=max(dp[i][j1][j2][j3],dp[i-1][j1-1][j2][j3]+a[i].a[0]);
						if(j2>0)	dp[i][j1][j2][j3]=max(dp[i][j1][j2][j3],dp[i-1][j1][j2-1][j3]+a[i].a[1]);
						if(j3>0)	dp[i][j1][j2][j3]=max(dp[i][j1][j2][j3],dp[i-1][j1][j2][j3-1]+a[i].a[2]);
					}
				}
			}
			for(int i = n;i <= n;i++){
				for(int j1 = 0;j1 <= min(i,n/2);j1++){
					for(int j2 = 0;j2 <= n/2&&j2<=i-j1;j2++){
						int j3 = i-j1-j2;
						ans=max(ans,dp[i][j1][j2][j3]);
					}
				}
			}
		}
		else{
			sort(a+1,a+n+1);
			for(int i = 1;i <= n/2;i++)	ans+=a[i].a[0];
			for(int i = 1;i <= n/2;i++)	ans+=a[n-i+1].a[1];
		}
		cout << ans << endl;
	}
	return 0;
}
