#include<bits/stdc++.h>
#define ll long long
#define endl "\n"
#define fi first
#define se second
using namespace std;
map<string,int>mp;
map<int,int>cn;
int main(){
	freopen("replace.in","r",stdin);
	freopen("replace.out","w",stdout);
	int n,q; cin >> n >> q;
	bool f = true;
	while(n--){
		string s1,s2; cin >> s1 >> s2;
		mp[s1+s2]++;
		int b1=-1,b2=-1;
		for(int i = 0;i < s1.size();i++){
			if(s1[i]>'b'||s2[i]>'b')	f = false;
			else{
				if(s1[i]=='b'){
					if(b1==-1){
						b1 = i;
					}
					else{
						f = false;
					}
				}
				if(s2[i]=='b'){
					if(b2==-1){
						b2 = i;
					}
					else{
						f = false;
					}
				}
			}
		}
		if(b1<0||b2<0)	f = false;
		if(f)	cn[b2-b1]++;
	}
	while(q--){
		string s1,s2; cin >> s1 >> s2;
		if(f){
			int b1=-1,b2=-1;
			for(int i = 0;i < s1.size();i++){
				if(s1[i]>'b'||s2[i]>'b')	f = false;
				else{
					if(s1[i]=='b'){
						if(b1==-1){
							b1 = i;
						}
						else{
							f = false;
						}
					}
					if(s2[i]=='b'){
						if(b2==-1){
							b2 = i;
						}
						else{
							f = false;
						}
					}
				}
			}
			if(b1<0||b2<0)	f = false;
			if(f)	cout << cn[b2-b1] << endl;
		}
		if(!f){
			int cnt = 0;
			for(int len = s1.size();len >= 1;len--){
				for(int i = 0;i+len-1 < s1.size();i++){
					if(s1.substr(0,i) == s2.substr(0,i) && s1.substr(i+len,s1.size()-i-len) == s2.substr(i+len,s1.size()-i-len)){
						cnt+=mp[s1.substr(i,len)+s2.substr(i,len)];
					}
				}
			}cout << cnt << endl;
		}
		
	}
	return 0;
}