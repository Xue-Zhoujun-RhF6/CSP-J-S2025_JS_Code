#include<bits/stdc++.h>
#define ll long long
#define endl "\n"
#define fi first
#define se second
using namespace std;
int p[10015],n,k,a[11][10005];
struct node{
	int u,v;
	ll val;
	bool operator<(const node &Node){
		return val<Node.val;
	}
};
void init(){
	for(int i = 1;i <= n+k;i++)	p[i]=i;
}
int find(int x){
	if(p[x]==x)	return x;
	return p[x]=find(p[x]);
}
void merge(int a,int b){
	int ra = find(a),rb = find(b);
	if(ra!=rb)	p[rb]=ra;
}
bool judge(int a,int b){
	return find(a)==find(b);
}
ll slove(vector<node>&G,int cn){
	sort(G.begin(),G.end());
	ll cnt = 0,ans = 0;
	for(auto x : G){
		int u = x.u,v = x.v;
		if(!judge(u,v)){
			//cout << u << " " << v << endl;
			merge(u,v);
			ans+=x.val,cnt++;
		}
		if(cnt>=cn-1)	break;
	}
	return ans;
}
vector<node>G;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int m; cin >> n >> m >> k;
	while(m--){
		int x,y;
		ll z; cin >> x >> y >> z;
		G.push_back({x,y,z});
	}
	for(int i = 0;i < k;i++){
		for(int j = 0;j <= n;j++){
			cin >> a[i][j];
		}
	}
	ll mn = 1e18;
	for(int s = 0;s < (1<<k);s++){
		auto g = G;
		ll ans = 0;
		int cn = n;
		for(int i = 0;i < k;i++){
			if((s>>i)&1){
				for(int j = 1;j <= n;j++)	g.push_back({i+n+1,j,a[i][j]});
				ans+=a[i][0],cn++;
			}
		}
		init();
		ans+=slove(g,cn);
		//cout << s << " " << ans << endl;
		mn = min(mn,ans);
	}
	cout << mn;
	return 0;
}