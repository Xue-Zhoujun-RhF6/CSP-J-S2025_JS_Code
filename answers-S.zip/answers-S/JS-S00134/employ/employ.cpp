#include<bits/stdc++.h>
#define ll long long
#define endl "\n"
#define fi first
#define se second
using namespace std;

int main(){
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	int a,b; cin >> a >> b;
	if(a+100<b)cout << a+b;
	else	cout << 1145;
	return 0;
}