#include <bits/stdc++.h>
using namespace std;

int n, q;
string mp[200005][2];

int main(){
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    scanf("%d%d", &n, &q);
    for(int i=0; i<n; i++){
        cin >> mp[i][0] >> mp[i][1];
    }
    while(q--){
        string a, b;
        cin >> a >> b;
        int s=0;
        for(int i=0; i<n; i++){
            int j=a.find(mp[i][0]);
            while(j!=-1){
                if(a.substr(0, j)+mp[i][1]+a.substr(j+mp[i][0].size())==b) s++;
                j = a.find(mp[i][0], j+1);
            }
        }
        printf("%d\n", s);
    }
    return 0;
}
