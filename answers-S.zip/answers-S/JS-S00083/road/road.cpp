#include <bits/stdc++.h>
using namespace std;

int n, m, k, c[15];
vector<pair<int,int> > edge[10020];
bool f[10020];

priority_queue<pair<int,int>, vector<pair<int, int> >, greater<pair<int,int> > > pq;

void ins(int p){
    //printf("insert(%d)\n", p);
    for(int i=0; i<edge[p].size(); i++){
        if(!f[edge[p][i].first]){
            pq.push({edge[p][i].second, edge[p][i].first});
        }
    }
}

long long cal(){ //"minimum spawn tree"
    long long ret=0;
    ins(1); f[1] = true;
    while(!pq.empty()){
        while(!pq.empty() && f[pq.top().second]) pq.pop();
        if(pq.empty()) break;
        int p=pq.top().second, v=pq.top().first;
        ret += v;
        pq.pop();
        ins(p); f[p] = true;
    }
    //printf("ret=%lld\n", ret);
    return ret;
}

void solve(){
    long long ans=(1ll<<60), s=0;
    for(int d=0; d<(1<<k); d++){
        s = 0;
        //printf("try:%d\n", d);
        memset(f, 0, sizeof(f));
        int tmp=d;
        for(int i=0; i<k; i++){
            f[n+i+1] = (d>>i)&1;
            if(!f[n+i+1]) s += c[i];
        }
        ans = min(ans, cal()+s);
    }
    printf("%lld\n", ans);
}

int main(){
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &k);
    for(int i=0; i<m; i++){
        int u, v, w;
        scanf("%d%d%d", &u, &v, &w);
        edge[u].push_back({v, w});
        edge[v].push_back({u, w});
    }
    for(int i=0; i<k; i++){
        scanf("%d", c+i);
        for(int j=1; j<=n; j++){
            int w;
            scanf("%d", &w);
            edge[j].push_back({n+i+1, w});
            edge[n+i+1].push_back({j, w});
        }
    }
    solve();
    return 0;
}
