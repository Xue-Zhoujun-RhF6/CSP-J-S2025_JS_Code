#include <bits/stdc++.h>
using namespace std;

int n, m;
int s[50], c[50], per[50];

const int mod=998244353;

int main(){
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for(int i=0; i<n; i++){
        char c;
        cin >> c;
        s[i] = c-'0';
    }
    for(int i=0; i<n; i++){
        per[i] = i;
        scanf("%d", c+i);
    }
    int ans=0, now;
    do{
        now = 0;
        for(int i=0; i<n; i++){
            if(c[per[i]]<=now || s[i]==0){
                now++;
            }
        }
        if(n-now>=m) ans = (ans+1)%mod;
    }while(next_permutation(per, per+n));
    printf("%d\n", ans);
    return 0;
}
