#include <bits/stdc++.h>
using namespace std;

int d[100005][3], n, sel[100005];

int main(){
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    int t;
    scanf("%d", &t);
    while(t--){
        int cnt[3]={};
        vector<int> ch[3];
        int ans = 0;
        scanf("%d", &n);
        for(int i=0; i<n; i++){
            int maxv=-1, p=-1, minv=10000000;
            for(int j=0; j<3; j++){
                scanf("%d", &d[i][j]);
                if(d[i][j]>=maxv){
                    p = j;
                    maxv = d[i][j];
                }
            }
            for(int j=0; j<3; j++)
                if(j!=p) minv = min(minv, maxv-d[i][j]);
            //printf("i=%d, select=%d, maxv=%d, minv=%d\n", i, p, maxv, minv);
            ch[p].push_back(minv);
            sel[i] = p;
            cnt[p]++;
            ans += maxv;
        }
        for(int i=0; i<3; i++){
            if(cnt[i]>n/2){
                sort(ch[i].begin(), ch[i].end());
                for(int j=0; j<cnt[i]-n/2; j++)
                    ans -= ch[i][j];
                break;
            }
        }
        printf("%d\n", ans);
    }
    return 0;
}
