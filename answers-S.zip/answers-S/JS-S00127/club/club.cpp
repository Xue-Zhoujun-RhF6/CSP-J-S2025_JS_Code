#include <bits/stdc++.h>
using namespace std;
int t,n;
int a[100005],c[3];
int mx=0,mn=0;
int main(){
	freopen("club.in","r",stdin);
	cin>>t;
	int s[t];
	while(t>0){
		int b=0;
		cin>>n;
		while(n>0){
			for (int i=0;i<3;i++){
				cin>>a[i];
				if(a[i]>mx) {mx=a[i]; b=i;}
				if(a[i]<mn) {mn=a[i];}
			}
			if(c[b]<=n/2) {
				s[t]+=mx;
				c[b]++;
			}
			else{
				for (int j=0;j<3;j++){
					if((j!=b)&&(a[j]>=mn)){
						s[t]+=a[j];
						c[j]++;
					}
				}
			}
			
			n--;
		}
		t--;			
	}
	for (int i=0;i<3;i++){
		cout<<s[i]<<endl;
	}
	freopen("club.out","w",stdout);
	return 0;
}
