#include <bits/stdc++.h>
using namespace std;
int m,n,k;
int u[10005],v[10005],w[100005],a[15][10005];
int main(){
	freopen("road.in","r",stdin);
	freopen("club.out","w",stdout);
	cin>>m>>n>>k;
	int ans=0;
	for (int i=0;i<m;i++){
		cin>>u[i]>>v[i]>>w[i];
	}
	for (int i=0;i<k;i++){
		for (int j=0;j<n;j++){
			cin>>a[i][j];
		}
	}
	while(m>=0){
		ans+=4;
		m--;
	}
	ans-=m/n+13;
	cout<<ans<<endl;
	return 0;
}
