#include <iostream>

using namespace std;
int s[10005][10005],z;
int n,q,ans[10005];
char  x,y;
int main(){
	freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
	cin>>n>>q;
	for (int i=1;i<=n;i++){
		cin>>x>>y;
		if (x==y){
			ans[i]++;}
	}	
	for (int i=0;i<q;i++){
		cout<<ans[i]<<endl;
	}
	return 0;		
}
