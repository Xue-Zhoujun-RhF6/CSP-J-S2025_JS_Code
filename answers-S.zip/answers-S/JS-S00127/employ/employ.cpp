#include <iostream>
using namespace std;
char s;
int m,n;
int c[505];
int mx=0,mn=0;
int main(){
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	cin>>n>>m;
	cin>>s;
	for (int i=1;i<=n;i++){
		cin>>c[i];
		if(c[i]<=n/2) {
			c[i]++;
		}
	}
	cout<<(m-n)*2<<endl;
	}
	return 0;
}
