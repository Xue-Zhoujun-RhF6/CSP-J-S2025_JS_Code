#include<bits/stdc++.h>
using namespace std;
int t,n;
struct cbd{
  int a;
  int b;
  int c;
};
cbd x[1000005],y[1000005];
int q[5],p[5];
int d1,d2,x1,x2,z1,z2;
int main(){
  freopen("club.in","r",stdin);
  freopen("club.out","w",stdout);
  cin>>t;
  while(t--){
    cin>>n;
    if(n==2){
      cin>>q[1]>>q[2]>>q[3]>>p[1]>>p[2]>>p[3];
      d1=max(q[1],max(q[2],q[3]));
      d2=max(p[1],max(p[2],p[3]));
      x1=min(q[1],min(q[2],q[3]));
      x2=min(p[1],min(p[2],p[3]));
      z1=q[1]+q[2]+q[3]-d1-x1;
      z2=p[1]+p[2]+p[3]-d2-x2;
      if((q[1]==d1&&p[1]==d2)||(q[2]==d1&&p[2]==d2)||(q[3]==d1&&p[3]==d2))cout<<max(d1+z2,d2+z1)<<endl;
      else cout<<d1+d2<<endl;
      continue;
      }
    int m;
    m=n;
    n=n/2;
    int ans=0;
    int a1=0,b1=0,c1=0;
    for(int i=1;i<=m;i++){
        cin>>x[i].a>>x[i].b>>x[i].c;
        if(max(x[i].a,max(x[i].b,x[i].c))==x[i].a){
            if(a1<n){
                a1++;
                ans+=x[i].a;
                }
            else if(x[i].b>x[i].c){
                if(b1<n){
                    b1++;
                    ans+=x[i].b;
                    }
                else {
                    c1++;
                    ans+=x[i].c;
                }
            }
        }
        else if(max(x[i].a,max(x[i].b,x[i].c))==x[i].b){
            if(b1<n){
                b1++;
                ans+=b1;
            }
            else if(x[i].a>x[i].c){
                if(a1<n){
                    a1++;
                    ans+=a1;
                }
                else{
                    c1++;
                    ans+=c1;
                }
            }
        }
        else{
            if(c1<n){
                c1++;
                ans+=x[i].c;
            }
            else if(x[i].a>x[i].b){
                if(a1<n){
                    a1++;
                    ans+=x[i].a;
                }
                else{
                    b1++;
                    ans+=x[i].b;
                }
            }
        }

    }
        //cout<<"*"<<a1<<" *"<<b1<<" *"<<c1;
        cout<<ans<<endl;

  }

  return 0;
}

