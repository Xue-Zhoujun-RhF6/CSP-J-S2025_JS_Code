#include<bits/stdc++.h>
using namespace std;
int n,m;
int c[6666666];
string a;
int s=1,s1=1;
int main(){
  freopen("employ.in","r",stdin);
  freopen("employ.out","w",stdout);
  cin>>n>>m;
  cin>>a;
  for(int i=1;i<=n;i++){
    cin>>c[i];
  }
  for(int i=m+1;i<=n;i++){
    s*=c[i];
  }
  for(int i=1;i<=m;i++){
    s1*=c[i];
  }
  cout<<s/s1%998244353<<endl;
  return 0;
}
