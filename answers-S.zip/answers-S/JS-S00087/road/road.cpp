#include<bits/stdc++.h>
using namespace std;
int n,m,k;//原有的城市数道路数和准备进行城市化改造的乡镇数
int u[666666],v[666666],w[666666];
int a[666666],b[6666666];
int main(){
  freopen("road.in","r",stdin);
  freopen("road.out","w",stdout);
  cin>>n>>m>>k;
  for(int i=1;;i++){
    cin>>u[i]>>v[i]>>w[i];//两座城市与修复该道路的费用
  }

return 0;
}
