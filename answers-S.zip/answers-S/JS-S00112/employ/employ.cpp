#include<bits/stdc++.h>
using namespace std;
int a[510],num;
int n,m,ans;
void dfs(int x){
	if(x==num){
		ans++;
		ans%=85959736;
		return ;
		}
	for(int i=1;i<=m-x+1;i++){

			dfs(x+i);
		}
		return ;
	}
int main(){
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	//---------------------------------------------------------------------------------------
	
	string s;
	cin>>n>>m;
	cin>>s;
	int l=s.size();
	for(int i=1;i<=n;i++){
	cin>>a[i];	
	}
	sort(a+1,a+l+1);
	for(int i=1;i<=n;i++){
	if(a[i]>0) num++;	
	}
	dfs(1);
	cout<<ans;
	//---------------------------------------------------------------------------------------
	fclose(stdin);
	close(stdout);
}
