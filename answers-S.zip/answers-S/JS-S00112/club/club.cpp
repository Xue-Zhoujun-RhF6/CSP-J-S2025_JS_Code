#include<bits/stdc++.h>
using namespace std;
int t,n,clubone,clubtwo,clubthree,yyd1[50010],yyd2[50010],yyd3[50010],hxp,jlrxzz,sum;
int main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	//---------------------------------------------------------------------------------------
	cin>>t;
	while(t--){
		for(int i=1;i<=50010;i++){
			yyd1[i]=0;
			yyd2[i]=0;
			yyd3[i]=0;
			}
		sum=0;
		clubone=0;
		clubthree=0;
		clubtwo=0;
		cin>>n;
		for(int i=1;i<=n;i++){
			int x,y,z;
			cin>>x>>y>>z;
			hxp=max(z,max(x,y));
			if(hxp==x&&x==y&&y==z){
				jlrxzz=min(clubone,min(clubthree,clubtwo));
				if(jlrxzz==clubone){
					clubone++;
					yyd1[i]=hxp;
					}
				else if(jlrxzz==clubtwo){
					clubtwo++;
					yyd2[i]=hxp;
					}
				else{
					clubthree++;
					yyd3[i]=hxp;
					}
				
			}
			else if(hxp==x&&x==y&&y!=z){
				if(clubone==n/2&&clubtwo==n/2){
					clubthree++;
					yyd3[i]=hxp;
					}
					else{
						jlrxzz=min(clubone,clubtwo);
						if(jlrxzz==clubone){
						clubone++;
						yyd1[i]=hxp;
						}	
						else if(jlrxzz==clubtwo){
						clubtwo++;
						yyd2[i]=hxp;
						}
						}
				}
			else if(hxp==x&&x==z&&z!=y){
				if(clubone==n/2&&clubthree==n/2){
					clubtwo++;
					yyd2[i]=hxp;
					}
					else{
						jlrxzz=min(clubone,clubthree);
						if(jlrxzz==clubone){
						clubone++;
						yyd1[i]=hxp;
						}	
						else if(jlrxzz==clubthree){
						clubthree++;
						yyd3[i]=hxp;
						}
						}
				}
				else if(hxp==y&&y==z&&z!=x){
				if(clubtwo==n/2&&clubthree==n/2){
					clubone++;
					yyd1[i]=hxp;
					}
					else{
						jlrxzz=min(clubthree,clubtwo);
						if(jlrxzz==clubthree){
						clubthree++;
						yyd3[i]=hxp;
						}	
						else if(jlrxzz==clubtwo){
						clubtwo++;
						yyd2[i]=hxp;
						}
						}
				}
				else if(hxp==x&&x!=y&&x!=z){
					if(clubone==n/2&&hxp>=yyd1[i-1]){
						yyd1[i-1]=hxp;

						}
					else{
						yyd1[i]=hxp;
						clubone++;
						}
				}
				else if(hxp==y&&y!=x&&y!=z){
					if(clubtwo==n/2&&hxp>=yyd2[i-1]){
						yyd2[i-1]=hxp;
						}
					else{
						yyd2[i]=hxp;
						clubtwo++;
						}
				}
				else if(hxp==z&&z!=y&&z!=x){
					if(clubthree==n/2&&hxp>=yyd3[i-1]){
						yyd3[i-1]=hxp;
						}
					else{
						yyd3[i]=hxp;
						clubthree++;
						}
				}
	}
	for(int i=1;i<=n;i++){
		sum+=yyd1[i]+yyd2[i]+yyd3[i];
		}
		cout<<sum<<endl;
}
	//---------------------------------------------------------------------------------------
	fclose(stdin);
	fclose(stdout)
}
