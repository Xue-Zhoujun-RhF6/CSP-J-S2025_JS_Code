#include<bits/stdc++.h>
using namespace std;
string s[200010][2];
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    int n,q;
    cin>>n>>q;
    for(int i=1;i<=n;i++)cin>>s[i][0]>>s[i][1];
    while(q--){
        string t1,t2;
        cin>>t1>>t2;
        if(t1.size()!=t2.size()){
            cout<<0<<endl;
            continue;
        }
        int ans=0;
        for(int i=1;i<=n;i++){
            int d=t1.find(s[i][0]);
            if(d==-1)continue;
            string x=t1.substr(0,d);
            string y=s[i][1];
            string z=t1.substr(d+s[i][0].size());
            string t=x+y+z;
            if(t==t2)ans++;
        }
        cout<<ans<<endl;
    }
    return 0;
}
