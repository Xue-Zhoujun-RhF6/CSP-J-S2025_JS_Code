#include<bits/stdc++.h>
using namespace std;
int n,a[100010][3],c[4],p[20010],t;
int f(int a,int b,int c){
    if(a>=b&&a>=c)return 1;
    if(b>=a&&b>=c)return 2;
    if(c>=a&&c>=b)return 3;
    return 1;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--){
        memset(p,0,sizeof(p));
        int sum=0;
        c[1]=0;c[2]=0;c[3]=0;
        cin>>n;
        for(int i=1;i<=n;i++){
            cin>>a[i][0]>>a[i][1]>>a[i][2];
            int d=f(a[i][0],a[i][1],a[i][2]);
            sum+=a[i][d-1];
            c[d]++;
        }
        int k=max(c[1],max(c[2],c[3]))-n/2;
        if(c[1]>n/2){
            for(int i=1;i<=n;i++){
                if(a[i][0]-max(a[i][1],a[i][2])>=0)p[a[i][0]-max(a[i][1],a[i][2])]++;
            }
            for(int i=0;i<=20009;i++){
                if(p[i]>=k){
                    sum-=i*k;
                    break;
                }
                else{
                    sum-=i*p[i];
                    k-=p[i];
                }
            }
        }
        else if(c[2]>n/2){
            for(int i=1;i<=n;i++){
                if(a[i][1]-max(a[i][0],a[i][2])>=0)p[a[i][1]-max(a[i][0],a[i][2])]++;
            }
            for(int i=0;i<=20009;i++){
                if(p[i]>=k){
                    sum-=i*k;
                    break;
                }
                else{
                    sum-=i*p[i];
                    k-=p[i];
                }
            }
        }
        else if(c[3]>n/2){
            for(int i=1;i<=n;i++){
                if(a[i][2]-max(a[i][0],a[i][1])>=0)p[a[i][2]-max(a[i][0],a[i][1])]++;
            }
            for(int i=0;i<=20009;i++){
                if(p[i]==0)continue;
                if(p[i]>=k){
                    sum-=i*k;
                    break;
                }
                else{
                    sum-=i*p[i];
                    k-=p[i];
                }
            }
        }
        cout<<sum<<endl;
    }
    return 0;
}
