#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;;
int n,m,a[501],cnt1=0,cnt2=0;
string s;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>s;
    for(int i=1;i<=n;i++){
        cin>>a[i];
        if(a[i]==0)cnt1++;
    }
    for(int i=0;i<s.size();i++){
        if(s[i]=='1')cnt2++;
    }
    if(n-cnt1<m){
        cout<<0;
        return 0;
    }
    if(cnt2<m){
        cout<<0;
        return 0;
    }
    int ans=1;
    for(int i=1;i<=n;i++){
        ans*=i;
        ans%=mod;
    }
    cout<<ans;
    return 0;
}
