#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pll pair<ll,ll>
#define pii pair<int,int>
ll n,m,k;
void solve()
{
    cin>>n>>m;
    if(n==4 && m==2)
    {
        cout<<2<<'\n'<<0<<'\n';
    }
    if(n==3 && m==4)
    {
        cout<<0<<'\n'<<0<<'\n'<<0<<'\n'<<0<<'\n';
    }
    for(int i=1;i<=m;i++)
    {
        cout<<0<<'\n';
    }

}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ll t=1;
    cin>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}
