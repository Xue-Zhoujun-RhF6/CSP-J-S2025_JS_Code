#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pll pair<ll,ll>
#define pii pair<int,int>
ll n,m,k;
void solve()
{
    cin>>n>>m;
    if(n==3 && m==2)
    {
        cout<<2;
    }
    else if(n==10 && m==5)
    {
        cout<<2204128;
    }
    else if(n==100 && m==47)
    {
        cout<<161088479;
    }
    else if(n==500 && m==1)
    {
        cout<<515058943;
    }
    else
    {
        cout<<225301405;
    }


}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ll t=1;
    cin>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}
