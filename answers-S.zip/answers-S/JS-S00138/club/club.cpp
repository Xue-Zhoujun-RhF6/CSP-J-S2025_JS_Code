#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pll pair<ll,ll>
#define pii pair<int,int>
ll a[100005][4],n,cnt[4],ans,b[100005];
vector<ll> an;
int  dfs(ll step)
{
    if(step>n)
    {
        an.push_back(ans);
        return 0;
    }
    for(int i=1;i<=3;i++)
    {
        if(cnt[i]<n/2)
        {
            cnt[i]++;
            ans+=a[step][i];
            step++;
            dfs(step);
            step--;
            cnt[i]--;
            ans-=a[step][i];
        }
    }

}
int solve()
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=3;j++)
        {
            cin>>a[i][j];

        }
    }

    for(int i=1;i<=3;i++)
    {
        cnt[i]=0;
    }
    ans=0;
    an.clear();
    dfs(1);
    ans=0;
    for(int i=1;i<=an.size();i++)
    {
        ans=max(ans,an[i]);
    }
    cout<<ans<<'\n';
    return 0;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ll t=1;
    cin>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}
