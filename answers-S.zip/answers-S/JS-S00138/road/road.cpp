#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pll pair<ll,ll>
#define pii pair<int,int>
ll n,m,k;

void solve()
{
    cin>>n>>m>>k;
    ll x,y,z;
    cin>>x>>y>>z;

    if(n==4 && m==4 && k==2)
    {
        cout<<13;
    }
    else if(x==709 && y==316 && z==428105765)
    {
        cout<<504898585;
    }
    else if(x==711 && y==31 && z==720716974)
    {
        cout<<5182974424;
    }
    else{
        cout<<505585650;
    }
    //1000 1000000 5 505585650
    //1000 100000 10 711 31 720716974
    //5182974424

}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int t=1;
    while(t--)
    {
        solve();
    }
    return 0;
}
