#include<bits/stdc++.h>
#define int long long
using namespace std;
const int M=2e6+10,N=2e4+10,INF=1e16;
struct node{
    int u,v,w;
}edge[M];
int n,m,K,ans=INF,fa[N],val,c[20];
bool flag[N];
int find(int k){
    if(fa[k]==k) return k;
    return fa[k]=find(fa[k]);
}
void Kru(){
    int res=0;
    for(int i=1;i<=n+K;i++)
        fa[i]=i;
    for(int i=1;i<=m;i++){
        if(val+res>=ans) return;
        if(!(flag[edge[i].u]&&flag[edge[i].v]&&find(edge[i].u)!=find(edge[i].v))) continue;
        fa[find(edge[i].u)]=find(edge[i].v);res+=edge[i].w;
    }
    ans=min(ans,val+res);
    return;
}
void dfs(int x){
    if(x>K){
        Kru();
        return;
    }
    flag[n+x]=0;
    dfs(x+1);
    flag[n+x]=1;val+=c[x];
    dfs(x+1);
    val-=c[x];
    return;
}
signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>m>>K;
    for(int i=1;i<=m;i++)
        cin>>edge[i].u>>edge[i].v>>edge[i].w;
    for(int i=1;i<=K;i++){
        cin>>c[i];
        for(int j=1;j<=n;j++){
            int a;cin>>a;
            edge[++m]=(node){n+i,j,a};
        }
    }
    sort(edge+1,edge+1+m,[](node x,node y){return x.w<y.w;});
    for(int i=1;i<=n;i++) flag[i]=1;
    dfs(1);
    cout<<ans<<'\n';
    return 0;
}