#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=505,Mod=998244353;
int n,m,c[N],ans,way[N],jc[N];
char str[N];
bool visited[N];
void solve(){
    int cnt=0;
    for(int i=1;i<=n;i++)
        if(i-cnt-1<c[way[i]]&&str[i]=='1')
            cnt++;
    if(cnt>=m) ans++;
    return;
}
void dfs(int x){
    if(x>n){
        solve();
        return;
    }
    for(int i=1;i<=n;i++){
        if(visited[i]) continue;
        visited[i]=1;way[x]=i;
        dfs(x+1);visited[i]=0;
    }
    return;
}
int Sum1(){
    int cnt=0;
    for(int i=1;i<=n;i++)
        if(str[i]=='1')
            cnt++;
    return cnt;
}
bool sp1(){
    return Sum1()==n;
}
signed main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>m>>str+1;
    for(int i=1;i<=n;i++)
        cin>>c[i];
    if(n<=18){
        dfs(1);cout<<ans<<'\n';
        return 0;
    }
    jc[0]=1;
    for(int i=1;i<=n;i++)
        jc[i]=jc[i-1]*i%Mod;
    int cnt[N]={},tt[N][N]={};
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            if(c[j]<i)
                cnt[i]++;
    for(int i=1;i<=n;i++){
        tt[i-1][0]=1;
        for(int j=1;j<=n;j++){
            tt[i][j]=tt[i-1][j];
            (tt[i][j]+=tt[i-1][j-1]*max(cnt[i]-(j-1),(int)0))%=Mod;
        }
    }
    int sum=tt[n][n-m+1]*jc[m-1]%Mod;
    cout<<((jc[n]-sum)%Mod+Mod)%Mod<<'\n';
    return 0;
}