#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+10;
int T,n,a[N][4],ans,cnt[4];
priority_queue<int,vector<int>,greater<int> >Q[4];
void _init(){
    for(int i=1;i<=3;i++)
        while(!Q[i].empty())
            Q[i].pop();
    ans=cnt[1]=cnt[2]=cnt[3]=0;
    return;
}
signed main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>T;
    while(T--){
        cin>>n;_init();
        for(int i=1;i<=n;i++)
            for(int j=1;j<=3;j++)
                cin>>a[i][j];
        for(int i=1;i<=n;i++){
            if(a[i][1]>=max(a[i][2],a[i][3])){
                Q[1].push(a[i][1]-max(a[i][2],a[i][3]));
                cnt[1]++;ans+=a[i][1];
                if(cnt[1]>n/2){
                    ans-=Q[1].top();Q[1].pop();
                }
            }
            else{
                if(a[i][2]>=max(a[i][1],a[i][3])){
                    Q[2].push(a[i][2]-max(a[i][1],a[i][3]));
                    cnt[2]++;ans+=a[i][2];
                    if(cnt[2]>n/2){
                        ans-=Q[2].top();Q[2].pop();
                    }
                }
                else{
                    Q[3].push(a[i][3]-max(a[i][1],a[i][2]));
                    cnt[3]++;ans+=a[i][3];
                    if(cnt[3]>n/2){
                        ans-=Q[3].top();Q[3].pop();
                    }
                }
            }
        }
        cout<<ans<<'\n';
    }
    return 0;
}