#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=5e6+10,B=233;
map<pair<unsigned long long,unsigned long long>,int>mp;
int n,q,len[2],ans;
unsigned long long sub_hash[2][N],Base[N];
string str[2];
unsigned long long h(bool p,int l,int r){
    return sub_hash[p][r]-sub_hash[p][l-1]*Base[r-l+1];
}
void get_sub_hash(){
    for(int i=0;i<len[0];i++)
        sub_hash[0][i]=(i?sub_hash[0][i-1]*B:0)+str[0][i];
    for(int i=0;i<len[1];i++)
        sub_hash[1][i]=(i?sub_hash[1][i-1]*B:0)+str[1][i];
    return;
}
signed main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>q;Base[0]=1;
    for(int i=1;i<N;i++)
        Base[i]=Base[i-1]*B;
    for(int i=1;i<=n;i++){
        cin>>str[0]>>str[1];
        len[0]=str[0].length();len[1]=str[1].length();
        get_sub_hash();
        mp[make_pair(h(0,0,len[0]-1),h(1,0,len[1]-1))]++;
    }
    while(q--){
        cin>>str[0]>>str[1];
        len[0]=str[0].length();len[1]=str[1].length();
        if(len[0]!=len[1]){
            cout<<"0\n";
            continue;
        }
        get_sub_hash();
        int l=0,r=len[0]-1;ans=0;
        while(str[0][l]==str[1][l]) l++;
        while(str[0][r]==str[1][r]) r--;
        for(int i=0;i<=l;i++)
            for(int j=r;j<len[0];j++)
                ans+=mp[make_pair(h(0,i,j),h(1,i,j))];
        cout<<ans<<'\n';
    }
    return 0;
}