#include<bits/stdc++.h>
using namespace std;
//int b[20005],c[20005],d[20005];
int ans;
//bool cmp(int x,int y){
//	return x>y;
//}
//int ans;
int cntb[2005];
int cnt=0;
int cntl=0;
int a[20005][20005];
int bj[2002][5];
int maxn=-1;
int maxl[1005],maxr[1005];
int main(){
	freopen("club.in","r",in);
	freopen("club.out","w",out);
	int t;
	cin>>t;
	while(t--){
		memset(bj,0,sizeof(bj));
		int n;
		cin>>n;
		ans=0;
		
		/*for(int i=1;i<=n*3;i++){
			cin>>b[i];
		}
		for(int i=1;i<=n*3;i++){
			if(i<=3) c[i]=i;
			else if(i%3==0) c[i]=3;
			else{
				c[i]=i%3;
			}
		}
		for(int i=1;i<=n*3;i++){
			d[i]=i;
		}
		for(int i=1;i<=n;i++){
			for(int j=2;j<i;j++){
				if(b[i]<b[j]){
					swap(b[i],b[j]);//du
					swap(c[i],c[j]);//wei
					swap(d[i],d[j]);//ren
				}
			}
		}
*/
		//for(int i=1;i<=n*3;i++){
			//cout<<b[i]<<endl;
		//}
		/*int cnt1=0,cnt2=0,cnt3=0,cntr=0;
		for(int i=1;i<=n*3;i++){
			if(c[i]==1) cnt1++;
			if(c[i]==2) cnt2++;
			if(c[i]==3) cnt3++;
			if(cnt1<=n/2&&cnt2<=n/2&&cnt3<=n/2&&d[i]!=d[i+1]&&d[i+1]!=d[i+2]&&d[i+2]!=b[i]) ans+=b[i],cout<<"bi"<<"="<<b[i]<<endl;
			
		}*/
		//cout<<ans<<endl;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=3;j++){
				if(a[i][j]>maxn){
					maxn=a[i][j];
					
					//cout<<"maxn"<<maxn<<endl;
					cnt=j;
					cntb[cnt]++;
					//if(cnt==1) maxl[i]=a[i][2],maxr[i]=a[i][3];
					//if(cnt==2) maxl[i]=a[i][1],maxr[i]=a[i][3];
					//if(cnt==3) maxl[i]=a[i][1],maxr[i]=a[i][2];
					
					//cout<<"cnt="<<cnt<<endl;
					
				}
				
			}
		
			if(cntb[cnt]<=n/2){
				bj[i][cnt]+=maxn;
			}/*else{
				if(maxl[i]<maxr[i]){
					if(cnt==1) bj[i][3]+=maxr[i];
					if(cnt==2) bj[i][3]+=maxr[i];
					if(cnt==3) bj[i][2]+=maxr[i];
				}
				else{
					if(cnt==1) bj[i][2]+=maxl[i];
					if(cnt==2) bj[i][1]+=maxl[i];
					if(cnt==3) bj[i][1]+=maxl[i];
				}
			}*/
		}

		
		for(int i=1;i<=n;i++){
			for(int j=1;j<=3;j++){
				//cout<<"b["<<i<<"]"<<"["<<j<<"]"<<"="<<bj[i][j]<<endl;
				ans+=bj[i][j];
			}
		}
		cout<<ans<<endl;
		
	}
	return 0;
}
