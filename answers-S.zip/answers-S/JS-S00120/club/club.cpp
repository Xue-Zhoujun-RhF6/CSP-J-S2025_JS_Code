#include<bits/stdc++.h>
using namespace std;
int a[100010][4],n,c[4]={0};
int dfs(int p,int k){
    if(k==n+1)return 0;
    int ans=0;
    for(int i=1;i<=3;i++){

        if(c[i]>=n/2)continue;
        c[i]++;
        ans=max(dfs(i,k+1)+a[k][i],ans);
       c[i]--;
    }
    return ans;
}
void cpf(){

    for(int i=0;i<=4;i++)c[i]=0;
    cin>>n;

    for(int i=1;i<=n;i++){
        cin>>a[i][1]>>a[i][2]>>a[i][3];
    };
    cout<<dfs(1,1)<<endl;

}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int T;
    cin>>T;
    while(T--){
        cpf();
    }



    return 0;
}
