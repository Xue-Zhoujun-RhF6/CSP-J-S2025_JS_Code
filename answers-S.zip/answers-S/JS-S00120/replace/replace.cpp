#include<bits/stdc++.h>
using namespace std;

int main(){
    //freopen("replace.in","r",stdin);
    //freopen("replace.out","w",stdout);
    string s1="123456",s2="345";
    cout<<s1.find(s2);
    return 0;
}
