#include <bits/stdc++.h>
using namespace std;
int max3mar;
int max3(int *l)
{
    int re = 0;
    for (size_t i = 0; i < 3; i++)
    {
        if (l[i] > re)
        {
            max3mar = i, re = l[i];
        }
    }
    return re;
}

struct p
{
    int data[3];
    int &operator[](int x) { return (data[x]); }
    bool operator<(p &other)
    {
        return (max3(data) > max3(other.data));
    }
};
const int MAX = 1e5 + 5;
int t, n, an[MAX][4], x[4], xi[MAX][4];
p a[MAX];
int main()
{
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    cin >> t;
    while (t--)
    {
        memset(a, 0, sizeof(a));
        memset(x, 0, sizeof(x));
        memset(an, 0, sizeof(an));
        cin >> n;
        n >> 1;
        for (size_t i = 1; i <= n; i++)
        {
            cin >> a[i][0] >> a[i][1] >> a[i][2];
        }
        sort(a + 1, a + n + 1);
        
        
        cout << max3(an[n]) << "\n";
    }
}