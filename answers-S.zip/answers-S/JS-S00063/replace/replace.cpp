#include <bits/extc++.h>
using namespace std;
using namespace __gnu_pbds;
gp_hash_table<string, string> m;
string x, y, tmp1, tmp2, tmp3;
int n, q, a = 0;
int main()
{
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    cin >> n >> q;
    for (int i = 0; i < n; i++)
    {
        cin >> x >> y;
        m[x] = y;
    }
    for (int i = 0; i < q; i++)
    {
        cin >> x >> y;
        for (size_t i = 0; i < x.size(); i++)
        {
            for (size_t j = 1; i + j < x.size(); j++)
            {
                tmp2 = x.substr(i, j);
                if (m[tmp2] != "")
                {
                    if (tmp1 + m[tmp2] + x.substr(i + j) == y)
                        a++;
                }
            }
            tmp1 += x[i];
        }
    }
    cout << a;
}