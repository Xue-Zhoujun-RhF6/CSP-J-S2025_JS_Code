#include <bits/stdc++.h>
using namespace std;
int n, m, k;
struct edge
{
    long long fr, to, dis;
    bool operator<(edge &other)
    {
        return dis < other.dis;
    }
};
struct node
{
    int to;
};
vector<int> no[10005];

vector<edge> a;
long long u, v, w, ans;
bitset<10005> vis, link[10005];
bool li(int x, int y)
{
    bool l = 0;
    if (link[x][y] || link[y][x])
    {
        return 1;
    }
    for (auto &&i : no[x])
    {
        l = li(i, y) ? 1 : l;
    }
    return link[x][y] = l;
}
int main()
{
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    cin >> n >> m >> k;

    for (int i = 0; i < m; i++)
    {
        cin >> u >> v >> w;
        a.push_back({u, v, w});
    }
    for (int i = 0; i < k; i++)
    {
        vector<long long> x(n);
        cin >> u;
        for (auto &i : x)
        {
            cin >> i;
        }
        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {

                a.push_back({i + 1, j + 1, u + x[i] + x[j]});
            }
        }
    }
    sort(a.begin(), a.end());

    for (auto &i : a)
    {
        if (vis.count() == n)
        {

            break;
        }
        if (!(vis[i.fr] && vis[i.to] && li(i.fr, i.to)))
        {
            vis[i.fr] = 1, vis[i.to] = 1, ans += i.dis;
            no[i.fr].push_back(i.to);
            no[i.to].push_back(i.fr);
        }
    }
    cout << ans;
}