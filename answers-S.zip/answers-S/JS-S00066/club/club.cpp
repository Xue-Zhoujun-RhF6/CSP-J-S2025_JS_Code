#include<bits/stdc++.h>
#include<iostream>
using namespace std;

int main(){
    //ios::sync_with_stdio(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    long long t;
    cin>>t;
    long long s[4];
    long long ans[1000];
    long long n[1000];
    long long a[10000][10000][100];
    for(int k=1;k<=t;k++)
    {
        s[1]=0;
        s[2]=0;
        s[3]=0;
        cin>>n[k];
        ans[k]=0;
        for(int i=1;i<=n[k];i++)
        {
            cin>>a[k][i][1];
            cin>>a[k][i][2];
            cin>>a[k][i][3];
        for(int q=1;q<=n[k];q++)
        {
            ans[k]+=max(a[k][q][1],a[k][q][2]);
        }
        }
    }
    for(int e=1;e<=t;e++)
    {
        cout<<ans[e]<<endl;
    }
    //fclose("r");
    //fclose("w");
    return 0;
}
