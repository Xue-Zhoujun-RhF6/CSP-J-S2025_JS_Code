#include<bits/stdc++.h>
#include<iostream>
using namespace std;

int main(){
    ios::sync_with_stdio(0);
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    long long t;
    cin>>t;
    long long b[1000][1000][100];
    long long s[4];
    long long ans[1000];
    long long n[1000];
    long long a[10000][10000][100];
    for(int k=1;k<=t;k++)
    {
        s[1]=0;
        s[2]=0;
        s[3]=0;
        cin>>n[k];
        for(int i=1;i<=n[k];i++)
        {
            cin>>a[k][i][1];
            cin>>a[k][i][2];
            cin>>a[k][i][3];
            if(a[k][i][1]>=a[k][i][2]&&a[k][i][2]>=a[k][i][3])
            {
                b[k][i][1]=1;
                b[k][i][2]=2;
                b[k][i][3]=3;
            }
            else
            if(a[k][i][2]>=a[k][i][1]&&a[k][i][1]>=a[k][i][3])
            {
                swap(a[k][i][1],a[k][i][2]);
                b[k][i][1]=2;
                b[k][i][2]=1;
                b[k][i][3]=3;
            }
            else
            if(a[k][i][2]>=a[k][i][1]&&a[k][i][3]>=a[k][i][2])
            {
                swap(a[k][i][1],a[k][i][3]);
                b[k][i][1]=3;
                b[k][i][2]=2;
                b[k][i][3]=1;
            }
            else
            if(a[k][i][2]>=a[k][i][3]&&a[k][i][3]>=a[k][i][1])
            {
                swap(a[k][i][1],a[k][i][2]);
                swap(a[k][i][2],a[k][i][3]);
                b[k][i][1]=2;
                b[k][i][2]=3;
                b[k][i][3]=1;
            }
            else
            if(a[k][i][3]>=a[k][i][1]&&a[k][i][1]>=a[k][i][2])
            {
                swap(a[k][i][1],a[k][i][2]);
                swap(a[k][i][1],a[k][i][3]);
                b[k][i][1]=3;
                b[k][i][2]=1;
                b[k][i][3]=2;
            }
            else
            {
                swap(a[k][i][2],a[k][i][3]);
                b[k][i][1]=1;
                b[k][i][2]=3;
                b[k][i][3]=2;
            }
        }
        for(int q=1;q<=n[k];q++)
        {
            ans[k]+=a[k][q][1];
            s[b[k][q][1]]++;
            for(int w=1;w<=q-1;w++)
            {
                if(s[b[k][q][1]]>n[k]/2)
                {
                    if(a[k][q][1]>a[k][w][1]-a[k][w][2])
                    {
                        s[b[k][q][1]]--;
                        s[b[k][w][2]]++;
                        ans[k]-=a[k][w][1];
                        ans[k]+=a[k][w][2];
                    }
                }
            }
        }
    }
    for(int e=1;e<=t;e++)
    {
        cout<<ans[e]<<endl;
    }
    //fclose("r");
    //fclose("w");
    return 0;
}
