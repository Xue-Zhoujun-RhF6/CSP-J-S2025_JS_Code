#include <bits/stdc++.h>
using namespace std;
//#define int long long
using ll = long long;
#define pii pair<int,int>
#define fir first
#define sec second
#define pb push_back
#define chmin(a,b) (a=min(a,b))
#define chmax(a,b) (a=max(a,b))
const int inf=0x3f3f3f3f3f3f3f3f;
const int mod=998244353;
int n,m,c[510],rm[510],dp[2][510][510],C[510][510],P[510][510],fac[510],ans;
//dp[i][j][k][l]
//first i days
//j people failed
//k days to be determined
string s;
signed main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n>>m>>s;
    s=" "+s;
    for(int i=1;i<=n;i++)
    {
        int x;
        cin>>x;
        c[x]++;
        for(int j=0;j<x;j++)rm[j]++;
    }
    dp[0][0][0]=1;
    fac[0]=1;
    for(int i=1;i<=n;i++)fac[i]=1ll*fac[i-1]*i%mod;
    for(int i=0;i<=n;i++)
    {
        C[i][0]=1;
        for(int j=1;j<=i;j++)C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
        for(int j=0;j<=i;j++)P[i][j]=1ll*C[i][j]*fac[j]%mod;
    }
    for(int i=1;i<=n;i++)
    {
        memset(dp[i&1],0,sizeof(dp[i&1]));
        bool ps=s[i]-'0';
        for(int j=0;j<i;j++)if(j<=n-m)
            for(int k=0;k<i;k++)
            {
                int tmp=dp[i&1^1][j][k];
                if(!tmp)continue;
//                cout<<"!!!!!"<<i-1<<" "<<j<<" "<<k<<"    "<<tmp<<endl;
                if(ps)(dp[i&1][j][k+1]+=tmp)%=mod;
                int tr=n-rm[j]-(i-1-k);
//                cout<<"tr="<<tr<<"....."<<rm[j]<<endl;
                int tc=c[j+1];
                if(tr>0)for(int l=min(k,tc);~l;l--)(dp[i&1][j+1][k-l]+=1ll*tmp*tr%mod*C[k][l]%mod*P[tc][l]%mod)%=mod;
                if(!ps)for(int l=min(k+1,tc);~l;l--)(dp[i&1][j+1][k+1-l]+=1ll*tmp*C[k+1][l]%mod*P[tc][l]%mod)%=mod;
            }
    }
    for(int i=0;i<=n-m;i++)(ans+=1ll*dp[n&1][i][rm[i]]*fac[rm[i]]%mod)%=mod;
    cout<<ans<<endl;
    return 0;
}
//100+[80,100]+100+100=[380,400].
//T2 > t4

/*
3 2
101
1 1 2
*/
