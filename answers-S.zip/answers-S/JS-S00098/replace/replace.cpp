#include <bits/stdc++.h>
using namespace std;
//#define int long long
using ll = long long;
#define pii pair<int,int>
#define fir first
#define sec second
#define pb push_back
#define chmin(a,b) (a=min(a,b))
#define chmax(a,b) (a=max(a,b))
const int inf=0x3f3f3f3f;
int n,q,cnt;
int t[5000010][26],fail[23][5000010],c[5000010],len[5000010],qr[5000010],hd,tl;
string s1,s2;
int query(int u,int k)
{
    if(len[u]<k)return 0;
    int ans=c[u];
    for(int i=22;~i;i--)if(len[fail[i][u]]>=k)u=fail[i][u];
    return ans-c[fail[0][u]];
}
signed main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n>>q;
    for(int i=1;i<=n;i++)
    {
        cin>>s1>>s2;
        int l=s1.size(),u=0;
        for(int i=0;i<l;i++)
        {
            int c=s1[i]-'a';
            if(!t[u][c])t[u][c]=++cnt,len[cnt]=2*i+1;
            u=t[u][c];

            c=s2[i]-'a';
            if(!t[u][c])t[u][c]=++cnt,len[cnt]=2*i+2;
            u=t[u][c];
        }
        c[u]++;
    }
    hd=1;
    for(int i=0;i<26;i++)if(t[0][i])qr[++tl]=t[0][i];
    while(hd<=tl)
    {
        int u=qr[hd];
        hd++;
        for(int i=0;i<26;i++)
            if(t[u][i])
            {
                int v=t[u][i],f=fail[0][u];
                while(f&&!t[f][i])f=fail[0][f];
                fail[0][v]=t[f][i],c[v]+=c[fail[0][v]],qr[++tl]=v;
            }
            else t[u][i]=t[fail[0][u]][i];
    }
    for(int i=1;i<23;i++)for(int j=1;j<=cnt;j++)fail[i][j]=fail[i-1][fail[i-1][j]];
//    for(int i=0;i<=cnt;i++)for(int j=0;j<26;j++)if(t[i][j])cout<<"t["<<i<<"]["<<j<<"]="<<t[i][j]<<endl;
    while(q--)
    {
        cin>>s1>>s2;
        if(s1.size()!=s2.size()){cout<<"0\n";continue;}
        int l=-1,r=0;
        int len=s1.size();
        for(int j=0;j<len;j++)if(s1[j]!=s2[j])
        {
            if(l==-1)l=j;
            r=j;
        }
//        cout<<"....."<<l<<" "<<r<<endl;
        int u=0;
        ll ans=0;
        for(int j=0;j<len;j++)
        {
            u=t[u][s1[j]-'a'];
            u=t[u][s2[j]-'a'];
            if(j>=r)ans+=query(u,2*(j-l+1));
        }
        cout<<ans<<'\n';
    }
    return 0;
}
