#include <bits/stdc++.h>
using namespace std;
//#define int long long
using ll = long long;
#define pii pair<int,int>
#define fir first
#define sec second
#define pb push_back
#define chmin(a,b) (a=min(a,b))
#define chmax(a,b) (a=max(a,b))
const int inf=0x3f3f3f3f;
int n,m,k,cnt,c[15];
bool vis[1024];
ll ans;
struct edge
{
    int u,v,w;
    edge(){}
    edge(int _u,int _v,int _w)
    {u=_u,v=_v,w=_w;}
    bool operator<(edge &B)const
    {return w<B.w;}
}g[1000010],ng[110010];
struct dsu
{
    ll ans=0;
    int fa[10011];
    void init(){for(int i=1;i<=n+k;i++)fa[i]=i;}
    int find(int u){return fa[u]==u?u:fa[u]=find(fa[u]);}
    bool merge(int u,int v,int w){u=find(u),v=find(v);return (u^v)?(fa[u]=v,ans+=w,1):0;}
}t[1024];
signed main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++)cin>>g[i].u>>g[i].v>>g[i].w;
    sort(g+1,g+m+1);
    for(int i=0;i<(1<<k);i++)t[i].init();
    for(int i=1;i<=m;i++)
    {
        int u=g[i].u,v=g[i].v,w=g[i].w;
//        cout<<"..."<<u<<" "<<v<<" "<<w<<" "<<t[0].find(u)<<" "<<t[0].find(v)<<endl;
        if(t[0].merge(u,v,w))ng[++cnt]=g[i];
    }
    ans=t[0].ans;
//    cout<<"...ans="<<ans<<endl;
    for(int i=1;i<=k;i++)
    {
        cin>>c[i];
        for(int j=1;j<=n;j++)
        {
            int x;
            cin>>x;
            ng[++cnt]={i+n,j,x};
        }
    }
    sort(ng+1,ng+cnt+1);
    const int U=1<<k;
//    cout<<"cnt="<<cnt<<"    "<<U<<endl;
    for(int i=1;i<=cnt;i++)
    {
        int u=ng[i].u,v=ng[i].v,w=ng[i].w;
//        cout<<"qwq"<<u<<" "<<v<<endl;
        if(u<=n){for(int j=1;j<U;j++)if(!vis[j])t[j].merge(u,v,w);}
        else
        {
            int pk=1<<(u-n-1);
            for(int j=pk;j<U;j++)if((j&pk)&&!vis[j])t[j].merge(u,v,w);
        }
        for(int j=1;j<U;j++)if(t[j].ans>=ans)vis[j]=1;
    }
    for(int i=1;i<U;i++)
    {
        ll pans=t[i].ans;
//        cout<<"qwq"<<i<<"   "<<pans<<endl;
        for(int j=0;j<k;j++)if(i&(1<<j))pans+=c[j+1];
        chmin(ans,pans);
    }
    cout<<ans<<'\n';
    return 0;
}
