#include <bits/stdc++.h>
using namespace std;
#define int long long
#define pii pair<int,int>
#define fir first
#define sec second
#define pb push_back
#define chmin(a,b) (a=min(a,b))
#define chmax(a,b) (a=max(a,b))
const int inf=0x3f3f3f3f3f3f3f3f;
int n,a[100010][3],ans;
priority_queue<pii>qr[3];
void solve()
{
    cin>>n;
    for(int i=0;i<3;i++)
    {
        while(!qr[i].empty())qr[i].pop();
        assert(!qr[i].size());
    }
    ans=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<3;j++)cin>>a[i][j];
        int p=0,q=1,r=2;
        if(a[i][p]<a[i][q])swap(p,q);
        if(a[i][q]<a[i][r])swap(q,r);
        if(a[i][p]<a[i][q])swap(p,q);

        if(qr[p].size()<n/2)ans+=a[i][p],qr[p].push({a[i][q]-a[i][p],i});
        else if(qr[p].top().fir>a[i][q]-a[i][p])ans+=qr[p].top().fir+a[i][p],qr[p].pop(),qr[p].push({a[i][q]-a[i][p],i});
        else ans+=a[i][q],qr[q].push({0,i});
    }
    cout<<ans<<'\n';
}
signed main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    int t;
    cin>>t;
    while(t--)solve();
    return 0;
}
