#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e4 + 10;

int n, m, k, ans = 0;
vector<pair<int, int>> G[maxn];
int dis[maxn], vis[maxn];

inline void dijkstra(int s) {
    memset(dis, 0x3f, sizeof dis);
    memset(vis, 0, sizeof vis);
    priority_queue<pair<int, int>> q;
    q.push({0, s});
    dis[s] = 0, vis[s] = false;
    while (q.size()) {
        int u = q.top().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = true;
        for (auto it : G[u]) {
            int v = it.first, w = it.second;
            if (dis[v] > dis[u] + w) {
                dis[v] = dis[u] + w;
                for (auto kv : G[u]) {
                    if (kv.first == v) {
                        kv.second = 0;
                        break;
                    }
                }
                for (auto kv : G[v]) {
                    if (kv.first == u) {
                        kv.second = 0;
                        break;
                    }
                }
                if (!vis[v]) {
                    q.push({-dis[v], v});
                    vis[v] = false;
                }
            }
        }
    }
}

signed main() {
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    cin >> n >> m >> k;
    for (int i = 1, u, v, w; i <= n; i++) {
        cin >> u >> v >> w;
        G[u].push_back({v, w});
        G[v].push_back({u, w});
    }
    for (int i = 1; i <= k; i++) {
        for (int j = 0, w; j <= n; j++) {
            cin >> w;
            G[n + i].push_back({j, w});
            G[j].push_back({n + i, w});
        }
    }
    dijkstra(1);
    for (int i = 1; i <= n; i++) {
        ans += dis[i];
    }
    cout << ans << '\n';
    return 0;
}
/*i*/
