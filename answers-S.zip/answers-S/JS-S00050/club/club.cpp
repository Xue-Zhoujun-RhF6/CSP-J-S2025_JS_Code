#include <bits/stdc++.h>
#define int long long
using namespace std;

const int maxn = 1e5 + 10;

int n, k, dp[maxn][4], ans = 0;
struct choice {
    int a, b, c;
} s[maxn];
struct node {
    int a, b, c;
} cnt[maxn][4];

inline int max3(int x, int y, int z) {
    return max(x, max(y, z));
}

inline int query(int x, int y, int z) {
    if (x >= y && x >= z) return 1;
    if (y >= x && y >= z) return 2;
    if (z >= x && z >= y) return 3;
}

inline bool cmp(choice x, choice y) {
    if (x.a != y.a) return x.a > y.a;
    if (x.b != y.b) return x.b > y.b;
    return x.c > y.c;
}

inline void dfs(int step, int sum, int g1, int g2, int g3) {
    if (step == n) {
        ans = max(ans, sum);
        return ;
    }
    if (g1 < k) {
        dfs(step + 1, sum + s[step + 1].a, g1 + 1, g2, g3);
    }
    if (g2 < k) {
        dfs(step + 1, sum + s[step + 1].b, g1, g2 + 1, g3);
    }
    if (g3 < k) {
        dfs(step + 1, sum + s[step + 1].c, g1, g2, g3 + 1);
    }
}

inline void solve2() {
    memset(dp, 0, sizeof dp);
    memset(cnt, 0, sizeof cnt);
    sort(s + 1, s + n + 1, cmp);
    // cerr << "CASE" << '\n';
    for (int i = 1; i <= n; i++) {
        /*
        node tmp = cnt[i - 1][query(dp[i - 1][1], dp[i - 1][2], dp[i - 1][3])];
        cnt[i][1] = cnt[i][2] = cnt[i][3] = tmp;
        if (cnt[i][1].a < k) {
            dp[i][1] = dp[i - 1][query(dp[i - 1][1], dp[i - 1][2], dp[i - 1][3])] + s[i].a;
            cnt[i][1].a++;
        }
        if (cnt[i][2].b < k) {
            dp[i][2] = dp[i - 1][query(dp[i - 1][1], dp[i - 1][2], dp[i - 1][3])] + s[i].b;
            cnt[i][2].b++;
        }
        if (cnt[i][3].c < k) {
            dp[i][3] = dp[i - 1][query(dp[i - 1][1], dp[i - 1][2], dp[i - 1][3])] + s[i].c;
            cnt[i][3].c++;
        }
        */
        if (cnt[i - 1][1].a < k && dp[i - 1][1] + s[i].a > dp[i][1]) {
            dp[i][1] = dp[i - 1][1] + s[i].a;
            cnt[i][1] = cnt[i - 1][1];
            cnt[i][1].a++;
        }
        if (cnt[i - 1][2].a < k && dp[i - 1][2] + s[i].a > dp[i][1]) {
            dp[i][1] = dp[i - 1][2] + s[i].a;
            cnt[i][1] = cnt[i - 1][2];
            cnt[i][1].a++;
        }
        if (cnt[i - 1][3].a < k && dp[i - 1][3] + s[i].a > dp[i][1]) {
            dp[i][1] = dp[i - 1][3] + s[i].a;
            cnt[i][1] = cnt[i - 1][3];
            cnt[i][1].a++;
        }
        if (cnt[i - 1][1].b < k && dp[i - 1][1] + s[i].b > dp[i][2]) {
            dp[i][2] = dp[i - 1][1] + s[i].b;
            cnt[i][2] = cnt[i - 1][1];
            cnt[i][2].b++;
        }
        if (cnt[i - 1][2].b < k && dp[i - 1][2] + s[i].b > dp[i][2]) {
            dp[i][2] = dp[i - 1][2] + s[i].b;
            cnt[i][2] = cnt[i - 1][2];
            cnt[i][2].b++;
        }
        if (cnt[i - 1][3].b < k && dp[i - 1][3] + s[i].b > dp[i][2]) {
            dp[i][3] = dp[i - 1][3] + s[i].b;
            cnt[i][3] = cnt[i - 1][3];
            cnt[i][3].b++;
        }
        if (cnt[i - 1][1].c < k && dp[i - 1][1] + s[i].c > dp[i][3]) {
            dp[i][3] = dp[i - 1][1] + s[i].c;
            cnt[i][3] = cnt[i - 1][1];
            cnt[i][3].c++;
        }
        if (cnt[i - 1][2].c < k && dp[i - 1][2] + s[i].c > dp[i][3]) {
            dp[i][3] = dp[i - 1][2] + s[i].c;
            cnt[i][3] = cnt[i - 1][2];
            cnt[i][3].c++;
        }
        if (cnt[i - 1][3].c < k && dp[i - 1][3] + s[i].c > dp[i][3]) {
            dp[i][3] = dp[i - 1][3] + s[i].c;
            cnt[i][3] = cnt[i - 1][3];
            cnt[i][3].c++;
        }
        // cerr << "Person" << i << '\n';
        // cerr << cnt[i][1].a << ' ' << cnt[i][1].b << ' ' << cnt[i][1].c << " dp " << dp[i][1] << '\n';
        // cerr << cnt[i][2].a << ' ' << cnt[i][2].b << ' ' << cnt[i][2].c << " dp " << dp[i][2] << '\n';
        // cerr << cnt[i][3].a << ' ' << cnt[i][3].b << ' ' << cnt[i][3].c << " dp " << dp[i][3] << '\n';
    }
    ans = max3(dp[n][1], dp[n][2], dp[n][3]);
    // cerr << '\n';
}

inline void work() {
    cin >> n;
    k = n / 2;
    ans = 0;
    for (int i = 1; i <= n; i++) {
        cin >> s[i].a >> s[i].b >> s[i].c;
    }
    if (n <= 10) dfs(0, 0, 0, 0, 0);
    else solve2();
    cout << ans << '\n';
}

signed main() {
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    int t;
    cin >> t;
    while (t--) work();
    return 0;
}
/*
17:45 死了，T1 T2 T3 T4 都不会做。。。懒得打暴搜了，估计也是最后一场考试了，随便写点吧，巧了可能能得到几分。。。

感谢陪伴我度过初中快乐的三年的所有人，陪我一起学 OI 的所有同学，以及每一位帮助过我的人。

我太菜了，什么都不会，不过感谢zy最后一天的鼓励。

实在不知道该写什么了，就这样吧。

哦哦，I love you!

名字一个代码放一个字母吧，缀在最后。
*/
/*z*/
