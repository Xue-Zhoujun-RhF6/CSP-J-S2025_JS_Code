#include <bits/stdc++.h>
using namespace std;

int n, q;

signed main() {
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    cin >> n >> q;
    for (int i = 1; i <= q; i++) {
        puts("0");
    }
    return 0;
}
/*n*/
