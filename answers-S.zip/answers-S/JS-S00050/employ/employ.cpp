#include <bits/stdc++.h>
#define int long long
using namespace std;

const int maxn = 505, mod = 998244353;

int n, m, a[maxn], ans = 1;
string s;

signed main() {
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    puts("0");
    return 0;
}
/*g*/
