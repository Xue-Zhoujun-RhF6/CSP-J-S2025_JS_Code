#include <bits/stdc++.h>
using namespace std;

int n, m;
string s;
int c[505];
bool used[505];
long long ans = 0;
void solve(int now, int sum)
{
    //cout << now << ' ' << sum << endl;
    if (now == n)
    {
        if (sum >= m) ans++, ans %= 998244353;
        return;
    }
    for (int i = 1; i <= n; i++)
    {
        //cout << "used" << i << ' ' << used[i] << endl;
        if (!used[i])
        {
           used[i] = 1;
           if (c[i] > now - sum && s[now] == '1') solve(now + 1, sum + 1);
           else solve(now + 1, sum);
           used[i] = 0;
        }
    }
}
int main()
{
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    scanf("%d%d", &n, &m);
    scanf("%s", s.c_str());
    //cin >> s;
    //cout << s << endl;
    for (int i = 1; i <= n; i++) scanf("%d", &c[i]);
    solve(0, 0);
    printf("%lld\n", ans);
    return 0;
}