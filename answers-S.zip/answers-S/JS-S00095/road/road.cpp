#include <bits/stdc++.h>
using namespace std;

int n, m, k;
int mp[10005][10005];
int c[15], a[15][1005];
bool al[15];
int main()
{
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    scanf("%d%d%d", &n, &m, &k);
    memset(mp, 0x3f3f3f3f, sizeof(mp));
    for (int i = 1; i <= m; i++)
    {
        int u, v, w;
        scanf("%d%d%d", &u, &v, &w);
        mp[u][v] = min(mp[u][v], w); 
        mp[v][u] = min(mp[v][u], w);
    }
    for (int i = 1; i <= k; i++)
    {
        scanf("%d", &c[i]);
        for (int j = 1; j <= n; j++) scanf("%d", &a[i][j]);
    }
    priority_queue<int> pq;
    pq.push(1);
    while (!pq.size() == n)
    {
        int top = pq.top();
        int min = 0x3f3f3f3f, op = -1, un;
        for (int i = 1; i <= n; i++)
        {
            if (mp[top][i] <= min && i != top) min = mp[top][i], un = i;
        }
        for (int i = 1; i <= k)
        {
            for (int j = 1; j <= n)
            {
                if (j != top && c[i] + c[i][top] + c[i][j] < min)
                {
                    min = c[i] + c[i][top] + c[i][j];
                    op = i;
                    un = j;
                }
            }
        }
    }
    return 0;
}