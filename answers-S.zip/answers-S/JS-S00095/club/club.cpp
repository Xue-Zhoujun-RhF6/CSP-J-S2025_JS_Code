#include <bits/stdc++.h>
using namespace std;

int n, m[100005][4];
int solve(int c, int m1, int m2, int m3)
{
    int k = m1 + m2 + m3;
    if (k == n) return c;
    k++;
    int ans = 0;
    if (m1 < n / 2) ans = max(ans, solve(c + m[k][1], m1 + 1, m2, m3));
    if (m2 < n / 2) ans = max(ans, solve(c + m[k][2], m1, m2 + 1, m3));
    if (m3 < n / 2) ans = max(ans, solve(c + m[k][3], m1, m2, m3 + 1));
    return ans;
}
int main()
{
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    //cout << "hello world" << endl;
    int t;
    scanf("%d", &t);
    while (t--)
    {
        scanf("%d", &n);
        for (int i = 1; i <= n; i++) scanf("%d%d%d", &m[i][1], &m[i][2], &m[i][3]);
        printf("%d\n", solve(0, 0, 0, 0));
        //cout << 1 << endl;
    }
    return 0;
}
