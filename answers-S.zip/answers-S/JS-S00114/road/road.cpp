#include <bits/stdc++.h>
#define maxn 1000200
#define int long long
using namespace std;
long long tot = 0;
int head[maxn],nxt[maxn],v[maxn],dist[maxn],w[maxn];
bool vis[maxn];
int info[20][maxn];
int cost[maxn];
bool change[20];
int n,m,k;
int tot1 = 0;
int head1[maxn],nxt1[maxn],v1[maxn],w1[maxn];
int res = 0x7f7f7f7f;
void add_edge(int x,int y,int c){
    v[++tot] = y;
    w[tot] = c;
    nxt[tot] = head[x];
    head[x] = tot;
}
void add_edge1(int x,int y,int c){
    v1[++tot1] = y;w1[tot1] = c;
    nxt1[tot1] = head1[x];
    head1[x] = tot1;
}
int process(){
    memcpy(head1,head,sizeof(head));
    memcpy(nxt1,nxt,sizeof(nxt));
    memcpy(v1,v,sizeof(v));
    memcpy(w1,w,sizeof(w));
    tot1 = tot;
    for (int i = 1;i <= k;i++){
        if (change[i]){
            add_edge1(i,n+i,cost[i] + info[i][i]);
            add_edge1(n+i,i,cost[i] + info[i][i]);
            for (int j = 1;j <= n;j++){
                if (j == i)continue;
                add_edge1(n+i,j,info[i][j]);
            }
        }
    }
    memset(dist,0x3f,sizeof(dist));
    memset(vis,0,sizeof(vis));
    int ans = 0;
    priority_queue <pair<int,int>> q;
    dist[1] = 0;
    q.push(make_pair(0,1));
    while (!q.empty()){
        int point = q.top().second;
        q.pop();
        if (vis[point]) continue;
        vis[point] = true;
        for (int i = head1[point];i;i = nxt1[i]){
            int y = v1[i];
            if (!vis[y] && dist[y] > w1[i]){
                dist[y] = w1[i];
                q.push(make_pair(-dist[y],y));
            }
        }
    }
    for (int i = 1;i <= n+k;i++){
        if (dist[i] != dist[0]) ans += dist[i];
    }
    return ans;
}
void dfs(int point){
    if (point > k){
        int val = process();
        res = min(res,val);
        return;
    }
    dfs(point+1);
    change[point] = 1;
    dfs(point+1);
    change[point] = 0;
    process();
}
signed main(){
    memset(head,0,sizeof(head));
    memset(nxt,0,sizeof(nxt));
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin >> n >> m >> k;
    for (int i = 0;i < m;i++){
        int x = 0,y = 0,c = 0;
        cin >> x >> y >> c;
        add_edge(x,y,c);add_edge(y,x,c);
    }
    for (int i = 1;i <= k;i++){
        cin >> cost[i];
        for (int j = 1;j <= n;j++) cin >> info[i][j];
    }
    dfs(1);
    cout << res << endl;
    return 0;
}
