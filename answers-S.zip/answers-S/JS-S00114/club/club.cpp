#include <bits/stdc++.h>
#define maxn 100010
using namespace std;
int val[maxn][5];
int dp[maxn][5][6];
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin >> t;
    for (int k = 0;k < t;k++){
        memset(val,0,sizeof(val));
        memset(dp,0,sizeof(dp));
        int n;
        cin >> n;
        for (int i = 1;i <= n;i++){
            cin >> val[i][1] >> val[i][2] >> val[i][3];
        }
        int limit = n/2;
        for(int i = 1;i <= n;i++){
            if(dp[i-1][1][1] < limit){
                if (dp[i-1][1][5] + val[i][1] > dp[i][1][5]){
                    dp[i][1][5] = dp[i-1][1][5] + val[i][1];
                    dp[i][1][1] = dp[i-1][1][1] + 1;
                    dp[i][1][2] = dp[i-1][1][2];dp[i][1][3] = dp[i-1][1][3];
                }
            }
            if(dp[i-1][2][1] < limit){
                if (dp[i-1][2][5] + val[i][1] > dp[i][1][5]){
                    dp[i][1][5] = dp[i-1][2][5] + val[i][1];
                    dp[i][1][1] = dp[i-1][2][1] + 1;
                    dp[i][1][2] = dp[i-1][2][2];dp[i][1][3] = dp[i-1][2][3];
                }
            }
            if(dp[i-1][3][1] < limit){
                if (dp[i-1][3][5] + val[i][1] > dp[i][1][5]){
                    dp[i][1][5] = dp[i-1][3][5] + val[i][1];
                    dp[i][1][1] = dp[i-1][3][1] + 1;
                    dp[i][1][2] = dp[i-1][3][2];dp[i][1][3] = dp[i-1][3][3];
                }
            }

            if(dp[i-1][1][2] < limit){
                if (dp[i-1][1][5] + val[i][2] > dp[i][2][5]){
                    dp[i][2][5] = dp[i-1][1][5] + val[i][2];
                    dp[i][2][2] = dp[i-1][1][2] + 1;
                    dp[i][2][1] = dp[i-1][1][1];dp[i][2][3] = dp[i-1][1][3];
                }
            }
            if(dp[i-1][2][2] < limit){
                if (dp[i-1][2][5] + val[i][2] > dp[i][2][5]){
                    dp[i][2][5] = dp[i-1][2][5] + val[i][2];
                    dp[i][2][2] = dp[i-1][2][2] + 1;
                    dp[i][2][1] = dp[i-1][2][1] + 1;dp[i][2][3] = dp[i-1][2][3];
                }
            }
            if(dp[i-1][3][2] < limit){
                if (dp[i-1][3][5] + val[i][2] > dp[i][2][5]){
                    dp[i][2][5] = dp[i-1][3][5] + val[i][2];
                    dp[i][2][2] = dp[i-1][3][2] + 1;
                    dp[i][2][1] = dp[i-1][3][1];dp[i][2][3] = dp[i-1][3][3];
                }
            }

            if(dp[i-1][1][3] < limit){
                if (dp[i-1][1][5] + val[i][3] > dp[i][3][5]){
                    dp[i][3][5] = dp[i-1][1][5] + val[i][3];
                    dp[i][3][3] = dp[i-1][1][3] + 1;
                    dp[i][3][2] = dp[i-1][1][2];dp[i][3][1] = dp[i-1][1][1];
                }
            }
            if(dp[i-1][2][3] < limit){
                if (dp[i-1][2][5] + val[i][3] > dp[i][3][5]){
                    dp[i][3][5] = dp[i-1][2][5] + val[i][3];
                    dp[i][3][3] = dp[i-1][2][3] + 1;
                    dp[i][3][2] = dp[i-1][2][2];dp[i][3][1] = dp[i-1][2][1];
                }
            }
            if(dp[i-1][3][3] < limit){
                if (dp[i-1][3][5] + val[i][3] > dp[i][3][5]){
                    dp[i][3][5] = dp[i-1][3][5] + val[i][3];
                    dp[i][3][3] = dp[i-1][3][3] + 1;
                    dp[i][3][2] = dp[i-1][3][2];dp[i][3][1] = dp[i-1][3][1];
                }
            }
            cout << dp[i][1][5] << " " << dp[i][2][5] << " " << dp[i][3][5] << endl;
        }
        cout << max(dp[n][1][5],max(dp[n][2][5],dp[n][3][n])) << endl;
    }
    return 0;
}
