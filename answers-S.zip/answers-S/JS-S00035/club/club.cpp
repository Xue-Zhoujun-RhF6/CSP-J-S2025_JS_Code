#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
int a[maxn][4];
int b[maxn][4];
struct person
{
    int id,w1,w2,n1,n2,n3;
}p[maxn];
bool cmp1(int a,int b)
{
    return a>b;
}
bool cmp2(person a,person b)
{
    return a.w1<b.w1;
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin >> t;
    while(t--)
    {
        for(int i=1;i<=maxn;i++)
            p[i].id=p[i].w1=p[i].w2=p[i].n1=p[i].n2=p[i].n3=0;
        int n;
        cin >> n;
        int nx=0,ny=0,nz=0;
        long long ans=0;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=3;j++)
            {
                cin >> a[i][j];
                b[i][j]=a[i][j];
            }
            sort(b[i]+1,b[i]+4,cmp1);
            p[i].w1=b[i][1]-b[i][2];
            p[i].w2=b[i][2]-b[i][3];
            p[i].id=i;
            ans+=b[i][1];
            if(b[i][1]==a[i][1])
            {
                nx++;
                p[i].n1=1;
            }
            else if(b[i][1]==a[i][2])
            {
                ny++;
                p[i].n1=2;
            }
            else
            {
                nz++;
                p[i].n1=3;
            }
            if(b[i][2]==a[i][1])
                p[i].n2=1;
            else if(b[i][2]==a[i][2])
                p[i].n2=2;
            else
                p[i].n2=3;
            if(b[i][3]==a[i][1])
                p[i].n3=1;
            else if(b[i][3]==a[i][2])
                p[i].n3=2;
            else
                p[i].n3=3;
        }
        sort(p+1,p+n+1,cmp2);
        if(nx>n/2)
        {
            for(int i=1;i<=n;i++)
            {
                if(p[i].n1!=1)
                    continue;
                if(nx==n/2)
                    break;
                ans-=p[i].w1;
                if(p[i].n2==2)
                    ny++;
                else
                    nz++;
                nx--;
            }
            if(ny>n/2)
            {
                for(int i=1;i<=n;i++)
                {
                    if(p[i].n2!=2)
                        continue;
                    if(ny==n/2)
                        break;
                    ans-=p[i].w2;
                    nz++;
                    ny--;
                }
            }
            else if(nz>n/2)
            {
                for(int i=1;i<=n;i++)
                {
                    if(p[i].n2!=3)
                        continue;
                    if(nz==n/2)
                        break;
                    ans-=p[i].w2;
                    ny++;
                    nz--;
                }
            }
        }
        else if(ny>n/2)
        {
            for(int i=1;i<=n;i++)
            {
                if(p[i].n1!=2)
                    continue;
                if(ny==n/2)
                    break;
                ans-=p[i].w1;
                if(p[i].n2==1)
                    nx++;
                else
                    nz++;
                ny--;
            }
            if(nx>n/2)
            {
                for(int i=1;i<=n;i++)
                {
                    if(p[i].n2!=1)
                        continue;
                    if(nx==n/2)
                        break;
                    ans-=p[i].w2;
                    nz++;
                    nx--;
                }
            }
            else if(nz>n/2)
            {
                for(int i=1;i<=n;i++)
                {
                    if(p[i].n2!=3)
                        continue;
                    if(nz==n/2)
                        break;
                    ans-=p[i].w2;
                    nx++;
                    nz--;
                }
            }
        }
        else if(nz>n/2)
        {
            for(int i=1;i<=n;i++)
            {
                if(p[i].n1!=3)
                    continue;
                if(nz==n/2)
                    break;
                ans-=p[i].w1;
                if(p[i].n2==2)
                    ny++;
                else
                    nx++;
                nz--;
            }
            if(ny>n/2)
            {
                for(int i=1;i<=n;i++)
                {
                    if(p[i].n2!=2)
                        continue;
                    if(ny==n/2)
                        break;
                    ans-=p[i].w2;
                    nx++;
                    ny--;
                }
            }
            else if(nx>n/2)
            {
                for(int i=1;i<=n;i++)
                {
                    if(p[i].n2!=1)
                        continue;
                    if(nx==n/2)
                        break;
                    ans-=p[i].w2;
                    ny++;
                    nx--;
                }
            }
        }
        cout << ans << endl;
    }
    return 0;

}
