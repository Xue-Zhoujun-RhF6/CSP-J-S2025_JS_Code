#include<bits/stdc++.h>
using namespace std;
const int maxn=510;
const int mod=998244353;
int num;
long long ans;
bool s[maxn],c[maxn];
int cnt[maxn];
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;
    string s1;
    cin >> n >> m;
    cin >> s1;
    for(int i=0;i<n;i++)
        s[i+1]=s1[i]-'0';
    for(int i=1;i<=n;i++)
        cin >> c[i];
    for(int i=1;i<=n;i++)
        if(s[i]==1)
            num++;
    for(int i=1;i<=n;i++)
    {
        if(s[i]==0)
            cnt[i]++;
        cnt[i]+=cnt[i-1];
    }
    if(num<m)
    {
        cout << "0";
        return 0;
    }
    if(num==n)
    {
        ans=1;
        for(int i=1;i<=n;i++)
        {
            ans=ans*i%mod;
            ans%=mod;
        }
        cout << ans;
        return 0;
    }
    if(n==1)
    {
        if(c[1]==0)
            cout << 0;
        else
            cout << 1;
    }
    else if(n==2)
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(i==j)
                    continue;
                if(cnt[2]<c[j])
                    ans++;
            }
        }
    }
    else if(n==3)
    {
        for(int i1=1;i1<=n;i1++)
        {
            for(int i2=1;i2<=n;i2++)
            {
                for(int i3=1;i3<=n;i3++)
                {
                    if(i1==i2)
                        continue;
                    if(i2==i3)
                        continue;
                    if(i1==i3)
                        continue;
                    if(cnt[1]<c[i2] && cnt[2]<c[i3])
                    {
                        ans++;
                    }

                }
            }
        }
    }
    if(m==1)
    {
        int x=0;
        for(int i=1;i<=n;i++)
        {
            if(n-cnt[i]==1)
            {
                for(int j=1;j<=n;j++)
                {
                    if(c[j]>cnt[i])
                        x++;
                }
                ans=1;
                for(int j=1;j<n;j++)
                {
                    ans=ans*j%mod;
                }
                ans%=mod;
                ans*=x;
                ans%=mod;
                break;
            }
        }
    }
    cout << ans;
    return 0;
}
