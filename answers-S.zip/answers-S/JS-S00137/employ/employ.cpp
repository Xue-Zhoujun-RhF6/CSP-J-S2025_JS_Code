#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int n,m;
string s;
int c[505];
int f[505],b[505];
int jc(int x){
    int sum=1;
    while(x>0){

        sum=sum*x%mod;
        x--;
    }
    return sum;
}
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++){
        cin>>c[i];
        b[c[i]]++;
    }

        cout<<jc(n);




    return 0;
}
