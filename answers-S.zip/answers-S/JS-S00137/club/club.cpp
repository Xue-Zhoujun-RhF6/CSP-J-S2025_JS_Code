#include<bits/stdc++.h>
using namespace std;

int t;
int n;
struct node{
    int a,b,c;
}s[100005];
bool cmp(node x,node y){
    return x.a>y.a;
}
bool cmp2(node x,node y){
    if(x.a==y.a) return x.b<y.b;
    return x.a>y.a;
}
int dp[205][105][105][105];
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin>>t;
    while(t--){

        cin>>n;
        int fc=0;
        int fb=0;
        for(int i=1;i<=n;i++){
            cin>>s[i].a>>s[i].b>>s[i].c;
            if(s[i].c!=0)fc=1;
            if(s[i].b!=0)fb=1;;
        }
        if(fc==0&&fb==0&&n>201){
            int ans=0;
            sort(s+1,s+1+n,cmp);
            for(int i=1;i<=n/2;i++){
                ans+=s[i].a;
            }
            cout<<ans<<endl;
            continue;
        }
        else if(fc==0&&fb!=0&&n>201){
            sort(s+1,s+1+n,cmp2);
            int ans=0;
            for(int i=1;i<=n/2;i++){
                ans+=s[i].a;
            }
            for(int i=n/2+1;i<=n;i++){
                ans+=s[i].b;
            }
            cout<<ans<<endl;
            continue;
        }
        for(int i=1;i<=n;i++){
            for(int j=0;j<=i;j++){
                for(int k=0;k<=i;k++){
                    if(i-k-j<0) continue;
                        dp[i][j][k][i-j-k]=0;

                }

            }
        }
        dp[1][1][0][0]=s[1].a;
        dp[1][0][1][0]=s[1].b;
        dp[1][0][0][1]=s[1].c;
        for(int i=2;i<=n;i++){
            for(int j=0;j<=n/2;j++){
                for(int k=0;k<=n/2;k++){
                    if(i-j-k>n/2) continue;
                    if(j!=0){
                        dp[i][j][k][i-j-k]=max(dp[i][j][k][i-j-k],dp[i-1][j-1][k][i-j-k]+s[i].a);
                    }
                    if(k!=0){
                        dp[i][j][k][i-j-k]=max(dp[i][j][k][i-j-k],dp[i-1][j][k-1][i-j-k]+s[i].b);
                    }
                    if(i-k-j!=0){
                        dp[i][j][k][i-j-k]=max(dp[i][j][k][i-j-k],dp[i-1][j][k][i-j-k-1]+s[i].c);
                    }
                }
            }
        }
        int ans=0;
        for(int i=0;i<=n/2;i++){
            for(int j=0;j<=n/2;j++){
                int k=n-i-j;
                if(k>n/2) continue;
                ans=max(ans,dp[n][i][j][k]);
            }
        }
        cout<<ans<<endl;

    }

    return 0;
}
//pts<=60
