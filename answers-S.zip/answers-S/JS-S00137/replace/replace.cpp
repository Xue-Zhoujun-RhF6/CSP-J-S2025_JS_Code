#include<bits/stdc++.h>
using namespace std;
int n,q;

string s1,s2;
string t1,t2;
map<pair<string,string>,int> mp;
int ans=0;
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>s1>>s2;
        mp[{s1,s2}]++;
    }
    for(int i=1;i<=q;i++){
        ans=0;
        cin>>t1>>t2;
        int m=t1.size();
        int l=0,r=m-1;
        while(t1[l]==t2[l]&&l<m) l++;
        while(t1[r]==t2[r]&&r>=0) r--;
        int ll=l,rr=r;
        for(int l=ll;l>=0;l--){
            for(int r=rr;r<m;r++){
                string a=t1.substr(l,r-l+1);
                string b=t2.substr(l,r-l+1);
                ans+=mp[{a,b}];
            }
        }
        cout<<ans<<endl;

    }

    return 0;
}
