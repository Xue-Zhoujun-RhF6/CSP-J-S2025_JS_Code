#include<bits/stdc++.h>
using namespace std;
#define pi pair<int,int>
#define int long long
int n,m,k;
int u,v,w;
struct node{
    int u,v,w;
};
vector<node> e;
int c[15];
int a[15][10005];
int d[10055];
bool vis[10055];
int fa[10055];
bool cmp(node x,node y){
    return x.w<y.w;
}
int find(int x){
    return (fa[x]==x?x:fa[x]=find(fa[x]));
}
int ans=0;
void p(){
    for(auto g:e){
        int u=g.u;
        int v=g.v;
        int w=g.w;
        int fu=find(u);
        int fv=find(v);
        if(fu!=fv){
            fa[fu]=fv;
            ans+=w;
        }
    }
}

signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>m>>k;
    for(int i=1;i<=n+k;i++){
        fa[i]=i;

    }
    for(int i=1;i<=m;i++){
        cin>>u>>v>>w;
        e.push_back({u,v,w});
    }

    for(int i=1;i<=k;i++){
        cin>>c[i];
        for(int j=1;j<=n;j++){
            cin>>a[i][j];
            if(c[i]==0){
                e.push_back({j,n+i,a[i][j]});

            }
        }
    }
    sort(e.begin(),e.end(),cmp);
    p();
    cout<<ans;
    return 0;
}
//pts50~~60
