#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,q,ls[200005];
string s1[200005],s2[200005],t1,t2;
int main()
{
	freopen("replace.in","r",stdin);
	freopen("replace.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++)
	{
		cin>>s1[i]>>s2[i];
		ls[i]=s1[i].size();
	}
	while(q--)
	{
		cin>>t1>>t2;
		int lt=t1.size();
		ll ans=0;
		for(int i=1;i<=n;i++)
		{
			int x=0,b=0;
			for(int j=0;j<lt;j++)
			{
				if(t1[j]==s1[i][x])
				{
					if(x==0)	b=j;
					x++;
					if(x==ls[i])
					{
						x=0;
						bool f=1;
						for(int k=0;k<ls[i];k++)
							if(t2[k+j-ls[i]+1]!=s2[i][k])
							{
								f=0;
								break;
							}
						for(int k=0;k<j-ls[i]+1;k++)	
							if(t1[k]!=t2[k])
							{
								f=0;
								break;
							}
						for(int k=j+1;k<lt;k++)	
							if(t1[k]!=t2[k])
							{
								f=0;
								break;
							}	
						if(f)	ans++;
						x=0;
						j=b;
					}
				}
				else
				{
					x=0;
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
