#include<bits/stdc++.h>
using namespace std;
#define ll long long
int T,n,m,a[4][100005],b[100005];
ll ans;
int main()
{
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	cin>>T;
	for(int p=1;p<=T;p++)
	{
		cin>>n;
		m=n/2;
		int d[9],x=0,xx=0,y=0,c=0;
		memset(b,0,100004);
		for(int i=1;i<=7;i++)	d[i]=0;
		ans=0;
		for(int i=1;i<=n;i++)
		{
			x=0;
			for(int j=1;j<=3;j++)	
			{
				cin>>a[j][i];
				x=max(x,a[j][i]);
			}
			if(x==a[1][i]&&x!=a[2][i]&&x!=a[3][i])	d[1]++,b[i]=1;
			if(x!=a[1][i]&&x==a[2][i]&&x!=a[3][i])	d[2]++,b[i]=2;
			if(x!=a[1][i]&&x!=a[2][i]&&x==a[3][i])	d[3]++,b[i]=3;
			if(x==a[1][i]&&x==a[2][i]&&x!=a[3][i])	d[4]++;
			if(x==a[1][i]&&x!=a[2][i]&&x==a[3][i])	d[5]++;
			if(x!=a[1][i]&&x==a[2][i]&&x==a[3][i])	d[6]++;
			if(x==a[1][i]&&x==a[2][i]&&x==a[3][i])	d[7]++;
			ans=ans+x;
		}
		if(d[1]<=m&&d[2]<=m&&d[3]<=m)	
		{
			cout<<ans<<endl;
			continue;
		}
		if(d[1]>m)	y=d[1]-m,c=1;
		if(d[2]>m)	y=d[2]-m,c=2;
		if(d[3]>m)	y=d[3]-m,c=3;
		int lg[d[c]+5],gg=0;
		for(int i=1;i<=n;i++)
		{
			if(b[i]==c)
			{
				xx=0;
				x=a[c][i];
				xx=max(xx,a[(c-1+1)%3+1][i]);
				xx=max(xx,a[(c-1+2)%3+1][i]);
				lg[++gg]=x-xx;
			}
		}
		sort(lg+1,lg+gg+1);
		for(int i=1;i<=y;i++)	ans-=lg[i];
		cout<<ans<<endl;
	}
	return 0;
}
