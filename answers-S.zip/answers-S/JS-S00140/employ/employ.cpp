#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll n,m,Mod=998244353,c[600];
string s;
ll ans=0;
int main()
{
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	cin>>n>>m;
	cin>>s;
	for(int i=1;i<=n;i++)	cin>>c[i];
	if(m==1)
	{
		int lg=0;
		for(int i=0;i<n;i++)	
			if(s[i]=='1')	
			{
				lg=i+1;
				break;
			}
		cout<<lg<<endl;
		for(int i=1;i<=n;i++)	if(c[i]>=lg)	ans++;
		cout<<ans<<endl;
		for(int i=n-1;i>=2;i--)	ans=(ans*i)%Mod;
		lg=n-lg;
		cout<<ans<<endl;
		return 0;
	}
	
	return 0;
}
