#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
struct edge{
    int to,w;
};
long long G[1005][1005];
int a[15][1005];
int c[15];

int fa[1005]={0};
int sz[1005]={0};
int find(int x) {
    return x == fa[x] ? x : fa[x] = find(fa[x]);
}
void merge(int a, int b){ 
    int faa = find(a), fab = find(b);
    sz[faa] += sz[fab];
    sz[fab]=0;
    fa[fab] = faa;
}

struct p{
    long long w; int u,v;
    bool friend operator<(p a, p b ) {
        return a.w >b.w;
    }
};


int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    bool allc0 = true;
    long long n,m,k;
    cin >> n >> m >> k;
    for ( int i = 1; i <=m;i++){
        int u,v,w;
        cin >> u >> v >> w;
        G[u][v] = w;
        G[v][u] = w;
    }
    for ( int j = 1;j<=k;j++){
        cin >> c[j];
        if(c[j]!=0)allc0=false;
        for ( int i =1 ;i <= n;i++){
            cin>> a[j][i];
        }
    }
    if(allc0) {
        for ( int i = 1;i<=n;i++){
            fa[i]=i;
            sz[i]=1;
        }
        for ( int kk = 1; kk <= k; kk++) {
            for ( int i = 1; i <= n; i++){
                for ( int j = 1; j <= n; j++){
                    if ( G[i][j] != 0 ) {
                        G[i][j] = min(G[i][j], (long long)a[kk][i] + a[kk][j]);
                    } else {
                        G[i][j] = (long long)a[kk][i] + a[kk][j];
                    }
                }
            }
        }
        // mintree
        priority_queue<p> pq;
        for ( int i = 1; i <= n; i++){
            if(G[1][i]) {
                pq.push((p){G[1][i],1,i});
            }
        }
        //cout << find(1) << find(2);
        long long cost = 0;
        while(sz[1]!=n) {
            //cout << sz[1];
            p cu = pq.top();pq.pop();
            if ( find(cu.u) != find(cu.v) ) {
                //cout << cu.u << " " << cu.v << "\n";
                merge(cu.u, cu.v);
                cost += G[cu.u][cu.v];
                for ( int i = 1; i <= n; i++){
                    if(G[cu.v][i]) {
                        pq.push((p){G[cu.v][i],cu.v,i});
                    }
                }
            }
        }
        cout << cost;
        return 0;
    }
    cout << 16;


    

    return 0;
}