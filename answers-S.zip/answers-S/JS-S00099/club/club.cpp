#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
struct myd{
    int d1, d2, d3;
};

struct dpt{
    long long cost;
    int st1,st2,st3;
};

int st1=0,st2=0,st3=0,n2;
bool tb = true;

bool cmp1(myd m1, myd m2) {
    if ( max({m1.d1,m1.d2,m1.d3}) > max({m2.d1,m2.d2,m2.d3})) {
        return true;
    } else {
        return false;
    }
    return true;
    // return max({abs(m1.d1-m1.d2),abs(m1.d1-m1.d3),abs(m1.d2-m1.d3)})>max({abs(m2.d1-m2.d2),abs(m2.d1-m2.d3),abs(m2.d2-m2.d3)});
}

bool cmptb(myd m1, myd m2) {
    return abs(m1.d1-m1.d2)>abs(m2.d1-m2.d2);
}


int whichst(myd m) { //
    // int mm = max({m.d1,m.d2,m.d3});
    // if ( st1 < n2 && m.d1 == mm && m.d2 != mm && m.d3 != mm) {
    //     return 1;
    // }
    // if ( st2 < n2 && m.d1 != mm && m.d2 == mm && m.d3 !=mm){
    //     return 2;
    // }
    // if ( st3 < n2 &&m.d1 != mm && m.d2 != mm && m.d3 == mm ) {
    //     return 3;
    // }
    // if ( m.d1 == mm && m.d2 == mm && m.d3 != mm) {
    //     if ( st1 >= n2) return 2;
    //     if ( st2 >= n2) return 1;
    //     return st1 < st2 ? 1: 2;
    // }
    // if( m.d1 != mm && m.d2 == mm && m.d3 == mm){
    //     if ( st2 >= n2) return 3;
    //     if ( st3 >= n2) return 2;
    //     return st2 < st3 ? 2 : 3;
    // }
    // if ( m.d1 == mm && m.d2 != mm && m.d3 == mm){
    //     return st1 < st3? 1:3;
    // }
    // if ( st1 < st2 && st1 < st3) return 1;
    // if ( st2 < st1 && st2 < st3 )return 2;
    // if ( st3 < st1 && st3 < st2)return 3;
    // if ( st1 == st2 && st2 < st3) return 1;
    // if ( st2 == st3 && st2 < st3) return 1;
    int d1 = m.d1, d2 = m.d2, d3=m.d3;

    if (tb){
        if ( d1 > d2 && st1 < n2) {
            return 1;
        } else {
            return 2;
        }
        if ( d2 > d1 && st2 < n2) {
            return 2;
        } else {
            return 1;
        }
        if (d1==d2)return st1<st2?1:2;
    }


    if ( d1 > d2 && d1 > d3) {
        if(st1<n2) return 1;
        if ( d2 == d3) return st2 < st3 ? 2 : 3;
        return d2 > d3 ? 2 : 3;
    } 
    if ( d2 > d1 && d2 > d3){
        if ( st2 < n2) return 2;
        if ( d1 == d3) return st1 < st3 ? 1: 3;
        return d1 > d3 ? 1:3;
    }
    if ( d3 > d1 && d3 > d2) {
        if ( st3 < n2) return 3;
        if ( d1 == d2 ) return st1 < st2? 1:2;
        return d1 > d2 ? 1: 2; 
    }
    if ( d1 == d2 && d1 > d3) {
        if ( st1 < n2 && st2 < n2)return st1 < st2? 1:2;
        if ( st1 == n2) return 2;
        return 1;
    }
    if ( d1 == d3 && d1 > d2 ) {
        if ( st1 < n2 && st3 < n2)return st1 < st3? 1:3;
        if ( st1 == n2) return 3;
        return 1;
    }
    if ( d2 == d3 && d2 > d1) {
        if ( st2 < n2 && st3 < n2) return st2 < st3?2:3;
        if ( st2==n2)return 3;
        return 2;
    }
    if ( d1 == d2 && d2 == d3) {
        if ( st1 != n2 && st1 < st2 && st1 < st3) return 1;
        if ( st1 == n2 && st1 < st2 && st1 < st3) return st2 < st3 ? 2:3;
        if ( st2 != n2 && st2 < st1 && st2 < st3) return 2;
        if ( st2 == n2 && st2 < st1 && st2 < st3) return st1 < st3?1:3;
        if ( st3 != n2 && st3 < st1 && st3 < st2) return 3;
        if ( st3 == n2 && st3 < st1 && st3 < st2) return st2<st3?2:3;
        if ( st1 == st2 && st1 > st3) return 3;
        if ( st1 == st2 && st1 < st3) return 1;
        if ( st2==st3 && st2 > st1)return 1;
        if ( st2==st3 && st2 < st1)return 2;
        if ( st1==st3 && st1>st2)return 2;
        if ( st1==st3 && st1<st2)return 1;
        if (st1==st2&&st2==st3)return 1;
    }
    if(st1 == n2) return 2;
    return 1;
} 

dpt maxdpt(dpt myd1, dpt myd2) {
    if ( myd1.cost >= myd2.cost) return myd1;
    return myd2;
}

vector<myd> myds;
int n;
long long cost =0, maxcost = 0;
void dfs(int i, int st, long long cost){
    if ( i == n ) {
        maxcost = max(cost,maxcost);
        return;
    }
    if(st==1)st1++;
    if(st==2)st2++;
    if(st==3)st3++;
    if(st1<n2)dfs(i+1,1,cost+((i+1!=n)?myds[i+1].d1:0));
    if(st2<n2)dfs(i+1,2,cost+((i+1!=n)?myds[i+1].d2:0));
    if(st3<n2)dfs(i+1,3,cost+((i+1!=n)?myds[i+1].d3:0));
    if(st==1)st1--;
    if(st==2)st2--;
    if(st==3)st3--;
}


int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    int t;
    cin >> t;
    while(t--){
        // myd myds[100005];
        myds.clear();cost=maxcost=0;
        tb = true;
        cin >> n;

        for ( int i = 0; i < n; i++) {
            myd myd11;
            cin >> myd11.d1 >> myd11.d2 >> myd11.d3;
            if(myd11.d3!=0)tb = false;
            myds.push_back(myd11);
        }
        n2 = n / 2;        
        int p=0;
        unsigned long long cost = 0;
        st1=0,st2=0,st3=0;

        

        if ( n <= 10 ) {
            dfs(0,1,myds[0].d1);dfs(0,2,myds[0].d2);dfs(0,3,myds[0].d3);
            cout << maxcost << "\n";
            continue;
        }



        if(tb){
            sort(myds.begin(),myds.end(),cmptb);
            while (p!=n){
                myd cmyd=myds[p];
                int pl = whichst(cmyd);
                if(pl==1){
                    cost += cmyd.d1;
                    st1++;
                } else if(pl==2) {cost+=cmyd.d2;st2++;}
                else {cost += cmyd.d3;st3++;}
                p++;
            }
            cout << cost << "\n";
            continue;
        }


        
        //         unsigned long long maxcost = 0;
        // dp[0][1] = {myds[0].d1,1,0,0};
        // dp[0][2] = {myds[0].d2,0,1,0};
        // dp[0][3] = {myds[0].d3,0,0,1};
        // for ( int i = 1 ;i < n;i++){
        //     if ( dp[i-1][1].st1<n2) {
        //         maxcost = max(maxcost,dp[i-1][1].cost+myds[i].d1);
        //         dp[i][1] = maxdpt(
        //             {dp[i-1][1].cost+myds[i].d1,dp[i-1][1].st1+1,dp[i-1][1].st2,dp[i-1][1].st3},
        //             dp[i][1]
        //         );
        //     }
        //     if ( dp[i-1][1].st2<n2) {
        //         maxcost = max(maxcost,dp[i-1][1].cost+myds[i].d2);
        //         dp[i][2] = maxdpt(
        //             {dp[i-1][1].cost+myds[i].d2,dp[i-1][1].st1,dp[i-1][1].st2+1,dp[i-1][1].st3},
        //             dp[i][2]
        //         );
        //     }
        //     if ( dp[i-1][1].st3<n2) {
        //         maxcost = max(maxcost,dp[i-1][1].cost+myds[i].d3);
        //         dp[i][3] = maxdpt(
        //             {dp[i-1][1].cost+myds[i].d3,dp[i-1][1].st1,dp[i-1][1].st2,dp[i-1][1].st3+1},
        //             dp[i][3]
        //         );
        //     }
        //     //////////////////////
        //     if ( dp[i-1][2].st1<n2) {
        //         maxcost = max(maxcost,dp[i-1][2].cost+myds[i].d1);
        //         dp[i][1] = maxdpt(
        //             {dp[i-1][2].cost+myds[i].d1,dp[i-1][2].st1+1,dp[i-1][2].st2,dp[i-1][2].st3},
        //             dp[i][1]
        //         );
        //     }
        //     if ( dp[i-1][2].st2<n2) {
        //         maxcost = max(maxcost,dp[i-1][2].cost+myds[i].d2);
        //         dp[i][2] = maxdpt(
        //             {dp[i-1][2].cost+myds[i].d2,dp[i-1][2].st1,dp[i-1][2].st2+1,dp[i-1][2].st3},
        //             dp[i][2]
        //         );
        //     }
        //     if ( dp[i-1][2].st3<n2) {
        //         maxcost = max(maxcost,dp[i-1][2].cost+myds[i].d3);
        //         dp[i][3] = maxdpt(
        //             {dp[i-1][2].cost+myds[i].d3,dp[i-1][2].st1,dp[i-1][2].st2,dp[i-1][2].st3+1},
        //             dp[i][3]
        //         );
        //     }
        //     ///////////////////////////
        //     if ( dp[i-1][3].st1<n2) {
        //         maxcost = max(maxcost,dp[i-1][3].cost+myds[i].d1);
        //         dp[i][1] = maxdpt(
        //             {dp[i-1][3].cost+myds[i].d1,dp[i-1][3].st1+1,dp[i-1][3].st2,dp[i-1][3].st3},
        //             dp[i][1]
        //         );
        //     }
        //     if ( dp[i-1][3].st2<n2) {
        //         maxcost = max(maxcost,dp[i-1][3].cost+myds[i].d2);
        //         dp[i][2] = maxdpt(
        //             {dp[i-1][3].cost+myds[i].d2,dp[i-1][3].st1,dp[i-1][3].st2+1,dp[i-1][3].st3},
        //             dp[i][2]
        //         );
        //     }
        //     if ( dp[i-1][3].st3<n2) {
        //         maxcost = max(maxcost,dp[i-1][3].cost+myds[i].d3);
        //         dp[i][3] = maxdpt(
        //             {dp[i-1][3].cost+myds[i].d3,dp[i-1][3].st1,dp[i-1][3].st2,dp[i-1][3].st3+1},
        //             dp[i][3]
        //         );
        //     }
        // }
        // cout << max({dp[n-1][1].cost, dp[n-1][2].cost, dp[n-1][3].cost,maxcost}) << "\n";
        sort(myds.begin(),myds.end(),cmp1);




        while (p!=n){
            myd cmyd=myds[p];
            int pl = whichst(cmyd);
            if(pl==1){
                cost += cmyd.d1;
                st1++;
            } else if(pl==2) {cost+=cmyd.d2;st2++;}
            else {cost += cmyd.d3;st3++;}
            p++;
        }
        cout << cost << "\n";
    

    }

    return 0;
}