include<bits/stdc++.h>
using namespace std;
int n,m,k;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin >> n >> m >> k;
    cout << "辛苦了！"<< endl
    return 0;
}
