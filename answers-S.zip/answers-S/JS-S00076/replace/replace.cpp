include<bits/stdc++.h>
using namespace std;
int n,m,k;
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin >> n >> m >> k;
    cout << "辛苦了！"<< endl
    return 0;
}
