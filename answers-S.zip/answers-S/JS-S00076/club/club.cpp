include<bits/stdc++.h>
using namespace std;
struct node{
    int a1;
    int a2;
    int a3;
}a[31];
int n,t;
int a1,a2,a3;
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin >> t;
    while(t--){
        cin >> n;
        for(int j = 0;j < n;++j){
            cin >> a[j].a1 >> a[j].a2 >> a[j].a3;
            int x = max(a[j].a1,max(a[j].a2,a[j].a3))
            int y += x;
        }
    }
    cout << y;
}
