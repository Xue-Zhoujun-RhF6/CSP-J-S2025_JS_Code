#include <bits/stdc++.h>
using namespace std;
template <typename T>
void readi(T &x)
{
    T f = 1;
    x = 0;
    int ch;
    while (ch = getchar(), !feof(stdin) && ch != '-' && !isdigit(ch))
        ;
    if (ch == '-')
        f = -f, ch = getchar();
    while (!feof(stdin) && isdigit(ch))
    {
        x = (x << 3) + (x << 1) + ch - '0';
        ch = getchar();
    }
    x *= f;
}

void readl(){};

template <typename T, typename... Args>
void readl(T &t, Args &...args)
{
    readi(t);
    readl(args...);
}

const int MAXN = 1e5 + 7;
int n, sum;
vector<int> decl[4];
int cnta[4], vote[4];
int pre[4] = {0, 3, 1, 2};
int nxt[4] = {0, 2, 3, 1};
int main()
{
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    int T;
    readi(T);
    while (T--)
    {
        readi(n);
        sum = 0;
        decl[1].clear();
        decl[2].clear();
        decl[3].clear();
        cnta[1] = cnta[2] = cnta[3] = 0;
        for (int i = 1; i <= n; i++)
        {
            readl(vote[1], vote[2], vote[3]);
            int max_id;
            if (vote[1] >= vote[2] && vote[1] >= vote[3])
                max_id = 1;
            else if (vote[2] >= vote[3] && vote[2] >= vote[1])
                max_id = 2;
            else
                max_id = 3;
            cnta[max_id]++;
            sum += vote[max_id];
            decl[max_id].push_back(vote[max_id] - max(vote[pre[max_id]], vote[nxt[max_id]]));
        }
        if (cnta[1] > n / 2)
        {
            sort(decl[1].begin(), decl[1].end());
            int res = cnta[1] - n / 2;
            for (int i = 0; i < res; i++)
                sum -= decl[1][i];
        }
        else if (cnta[2] > n / 2)
        {
            sort(decl[2].begin(), decl[2].end());
            int res = cnta[2] - n / 2;
            for (int i = 0; i < res; i++)
                sum -= decl[2][i];
        }
        else if (cnta[3] > n / 2)
        {
            sort(decl[3].begin(), decl[3].end());
            int res = cnta[3] - n / 2;
            for (int i = 0; i < res; i++)
                sum -= decl[3][i];
        }
        printf("%d\n", sum);
    }

    return 0;
}