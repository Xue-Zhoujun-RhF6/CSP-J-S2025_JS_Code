/*
 * Q: All r..ds l..d wh.r.? 
 * A: Rome.
*/

/* 
  I should have reviewed 最小生成树...               
*/

#include <bits/stdc++.h>
using namespace std;
template <typename T>
void readi(T &x)
{
    T f = 1;
    x = 0;
    int ch;
    while (ch = getchar(), !feof(stdin) && ch != '-' && !isdigit(ch))
        ;
    if (ch == '-')
        f = -f, ch = getchar();
    while (!feof(stdin) && isdigit(ch))
    {
        x = (x << 3) + (x << 1) + ch - '0';
        ch = getchar();
    }
    x *= f;
}

void readl(){};

template <typename T, typename... Args>
void readl(T &t, Args &...args)
{
    readi(t);
    readl(args...);
}

typedef unsigned long long ull;
const int MAXN = 1e4 + 7, MAXM = 1e6 + 7, MAXK = 10;
struct P
{
    int v, w;
    P *next;
    P(int _v, int _w, P *_n) : v(_v), w(_w), next(_n) {}
};
P *head[MAXN * 2];
int c[MAXK], vis[MAXN * 2], dis[MAXN * 2];
int n, m, k;
int upgrades;

#define town_to_city(town) (town) + MAXN
#define ttoc(town) town_to_city(town)
#define town_allow(town) ((upgrades >> (town)) & 1)
#define allowed(city) (((city) < MAXN) || town_allow((city)-MAXN))

ull ans = LONG_LONG_MAX, curans;

int cnt_upgrade()
{
    int x = upgrades, ans = 0;
    while (x)
    {
        x -= x & (-x);
        ans++;
    }
    return ans;
}

void Build()
{
    int to_be_include = n + cnt_upgrade();
    memset(vis, 0x00, sizeof(vis));
    memset(dis, 0x7f, sizeof(dis));
    dis[1] = 0;
    priority_queue<pair<int, int>> pq;
    pq.push({0, 1});
    while (pq.size() && to_be_include)
    {
        int d = -pq.top().first, u = pq.top().second;
        pq.pop();
        if (vis[u])
            continue;
        curans += d;
        vis[u] = true;
        to_be_include--;
        for (P *p = head[u]; p; p = p->next)
        {
            if (!allowed(p->v))
                continue;
            if (!vis[p->v] && dis[p->v] > p->w)
            {
                dis[p->v] = p->w;
                pq.push({-p->w, p->v});
            }
        }
    }
}

int main()
{
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    readl(n, m, k);
    for (int i = 0; i < m; i++)
    {
        int u, v, w;
        readl(u, v, w);
        head[u] = new P(v, w, head[u]);
        head[v] = new P(u, w, head[v]);
    }
    for (int i = 0; i < k; i++)
    {
        readi(c[i]);
        for (int j = 1; j <= n; j++)
        {
            int w;
            readi(w);
            head[j] = new P(town_to_city(i), w, head[j]);
            head[town_to_city(i)] = new P(j, w, head[town_to_city(i)]);
        }
    }
    for (upgrades = 0; upgrades < (1 << k); upgrades++)
    {
        curans = 0;
        for (int i = 0; i < k; i++)
            if (town_allow(i))
                curans += c[i];
        Build();
        ans = min(ans, curans);
    }
    printf("%llu\n", ans);
    return 0;
}