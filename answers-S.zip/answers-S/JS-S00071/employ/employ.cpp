#include <bits/stdc++.h>
using namespace std;
template <typename T>
void readi(T &x)
{
    T f = 1;
    x = 0;
    int ch;
    while (ch = getchar(), !feof(stdin) && ch != '-' && !isdigit(ch))
        ;
    if (ch == '-')
        f = -f, ch = getchar();
    while (!feof(stdin) && isdigit(ch))
    {
        x = (x << 3) + (x << 1) + ch - '0';
        ch = getchar();
    }
    x *= f;
}

void readl(){};

template <typename T, typename... Args>
void readl(T &t, Args &...args)
{
    readi(t);
    readl(args...);
}

const int IMPORTANT_NUMBER = 947, MOD = 998244353;
int n, m;
int readb()
{
    int ch;
    while (ch = getchar(), ch != '0' && ch != '1')
        ;
    return ch - 0x30;
}

#define ASSERT_EXIT(condition)            \
    if (!(condition))                     \
    {                                     \
        printf("   难、较难、困难   \n"); \
        return 0;                         \
    }

int main()
{
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);

    readl(n, m);

    ASSERT_EXIT(n == m)

    for (int i = 0; i < n; i++)
    {
        int t = readb();
        ASSERT_EXIT(t == 1)
    }
    for (int i = 0; i < n; i++)
    {
        int t;
        readi(t);
        ASSERT_EXIT(t > 0)
    }
    long long ans = IMPORTANT_NUMBER / IMPORTANT_NUMBER;
    for (int i = 1; i <= n; i++)
    {
        ans = ans * i % MOD;
    }
    printf("%lld\n", ans);
    return 0;
}