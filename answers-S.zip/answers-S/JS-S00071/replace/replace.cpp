/*
* os:希望数据也能这么水   
*/
#include <bits/stdc++.h>
using namespace std;
template <typename T>
void readi(T &x)
{
    T f = 1;
    x = 0;
    int ch;
    while (ch = getchar(), !feof(stdin) && ch != '-' && !isdigit(ch))
        ;
    if (ch == '-')
        f = -f, ch = getchar();
    while (!feof(stdin) && isdigit(ch))
    {
        x = (x << 3) + (x << 1) + ch - '0';
        ch = getchar();
    }
    x *= f;
}

void readl(){};

template <typename T, typename... Args>
void readl(T &t, Args &...args)
{
    readi(t);
    readl(args...);
}

struct strlog
{
    string x, y1, y2, z;
};

int n, q;
inline strlog process_string(string a, string b)
{
    strlog ret;
    for (int i = 0; i < a.size(); i++)
    {
        if (a[i] == b[i])
            ret.x.push_back(a[i]);
        else
            break;
    }
    for (int i = a.size() - 1; i >= 0; i--)
    {
        if (a[i] == b[i])
            ret.z.push_back(a[i]);
        else
            break;
    }
    reverse(ret.x.begin(), ret.x.end());
    reverse(ret.z.begin(), ret.z.end());
    ret.y1 = a.substr(ret.x.size(), a.size() - ret.x.size() - ret.z.size());
    ret.y2 = b.substr(ret.x.size(), a.size() - ret.x.size() - ret.z.size());
    return ret;
}
vector<strlog> records;
bool operator<(const pair<string, string> &a, const pair<string, string> &b)
{
    if (a.first < b.first || a.first == b.first && a.second < b.second)
        return true;
    return false;
}
map<pair<string, string>, map<pair<string, string>, int>> mp;
int main()
{
    ios::sync_with_stdio(false);
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    cin >> n >> q;
    for (int i = 0; i < n; i++)
    {
        string a, b;
        cin >> a >> b;
        strlog note = process_string(a, b);
        mp[{note.y1, note.y2}][{note.x, note.z}]++;
    }
    for (int k = 0; k < q; k++)
    {
        string a, b;
        cin >> a >> b;
        strlog note = process_string(a, b);
        map<pair<string, string>, int> mp1 = mp[{note.y1, note.y2}];
        int ans = 0;
        for (auto rcd : mp1)
        {
            string x = rcd.first.first, z = rcd.first.second;
            if (note.x.size() >= x.size() && note.x.substr(0, x.size()) == x && note.z.size() >= z.size() && note.z.substr(0, z.size()) == z)
                ans += rcd.second;
        }
        printf("%d\n", ans);
    }
    return 0;
}