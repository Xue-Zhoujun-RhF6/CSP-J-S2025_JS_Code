#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=998244353;
int n,m;
string s;
int a[510];
signed main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    cin>>s;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    int ans=1;
    for(int i=1;i<=n;i++){
        ans=(ans%mod*i%mod)%mod;
    }
    cout<<ans<<endl;
    return 0;
}