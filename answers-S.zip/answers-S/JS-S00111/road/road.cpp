#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,k,ans,a[100100];
struct T{
    int l1,l2,co;
}r[1000100];
signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%lld%lld",&m,&n,&k);
    for(int i=1;i<=n;i++){
        a[i]=i;
    }
    for(int i=1;i<=m;i++){
        scanf("%lld%lld%lld",&r[i].l1,&r[i].l2,&r[i].co);
        ans+=r[i].co;
    }
    cout<<ans<<endl;
    return 0;
}