#include<bits/stdc++.h>
#include<stdio.h>
#define int long long
using namespace std;
struct T{
    int cut;
    int id;
};
int t;
int n,a[100100][4];
int dp[210][210][210];
T c[100100];
int f(int np,int fc,int sc){
    // cout<<np<<' '<<fc<<' '<<sc<<"\n";
    if(!dp[np][fc][sc]){  
        if(np>n) return 0;
        int res=-10;
        if(fc<n/2) res=max(res,a[np][1]+f(np+1,fc+1,sc));
        if(sc<n/2) res=max(res,a[np][2]+f(np+1,fc,sc+1));
        if(np-1-fc-sc<n/2) res=max(res,a[np][3]+f(np+1,fc,sc));
        dp[np][fc][sc]=res;
    }
    return dp[np][fc][sc];
}
bool cmp(T x,T y){
    return x.cut>y.cut;
}
void dod(){
    memset(a,0,sizeof(a));
    memset(c,0,sizeof(c));
    memset(dp,0,sizeof(dp));
    scanf("%lld",&n);
    int sum3=0,sum2=0,sum1=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=3;j++){
            scanf("%lld",&a[i][j]);
        }
        sum3+=a[i][3];
        sum2+=a[i][2];
        sum1+=a[i][1];
    }
    sum2+=sum3;
    if(sum2==0){
        cout<<sum1<<"\n";
    } else if(sum3==0){
        for(int i=1;i<=n;i++){
            c[i].cut=a[i][2]-a[i][1];
            c[i].id=i;
        }
        sort(c+1,c+1+n,cmp);
        int ans=0;
        for(int i=1;i<=n;i++){
            if(i>n/2){
                ans+=a[c[i].id][1];
            } else {
                ans+=a[c[i].id][2];
            }
        }
        cout<<ans<<"\n";
    } else cout<<f(1,0,0)<<'\n';
}
signed main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%lld",&t);
    while(t--){
        dod();
    }
    return 0;
}