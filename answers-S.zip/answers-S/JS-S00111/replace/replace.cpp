#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,q;
struct T{
    string ra,rb,wh1,wh2;
};
struct node{
    string ra,rb;
};
vector<node> bo[2000100];
vector <T> ms;
T _find(string a,string b){
    int st=0,ed=0;
    for(int i=0;i<a.size();i++){
        if(a[i]!=b[i]){
            st=i;
            break;
        }
    }
    for(int i=a.size()-1;i>=0;i--){
        if(a[i]!=b[i]){
            ed=i;
            break;
        }
    }
    return {a,b,a.substr(st,ed-st+1),b.substr(st,ed-st+1)};
}
signed main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    scanf("%lld%lld",&n,&q);
    if(n>1010&&q!=1){
        for(int i=1;i<=n;i++){
            string s1,s2;
            int k1=s1.find('b'),k2=s2.find('b');
            bo[k2-k1+1].push_back({s1,s2});
        }
        for(int i=1;i<=q;i++){
            string tr1,tr2;
            cin>>tr1,tr2;
            int k1=tr1.find('b'),k2=tr2.find('b');
            int k=k2-k1;
            int ans=0;
            for(node i:bo[k+1]){
                if(tr1.find(i.ra)+1&&tr2.find(i.rb)+1){
                    ans++;
                }
            }
            printf("%lld\n",ans);
        }
    } else {
        for(int i=1;i<=n;i++){
            string s1,s2;
            cin>>s1>>s2;
            ms.push_back(_find(s1,s2));
        }
        for(int i=1;i<=q;i++){
            string tr1,tr2;
            cin>>tr1>>tr2;
            T x=_find(tr1,tr2);
            int ans=0;
            for(T i:ms){
                if(i.wh1==x.wh1&&i.wh2==x.wh2){
                    if(i.ra.find(x.wh1)+1&&i.rb.find(x.wh2)+1&&tr1.find(i.ra)+1&&tr2.find(i.rb)+1) ans++;
                }
            }
            printf("%lld\n",ans);
        }
    }
    
    return 0;
}