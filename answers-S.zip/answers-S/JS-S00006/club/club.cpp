#include <bits/stdc++.h>
using namespace std;
int a[100005][5];
int b[100005][5];
int vis[5];;
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;
        for(int i = 1; i <= n ; i++)
        {
            for(int j = 1;j <= 3; j++)
            {
                cin >> a[i][j];
            }
        }
        int nc = 0,nb = 0;
        for(int i = 1; i <= n; i++)
        {
            if(a[i][3] == 0)
            {
                nc++;
            }
            if(a[i][2] == 0)
            {
                nb++;
            }
        }
        for(int i = 1; i <= 3; i++)
        {
            vis[i] = 0;
        }
       if(n == 2)
       {
           int maxn = 0;
           maxn = max(a[1][1] + a[1][2],a[1][1] + a[1][3]);
           maxn = max(maxn,a[1][2] + a[2][1]);
           maxn = max(maxn,a[1][2] + a[2][3]);
           maxn = max(maxn,a[1][3] + a[2][1]);
           maxn = max(maxn,a[1][3] + a[2][2]);
            cout << maxn  << "\n";
       }
       if(n == 4)
       {
           int maxn = 0;
           int k = 2;
           for(int i = 1; i <= 3; i++)
           {
               for(int j = 1; j <= 3; j++)
               {
                   for(int d = 1; d <= 3;d++)
                   {
                       for(int y = 1; y <= 3; y++)
                       {
                           if(i == j && j == y) continue;
                           if(i == j && j == d) continue;
                           if(j == d && d == y) continue;
                           if(i == d && d == y) continue;
                           maxn = max(maxn,a[1][i] + a[2][j] + a[3][d] + a[4][y]);
                       }
                   }
               }
           }
           cout << maxn << "\n";
       }
       if(nb == n && nc == n)
       {
            int k = n / 2;
            int maxn = 0;
            int tot = 0;
            multiset<int> p;
            for(int i = 1; i <= n; i++)
            {
                p.insert(a[i][1]);
                tot += a[i][1];
            }
            while(k--)
            {
                int pos = *p.begin();
                maxn += pos;
                //cout << pos << " ";
                p.erase(p.find(pos));
            }
            cout << tot - maxn << "\n";
       }
    }
    return 0;
}