#include<bits/stdc++.h>
using namespace std;
int a[505];
int vis[505];

int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;
    cin >> n >> m;
    string s;
    cin >> s;
    int ans = 0;
    for(int i = 1; i <= n ; i++)
    {
        cin >> a[i];
    }
    for(int i = 0; i < n; i++)
    {
        if(s[i] == '1') ans++;
    }
    long long k = 1;
    if(ans == n)
    {
        for(int i = 1; i <= n; i++)
        {
            k = ((k % 998244353) * i) % 998244353;
        }
        cout << k << endl;
        return 0;
    }
    
    //int t = 0;
   // vis[0] = 0;
    //for(int i = 0; i < n - 1; i++)
    //{
        //if(s[i] == '1')
        //{
        //    vis[i + 1] = vis[i];
        //}
        //else if(s[i] == '0')
       // {
       //     vis[i + 1] = vis[i] + 1;
        //}
    //}
    //for(int i = 0;i < n; i++)
    //{
       // cout << vis[i];
    //}
    return 0;
}