#include <iostream>
#include <cstring>
#include <algorithm>
#define int long long
#define mas 10010
using namespace std;

struct edge{
    int u, v, w;
};

int n, m, k, ep;
int dist[mas][mas];
edge g[1000010];
int a[20];

int b[mas];
int f(int x, int y){
    if (b[x]==b[y]) return b[x];
    return b[x]=b[y];
}

int fu(){
    sort(g+1, g+ep+1, [](edge a, edge b){return a.w<b.w;});

    int ans=0, cnt=0;
    for (int i=1;i<=n;i++)
        b[i]=i;

    for (int i=1;i<ep && cnt<m;i++){
        if (b[g[i].u]==b[g[i].v])
            continue;
        cnt++;
        ans+=g[i].w;
        f(g[i].u, g[i].v);
        // cout << g[i].u << " " << g[i].v << endl;
    }

    return ans;
}

signed main(){
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);

    memset(dist, 0x7f, sizeof dist);

    cin >> n >> m >> k;
    for (int i=1;i<=m;i++){
        int u, v, w;
        cin >> u >> v >> w;
        dist[u][v]=dist[v][u]=w;
    }
    for (int j=1;j<=k;j++){
        int c;
        cin >> c;
        memset(a, 0, sizeof a);
        for (int i=1;i<=n;i++)
            cin >> a[i];
        for (int p=1;p<=n;p++)
            for (int q=1;q<=n;q++){
                if (p<=q) continue;
                dist[p][q]=dist[q][p]=min(dist[p][q], a[p]+a[q]);
            }
    }
    for (int i=1;i<=n;i++)
        for (int j=1;j<=n;j++){
            if (i>=j&&dist[i][j]!=0x7f7f7f7f7f7f7f7f)
                g[++ep]={i, j, dist[i][j]};
        }

    // for (int i=1;i<=n;i++){
    //     for (int j=1;j<=n;j++){
    //         if (dist[i][j]==0x7f7f7f7f7f7f7f7f) cout << "x" << " ";
    //         else cout << dist[i][j] << " ";
    //     }
    //     cout << endl;
    // }
    
    cout << fu() << endl;

    fclose(stdin);
    fclose(stdout);
    return 0;
}
/*

4 4 2

1 4 6
2 3 7
4 2 5
4 3 4

0 1 8 2 4
0 1 3 2 4

ans:12

*/