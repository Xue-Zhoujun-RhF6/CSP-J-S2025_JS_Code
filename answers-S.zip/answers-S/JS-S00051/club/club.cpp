#include <iostream>
#include <algorithm>
#define mas 100010
using namespace std;

struct p{
    int id;
    int sub1, sub2; // sub1= a-b sub2=a-c
    int a, b, c; // id, a[a]>=a[b]>=a[c]
};

int T, n;
int a[mas][4];
int b[mas][4];// high to low
p cha[mas];

int num[4];

int ma[mas]; // choose id

int main(){
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);

    cin >> T;
    
    while (T--){
        cin >> n;
        for (int i=1;i<=n;i++){
            int m1=1, m2=1;
            for (int j=1;j<=3;j++){
                cin >> a[i][j];
                b[i][j]=a[i][j];
                if (a[i][m1]<a[i][j])
                    m1=j;
                if (a[i][m2]>a[i][j])
                    m2=j;
            }
            sort(b[i]+1, b[i]+4);
            ma[i]=cha[i].a=m1;
            cha[i].c=m2;
            cha[i].b=6-m1-m2;
            cha[i].id=i;
            cha[i].sub1=b[i][3]-b[i][2];
            cha[i].sub2=b[i][3]-b[i][1];
            // if (cha[i].sub1<cha[i].sub2) swap(cha[i].sub1, cha[i].sub2); ???
        }

        for (int i=1;i<=3;i++)
            num[i]=0;
        for (int i=1;i<=n;i++){
            num[ma[i]]++;
        }
        if (num[1]>n/2 || num[2]>n/2 || num[3]>n/2){ // (1)
            int chao=1, chaonum=0, cnt=0;
            if (num[2]>n/2) chao=2;
            else if (num[3]>n/2) chao=3;
            chaonum=num[chao]-n/2;

            sort(cha+1, cha+n+1, [](p a, p b){return a.sub1<b.sub1;});
            
            // for (int i=1;i<=n;i++)
            //     cout << cha[i].sub1 << endl;

            for (int i=1;i<=n&&cnt<chaonum;i++){
                if (ma[cha[i].id]==chao){
                    cnt++;
                    ma[cha[i].id]=cha[i].b;
                    // if (cha[i].id==5) cout << ma[cha[i].id] << endl;
                }
            }
        }


        for (int i=1;i<=3;i++)
            num[i]=0;
        for (int i=1;i<=n;i++){
            num[ma[i]]++;
        }
        if (num[1]>n/2 || num[2]>n/2 || num[3]>n/2){ // (2)
            int chao=1, chaonum=0, cnt=0;
            if (num[2]>n/2) chao=2;
            else if (num[3]>n/2) chao=3;
            chaonum=num[chao]-n/2;

            sort(cha+1, cha+n+1, [](p a, p b){return a.sub2<b.sub2;});
            for (int i=1;i<=n&&cnt<chaonum;i++){
                if (ma[cha[i].id]==chao){
                    cnt++;
                    ma[cha[i].id]=cha[i].c;
                }
            }
        }

        for (int i=1;i<=3;i++)
            num[i]=0;
        for (int i=1;i<=n;i++){
            num[ma[i]]++;
        }

        int ans=0;
        for (int i=1;i<=n;i++)
            ans+=a[i][ma[i]];
        
        cout << ans << endl;
    }

    fclose(stdin);
    fclose(stdout);
    return 0;
}

/*
1
5
1 3 4
1 3 4
1 5 3
1 5 3
5 6 1

(1) chao=2
cha a b c sub1 sub2
1   3 2 1   1  3
2   3 2 1   1  3
3   2 3 1   2  4
4   2 3 1   2  4
5   2 1 3   1  5



*/