#include <iostream>
#define int long long
using namespace std;

int n, m, p, ans;
string s;
int c[510];

signed main(){
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);

    cin >> n >> m;
    if (n==m) {
        cout << "0" << endl;
        return 0;
    }

    cin >> s;
    if (s.find("0")!=-1 && m!=1)
        cout << "not a" << endl;
    
    for (int i=1;i<=n;i++){
        cin >> c[i];
        if (c[i]) p++;
        // p++;
    }

    ans=1;
    for (int i=1;i<=p;i++){
        ans=(ans*i)%998244353;
    }
    cout << ans << endl;

    fclose(stdin);
    fclose(stdout);
    return 0;
}