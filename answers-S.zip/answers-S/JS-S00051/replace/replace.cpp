#include <iostream>
using namespace std;

int main(){
    freopen("replace.in", "r", stdin);
    freopen("repace.out", "w", stdout);

    int n;
    cin >> n >> n;
    for (int i=1;i<=n;i++)
        cout << "0" << endl;

    fclose(stdin);
    fclose(stdout);
    return 0;
}