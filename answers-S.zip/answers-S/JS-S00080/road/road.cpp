#include<bits/stdc++.h>
using namespace std;
long long a[10005][10005];
long long len[10005];
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m,k;
    cin>>n>>m>>k;
    memset(a,0x7f,sizeof(a));
    for(int i=1;i<=m;i++){
        int tmp1,tmp2,tmp3;
        cin>>tmp1>>tmp2>>tmp3;
        a[tmp1][tmp2]=tmp3;
        a[tmp2][tmp1]=tmp3;
    }
    long long tmpk[10005];
    long long val;
    for(int i=1;i<=k;i++){
        cin>>val;
        for(int j=1;j<=n;j++){
            cin>>tmpk[j];
        }
        for(int j=1;j<=n;j++){
            for(int l=1;l<=n;l++){
                if(j!=l){
                    a[j][l]=min(a[j][l],(long long)tmpk[l]+(long long)tmpk[j]+(long long)val);
                }
                
            }
        }
    }
    for(int j=1;j<=n;j++){
        for(int l=1;l<=n;l++){
            cout<<a[j][l]<<" "; 
        }
        cout<<endl;
    }  
    priority_queue<pair<long long,pair<int,int>>,vector<pair<long long,pair<int,int>>>,greater<pair<long long,pair<int,int>>>> q;
    q.push({0,{1,0}});
    long long ans=0;
    len[1]=0;
    while(!q.empty()){
        pair<long long,pair<int,int>> tmp=q.top();
        q.pop();
        if(len[tmp.second.first]){
            continue;
        }
        len[tmp.second.first]=len[tmp.second.second]+tmp.first;
//        cout<<len[tmp.second.first]<<" "<<tmp.second.first<<" "<<tmp.second.second<<endl;
        ans=max(ans,len[tmp.second.first]);
        cout<<len[tmp.second.first]<<endl;
        for(int i=1;i<=n;i++){
            if(i!=tmp.second.first){
                q.push({a[tmp.second.first][i],{i,tmp.second.first}});
            }
        }
    }
    cout<<ans;
    return 0;
}