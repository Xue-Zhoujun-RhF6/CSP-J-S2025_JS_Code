#include<bits/stdc++.h>
using namespace std;
int a[100005][4];
int dp[100005][2];
bool cmp(int a,int b){
    return a>b;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int ans1[200000];
        int ans2[200000];
        memset(ans1,0,sizeof(ans1));
        memset(ans2,0,sizeof(ans2));
        for(int i=1;i<=n;i++){
            cin>>ans1[i]>>ans2[i]>>a[i][3];
        }
        sort(ans1+1,ans1+n+1,cmp);
        sort(ans2+1,ans2+n+1,cmp);
        long long ans=0;
        for(int i=1;i<=n/2;i++){
            ans+=ans1[i];
            ans+=ans2[i];
        }
        cout<<ans<<endl;
    }
    return 0;
}