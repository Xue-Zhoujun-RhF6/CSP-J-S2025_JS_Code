#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    int t,q;
    cin>>t>>q;
    while(q--){
        cout<<0<<endl;
    }
    return 0;
}