#include<bits/stdc++.h>
using namespace std;
const int s=3;
const int maxn=1e5+2;
int c,k,n,t,ans=0;
int d[maxn],cnt[5],a[maxn][10];
struct node{
    int num,maxi,seci,mini;
}more[maxn];
void init(){
    for(int i=0;i<maxn;i++)
        more[i].num=more[i].maxi=more[i].seci=more[i].mini=0;
}
bool cmp(node x,node y){
    return a[x.num][x.maxi]<a[y.num][y.maxi];
}
bool check(int &k){
    k=0;
    for(int i=1;i<=s;i++){
        if(cnt[i]>n/2){
            k=i;
            return false;
        }
    }
    return true;
}
int find_second_love(int x,int k){
    int maxa=INT_MIN,maxai=-1;
    for(int i=1;i<=s;i++){
        if(i!=k){
            if(maxa<a[x][i]){
                maxa=a[x][i];
                maxai=i;
            }
        }
    }
    return maxai;
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    for(int l=1;l<=t;l++){
        c=0,ans=0;
        memset(a,0,sizeof(a));
        memset(d,0,sizeof(d));
        memset(cnt,0,sizeof(cnt));
        cin>>n;
        for(int i=1;i<=n;i++){
            a[i][5]=0x3f;
            for(int j=1;j<=s;j++){
                cin>>a[i][j];
                if(a[i][0]<a[i][j]) a[i][0]=a[i][j],a[i][4]=j;  //a[i][0]( max( max( a[i][1],a[i][2] ),a[i][3] ) )shi cheng yuan dui suo you she tuan de zui da man yi du;a[i][4]shi suo you cheng yuan dui ji ge she tuan zui man yi
                if(a[i][5]>a[i][j]) a[i][5]=a[i][j],a[i][6]=j;  //a[i][5]geng a[i][0] xiang fan ; a[i][6]shi suo you cheng duan dui di ji ge she tuan zui bu man yi
            }
            cnt[a[i][4]]++;
            d[i]=a[i][4];
        }
        while(check(k)==false){
            int p;
            init();
            for(int i=1;i<=n;i++){
                if(d[i]==k){
                    p=find_second_love(i,k);
                    c++;
                    more[c].num=i;
                    more[c].maxi=a[more[c].num][4];
                    more[c].seci=p;
                    more[c].mini=a[more[c].num][6];
                }
            }
            sort(more+1,more+c+1,cmp);
            p=cnt[k]-n/2;
            for(int i=1;i<=p;i++){
                cnt[more[i].seci]++;
                d[more[i].num]=a[more[i].num][more[i].seci];
            }
            cnt[k]-=p;
        }
        for(int i=1;i<=n;i++){
            ans+=a[i][d[i]];
        }
        cout<<ans<<endl;
    }
    return 0;
}
