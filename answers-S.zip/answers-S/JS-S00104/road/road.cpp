#include<bits/stdc++.h>
using namespace std;
const int maxn=1e4+2;
int n,m,k,u,v,w;
int c[maxn],dis[maxn],a[maxn][maxn];
bool vis[maxn];
struct node{
    int v,w;
};
vector<node> g[maxn];
/*void dijkstra(int st){
    memset(dis,0x3f,sizeof(dis));
    dis[st]=0;
    priority_queue<node> q;
    q.push({st,0});
    while(!q.empty()){
        node cur=q.top();
        q.pop();
        v=-1;
        for(int i=1;i<=n;i++){
            if(){   //?
                v=i;
            }
        }
        if(v==-1) break;
        if(vis[v]) break;
        vis[v]=1;
        for(int i=0;i<g[v].size();i++){
            u=g[v][i].v;
            w=g[v][i].w;
            if(dis[v]>dis[u]+w){
                dis[v]=dis[u]+w;
                q.push({u,w});
            }
        }
    }
}*/
int main()
{
//    freopen("road.in","r",stdin);
//    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        cin>>u>>v>>w;
        g[u].push_back({v,w});
        g[v].push_back({u,w});
    }
    for(int i=1;i<=k;i++){
        cin>>c[i];
        for(int j=1;j<=n;j++)
            scanf("%d",&a[j][i]);
    }
    return 0;
}
