#include<bits/stdc++.h>

using namespace std;

struct node{
    int a, b, c;
};

struct node1{
    int a, b;
};

int T;
int n;
node p[100006];
node1 p1[100006];
//bool vis[100006];
int a, b, c;
int sum;

bool cmp(node a, node b)
{
    int aa = max(a.a, max(a.b, a.c));
    int bb = max(b.a, max(b.b, b.c));
    return aa > bb;
}

bool cmp1(node1 a, node1 b)
{

    return a.b > b.b;
}

int main()
{
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);

    cin >> T;
    for(int I = 0; I < T; I ++)
    {
        cin >> n;
        bool f = 0;
        bool f1 = 0;
        for(int i = 0; i < n; i ++)
        {
            cin >> p[i].a >> p[i].b >> p[i].c;
            p1[i].a = i;
            p1[i].b = p[i].a - p[i].b;
            if(p[i].b != 0) f = 1;
            if(p[i].c != 0) f1 = 1;
            //vis[i] = 0;
        }
        if(n == 2)
        {
            cout << max(p[0].a + p[1].b, max(p[0].a + p[1].c, max(p[0].b + p[1].a, max(p[0].b + p[1].c, max(p[0].c + p[1].a, p[0].c + p[1].b)))));
        }
        if(f == 0 && f1 == 0)
        {
            sort(p, p + n, cmp);
            int aaa = 0;
            for(int i = 0; i < n / 2; i ++)
            {
                aaa += p[i].a;
            }
            cout << aaa << endl;
        }
        else if(f1 == 0)
        {
            int aaa = 0;
            sort(p1, p1 + n, cmp1);
            for(int i = 0; i < n / 2; i ++)
            {
                aaa += p[p1[i].a].a;
                //cout << p[p1[i].a].a << endl;
            }
            for(int i = n / 2; i < n; i ++)
            {
                aaa += p[p1[i].a].b;
                //cout << p[p1[i].a].b << endl;
            }
            cout << aaa << endl;
        }

    }

    fclose(stdin);
    fclose(stdout);
    return 0;
}

/*

1
6
10 9 0
4 0 0
8 6 0
6 0 0
0 7 0
3 5 0


*/
