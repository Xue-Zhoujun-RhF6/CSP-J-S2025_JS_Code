#include<bits/stdc++.h>
using namespace std;
int n,maxn = INT_MIN;
//pair <int,int>
int a[100005],b[100005],c[100005];
//bool vis[100005];
int ma = 0, mb = 0, mc = 0;
int re()
{
    int f = 1;
    int num = 0;
    char c;
    c = getchar();
    while(!isdigit(c))
    {
        if(c == '-')f = -1;
        c = getchar();
    }
    while(isdigit(c))
    {
        num = (num << 3) + (num << 1) + c - '0';
        c = getchar();
    }
    return num * f;
}
void  dfs(int dep,int sum)
{
    if(dep > n)
    {
        maxn = max(maxn, sum);
        return;
    }
    if(ma < n / 2)
    {
        ma++;
        dfs(dep + 1,sum + a[dep]);
        ma--;
    }
    if(mb < n / 2)
    {
        mb++;
        dfs(dep + 1, sum + b[dep]);
        mb--;
    }
    if(mc < n / 2)
    {
        mc++;
        dfs(dep + 1, sum + c[dep]);
        mc--;
    }
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t = re();
    while(t--)
    {
        n = re();
        for(int i = 1; i <= n; i++)
        {
            int x, y, z;
            x =re();
            y = re();
            z = re();
            a[i] = x;
            b[i] = y;
            c[i] = z;
        }
        maxn = INT_MIN;
        ma = 0;
        mb = 0;
        mc = 0;
        dfs(1, 0);
        cout << maxn << endl;
    }
    return 0;
}
