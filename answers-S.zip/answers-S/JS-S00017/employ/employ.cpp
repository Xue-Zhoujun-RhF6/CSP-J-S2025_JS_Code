#include<bits/stdc++.h>
using namespace std;
int n, m;
int cnt =0;
int c[1005];
int f[5];
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin >> n >> m;
    for(int i = 1;i <= n; i++)
    {
        char s;
        cin >> s;
    }
    for(int i = 1; i <= n; i++)
    {
        cin >> c[i];
        if(c[i] == 0)cnt++;
        else if(cnt >= c[i])cnt++;
    }
    long long ans = 1;
    int t = n - cnt;
    cout << t << endl;
    while(t > 0)
    {
        ans *= t;
        ans= (ans % 998244353);
        t--;
    }
    cout << ans << endl;
    return 0;
}
