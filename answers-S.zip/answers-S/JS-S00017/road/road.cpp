#include<bits/stdc++.h>
using namespace std;
int g[10005][10005];
int n, m, k;
int c[10005], f[1005][1005];
int ans = INT_MAX;
bool vis[10005];
int re()
{
    int f = 1;
    int num = 0;
    char c;
    c = getchar();
    while(!isdigit(c))
    {
        if(c == '-')f = -1;
        c = getchar();
    }
    while(isdigit(c))
    {
        num = (num << 3) + (num << 1) + c - '0';
        c = getchar();
    }
    return num * f;
}
void dfs(int dep, int sum)
{
    if(dep > n)
    {
        ans = min(ans, sum);
        return;
    }
    for(int i = 1; i <= n; i++)
    {
        if(vis[i] == 0)
        {
            vis[i] = 1;
            dfs(dep + 1, sum + g[i][i]);
            vis[i] = 0;
        }
    }

}
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);

    n = re();
    m = re();
    k = re();
    memset(g, 0x3f, sizeof g);
    for(int i = 1; i <= m; i++)
    {
        int a = re();
        int b = re();
        int w = re();
        g[a][b] = w;
        g[b][a] = w;
    }
    for(int i = 1; i <= k; i++)
    {
        c[i] = re();
        for(int j = 1;j <= n;j++)
        {
            int w = re();
            f[i][j] = w;
        }
    }
    for(int i = 1; i <= k; i++)
    {
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= n; j++)
            {
                g[i][j] = min(g[i][j],f[k][i] + f[k][j]);
            }
        }
    }
    dfs(1, 0);
    cout << ans << endl;
    return 0;
}
