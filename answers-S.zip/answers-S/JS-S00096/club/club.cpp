#include<bits/stdc++.h>
using namespace std;
int t,n;
const int N=1e5+10;
int a1[N],a2[N],a3[N];
int max1[N];
int ch1[N],ch2[N],ch3[N];
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);

    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        memset(ch1,0x3f,sizeof(ch1));
        memset(ch2,0x3f,sizeof(ch2));
        memset(ch3,0x3f,sizeof(ch3));
        for(int i=1;i<=n;i++){
            scanf("%d%d%d",&a1[i],&a2[i],&a3[i]);
            if(a1[i]>a2[i]&&a1[i]>a3[i]){
                if(a2[i]>a3[i]){
                    max1[i]=1; ch1[i]=a1[i]-a2[i];
                }else{
                    max1[i]=1; ch1[i]=a1[i]-a3[i];
                }
            }else if(a2[i]>a1[i]&&a2[i]>a3[i]){
                if(a1[i]>a3[i]){
                    max1[i]=2; ch2[i]=a2[i]-a1[i];
                }else{
                    max1[i]=2; ch2[i]=a2[i]-a3[i];
                }
            }else{
                if(a2[i]>a1[i]){
                    max1[i]=3; ch3[i]=a3[i]-a2[i];
                }else{
                    max1[i]=3; ch3[i]=a3[i]-a1[i];
                }
            }
        }

        int sum1=0,sum2=0,sum3=0,ans1=0,ans2=0,ans3=0;
        for(int i=1;i<=n;i++)
        {
            if(max1[i]==1) sum1++,ans1+=a1[i];
            else if(max1[i]==2) sum2++,ans2+=a2[i];
            else if(max1[i]==3) sum3++,ans3+=a3[i];
        }

        if(sum1>n/2){
            sort(ch1,ch1+n+1);
            int k=sum1-(n/2);
            for(int i=1;i<=k;i++){
                ans1-=ch1[i];
            }
        }else if(sum2>n/2){
            sort(ch2,ch2+n+1);
            int k=sum2-(n/2);
            for(int i=1;i<=k;i++){
                ans2-=ch2[i];
            }
        }else if(sum3>n/2){
            sort(ch3,ch3+n+1);
            int k=sum3-(n/2);
            for(int i=1;i<=k;i++){
                ans3-=ch3[i];
            }
        }
        cout<<ans1+ans2+ans3<<endl;
    }
    return 0;
}
