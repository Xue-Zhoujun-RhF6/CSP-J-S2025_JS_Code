#include<bits/stdc++.h>
using namespace std;
int main()
{
    cout<<1<<endl;
    return 0;
}
