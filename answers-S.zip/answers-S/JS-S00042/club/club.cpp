#include<bits/stdc++.h>
using namespace std;
template<typename Tp>
inline void read(Tp &x){
	x=0;
	bool f=0;
	char c=getchar();
	while(!isdigit(c)&&c!='-')c=getchar();
	if(c=='-')f=1,c=getchar();
	while(isdigit(c))x=x*10+c-'0',c=getchar();
	if(f)x=-x;
}
template<typename Tp>
inline void write(Tp x){
	if(x<0)putchar('-'),x=-x;
	if(x<10)putchar(x+'0');
	else write(x/10),putchar(x%10+'0');
}
const int N=1e5+5;
int t,n,sn;
long long a[N][4],m[N][4],ans,s[4],p[N];
int main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	read(t);
	while(t--){		//clear!
		read(n);
		sn=s[1]=s[2]=s[3]=ans=0;
		for(int i=1;i<=n;i++){
			read(a[i][1]),read(a[i][2]),read(a[i][3]);
			long long mx=max({a[i][1],a[i][2],a[i][3]});
			m[i][1]=a[i][1]-mx;
			m[i][2]=a[i][2]-mx;
			m[i][3]=a[i][3]-mx;
			if(mx==a[i][1])s[1]++;
			if(mx==a[i][2])s[2]++;
			if(mx==a[i][3])s[3]++;
			ans+=mx;
		}
		int x=0,y=0,z=0;
		if(s[1]>(n>>1))x=1,y=2,z=3;
		else if(s[2]>(n>>1))x=2,y=1,z=3;
		else if(s[3]>(n>>1))x=3,y=1,z=2;
		else{
			write(ans);
			putchar('\n');
			continue;
		}
		for(int i=1;i<=n;i++){
			if(m[i][x]==0)p[++sn]=-max(m[i][y],m[i][z]);
		}
		sort(p+1,p+sn+1);
		for(int i=1;i<=s[x]-(n>>1);i++)ans-=p[i];
		write(ans);
		putchar('\n');
	}
	return 0;
}