#include<bits/stdc++.h>
using namespace std;
template<typename Tp>
inline void read(Tp &x){
	x=0;
	bool f=0;
	char c=getchar();
	while(!isdigit(c)&&c!='-')c=getchar();
	if(c=='-')f=1,c=getchar();
	while(isdigit(c))x=x*10+c-'0',c=getchar();
	if(f)x=-x;
}
template<typename Tp>
inline void write(Tp x){
	if(x<0)putchar('-'),x=-x;
	if(x<10)putchar(x+'0');
	else write(x/10),putchar(x%10+'0');
}
int main(){
	freopen("replace.in","r",stdin);
	freopen("replace.out","w",stdout);
	
	return 0;
}