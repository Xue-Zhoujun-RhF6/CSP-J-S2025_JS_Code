#include<bits/stdc++.h>
using namespace std;
template<typename Tp>
inline void read(Tp &x){
	x=0;
	bool f=0;
	char c=getchar();
	while(!isdigit(c)&&c!='-')c=getchar();
	if(c=='-')f=1,c=getchar();
	while(isdigit(c))x=x*10+c-'0',c=getchar();
	if(f)x=-x;
}
template<typename Tp>
inline void write(Tp x){
	if(x<0)putchar('-'),x=-x;
	if(x<10)putchar(x+'0');
	else write(x/10),putchar(x%10+'0');
}
const int N=1e4+15;
int n,m,k,vis[N];
long long a[11][N],c[11],ans=0,idx[11];
vector<pair<int,long long>> g[N];
void prim(){
	priority_queue<pair<long long,int>,vector<pair<long long,int>>,greater<pair<long long,int>>> q;
	q.push({0,1});
	int cnt=1;
	while(!q.empty()){
		long long d=q.top().first;
		int u=q.top().second;
		q.pop();
		if(vis[u])continue;
		vis[u]=1;
		ans+=d;
		for(auto i:g[u]){
			int v=i.first;
			long long w=i.second;
			if(!vis[v]){
				q.push({w,v});
			}
		}
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n),read(m),read(k);
	int u,v;
	long long w;
	for(int i=1;i<=m;i++){
		read(u),read(v),read(w);
		g[u].push_back({v,w});
		g[v].push_back({u,w});
	}
	bool f=1;
	for(int i=1;i<=k;i++){
		read(c[i]);
		if(c[i])f=0;
		for(int j=1;j<=n;j++){
			read(a[i][j]);
			if(!a[i][j])idx[i]=j;
		}
		if(!idx[i])f=0;
	}
	if(f){
		for(int i=1;i<=k;i++){
			for(int j=1;j<=n;j++){
				if(j==idx[i])continue;
				u=idx[i],v=j,w=a[i][j];
				g[u].push_back({v,w});
				g[v].push_back({u,w});
			}
		}
	}
	prim();
	if(!f&&k!=0){
		for(int i=1;i<=k;i++){
			long long sub=c[i];
			for(int j=1;j<=n;j++)sub+=a[i][j];
			ans=min(ans,sub);
		}
	}
	write(ans);
	return 0;
}