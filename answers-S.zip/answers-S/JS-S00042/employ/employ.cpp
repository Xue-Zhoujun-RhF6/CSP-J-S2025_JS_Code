#include<bits/stdc++.h>
using namespace std;
const int N=505;
const long long mod=998244353;
int n,m,c[N];
char s[N];
long long sum[N],dp[N][N];
int main(){
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	scanf("%d%d%s",&n,&m,s+1);
	for(int i=1;i<=n;i++)scanf("%d",c+i);
	for(int i=1;i<=n;i++)sum[i]=sum[i-1]+s[i]-'0';
	//if(sum[n]==n){
		sort(c+1,c+n+1);
		dp[1][0]=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<i;j++){
				dp[i][j]=(dp[i-1][j]*c[i]%mod+dp[i-1][j-1]*(i-c[i])%mod)%mod;
			}
		}
		long long ans=0;
		for(int i=0;i<=n-m;i++)ans=(ans+dp[n][i])%mod;
		if(sum[n]<m)printf("%d",0);
		else printf("%lld",ans);
	//}
	return 0;
}