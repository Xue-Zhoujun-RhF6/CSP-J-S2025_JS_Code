#include <bits/stdc++.h>
#define rep(i,n) for(int i=0,del##i##verme=int(n);i<del##i##verme;++i)
#define rep1(i,n) for(int i=1,parano##i##a=int(n);i<=parano##i##a;++i)
#define per(i,n) for(int i=int(n)-1;i>=0;--i)
#define per1(i,n) for(int i=int(n);i>=1;--i)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define y0 LingLuo
#define y1 VividCycle
typedef long long ll;
typedef unsigned long long ull;
typedef long double ldb;
const ll mod1=998244353;
const ll mod2=1000000007;
using namespace std;
int t,n,a,b,c,s;
vector<int> vc[4];
void Q()
{
    cin>>n;rep1(i,3) vc[i].clear();
    s=0;
    rep1(i,n)
    {
        cin>>a>>b>>c;int mx=max(a,max(b,c));
        s+=mx;
        if(mx==a) vc[1].pb(mx-max(b,c));
        else if(mx==b) vc[2].pb(mx-max(a,c));
        else vc[3].pb(mx-max(a,b));
    }
    rep1(i,3) if(int(vc[i].size())>n/2)
    {
        sort(vc[i].begin(),vc[i].end());
        int d=int(vc[i].size())-n/2;
        rep(j,d) s-=vc[i][j];
    }
    cout<<s<<'\n';
}
int main()
{
    #ifndef DEBUG
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    #endif
    ios_base::sync_with_stdio(false);cin.tie(0);cin>>t;while(t--)Q();
    return 0;
}
/*
naxie yiyiguxingde guocuo haiqing yuanliang wo
miandui xiongxiande jinhou bie likai wo
*/