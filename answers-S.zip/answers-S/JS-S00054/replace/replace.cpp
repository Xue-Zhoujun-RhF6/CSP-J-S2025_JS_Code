#include <bits/stdc++.h>
#define rep(i,n) for(int i=0,del##i##verme=int(n);i<del##i##verme;++i)
#define rep1(i,n) for(int i=1,parano##i##a=int(n);i<=parano##i##a;++i)
#define per(i,n) for(int i=int(n)-1;i>=0;--i)
#define per1(i,n) for(int i=int(n);i>=1;--i)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define y0 LingLuo
#define y1 VividCycle
typedef long long ll;
typedef unsigned long long ull;
typedef long double ldb;
const ll mod=10000000000000061;
using namespace std;
unsigned time_related_rand()
{
    return unsigned(chrono::steady_clock::now().time_since_epoch().count());
}
struct Trie{
    int cnt;
    int tr[5000006][27];
    bool vis[5000006];
    int dfn[5000006],rgt[5000006],toki;
    void init()
    {
        cnt=1;memset(tr[1],0,sizeof(tr[1]));vis[1]=false;toki=0;
    }
    int Insert(const string&s)
    {
        int cur=1;
        for(char chr:s)
        {
            int ch=int(chr&31);
            if(!tr[cur][ch])
            {
                tr[cur][ch]=++cnt;vis[cnt]=false;memset(tr[cnt],0,sizeof(tr[cnt]));
            }
            cur=tr[cur][ch];
        }
    //    cout<<'"'<<s<<'"'<<" -> "<<cur<<endl;
        return cur;
    }
    int Query(const string&s)
    {
        int cur=1;
        for(char chr:s)
        {
            int ch=int(chr&31);
            if(!tr[cur][ch]) break;
            cur=tr[cur][ch];
        }
        vis[cur]=true;
        return cur;
    }
    void dfs(int ver)
    {
        dfn[ver]=toki+1;
        if(vis[ver]) ++toki;
        rep1(i,26) if(tr[ver][i]) dfs(tr[ver][i]);
        rgt[ver]=toki;
    }
};
struct segtree{
    int tag[200005];
    void add(int i,int il,int ir,int ql,int qr)
    {
        if(il>qr||ql>ir) return ;
        if(ql<=il&&ir<=qr)
        {
          //  cout<<"ad "<<il<<" "<<ir<<endl;
            ++tag[i];return ;
        }
        int m=(il+ir)>>1;
        add(i<<1,il,m,ql,qr);add(i<<1|1,m+1,ir,ql,qr);
    }
    void erase(int i,int il,int ir,int ql,int qr)
    {
        if(il>qr||ql>ir) return ;
        if(ql<=il&&ir<=qr)
        {
            --tag[i];return ;
        }
        int m=(il+ir)>>1;
        erase(i<<1,il,m,ql,qr);erase(i<<1|1,m+1,ir,ql,qr);
    }
    int query(int i,int l,int r,int q)
    {
       // cout<<"? "<<l<<" "<<r<<endl;
        if(l==r) return tag[i];
        int m=(l+r)>>1;
        if(q<=m) return tag[i]+query(i<<1,l,m,q);
        return tag[i]+query(i<<1|1,m+1,r,q);
    }
};
Trie T;
int n,q;segtree seg;
string s1[200005],s2[200005];bool ok[200005];
int l1[200005],r1[200005],l2[200005],r2[200005],qaq[200005];
map<pair<ll,ll>,int> ID;int cnts;
vector<int> sts[200005],qrs[200005];
string q1[200005],q2[200005];
int qx[200005],qy[200005],qwq[200005];
int ans[200005];
vector<int> ad[200005],del[200005],qry[200005];
int tot;
void solve(int id)
{
    if(qrs[id].empty()) return;
    T.init();
    for(int stz:sts[id]) qaq[stz]=T.Insert(s1[stz]);
    for(int qrz:qrs[id]) qwq[qrz]=T.Query(q1[qrz]);
    T.dfs(1);
    for(int stz:sts[id]) l1[stz]=T.dfn[qaq[stz]]+tot,r1[stz]=T.rgt[qaq[stz]]+tot;
    for(int qrz:qrs[id]) qx[qrz]=T.dfn[qwq[qrz]]+tot;
    T.init();
    for(int stz:sts[id]) qaq[stz]=T.Insert(s2[stz]);
    for(int qrz:qrs[id]) qwq[qrz]=T.Query(q2[qrz]);
    T.dfs(1);
    for(int stz:sts[id]) l2[stz]=T.dfn[qaq[stz]]+tot,r2[stz]=T.rgt[qaq[stz]]+tot;
    for(int qrz:qrs[id]) qy[qrz]=T.dfn[qwq[qrz]]+tot;
 //   cout<<"# Solve"<<endl;
 //   for(int stz:sts[id]) cout<<l1[stz]<<"~"<<r1[stz]<<" / "<<l2[stz]<<"~"<<r2[stz]<<'\n';
 //   for(int qrz:qrs[id]) cout<<"query #"<<qrz<<" "<<qx[qrz]<<" / "<<qy[qrz]<<"\n";
    tot+=int(qrs[id].size());
}
int main()
{
    #ifndef DEBUG
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    #endif
    ios_base::sync_with_stdio(false);cin.tie(0);
    cin>>n>>q;
    rep1(i,n)
    {
        cin>>s1[i]>>s2[i];r1[i]=-1;
        int mn=-1,mx=-1;
        rep(j,s1[i].size())
        {
            if(s1[i][j]!=s2[i][j])
            {
                if(mn==-1) mn=j;
                mx=j;
            }
        }
        if(mn==-1) ok[i]=false;
        else
        {
            ok[i]=true;
            ll f=0,g=0;
            for(int j=mn;j<=mx;++j)
            {
                f=(f*131+s1[i][j])%mod;
                g=(g*131+s2[i][j])%mod;
            }
            if(!ID.count(mp(f,g)))
            {
                ID[mp(f,g)]=++cnts;
            }
            sts[ID[mp(f,g)]].pb(i);
            s1[i]=s1[i].substr(0,mn);reverse(s1[i].begin(),s1[i].end());
            s2[i]=s2[i].substr(mx+1);
        //    cout<<s1[i]<<" "<<s2[i]<<endl;
        }
    }
    rep1(i,q)
    {
        cin>>q1[i]>>q2[i];
        if(q1[i].size()!=q2[i].size()) continue;
        int mn=-1,mx=-1;
        rep(j,q1[i].size())
        {
            if(q1[i][j]!=q2[i][j])
            {
                if(mn==-1) mn=j;
                mx=j;
            }
        }
        if(mn==-1) continue;
        ll f=0,g=0;
        for(int j=mn;j<=mx;++j)
        {
            f=(f*131+q1[i][j])%mod;
            g=(g*131+q2[i][j])%mod;
        }
        if(!ID.count(mp(f,g))) continue;
        qrs[ID[mp(f,g)]].pb(i);
        q1[i]=q1[i].substr(0,mn);reverse(q1[i].begin(),q1[i].end());
        q2[i]=q2[i].substr(mx+1);
       // cout<<q1[i]<<" "<<q2[i]<<endl;
    }
    rep1(i,cnts) solve(i);
    rep1(i,n) if(l1[i]<=r1[i]&&l2[i]<=r2[i])
    {
        ad[l1[i]].pb(i);del[r1[i]].pb(i);
    }
    rep1(i,q) qry[qx[i]].pb(i);
    //cout<<". "<<tot<<endl;
    rep1(i,tot)
    {
        for(int x:ad[i])
        {
            seg.add(1,1,tot,l2[x],r2[x]);
           // cout<<l2[x]<<"~"<<r2[x]<<endl;
        }
        for(int x:qry[i]) 
        {
          //  cout<<x<<" !"<<qy[x]<<endl;
            ans[x]=seg.query(1,1,tot,qy[x]);
        }
        for(int x:del[i])
        {
           // cout<<l2[x]<<"~"<<r2[x]<<endl;
            seg.erase(1,1,tot,l2[x],r2[x]);
        }
    }
    rep1(i,q) cout<<ans[i]<<'\n';
    return 0;
}
/*
naxie yiyiguxingde guocuo haiqing yuanliang wo
miandui xiongxiande jinhou bie likai wo
*/