#include <bits/stdc++.h>
#define rep(i,n) for(int i=0,del##i##verme=int(n);i<del##i##verme;++i)
#define rep1(i,n) for(int i=1,parano##i##a=int(n);i<=parano##i##a;++i)
#define per(i,n) for(int i=int(n)-1;i>=0;--i)
#define per1(i,n) for(int i=int(n);i>=1;--i)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define y0 LingLuo
#define y1 VividCycle
typedef long long ll;
typedef unsigned long long ull;
typedef long double ldb;
const ll mod1=998244353;
using namespace std;
int n,m,st,q,c[505];
string s;
ll dp[505][505],nw[505][505];
ll ans,cur;
int main()
{
    #ifndef DEBUG
    freopen("employ.in","r",stdin);freopen("employ.out","w",stdout);
    #endif
    ios_base::sync_with_stdio(false);cin.tie(0);
    cin>>n>>m>>s;s="?"+s;
    rep1(i,n)
    {
        cin>>q;++c[q];
    }
    rep1(i,n) c[i]+=c[i-1];
    dp[0][0]=1;
    rep1(i,n)
    {
        if(s[i]=='0')
        {
            ++st;
        }
        else
        {
            memset(nw,0,sizeof(nw));
            rep(j,i+1) for(int k=j;k<=i;++k) if(dp[j][k])
            {
                int v=c[j+st]-k;ll w=dp[j][k]*v%mod1;
                nw[j+1][k+1]+=w;if(nw[j+1][k+1]>=mod1)nw[j+1][k+1]-=mod1;
                nw[j][k]+=dp[j][k];if(nw[j][k]>=mod1)nw[j][k]-=mod1;
                nw[j][k+1]-=w;if(nw[j][k+1]<0)nw[j][k+1]+=mod1;
            }
            memcpy(dp,nw,sizeof(dp));
        }
    }
    cur=1;
    per(i,n+1)
    {
        ll ss=0;
        rep(j,n+1) if(n-st-j>=m) ss+=dp[j][i];
        ss%=mod1;
        ans=(ans+ss*cur)%mod1;
        cur=cur*(n+1-i)%mod1;
    }
    cout<<ans<<'\n';
    return 0;
}
/*
naxie yiyiguxingde guocuo haiqing yuanliang wo
miandui xiongxiande jinhou bie likai wo
*/