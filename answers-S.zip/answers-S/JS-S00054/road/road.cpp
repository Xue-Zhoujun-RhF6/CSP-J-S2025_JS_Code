#include <bits/stdc++.h>
#define rep(i,n) for(int i=0,del##i##verme=int(n);i<del##i##verme;++i)
#define rep1(i,n) for(int i=1,parano##i##a=int(n);i<=parano##i##a;++i)
#define per(i,n) for(int i=int(n)-1;i>=0;--i)
#define per1(i,n) for(int i=int(n);i>=1;--i)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define y0 LingLuo
#define y1 VividCycle
typedef long long ll;
typedef unsigned long long ull;
typedef long double ldb;
const ll mod1=998244353;
const ll mod2=1000000007;
using namespace std;
struct Edge{
    int u,v;ll w;
};
bool operator<(const Edge&A,const Edge&B)
{
    return A.w<B.w;
}
struct dsu{
    int p[10035],s[10035];
    void init(int N)
    {
        rep1(i,N) p[i]=i,s[i]=1;
    }
    int getp(int x)
    {
        return (p[x]==x)?x:(p[x]=getp(p[x]));
    }
    bool merge(int x,int y)
    {
        x=getp(x);y=getp(y);if(x==y) return false;
        if(s[x]>s[y])swap(x,y);
        s[y]+=s[x];p[x]=y;return true;
    }
};
dsu D;
int n,m,k;
ll ans=0x3f3f3f3f3f3f3f3fll;
Edge eds[12][10035];
Edge cur[12][20035];int len[12];
ll c[12],wt;
Edge tmp[20035];int lent;
Edge bg[1000005];
void Simplify(Edge vc[],int&cnt,ll cst)
{
    lent=0;D.init(n+k);
   // cout<<"! begin "<<cst<<endl;
    rep1(i,cnt)
    {
      //  cout<<vc[i].u<<" "<<vc[i].v<<" "<<vc[i].w<<endl;
        if(D.merge(vc[i].u,vc[i].v))
        {
            
            cst+=vc[i].w;tmp[++lent]=vc[i];
        }
    }
    rep1(i,lent) vc[i]=tmp[i];
    cnt=lent;
    ans=min(ans,cst);
}
void dfs(int idx,ll curt)
{
    if(idx==k+1) return ;
    int nxt=idx+1;
    len[nxt]=len[idx];
    rep1(i,len[idx]) cur[nxt][i]=cur[idx][i];
    dfs(idx+1,curt);
    rep1(i,n) cur[nxt][++len[nxt]]=eds[idx][i];
    inplace_merge(cur[nxt]+1,cur[nxt]+len[idx]+1,cur[nxt]+len[nxt]+1);
    curt+=c[idx];
  //  cout<<idx<<" -> "<<nxt<<" "<<len[idx]<<" "<<len[nxt]<<endl;
    Simplify(cur[nxt],len[nxt],curt);
    dfs(idx+1,curt);
}
int main()
{
    #ifndef DEBUG
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    #endif
    ios_base::sync_with_stdio(false);cin.tie(0);
    cin>>n>>m>>k;
    rep1(i,m)
    {
        cin>>bg[i].u>>bg[i].v>>bg[i].w;
    }
    sort(bg+1,bg+m+1);
    Simplify(bg,m,0);
    rep1(i,m) cur[1][i]=bg[i];
    len[1]=m;
    rep1(i,k)
    {
        cin>>c[i];
        rep1(j,n)
        {
            eds[i][j].u=i+n;eds[i][j].v=j;
            cin>>eds[i][j].w;
        }
        sort(eds[i]+1,eds[i]+n+1);
    }
    dfs(1,0);
    cout<<ans<<'\n';
    return 0;
}
/*
naxie yiyiguxingde guocuo haiqing yuanliang wo
miandui xiongxiande jinhou bie likai wo
*/