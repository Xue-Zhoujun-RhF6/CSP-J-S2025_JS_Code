#include <bits/stdc++.h>
using namespace std;
struct nod{
	int ai1,ai2,ai3;
}a[300010];
int dp[51][51][51][101];
bool f=true;
int t,n,maxi=-10000000;
void dfs(int sum,int c1,int c2,int c3,int wei){
	if(c1>n/2 || c2>n/2 || c3>n/2){
		return ;
	}
	if(wei==n){
		maxi=max(maxi,sum);
		return ;
	}
	if(dp[c1][c2][c3][wei]>=sum){
		return ;
	}
	dp[c1][c2][c3][wei]=sum;
	dfs(sum+a[wei+1].ai1,c1+1,c2,c3,wei+1);
	dfs(sum+a[wei+1].ai2,c1,c2+1,c3,wei+1);
	dfs(sum+a[wei+1].ai3,c1,c2,c3+1,wei+1);
}
bool cmp(nod a,nod b){
	return a.ai1>b.ai1;
}
int main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	cin>>t;
	for(int i1=1;i1<=t;i1++){
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>a[i].ai1>>a[i].ai2>>a[i].ai3;
			if(a[i].ai2!=0 || a[i].ai3!=0){
				f=false;
			}
		}
		if(!f){
			memset(dp,-1,sizeof(dp));
			maxi=-10000000;
			dfs(a[1].ai1,1,0,0,1);
			dfs(a[1].ai2,0,1,0,1);
			dfs(a[1].ai3,0,0,1,1);
			cout<<maxi<<endl;
		}
		else{
			int sum=0;
			sort(a+1,a+n+1,cmp);
			for(int i=1;i<=n/2;i++){
				sum+=a[i].ai1;
			}
			cout<<sum<<endl;
		}
	}
	return 0;
}
