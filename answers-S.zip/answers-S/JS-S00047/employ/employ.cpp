#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("employ.in","r",stdin);
	freopen("employ.out","w",stdout);
	cout<<114514<<endl;
	return 0;
}
//shi nian qian de chou nan dao bu bao le me?
