#include<bits/stdc++.h>
#define ll long long
#define N 200005
using namespace std;
int n,m,k;
struct Node{
    int u,v,w;
}mst[N],ge[1000005],nw[N];
int p[N];
int find(int x){
    if(x!=p[x]) p[x]=find(p[x]);
    return p[x];
}
int c[N],a[11][10005];
signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int T=clock();
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++) cin>>ge[i].u>>ge[i].v>>ge[i].w;
    sort(ge+1,ge+m+1,[](Node a,Node b){
        return a.w<b.w;
    });
    int cnt=0;
    ll ans=0;
    for(int i=1;i<=n;i++) p[i]=i;
    for(int i=1;i<=m;i++){
        int u=find(ge[i].u),v=find(ge[i].v);
        if(u==v) continue;
        mst[++cnt]=ge[i];
        ans+=ge[i].w;
        p[u]=v;
        if(cnt==n-1) break;
    }
    // cout<<ans<<endl;
    for(int i=0;i<k;i++){
        cin>>c[i];
        for(int j=1;j<=n;j++) cin>>a[i][j];
    }
    for(int B=1;B<(1<<k);B++){
        if(clock()-T>0.9*CLOCKS_PER_SEC) break;
        ll tmp=0;
        for(int i=0;i<k;i++) if((B>>i)&1) tmp+=c[i];
        if(tmp>=ans) continue;
        // cout<<B<<' '<<tmp<<endl;
        int cur=0;
        for(int i=1;i<=cnt;i++) nw[++cur]=mst[i];
        for(int i=0;i<k;i++) if((B>>i)&1){
            for(int j=1;j<=n;j++) nw[++cur]=(Node){i+1+n,j,a[i][j]};
        }
        sort(nw+1,nw+cur+1,[](Node a,Node b){
            return a.w<b.w;
        });
        // for(int i=1;i<=cur;i++) cout<<nw[i].u<<' '<<nw[i].v<<' '<<nw[i].w<<endl;
        for(int i=1;i<=n+k;i++) p[i]=i;
        int cc=0;
        for(int i=1;i<=cur;i++){
            int u=find(nw[i].u),v=find(nw[i].v);
            if(u==v) continue;
            tmp+=nw[i].w;
            // cout<<nw[i].u<<' '<<nw[i].v<<' '<<nw[i].w<<endl;
            if(tmp>=ans){
                goto nt;
            }
            p[u]=v;
            cc++;
            if(cc==n+k-1) break;
        }
        // cout<<B<<endl;
        ans=min(ans,tmp);
        nt:;
    }
    cout<<ans<<endl;
    return 0;
}

// ducuotile xianzai 16:33 zaban