#include<bits/stdc++.h>
#define N 200005
#define S 5000005
#define mod 1000000027
#define P 13331
#define B 40
using namespace std;
bool _S;
int n,q;
char s[S],t[S];
struct Trie{
    int root[N];
    int tot;
    vector<int> ed[S+N];
    int trans[S+N][26];
    inline void insert(int Rt,char *s,int L,int R,int val,bool o){
        if(!root[Rt]) root[Rt]=++tot;
        int now=root[Rt];
        if(!o)for(int i=L;i<=R;i++){
            if(!trans[now][s[i]-'a']) trans[now][s[i]-'a']=++tot;
            now=trans[now][s[i]-'a'];
            // cout<<s[i];
        }
        else for(int i=R;i>=L;i--){
            if(!trans[now][s[i]-'a']) trans[now][s[i]-'a']=++tot;
            now=trans[now][s[i]-'a'];
            // cout<<s[i];
        }
        ed[now].push_back(val);
    }
    inline void query(int Rt,char *s,int L,int R,vector<int> &v,bool o){
        int now=root[Rt];
        for(auto nx:ed[now]) v.push_back(nx);
        if(!o)for(int i=L;i<=R;i++){
            now=trans[now][s[i]-'a'];
            if(!now) break;
            for(auto nx:ed[now]) v.push_back(nx);
        }
        else for(int i=R;i>=L;i--){
            now=trans[now][s[i]-'a'];
            if(!now) break;
            for(auto nx:ed[now]) v.push_back(nx);
        }
    }
}fr,ed;
int bs[S];
inline int ghs(char *s,int L,int R){
    int hs=0;
    for(int i=L;i<=R;i++) hs=(1ll*hs*P+s[i])%mod;
    return hs;
}
map<pair<int,int>,int> mp;
map<pair<int,int>,int> hscnt[N];
int Id;
inline int groot(int x,int y){
    if(mp.count({x,y})) return mp[{x,y}];
    return mp[{x,y}]=++Id;
}
vector<int> pre,suf;
bool _E;
struct DS{
    int col[N],val[N],now;
    int &operator[](int x){
        if(col[x]!=now) val[x]=0,col[x]=now;
        return val[x];
    }
    inline void clear(){
        now++;
    }
}ds;
int hsh[S];
inline int get_hsh(int l,int r){
    if(l>r) return 0;
    return (hsh[r]-1ll*hsh[l-1]*bs[r-l+1]%mod+mod)%mod;
}
signed main(){
    // cerr<<(&_S-&_E)/1024.0/1024.0<<endl;
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>q;
    bs[0]=1;
    for(int i=1;i<S;i++) bs[i]=1ll*bs[i-1]*P%mod;
    for(int i=1;i<=n;i++){
        cin>>(s+1)>>(t+1);
        int m=strlen(s+1);
        int L=0,R=m+1;
        while(L+1<=m and s[L+1]==t[L+1]) L++;
        while(R-1>=1 and s[R-1]==t[R-1]) R--;
        if(L>R) continue;
        int h1=ghs(s,L+1,R-1),h2=ghs(t,L+1,R-1);
        int id=groot(h1,h2);
        if(L<=B and m-R+1<=B){
            hscnt[id][{ghs(s,1,L),ghs(s,R,m)}]++;
            continue;
        }
        // cout<<"ins "<<i<<endl;
        fr.insert(id,s,1,L,i,1);
        // cout<<endl;
        ed.insert(id,s,R,m,i,0);
    }
    while(q--){
        cin>>(s+1)>>(t+1);
        int m=strlen(s+1);
        int L=0,R=m+1;
        while(L+1<=m and s[L+1]==t[L+1]) L++;
        while(R-1>=1 and s[R-1]==t[R-1]) R--;
        // if(L>R) cerr<<"wtf?"<<endl;
        int h1=ghs(s,L+1,R-1),h2=ghs(t,L+1,R-1);
        if(!mp.count({h1,h2})){
            cout<<0<<'\n';
            continue;
        }
        int id=groot(h1,h2);
        int sum=0;
        for(int i=1;i<=m;i++) hsh[i]=(1ll*hsh[i-1]*P+s[i])%mod;
        for(int i=max(1,L-B+1);i<=L+1;i++){
            for(int j=R-1;j<=min(m,R+B-1);j++){
                sum+=hscnt[id][{get_hsh(i,L),get_hsh(R,j)}];
            }
        }
        if(m<=B){
            cout<<sum<<'\n';
            continue;
        }
        vector<int> pre,suf;
        fr.query(id,s,1,L,pre,1);
        ed.query(id,s,R,m,suf,0);
        ds.clear();
        for(auto nx:pre) ds[nx]++;
        for(auto nx:suf) sum+=ds[nx];
        cout<<sum<<'\n';
    }
    return 0;
}

// O(q*B^2 + q*(S/2*B ... meimaren)) 

// ccf qiufangguo

// dayangli ruocheng shenme yangzi le aaaaaa....

// ??? weishenme guandiao fsanitize 3s -> 0.5s ?