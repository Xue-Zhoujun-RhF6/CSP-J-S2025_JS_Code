#include<bits/stdc++.h>
#define N 100005
#define fi first
#define se second
using namespace std;
int a[N][3],n;
vector<int> cg[3];
signed main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int t;
    cin>>t;
    bool F=0;
    while(t--){
        cin>>n;
        int sum=0;
        for(int i=0;i<3;i++) cg[i].clear();
        for(int i=1;i<=n;i++){
            for(int j=0;j<3;j++) cin>>a[i][j];
            static int id[3]={0,1,2};
            int Id=i;
            sort(id,id+3,[&Id](int x,int y){
                return a[Id][x]>a[Id][y];
            });
            cg[id[0]].push_back(a[i][id[0]]-a[i][id[1]]);
            sum+=a[i][id[0]];
        }
        int p=n/2;
        bool flag=0;
        for(int i=0;i<3;i++){
            sort(cg[i].begin(),cg[i].end());
            int cur=0;
            while((int)cg[i].size()-cur>p){
                flag=1;
                sum-=cg[i][cur++];
            }
        }
        F|=flag;
        cout<<sum<<'\n';
    }
    // if(F) cerr<<"strong";
    return 0;
}

// g++ test.cpp -o test -O2 -Wall -Wextra -std=c++14 -fsanitize=address,undefined

// Ren5Jie4Di4Ling5%, 30th, Oct. 2025

// 14:40 passed