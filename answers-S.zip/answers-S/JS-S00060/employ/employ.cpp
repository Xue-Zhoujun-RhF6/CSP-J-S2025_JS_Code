#include<bits/stdc++.h>
#define int long long
#define mod 998244353
using namespace std;
int n,m,s[505],c[505];
int f[1<<18][19];
signed main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    bool flag=0;
    for(int i=1;i<=n;i++){
        char c;
        cin>>c;
        s[i]=c-48;
        flag|=(s[i]==0);
    }
    for(int i=0;i<n;i++) cin>>c[i],flag|=(c[i]==0);
    if(n>18){
        if(!flag){
            int ans=1;
            for(int i=1;i<=n;i++) ans=ans*i%mod;
            cout<<ans<<endl;
        }
        else{
            cout<<0<<endl;
        }
        return 0;
    }
    f[0][0]=1;
    for(int i=1;i<(1<<n);i++){
        for(int j=0;j<n;j++)if((i>>j)&1){
            int _k=(int)__builtin_popcount(i);
            int T=i^(1<<j);
            for(int k=0;k<_k;k++){
                if(s[_k]==0) (f[i][k+1]+=f[T][k])%=mod;
                else{
                    if(k>=c[j]) (f[i][k+1]+=f[T][k])%=mod;
                    else (f[i][k]+=f[T][k])%=mod;
                }
            }
        }
    }
    int ans=0;
    for(int i=0;i<=n-m;i++) (ans+=f[(1<<n)-1][i])%=mod;
    cout<<ans<<endl;
    return 0;
}