#include<bits/stdc++.h>
using namespace std;
const int N=100010;
int a[N][4],n,t;long long ans;
struct T{
    int i,x;
};
bool operator<(T a,T b){return a.x<b.x;}
T v[5];
priority_queue<int,vector<int>,greater<int>> aq,bq,cq;

int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--){
        cin>>n;
        ans=0;
        while(!aq.empty())aq.pop();
        while(!bq.empty())bq.pop();
        while(!cq.empty())cq.pop();
        for(int i=1;i<=n;i++){
            scanf("%d%d%d",&a[i][1],&a[i][2],&a[i][3]);
            v[1]={1,a[i][1]};
            v[2]={2,a[i][2]};
            v[3]={3,a[i][3]};
            sort(v+1,v+4);
            //cerr<<v[3].x<<endl;
            ans+=v[3].x;
            if(v[3].i==1){
                aq.push(v[3].x-v[2].x);
            }
            else if(v[3].i==2){
                bq.push(v[3].x-v[2].x);
            }
            else{
                cq.push(v[3].x-v[2].x);
            }
        }
        int cz;
        if((cz=aq.size()-n/2)>0){
            for(int i=1;i<=cz;i++){
                ans-=aq.top();
                //cerr<<aq.top()<<endl;
                aq.pop();
            }
        }
        else if((cz=bq.size()-n/2)>0){
            for(int i=1;i<=cz;i++){
                ans-=bq.top();
                //cerr<<bq.top()<<endl;
                bq.pop();
            }
        }
        else if((cz=cq.size()-n/2)>0){
            for(int i=1;i<=cz;i++){
                ans-=cq.top();

                //cerr<<cq.top()<<endl;
                cq.pop();
            }
        }
        cout<<ans<<'\n';
    }



    return 0;
}
