#include<bits/stdc++.h>
using namespace std;
const int N=10100;
typedef long long ll;
int n,m,k,u,v,w;ll ans1,mans;
struct edge{
    int u,v,w;
};
bool operator<(edge a,edge b){return a.w<b.w;}
vector<edge> e;
int bc[N],a[11][N],c[11];
int find(int i){return bc[i]==i?i:bc[i]=find(bc[i]);}
bool mer(int a,int b){
    a=find(a),b=find(b);
    if(a==b)return 1;
    else{
        bc[a]=b;
        return 0;
    }
}
priority_queue<edge> pq2;
vector<edge> mn,mn2;
vector<int> vil;
ll zdl(){
    ll ans=0;
    mn2.clear();
    for(auto i:mn)mn2.push_back(i);
    for(int i=1;i<=n+15;i++)bc[i]=i;
    int t=n-1;
    for(auto s:vil){
        t++;
        for(int i=1;i<=n;i++)mn2.push_back({s+n+1,i,a[s][i]});
    }
    sort(mn2.begin(),mn2.end());
    for(auto k:mn2){
        if(t==0)break;
        if(!mer(k.u,k.v)){ans+=k.w;t--;}
    }
    return ans;
}
ll zdl0(){
    ll ans=0;
    for(int i=1;i<=n;i++)bc[i]=i;
    int t=n-1;
    for(auto k:e){
        if(t==0)break;
        if(!mer(k.u,k.v)){ans+=k.w;t--;mn.push_back(k);}
    }
    return ans;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    mn.clear();e.clear();
    for(int i=1;i<=m;i++){
        scanf("%d%d%d",&u,&v,&w);
        e.push_back({u,v,w});
    }
    sort(e.begin(),e.end());
    mans=zdl0();
    for(int i=1;i<=k;i++){
            scanf("%d",&c[i]);
            for(int j=1;j<=n;j++)scanf("%d",&a[i][j]);
    }
    for(int i=1;i<(1<<k);i++){
        //cerr<<i<<endl;
        vil.clear();ans1=0;
        for(int j=1;j<=k;j++){
            if((i>>(j-1))&1){
            vil.push_back(j);
            ans1+=c[j];
            }
        }
        ans1+=zdl();
        //cerr<<ans1<<' '<<mans<<endl;
        mans=min(mans,ans1);
    }
    cout<<mans;
    return 0;
}
