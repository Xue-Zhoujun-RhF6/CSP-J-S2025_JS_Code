#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
vector<int> v;
int n,m,c[505];long long ans=0;
string s;
bool h[505];
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>s;
    for(int i=1;i<=n;i++)scanf("%d",&c[i]);
    for(int i=0;i<n;i++){
        h[i]=(s[i]=='1');
    }
    for(int i=1;i<=n;i++)v.push_back(i);
    do{
        int fail=0;
        for(int i=0;i<n;i++){
                //cout<<v[i]<<' ';
            if(!h[i]||fail>=c[v[i]])fail++;
        }
        if(fail<=n-m)ans++;
        //cout<<fail<<endl;
    }
    while(next_permutation(v.begin(),v.end()));
    cout<<ans;

    return 0;
}
