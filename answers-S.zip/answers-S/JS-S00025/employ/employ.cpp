#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int len=505,mod=998244353;
int n,m,od[len],c[len],f=1,tmp=0;
bool vis[len];
ll ans=1;
string s;
void dfs(int dep){
    if(dep==n+1){
        int cnt=0;
        for(int i=1;i<=n;i++){
            if(c[od[i]]<=cnt) cnt++;
            else if(s[i-1]=='0') cnt++;
        }
        ans+=(n-cnt>=m);
        return;
    }
    for(int i=1;i<=n;i++){
        if(!vis[i]){
            vis[i]=1;
            od[dep]=i;
            dfs(dep+1);
            vis[i]=0;
        }
    }
}
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>m>>s;
    for(int i=1;i<=n;i++){
        cin>>c[i];
        if(s[i-1]=='0') f=0;
        if(c[i]==0) tmp++;
    }
    for(int i=1;i<=n-tmp;i++){
        ans=ans*i%mod;
    }
    if(n<=10){
        ans=0;
        dfs(1);
        cout<<ans<<'\n';
    }
    else if(m==n&&!f&&tmp) cout<<0<<'\n';
    else cout<<ans<<'\n';
    return 0;
}
