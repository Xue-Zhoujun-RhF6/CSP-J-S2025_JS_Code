#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int len=1e5+5;
struct node{
    int i,mx,tmx,c;
}p[len];
int T,n,a[len][10],cnt[10];
ll ans;
bool cmp(node x,node y){
    if(x.c==y.c) return a[x.i][x.mx]>a[y.i][y.mx];
    return x.c>y.c;
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>T;
    while(T--){
        ans=cnt[1]=cnt[2]=cnt[3]=0;
        cin>>n;
        for(int i=1;i<=n;i++){
            p[i].mx=p[i].tmx=0;
            for(int j=1;j<=3;j++){
                cin>>a[i][j];
                if(a[i][j]>a[i][p[i].mx]) p[i].tmx=p[i].mx,p[i].mx=j;
                else if(a[i][j]>a[i][p[i].tmx]) p[i].tmx=j;
            }
            p[i].i=i,p[i].c=a[i][p[i].mx]-a[i][p[i].tmx];
        }
        sort(p+1,p+1+n,cmp);
        for(int i=1;i<=n;i++){
            node t=p[i];
            if(cnt[t.mx]<n/2) ans+=a[t.i][t.mx],cnt[t.mx]++;
            else ans+=a[t.i][t.tmx],cnt[t.tmx]++;
        }
        cout<<ans<<'\n';
    }
    return 0;
}
