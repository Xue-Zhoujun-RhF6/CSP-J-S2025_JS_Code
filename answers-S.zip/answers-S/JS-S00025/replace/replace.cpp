#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int len=2e5+5;
int n,q,f=1,ln[len],p[len],p2[len];
string s1,s2;
map<string,string> chge;
bool sp(){
    int cnt1=0,cnt2=0,l=s1.size();
    for(int i=0;i<l;i++){
        if(s1[i]=='a') cnt1++;
        if(s1[i]=='b') cnt2++;
    }
    return (cnt1+cnt2==l&&cnt2==1);
}
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>s1>>s2;
        ln[i]=s1.size();
        p[i]=s1.find('b');
        p2[i]=s2.find('b');
        chge[s1]=s2;
        if(!sp()) f=0;
    }
    while(q--){
        cin>>s1>>s2;
        int l=s1.size(),ans=0;
        if(f){
            for(int i=1;i<=n;i++){
                int np1=s1.find('b'),np2=s2.find('b');
                if(p[i]<=np1&&ln[i]-p[i]<=l-np1&&np1-np2==p[i]-p2[i]) ans++;
            }
        }
        else for(int i=0;i<l;i++){
            for(int j=0;i+j<=l;j++){
                if(s1.substr(0,i)+chge[s1.substr(i,j)]+s1.substr(i+j)==s2) ans++;
                //cout<<s1.substr(0,i)<<' '<<chge[s1.substr(i,j)]<<' '<<s1.substr(i+j)<<'\n';
            }
        }
        cout<<ans<<'\n';
    }
    return 0;
}
