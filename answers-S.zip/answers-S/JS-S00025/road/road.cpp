#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int len=1e4+25;
struct edge{
    ll v,w;
    bool operator<(const edge &t)const{
        return t.w<w;
    }
};
ll n,tmp,m,k,c[20],f[20],vis[len],fa[len];
ll ans=2e17;
bool op=1;
vector<edge>e[len];
int find(int x){
    if(fa[x]==x) return x;
    else return fa[x]=find(fa[x]);
}
void merge(int x,int y){
    x=find(x),y=find(y);
    if(x!=y) fa[y]=x;
    return;
}
void prim(){
    ll tot=0,cnt=n;
    priority_queue<edge> q;
    q.push({1,0});
    for(int i=0;i<=k;i++){
        if(f[i]==1){
            tot+=c[i+1];
            cnt++;
        }
    }
    while(q.size()){
        edge t=q.top();
        q.pop();
        int u=t.v;
        if(vis[u]==1) continue;
        merge(1,u);
        vis[u]=1;
        tot+=t.w;
        cnt--;
        if(cnt==0) break;
        for(int i=0;i<e[u].size();i++){
            tmp++;
            if(tmp>=4e6) return;
            ll v=e[u][i].v,w=e[u][i].w;
            if(!vis[v]&&find(v)!=find(u)&&(v<=n||(v>n&&f[v-n-1]==1))){
                q.push({v,w});
            }
        }
    }
    if(cnt==0) ans=min(ans,tot);
    return;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>n>>m>>k;
    for(int i=1;i<=m;i++){
        ll u,v,w;
        cin>>u>>v>>w;
        e[u].push_back({v,w});
        e[v].push_back({u,w});
    }
    for(int i=1;i<=k;i++){
        cin>>c[i];
        if(c[i]) op=0;
        for(int j=1;j<=n;j++){
            ll u=n+i,v=j,w;
            cin>>w;
            e[u].push_back({v,w});
            e[v].push_back({u,w});
        }
    }
    if(op){
        for(int j=1;j<=n+k;j++)
            fa[j]=j,vis[j]=0;
        for(int j=0;j<k;j++){
            f[j]=1;
        }
        prim();
        cout<<ans<<'\n';
    }
    else{
        for(int i=0;i<1<<k;i++){
            for(int j=1;j<=n+k;j++)
                fa[j]=j,vis[j]=0;
            prim();
            f[0]++;
            int w=0;
            while(f[w]==2)
                f[w]=0,f[++w]++;
        }
        cout<<ans<<'\n';
    }
    return 0;
}
