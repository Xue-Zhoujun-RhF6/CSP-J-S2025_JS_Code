#include<bits/stdc++.h>
using namespace std;
int n,m,s[505],c[505];
const int mod=998244353;
int main()
{
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;++i) cin>>s[i];
    for(int i=1;i<=n;++i) cin>>c[i];
    int ans=1;
    for(int i=1;i<=n;++i) ans=ans*i%mod;
    return 0;
}