#include<bits/stdc++.h>
using namespace std;
int n,q;
string s1[200005],s2[200005];
int main()
{
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;++i)
    {
        cin>>s1[i];
        cin>>s2[i];
    }
    string a,b;
    for(int i=1;i<=q;++i)
    {
        cin>>a>>b;
        int ans=0;
        for(int j=1;j<=n;++j)
        {
            long long aa=a.find(s1[j]),bb=b.find(s2[j]);
            if(aa==bb&&aa<a.size())
            {
                string lsa=a,lsb=b;
                lsa.replace(aa,s1[j].size(),s2[j]);
                if(lsa==lsb) ans++;
            }
        }
        cout<<ans<<'\n';
    }
    return 0;
}