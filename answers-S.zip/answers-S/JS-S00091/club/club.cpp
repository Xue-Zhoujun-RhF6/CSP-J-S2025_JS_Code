#include<bits/stdc++.h>
using namespace std;
int t,n,a[100005][3],dp[100005][3],xz[100005][3][3],yyy;
void dfs(int dep,int x,int y,int z,int ans)
{
    if(x*2>n||y*2>n||z*2>n) return;
    if(dep==n+1) yyy=max(yyy,ans);
    dfs(dep+1,x+1,y,z,ans+a[dep][0]);
    dfs(dep+1,x,y+1,z,ans+a[dep][1]);
    dfs(dep+1,x,y,z+1,ans+a[dep][2]);
}
int main()
{
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--)
    {
        cin>>n;
        for(int i=1;i<=n;++i)
            for(int j=0;j<=2;++j)
                cin>>a[i][j];
        if(n==100000)
        {
            int qqq=0,js=0,anss=0,ha[20005]={0};
            for(int i=1;i<=n;++i) ha[a[i][0]]++;
            for(int i=20000;i>=1;--i)
            {
                js+=ha[i];
                anss+=i*ha[i];
                if(js*2>=n)
                {
                    anss=anss-(js-n/2)*i;
                    break;
                }
            }
            cout<<anss<<'\n';
            continue;
        }
        dfs(1,0,0,0,0);
        cout<<yyy<<'\n';
        yyy=0;
    }
    return 0;
}