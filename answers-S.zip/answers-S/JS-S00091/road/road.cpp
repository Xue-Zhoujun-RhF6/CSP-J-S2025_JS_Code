#include<bits/stdc++.h>
using namespace std;
int n,m,k,ans,d[10005],a[12][10005];
struct mrz{
    int to,w;
};
vector<mrz> G[10005];
void dj()
{
    d[1]=0;
    int qq=n-1;
    for(int i=2;i<=n;++i) d[i]=INT_MAX;
    int mm=INT_MAX,js;
    for(int i=0;i<G[1].size();++i) d[G[1][i].to]=min(d[G[1][i].to],G[1][i].w);
    while(qq--)
    {
        for(int i=2;i<=n;++i)
            if(d[i]!=0)
                if(d[i]<mm)
                {
                    js=i;
                    mm=d[i];
                }
        ans+=mm;
        d[js]=0;
        for(int i=0;i<G[js].size();++i) d[G[js][i].to]=min(d[G[js][i].to],G[js][i].w);
        mm=INT_MAX;
    }
}
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    int u,v,w;
    for(int i=1;i<=m;++i)
    {
        cin>>u>>v>>w;
        G[u].push_back({v,w});
        G[v].push_back({u,w});
    }
    int onxb;
    for(int i=1;i<=k;++i)
    {
        cin>>onxb;
        for(int j=1;j<=n;++j)
            cin>>a[i][j];
    }    
    for(int i=1;i<=k;++i)
        for(int j=1;j<n;++j)
            for(int w=j+1;w<=n;++w)
            {
                G[j].push_back({w,a[i][j]+a[i][w]});
                G[w].push_back({j,a[i][j]+a[i][w]});
            }
    dj();
    cout<<ans;
    return 0;
}