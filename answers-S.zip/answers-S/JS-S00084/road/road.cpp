#include<bits/stdc++.h>
using namespace std;

struct Edge{
	int u,v,w;
};
bool cmp(Edge a,Edge b){
	return a.w<b.w;
}
int n,m,k;
vector<Edge> e;
int c[15],a[10005],fa[10005];

int findfa(int x){
	if(fa[x]!=x) fa[x]=findfa(fa[x]);
	return fa[x];
}
bool bing(int x,int y){
	x=findfa(x),y=findfa(y);
	if(x!=y) fa[x]=y;
	return x!=y;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		Edge tmp;
		cin>>tmp.u>>tmp.v>>tmp.w;
		e.push_back(tmp);
	}
	for(int i=1;i<=k;i++){
		cin>>c[i];
		for(int j=1;j<=n;j++){
			cin>>a[j];
		}
		for(int j=1;j<=n;j++){
			for(int p=j+1;p<=n;p++){
				Edge tmp;
				tmp.u=j,tmp.v=p,tmp.w=a[j]+a[p]+c[i];
				e.push_back(tmp);
			}
		}
	}
	for(int i=1;i<=n;i++) fa[i]=i;
	sort(e.begin(),e.end(),cmp);
	long long ans=0,cnt=0;
	for(int i=0;i<e.size();i++){
		if(bing(e[i].u,e[i].v)){
			ans+=e[i].w;
			cnt++;
		}
		if(cnt==n-1) break;
	}
	cout<<ans;
	return 0;
}
