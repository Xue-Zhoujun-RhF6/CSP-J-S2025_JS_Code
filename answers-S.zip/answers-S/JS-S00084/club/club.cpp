#include<bits/stdc++.h>
using namespace std;

struct Person{
	int a,b,c;
};
bool cmp1(Person x,Person y){
	return x.a>y.a;
}
bool cmp2(Person x,Person y){
	return x.b>y.b;
}
bool cmp3(Person x,Person y){
	return x.c>y.c;
}
int t,n;
int an,bn,cn;
int ans;
vector<Person> a,b,c;
void fa(vector<Person>& to){
	for(int i=0;i<a.size();i++){
		if(i<=n/2) ans+=a[i].a;
		else to.push_back(a[i]);
	}
	an=-1;
}
void fb(vector<Person>& to){
	for(int i=0;i<b.size();i++){
		if(i<=n/2) ans+=b[i].b;
		else to.push_back(b[i]);
	}
	bn=-1;
}
void fc(vector<Person>& to){
	for(int i=0;i<c.size();i++){
		if(i<=n/2) ans+=c[i].c;
		else to.push_back(c[i]);
	}
	cn=-1;
}

int main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	cin>>t;
	while(t--){
		cin>>n;
		ans=0;
		for(int i=1;i<=n;i++){
			Person tmp;
			cin>>tmp.a>>tmp.b>>tmp.c;
			if(max(tmp.a,max(tmp.b,tmp.c)) == tmp.a) a.push_back(tmp),an++;
			if(max(tmp.a,max(tmp.b,tmp.c)) == tmp.b) b.push_back(tmp),bn++;
			if(max(tmp.a,max(tmp.b,tmp.c)) == tmp.c) c.push_back(tmp),cn++;
		}
		if(an>bn){
			if(bn>cn) fa(b);
			else if(an>cn) fa(c);
			else fc(a);
		} else {
			if(an>cn) fb(a);
			else if(bn>cn) fb(c);
			else fc(b);
		}
		if(an<0){
			if(bn>cn) fb(c);
			else fc(b);
		}else if(bn<0){
			if(an>cn) fa(c);
			else fc(a);
		}else{
			if(an>bn) fa(b);
			else fb(a);
		}
		if(an>0) fa(b);
		if(bn>0) fb(a);
		if(cn>0) fc(a);
		cout<<ans<<endl;
	}
	return 0;
}
