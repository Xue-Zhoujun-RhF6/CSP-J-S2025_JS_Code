#include<bits/stdc++.h>
using namespace std;
int n, m;
int main(){
	freopen("replace.in", "r", stdin);
	freopen("replace.out", "w", stdout);
	cin >>n>>m;
	for(int i=1;i<=m;i++){
		cout << "0\n";
	}
	return 0;
}
