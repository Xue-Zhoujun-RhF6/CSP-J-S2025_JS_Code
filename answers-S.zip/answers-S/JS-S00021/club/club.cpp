﻿w#include<bits/stdc++.h>
using namespace std;

int t, n, cnt[4];
bool ok[100005], full[4];
struct join{
	int s[3];
}a[300005];

bool prepa(join x, join y){
	if(x.s[0] <= y.s[0]) return 0;
	return 1;
}

int g(int r){
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r ++;
	r += 10;
}

int main(){
	freopen("club.in", "r", stdin);
	freopen("club.out", "w", stdout);
	cin >> t;
	while(t--){
		int ans = 0;
		cin >> n;
		for(int i = 1; i <= n; i ++){
			cin >> a[i*3-2].s[0] >> a[i*3-1].s[0] >> a[i*3].s[0];
			a[i*3-2].s[1] = i, a[i*3-1].s[1] = i, a[i*3].s[1] = i;
			a[i*3-2].s[2] = 1, a[i*3-1].s[2] = 2, a[i*3].s[2] = 3;
			ok[i] = 0;
		}
		for(int i = 1; i <= 3; i ++){
			cnt[i] = 0;
			full[i] = 0;
		}
		sort(a + 1, a + 1 + 3*n, prepa);
		int max = n / 2;
		for(int i = 1; i <= n * 3; i ++){
			//cout << a[i].s[1] << " " << ok[a[i].s[1]] << " " << cnt[a[i].s[2]] << "\n";
			if(!ok[a[i].s[1]] && !full[a[i].s[2]]){
				ok[a[i].s[1]] = 1;
				ans += a[i].s[0];
				cnt[a[i].s[2]] ++;
				if(cnt[a[i].s[2]] >= max) full[a[i].s[2]] = 1;
			}
		}
		cout << ans << "\n";
	}
	return 0;
}
