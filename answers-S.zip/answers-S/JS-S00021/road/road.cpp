#include<bits/stdc++.h>
using namespace std;

int n, m, k, ans, c[15], a[15], fa[10005], son[10005];
struct road{
	int u, v, w;
}r[1000005];

bool ob(road x, road y){
	if(x.w < y.w) return 1;
	return 0;
}

int ffa(int s){
	if(fa[s] == s) return fa[s];
	return ffa(fa[s]);
}

int init(int x, int y){ //y is x's father
	if(ffa(y) != ffa(x));
}

int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	cin >> n >> m >> k;
	for(int i = 1; i <= m; i ++){
		cin >> r[i].u >> r[i].v >> r[i].w;
	}
	for(int i = 1; i <= k; i ++){
		cin >> c[i];
		for(int j = 1; j <= n; j ++) cin >> a[i];
	}
	sort(r+1, r+1+m, ob);
	for(int i = 1; i <= n; i ++){
		fa[i] = i, son[i] = i;
	}
	for(int i = 1; i <= m; i ++){
		if(ffa(r[i].u) != ffa(r[i].v)){
			ans += r[i].w;
			fa[r[i].u] = fa[r[i].v];
		}
	}
	cout << ans << "\n";
	return 0;
}
