#include<bits/stdc++.h>
using namespace std;
int n,m,tag_A=1;
string s;
int c[550],cnt;
long long ans=1;
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>s;
    for(int i=0;i<n;i++){
        if(s[i]==0)tag_A=0;
        else cnt++;
    }
    if(cnt<m){
        cout<<0;
    }
    for(int i=1;i<=n;i++){
        cin>>c[i];
    }
    for(int i=1;i<=n;i++){
        ans*=i;
        ans%=998244353;
    }
    if(tag_A==1){
        cout<<ans;
        return 0;
    }
    if(m==n){
        if(tag_A==0)cout<<0;
        else cout<<ans;
        return 0;
    }
    cout<<ans;
    return 0;
}
