#include<bits/stdc++.h>
using namespace std;
int n,q;
long long ans=0;
string s1[200000+5],s2[200000+5],t1[200000+5],t2[200000+5];
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>s1[i]>>s2[i];
    }
    for(int i=1;i<=q;i++){
        cin>>t1[i]>>t2[i];
    }
    for(int i=1;i<=q;i++){
        for(int j=1;j<=n;j++){
            if(t1[i].size()-s1[i].size()+s2[i].size()==t2[i].size()){
                ans++;
            }
        }
        cout<<0<<endl;
    }
    return 0;
}
