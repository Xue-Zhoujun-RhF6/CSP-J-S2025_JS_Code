#include<bits/stdc++.h>
using namespace std;
int n,m,k,tag_A=1;
int ls[10000+17];
struct Node{
    int u,v,w;
};
int r[10000+17][10000+17];
int ans=0;
vector<Node > bian;
bool cmp(Node x,Node y){
    return x.w<y.w;
}
int fa[10000+7],dep[10000+7];
int fn(int f){
    if(fa[f]!=f)fa[f]=fn(fa[f]);
    return fa[f];
}
void hebin(int x,int y){
    if(dep[x]<dep[y])swap(x,y);
    fa[fn(y)]=fn(x);
    dep[x]+=dep[y];
}
void smaltree(int x){
    int cnt=0;
    for(int i=0;i<x;i++){
        if(fn(bian[i].u)==fn(bian[i].v)||fa[bian[i].u]==fa[bian[i].v])continue;
        hebin(bian[i].u,bian[i].v);
        cnt++;
        ans+=bian[i].w;
        if(cnt==n-1)return;
    }
    return ;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=1;i<=n;i++){
        fa[i]=i,dep[i]=1;
        for(int j=1;j<=n;j++)r[i][j]=-1;
    }
    for(int i=1;i<=m;i++){
        int u,v,w;
        scanf("%d%d%d",&u,&v,&w);
        r[u][v]=w;
    }
    for(int i=1;i<=k;i++){
        int ci;
        scanf("%d",&ci);
        if(ci!=0)tag_A=0;
        for(int j=1;j<=n;j++){
            scanf("%d",&ls[j]);
            if(ls[j]!=0)tag_A=0;
        }
    }
    if(tag_A==1){
        cout<<0<<endl;
        return 0;
    }
    for(int i=1;i<=n;i++){
        r[i][i]=-1;
        for(int j=1;j<=n;j++){
            if(r[i][j]!=-1){
                Node xxx;
                xxx.u=i,xxx.v=j,xxx.w=r[i][j];
                bian.push_back(xxx);
            }
        }
    }
    sort(bian.begin(),bian.end(),cmp);
    smaltree(bian.size());
    cout<<ans;
    return 0;
}
