#include<bits/stdc++.h>
using namespace std;
const int N=1e5+7;
struct Node{
    int l,m,n,maxn;
}a[N];
int n,ans,tag_A=1;
int p1,p2,p3;
int nn,m1,m2;
int maxn;
bool cmp(Node x,Node y){
    if(x.maxn!=y.maxn)return x.maxn>y.maxn;
}
void dfs(int w1,int w2,int w3,int ans,int t){
    maxn=max(maxn,ans);
    if(t==n+1){
        return;
    }
    if(w1+1<=nn)dfs(w1+1,w2,w3,ans+a[t].l,t+1);
    if(w2+1<=nn)dfs(w1,w2+1,w3,ans+a[t].m,t+1);
    if(w3+1<=nn)dfs(w1,w2,w3+1,ans+a[t].n,t+1);
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    cin>>t;
    while(t--){
        maxn=0;
        tag_A=1;
        scanf("%d",&n);
        nn=n/2;
        for(int i=1;i<=n;i++){
            scanf("%d%d%d",&a[i].l,&a[i].m,&a[i].n);
            if(a[i].m!=0||a[i].n!=0)tag_A=0;
            a[i].maxn=max(a[i].l,max(a[i].m,a[i].n));
        }
        if(tag_A==1){sort(a+1,a+n+1,cmp); for(int i=1;i<=nn;i++)ans+=a[i].l;  cout<<ans<<endl; continue;}
        dfs(0,0,0,0,1);
        cout<<maxn<<endl;
        continue;
    }
    return 0;
}





