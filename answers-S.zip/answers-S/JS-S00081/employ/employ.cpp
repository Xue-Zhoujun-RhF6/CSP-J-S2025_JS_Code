//g++ -g employ.cpp -o employ -std=c++14 -static
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int const maxn=505,M=998244353;
char s[maxn];
int c[maxn],p[maxn],a[maxn],pre[maxn];
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m,cnt=0;
    scanf("%d%d",&n,&m);
    scanf("%s",s+1);
    for(int i=1;i<=n;i++)a[i]=s[i]-'0',cnt+=a[i];
    for(int i=1;i<=n;i++)scanf("%d",c+i);
    if(n<=10){
        for(int i=1;i<=n;i++)p[i]=i;
        int ans=0,cnt=0;
        for(int i=1;i<=n;i++){
            if(i-cnt-1>=c[p[i]]||a[i]==0)continue;
            cnt++;
        }
        if(cnt>=m)ans++;
        while(next_permutation(p+1,p+1+n)){
            cnt=0;
            for(int i=1;i<=n;i++){
                if(i-cnt-1>=c[p[i]]||a[i]==0)continue;
                cnt++;
            }
            if(cnt>=m)ans++;
        }
        printf("%d",ans);
    }
    else if(cnt<m)printf("0");
    else if(m==n){
        sort(c+1,c+1+n);
        ll ans=1;
        for(int i=1;i<=n;i++){
            ans*=a[i]*(c[i]>0);
            ans=ans*i%M;
        }
        printf("%lld",ans);
    }
    else if(m==1){
        ll res=1,ans=1;
        for(int i=1;i<=n;i++)ans=ans*i%M;
        for(int i=1;i<=n;i++)pre[c[i]]++;
        for(int i=1;i<=n;i++)pre[i]+=pre[i-1];
        cnt=0;
        for(int i=1;i<=n;i++){
            if(!a[i])continue;
            res=res*pre[i-1-cnt]%M;
            cnt++;
        }
        for(int i=1;i<=n-cnt;i++)res=res*i%M;
        printf("%lld",(ans-res+M)%M);
    }
}