//g++ -g replace.cpp -o replace -std=c++14 -static
#include<bits/stdc++.h>
using namespace std;
int const maxn=2e5+5,maxm=5e6+5;
char str[maxm];
int check=1;
void read(vector<int>&a){
    scanf("%s",str+1);
    a.clear();
    int l=strlen(str+1);
    int flag=1,cnt=0;
    for(int i=1;i<=l;i++){
        a.push_back(str[i]-'a'+1);
        if(str[i]=='a')continue;
        if(str[i]=='b'&&cnt==0)cnt++;
        else flag=0;
    }
    check&=(flag&&cnt==1);
}
vector<int>s[maxn][2],t[maxn][2];
int ls[maxn][2],lt[maxn][2];
int ps[maxn][2],pt[maxn][2];
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    int n,q;
    scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++)read(s[i][0]),read(s[i][1]),ls[i][0]=s[i][0].size(),ls[i][1]=s[i][1].size();
    for(int i=1;i<=q;i++)read(t[i][0]),read(t[i][1]),lt[i][0]=t[i][0].size(),lt[i][1]=t[i][1].size();
    if(check){
        for(int i=1;i<=n;i++){
            for(int j=0;j<2;j++){
                for(int k=0;k<ls[i][j];k++){
                    if(s[i][j][k]==2)ps[i][j]=k;
                }
            }
        }
        for(int i=1;i<=q;i++){
            for(int j=0;j<2;j++){
                for(int k=0;k<lt[i][j];k++){
                    if(t[i][j][k]==2)pt[i][j]=k;
                }
            }
        }
        for(int i=1;i<=q;i++){
            if(lt[i][0]!=lt[i][1]){
                printf("0\n");
                continue;
            }
            int ans=0;
            for(int j=1;j<=n;j++){
                if(pt[i][1]-pt[i][0]==ps[j][1]-ps[j][0]&&pt[i][1]>=ps[j][1]&&lt[i][1]-pt[i][1]>=ls[j][1]-ps[j][1])ans++;
            }
            printf("%d\n",ans);
        }
    }
}