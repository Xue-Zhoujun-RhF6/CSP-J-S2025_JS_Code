//g++ -g club.cpp -o club -std=c++14 -static
#include<bits/stdc++.h>
using namespace std;
int const maxn=1e5+5;
int cnt[3],a[3];
vector<int>v[3];
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int t;
    scanf("%d",&t);
    while(t--){
        memset(cnt,0,sizeof(cnt));
        for(int i=0;i<3;i++)v[i].clear();
        int n,ans=0;
        scanf("%d",&n);
        for(int i=1;i<=n;i++){
            int sum=0;
            for(int j=0;j<3;j++)scanf("%d",a+j),sum+=a[j];
            int mx=max(a[0],max(a[1],a[2])),mn=min(a[0],min(a[1],a[2])),mid=sum-mx-mn;
            for(int j=0;j<3;j++){
                if(mx!=a[j])continue;
                cnt[j]++;
                v[j].push_back(mx-mid);
                ans+=mx;
                break;
            }
        }
        for(int i=0;i<3;i++){
            if(cnt[i]<=n/2)continue;
            sort(v[i].begin(),v[i].end());
            for(int j=0;j<cnt[i]-n/2;j++)ans-=v[i][j];
        }
        printf("%d\n",ans);
    }
}