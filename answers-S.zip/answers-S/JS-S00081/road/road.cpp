//g++ -g road.cpp -o road -std=c++14 -static
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
int const maxn=1e4+15;
vector<pii>G1[maxn],G2[maxn];
int vis[maxn],c[15],a[15][maxn];
struct node{
    int u,v,val;
    bool operator<(const node&A)const{
        return val>A.val;
    }
};
priority_queue<node>q;
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m,k;
    scanf("%d%d%d",&n,&m,&k);
    int u,v,w;
    while(m--){
        scanf("%d%d%d",&u,&v,&w);
        G1[u].push_back(make_pair(v,w));
        G1[v].push_back(make_pair(u,w));
    }
    vis[1]=1;
    for(int i=0;i<G1[1].size();i++){
        int v=G1[1][i].first,val=G1[1][i].second;
        q.push(node{1,v,val});
    }
    while(!q.empty()){
        node t=q.top();
        q.pop();
        int u=t.v;
        if(vis[u])continue;
        vis[u]=1;
        G2[t.u].push_back(make_pair(u,t.val));
        G2[u].push_back(make_pair(t.u,t.val));
        for(int i=0;i<G1[u].size();i++){
            int v=G1[u][i].first,val=G1[u][i].second;
            if(vis[v])continue;
            q.push(node{u,v,val});
        }
    }
    int check=1,beg=0;
    for(int i=1;i<=k;i++){
        scanf("%d",c+i);
        if(c[i])check=0;
        int flag=0;
        for(int j=1;j<=n;j++){
            scanf("%d",a[i]+j);
            G2[n+i].push_back(make_pair(j,a[i][j]));
            if(!a[i][j])flag=1;
        }
        check&=flag;
    }
    if(check)beg=(1<<k)-1;
    ll ans=1e18;
    for(int s=beg;s<(1<<k);s++){
        for(int i=1;i<=n+k;i++)vis[i]=0;
        ll res=0;
        int cnt=0;
        for(int i=1;i<=k;i++){
            if((s>>(i-1)&1)==0)continue;
            cnt++,res+=c[i];
            for(int j=1;j<=n;j++)G2[j].push_back(make_pair(n+i,a[i][j]));
        }
        q.push(node{0,1,0});
        while(!q.empty()){
            node t=q.top();
            q.pop();
            int u=t.v;
            if(vis[u])continue;
            vis[u]=1,res+=t.val;
            for(int i=0;i<G2[u].size();i++){
                int v=G2[u][i].first,val=G2[u][i].second;
                if(vis[v])continue;
                q.push(node{u,v,val});
            }
        }
        for(int i=1;i<=n;i++){
            for(int j=1;j<=cnt;j++)G2[i].pop_back();
        }
        ans=min(ans,res);
    }
    printf("%lld",ans);
}