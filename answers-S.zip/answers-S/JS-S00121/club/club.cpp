#include<bits/stdc++.h>
using namespace std;
struct node{
    int a,b,c,d;
}e[100005];
int f[100005];
int main(){
    ios::sync_with_stdio(0);cin.tie(0);
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int T,n,sum1,sum2,sum3,t,tt,ttt;
    long long ans;
    cin>>T;
    while(T--){
        cin>>n;
        sum1=0;
        sum2=0;
        sum3=0;
        ans=0;
        ttt=n/2;
        for(int i=1;i<=n;i++){
            cin>>e[i].a>>e[i].b>>e[i].c;
            t=max(e[i].a,max(e[i].b,e[i].c));
            if(e[i].a==t){
                sum1++;
                e[i].d=1;
                ans+=1ll*t;
            }
            else if(e[i].b==t){
                sum2++;
                e[i].d=2;
                ans+=1ll*t;
            }
            else{
                sum3++;
                e[i].d=3;
                ans+=1ll*t;
            }
//            if(i==1) cout<<e[i].a<<' '<<e[i].b<<' '<<e[i].c<<'\n';
        }
//        cout<<sum1<<'\n'<<sum2<<'\n'<<sum3<<'\n';
        if(sum1<=ttt&&sum2<=ttt&&sum3<=ttt){
            cout<<ans<<'\n';
            continue;
        }
//        cout<<"aaaaa\n";
        tt=0;
        if(sum1>ttt){
            for(int i=1;i<=n;i++){
                if(e[i].d==1) f[++tt]=e[i].a-max(e[i].b,e[i].c);
            }
            sort(f+1,f+tt+1);
            for(int i=1;i<=sum1-ttt;i++) ans-=1ll*f[i];
            cout<<ans<<'\n';
            continue;
        }
        if(sum2>ttt){
            for(int i=1;i<=n;i++){
                if(e[i].d==2) f[++tt]=e[i].b-max(e[i].a,e[i].c);
            }
            sort(f+1,f+tt+1);
            for(int i=1;i<=sum2-ttt;i++) ans-=1ll*f[i];
            cout<<ans<<'\n';
            continue;
        }
        if(sum3>ttt){
            for(int i=1;i<=n;i++){
                if(e[i].d==3) f[++tt]=e[i].c-max(e[i].b,e[i].a);
            }
            sort(f+1,f+tt+1);
            for(int i=1;i<=sum3-ttt;i++) ans-=1ll*f[i];
            cout<<ans<<'\n';
        }
    }
    return 0;
}
