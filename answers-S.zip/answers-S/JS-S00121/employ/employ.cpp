#include<bits/stdc++.h>
using namespace std;
int main(){
    ios::sync_with_stdio(0);cin.tie(0);
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m;
    cin>>n>>m;
    long long ans=1;
    for(int i=1;i<=n;i++){
        ans*=1ll*i;
        ans%=998244353;
    }
    cout<<ans;
    return 0;
}
