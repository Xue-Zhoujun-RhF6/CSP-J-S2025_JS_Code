#include<bits/stdc++.h>
using namespace std;
struct node{
    string s,ss;
    int l;
}a[200005];
bool cmp(node x,node y){
    if(x.s!=y.s) return x.s<y.s;
    return x.ss<y.ss;
}
int main(){
    ios::sync_with_stdio(0);cin.tie(0);
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    int n,q,ll;
    long long ans;
    string st,stt,xx,yy,z;
    cin>>n>>q;
    for(int i=1;i<=n;i++){
        cin>>a[i].s>>a[i].ss;
        a[i].l=a[i].s.size();
    }
    sort(a+1,a+n+1,cmp);
//    for(int i=1;i<=n;i++) cout<<a[i].s<<' '<<a[i].ss<<'\n';
//    cout<<'\n';
    for(int i=1;i<=q;i++){
        ans=0;
        cin>>st>>stt;
        ll=st.size();
        for(int j=0;j<st.size();j++){
            for(int k=1;k<=n;k++){
//                cout<<i<<' '<<j<<' '<<k<<' '<<st.substr(j,a[k].l)<<' '<<a[k].s<<' '<<(st.substr(j,a[k].l)==a[k].s)<<'\n';
                if(st.substr(j,a[k].l)==a[k].s){
//                    cout<<"aaaa\n";
                    if(j==0) xx="";
                    else xx=st.substr(0,j);
                    if(j+a[k].l>ll) yy="";
                    else yy=st.substr(j+a[k].l,ll-j-a[k].l);
//                    cout<<xx<<' '<<a[k].ss<<' '<<yy<<'\n';
                    if((xx+a[k].ss+yy)==stt){
                        ans++;
//                        cout<<"bbbb\n";
                    }
                }
            }
        }
        cout<<ans<<'\n';
    }
    return 0;
}
