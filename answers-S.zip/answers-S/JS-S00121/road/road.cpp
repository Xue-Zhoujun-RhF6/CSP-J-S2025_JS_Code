#include<bits/stdc++.h>
using namespace std;
struct node{
    int u,v,mm;
}a[1000005];
int b[10005],d[10005];
int c[1005][1005]={0};
bool cmp1(node x,node y){
    if(x.u!=y.u) return x.u<y.u;
    return x.v<y.v;
}
bool cmp2(node x,node y){
    return x.mm<y.mm;
}
int f(int x){
    if(x==d[x]) return x;
    return d[x]=f(d[x]);
}
int main(){
    ios::sync_with_stdio(0);cin.tie(0);
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n,m,k,maxn=INT_MIN,cc,maxnn,tot=0,tt=0,t=0,xx,yy,mmm;
    long long ans=0;
    cin>>n>>m>>k;
    if(n<=1000){
        for(int i=1;i<=n;i++){
            cin>>xx>>yy>>mmm;
            if(xx>yy) swap(xx,yy);
            c[xx][yy]=mmm;
            maxn=max(maxn,mmm);
        }
        for(int i=1;i<=k;i++){
            cin>>cc;
            if(cc>=maxn) continue;
            for(int j=1;j<=n;j++) cin>>b[j];
            maxnn=INT_MIN;
            for(int j=1;j<=n;j++){
                for(int kk=j+1;kk<=n;kk++){
                    if(1ll*b[j]+1ll*b[kk]+1ll*cc>=INT_MAX*1ll) continue;
                    if(c[j][kk]==0&&(b[j]+b[kk]+cc)<=maxn) c[j][kk]=b[j]+b[kk]+cc;
                    else if(c[j][kk]!=0&&(b[j]+b[kk]+cc)<c[j][kk]) c[j][kk]=b[j]+b[kk]+cc;
                    maxnn=max(maxnn,c[j][kk]);
//                    if(c[j][kk]<0) cout<<"aaaa\n";
//                    if(b[kk]<0) cout<<"bbbb\n";
                }
            }
            maxn=min(maxn,maxnn);
        }
        for(int i=1;i<=n;i++){
            for(int j=i+1;j<=n;j++){
                if(c[i][j]!=0){
                    a[++tot].u=i;
                    a[tot].v=j;
                    a[tot].mm=c[i][j];
                }
            }
        }
        sort(a+1,a+tot+1,cmp2);
        for(int i=1;i<=n;i++) d[i]=i;
        while(tt<n-1){
            ++t;
            xx=a[t].u;
            yy=a[t].v;
            if(f(d[xx])!=f(d[yy])){
                d[f(d[yy])]=f(d[xx]);
                ++tt;
                ans+=1ll*a[t].mm;
//                cout<<ans<<'\n';
            }
        }
        cout<<ans;
        return 0;
    }
    if(k==0){
        for(int i=1;i<=m;i++){
            cin>>a[i].u>>a[i].v>>a[i].mm;
            if(a[i].u>a[i].v) swap(a[i].u,a[i].v);
        }
        sort(a+1,a+m+1,cmp2);
        for(int i=1;i<=n;i++) d[i]=i;
        while(tt<n-1){
            ++t;
            xx=a[t].u;
            yy=a[t].v;
            if(f(d[xx])!=f(d[yy])){
                d[f(d[yy])]=f(d[xx]);
                ++tt;
                ans+=1ll*a[t].mm;
            }
        }
        cout<<ans;
        return 0;
    }
    cout<<0;
    return 0;
}
