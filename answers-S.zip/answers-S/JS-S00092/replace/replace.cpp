#include <bits/stdc++.h>
using namespace std;
#define ull unsigned long long
const int N = 2e5 + 5;
const int S = 5e6 + 5;
const int base = 29;

int n, q, l[N], r[N], len[N], L, R, Len;
string s1, s2;
ull ha1[N], ha2[N], hal[N], har[N], Ha1, Ha2, Hal[S], Har[S];
int main() {
    freopen("replace.in", "r", stdin);
    freopen("replace.out", "w", stdout);
    cin >> n >> q;
    for (int i = 1; i <= n; i++) {
        cin >> s1 >> s2;
        len[i] = s1.size();
        while (l[i] < len[i]) {
            if (s1[l[i]] != s2[l[i]])
                break;
            else
                l[i]++;
        }
        r[i] = len[i];
        while (--r[i] >= l[i])
            if (s1[r[i]] != s2[r[i]])
                break;
        for (int j = l[i]; j <= r[i]; j++)
            ha1[i] = ha1[i] * base + s1[j] - 'a';
        for (int j = l[i]; j <= r[i]; j++)
            ha2[i] = ha2[i] * base + s2[j] - 'a';
        for (int j = l[i] - 1; j >= 0; j--)
            hal[i] = hal[i] * base + s1[j] - 'a';
        for (int j = r[i] + 1; j < len[i]; j++)
            har[i] = har[i] * base + s1[j] - 'a';
    }
    while (q--) {
        cin >> s1 >> s2;
        if (s1.size() != s2.size()) {
            puts("0");
            continue;
        }
        Len = s1.size();
        while (L < Len) {
            if (s1[L] != s2[L])
                break;
            else
                L++;
        }
        R = Len;
        while (--R >= L)
            if (s1[R] != s2[R])
                break;
        for (int j = L; j <= R; j++)
            Ha1 = Ha1 * base + s1[j] - 'a';
        for (int j = L; j <= R; j++)
            Ha2 = Ha2 * base + s2[j] - 'a';
        Hal[L] = 0;
        for (int j = L - 1; j >= 0; j--)
            Hal[j] = Hal[j + 1] * base + s1[j] - 'a';
        Har[R] = 0;
        for (int j = R + 1; j < Len; j++)
            Har[j] = Har[j - 1] * base + s1[j] - 'a';
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            if (r[i] - l[i] != R - L || ha1[i] != Ha1 || ha2[i] != Ha2)
                continue;
            if (l[i] > L || len[i] - r[i] > Len - R)
                continue;
            if (hal[i] == Hal[L - l[i]] && har[i] == Har[R + len[i] - r[i] - 1])
                sum++;
        }
        cout << sum << endl;
    }
    return 0;
}