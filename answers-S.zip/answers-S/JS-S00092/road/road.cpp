#include <bits/stdc++.h>
using namespace std;
const int N = 1e4 + 20;

int n, m, k, f[N];
long long ans;
struct node {
    int u, v, w;
    bool operator < (const node &x) const {
        return w < x.w;
    }
};
vector<node> e;

int find(int x) {
    if (f[x] == x)
        return x;
    return f[x] = find(f[x]);
}

void Kruscal() {
    sort(e.begin(), e.end());
    for (int i = 0; i <= n + k; i++)
        f[i] = i;
    for (auto i : e) {
        if (find(i.u) == find(i.v))
            continue;
        ans += i.w;
        f[find(i.u)] = find(i.v);
    }
}

int main() {
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    cin >> n >> m >> k;
    for (int i = 1; i <= m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        e.push_back({u, v, w});
    }
    // e.push_back({0, 1, 0});
    for (int i = 1; i <= k; i++) {
        int c;
        cin >> c;
        // e.push_back({0, i + n, c});
        for (int j = 1; j <= n; j++) {
            int a;
            cin >> a;
            e.push_back({i + n, j, a});
        }
    }
    Kruscal();
    cout << ans << endl;
    return 0;
}
/*
5 5 1
1 2 1
1 3 2
3 4 6
4 5 1
2 5 5
0 10 10 3 0 10
*/