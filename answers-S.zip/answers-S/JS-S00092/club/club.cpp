#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;

int n, a[N][3];
long long ans;
int main() {
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    int T;
    scanf("%d", &T);
    while (T--) {
        scanf("%d", &n);
        vector<int> e[3];
        ans = 0;
        for (int i = 1; i <= n; i++) {
            scanf("%d%d%d", &a[i][0], &a[i][1], &a[i][2]);
            int maxm = 0;
            for (int j = 0; j < 3; j++)
                if (a[i][j] >= a[i][(j + 1) % 3] && a[i][j] >= a[i][(j + 2) % 3]) {
                    maxm = j;
                    break;
                }
            ans += a[i][maxm];
            e[maxm].push_back(min(a[i][maxm] - a[i][(maxm + 1) % 3], a[i][maxm] - a[i][(maxm + 2) % 3]));
        }
        for (int i = 0; i < 3; i++)
            if (e[i].size() > n / 2) {
                sort(e[i].begin(), e[i].end());
                int l = e[i].size();
                while (l > n / 2) {
                    ans -= e[i][e[i].size() - l];
                    l--;
                }
                break;
            }
        printf("%lld\n", ans);
    }
    return 0;
}