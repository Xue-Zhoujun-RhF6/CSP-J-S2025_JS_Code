#include <bits/stdc++.h>
using namespace std;
vector <int>
int n,m,k;

int main(){

    return 0;
}
