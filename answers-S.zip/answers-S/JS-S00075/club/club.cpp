#include <bits/stdc++.h>
using namespace std;
struct sub{
    int su,bi;
};
struct newmem{
    int po;
    sub ab,af,as;
}newm[100005];
int t,n,cnt1=0,cnt2=0,cnt3=0,cnt=0;
bool cmp(sub x,sub y){
    return x.su>y.su;
}
bool cmp2(newmem x,newmem y){
    return x.ab.su>y.ab.su;
}
sub dai[100005];
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%d",&t);
    while(t--){
        memset(newm,0,sizeof(newm));
        memset(dai,0,sizeof(dai));
        cnt1=cnt2=cnt3=cnt=0;
        long long sumsu=0;
        scanf("%d",&n);
        for(int i=1;i<=n;i++){
            sub a[4];
            scanf("%d%d%d",&a[1].su,&a[2].su,&a[3].su);
            a[1].bi=1,a[2].bi=2,a[3].bi=3;
            sort(a+1,a+4,cmp);
            newm[i].po=i;newm[i].ab.su=a[1].su,newm[i].ab.bi=a[1].bi,newm[i].af.su=a[2].su,newm[i].af.bi=a[2].bi,newm[i].as.su=a[3].su,newm[i].as.bi=a[3].bi;
        }
        sort(newm+1,newm+n+1,cmp2);
        for(int i=1;i<=n;i++){
                if(newm[i].ab.bi==1){
                    if(cnt1<n/2){
                        cnt1++;
                        sumsu+=newm[i].ab.su;
                    }else{
                        if(newm[i].af.bi==2){
                            if(cnt2<n/2){
                                dai[++cnt].su=newm[i].af.su;
                                dai[cnt].bi=newm[i].af.bi;
                            }else{
                                dai[++cnt].su=newm[i].as.su;
                                dai[cnt].bi=newm[i].as.bi;
                            }
                        }else{
                            if(cnt3<n/2){
                                dai[++cnt].su=newm[i].af.su;
                                dai[cnt].bi=newm[i].af.bi;
                            }else{
                                dai[++cnt].su=newm[i].as.su;
                                dai[cnt].bi=newm[i].as.bi;
                            }
                        }
                    }
                }
                else if(newm[i].ab.bi==2){
                    if(cnt2<n/2){
                        cnt2++;
                        sumsu+=newm[i].ab.su;
                    }else{
                        if(newm[i].af.bi==1){
                            if(cnt1<n/2){
                                dai[++cnt].su=newm[i].af.su;
                                dai[cnt].bi=newm[i].af.bi;
                            }else{
                                dai[++cnt].su=newm[i].as.su;
                                dai[cnt].bi=newm[i].as.bi;
                            }
                        }else{
                            if(cnt3<n/2){
                                dai[++cnt].su=newm[i].af.su;
                                dai[cnt].bi=newm[i].af.bi;
                            }else{
                                dai[++cnt].su=newm[i].as.su;
                                dai[cnt].bi=newm[i].as.bi;
                            }
                        }
                    }
                }
                else if(newm[i].ab.bi==3){
                    if(cnt3<n/2){
                        cnt3++;
                        sumsu+=newm[i].ab.su;
                    }else{
                        if(newm[i].af.bi==2){
                            if(cnt1<n/2){
                                dai[++cnt].su=newm[i].af.su;
                                dai[cnt].bi=newm[i].af.bi;
                            }else{
                                dai[++cnt].su=newm[i].as.su;
                                dai[cnt].bi=newm[i].as.bi;
                            }
                        }else{
                            if(cnt2<n/2){
                                dai[++cnt].su=newm[i].af.su;
                                dai[cnt].bi=newm[i].af.bi;
                            }else{
                                dai[++cnt].su=newm[i].as.su;
                                dai[cnt].bi=newm[i].as.bi;
                            }
                        }
                    }
                }
            }
        sort(dai+1,dai+cnt+1,cmp);
        for(int i=1;i<=cnt;i++){
            if(cnt1<n/2&&dai[i].bi==1){
                cnt1++;
                sumsu+=dai[i].su;
            }else if(cnt2<n/2&&dai[i].bi==2){
                cnt2++;
                sumsu+=dai[i].su;
            }else if(cnt3<n/2&&dai[i].bi==3){
                cnt3++;
                sumsu+=dai[i].su;
            }
        }
        cout<<sumsu<<"\n";
    }
    return 0;
}
