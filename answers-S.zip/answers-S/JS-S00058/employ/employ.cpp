#include<bits/stdc++.h>
using namespace std;

int n ,m;
string s;

int main(){
    freopen("employ.in", "r", stdin);
    freopen("employ.out", "w", stdout);
    cin >> n >> m >> s;
    for(int i = 0;i < n;i++){
        int lose;
        cin >> lose;
        if(s[i] - '0' == 0){
            if(i + 1 < m){
                cout << 0;
            }else{
                cout << i * (i - 1);
            }
        }
    }
    return 0;
}
