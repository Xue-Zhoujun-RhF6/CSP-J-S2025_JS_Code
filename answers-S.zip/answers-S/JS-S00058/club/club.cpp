#include<bits/stdc++.h>
using namespace std;
const int MAX_N = 1e5 + 5;
int member[MAX_N];
bool choose[MAX_N];
int dp[MAX_N];
int club[4];
int main(){
    freopen("club.in", "r", stdin);
    freopen("club.out", "w", stdout);
    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        for(int i = 1;i <= n * 3;i++){
            cin >> member[i];
        }
        int pos;
        for(int i = 1;i <= n;i++){
            for(int j = 1; j <= n * 3;j++){
                if(!choose[j] && club[j % 3] < n / 2){
                    if(dp[i] < member[j]){
                        dp[i] = member[j];
                        pos = j;
                    }
                }
            }
            dp[i] += dp[i - 1];
            int l = 3 * (pos / 3);
            club[pos - l]++;
            choose[l + 1] = 1;
            choose[l + 2] = 1;
            choose[l + 3] = 1;
        }
        cout << dp[n] << " ";
        memset(choose, 0, sizeof(choose));
        memset(dp, 0, sizeof(dp));
        club[0] = 0;
        club[1] = 0;
        club[2] = 0;
    }
    return 0;
}
