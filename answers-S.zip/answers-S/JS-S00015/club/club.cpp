#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e5+5;
ll t,n,a,b,c,ans;
vector<ll>clb[5];
signed main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%lld",&t);
    while(t--){
        ans=0,clb[1].clear(),clb[2].clear(),clb[3].clear();
        scanf("%lld",&n);
        for(int i=1;i<=n;i++){
            scanf("%lld%lld%lld",&a,&b,&c);
            if(a>b && a>c)      {clb[1].push_back(min(a-b,a-c));}
            else if(b>a && b>c) {clb[2].push_back(min(b-a,b-c));}
            else if(c>a && c>b) {clb[3].push_back(min(c-a,c-b));}
            ans+=max({a,b,c});
        }
        if((ll)clb[1].size()>n/2){
            sort(clb[1].begin(),clb[1].end());
            for(int i=0;i<=(ll)clb[1].size()-n/2-1;i++) {ans-=clb[1][i];}
        }
        if((ll)clb[2].size()>n/2){
            sort(clb[2].begin(),clb[2].end());
            for(int i=0;i<=(ll)clb[2].size()-n/2-1;i++) {ans-=clb[2][i];}
        }
        if((ll)clb[3].size()>n/2){
            sort(clb[3].begin(),clb[3].end());
            for(int i=0;i<=(ll)clb[3].size()-n/2-1;i++) {ans-=clb[3][i];}
        }
        //cerr<<"shushu\n";
        printf("%lld\n",ans);
    }
    return 0;
}
