#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=20,mod=998244353;
int n,m,a[N],b[N];
int dp[(1<<18)+50][N];
int get(int x){
    int res=0;
    while(x){
        res+=(x&1),x>>=1;
    }
    return res;
}
signed main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++){
        char c;
        cin>>c;
        a[i]=c-'0';
    }
    for(int i=0;i<n;i++){
        scanf("%d",&b[i]);
    }
    dp[0][0]=1;
    for(int i=0;i<1<<n;i++){
        int x=get(i);
        for(int j=0;j<=x;j++){
            for(int k=0;k<n;k++){
                if((i&(1<<k))){
                    continue;
                }
                //(dp[i|(1<<k)][j+((k-j)<b[k] && a[k]==1)]+=dp[i][j])%=mod;
                (dp[i|(1<<k)][j+(j>=b[k] && a[k]==1)]+=dp[i][j])%=mod;
            }
        }
    }

    for(int j=0;j<=n;j++){
        cerr<<dp[(1<<n)-1][j]<<" ";
    }cerr<<'\n';
    int ans=0;
    for(int j=0;j<=n-m;j++){
        (ans+=dp[(1<<n)-1][j])%=mod;
    }
    printf("%d",ans);
    return 0;
}
