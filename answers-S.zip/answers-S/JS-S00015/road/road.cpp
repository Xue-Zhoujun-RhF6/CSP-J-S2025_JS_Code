//zui xiao sheng cheng shu
#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e4+5,M=1e6+5,K=15;
int n,m,k,c[N],a[N],ans,f[N];
struct edge{
    int u,v,w;
}e[M<<1];
bool cmp(edge a,edge b){
    return a.w<b.w;
}
int find(int x){
    return f[x]==x?x:f[x]=find(f[x]);
}
void kruskal(){
    for(int i=1;i<=k;i++){
        for(int j=1;j<=n;j++){
            e[++m]={1ll*n+i,1ll*n+j,1ll*a[i][j]};
        }
    }
    int ans=0;
    for(int i=1;i<=m;i++){
        int u=e[i].u,v=e[i].v,w=e[i].w;
        if(find(u)!=find(v)){
            ans+=w;
            p[find(u)]=find(v);
            if(cnt==n*k){
                break;
            }
        }
    }
    printf("%d",ans);
}
signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=m;i++){
        scanf("%d%d%d",&e[i].u,&e[i].v,&e[i].w);
    }
    int tot=n;
    bool flag=1;
    for(int i=1;i<=k;i++){
        scanf("%d",&c[i]);
        flag&=(c[i]==0);
        bool zero=0;
        for(int j=1;j<=c[i];j++){
            scanf("%d",&a[i][j] );
            zero|=(a[i][j]>0ll);
        }
        tot+=2
    }
    if(flag){
        kruskal(),exit(0);
    }
    int now=0;
    for(int i=1;i<=m;i++){
        e[i]=a[i];
    }
    for(int i=1;i<=n;i++){
        f[i]=i;
    }
    sort(e+1,e+m+1,cmp);
    int ans=0,cnt=0;
    for(int i=1;i<=m;i++){
        int u=e[i].u,v=e[i].v;
        if(find(x)!=find(y)){
            ans=w;
            cnt++;
            a[++now]=e[i];

        }

    }
    for(int i=1;i<=e;i++){
        int u=e[i].u,v=e[i].v,w=e[i].w;
        if(find(u)!=find(v)){
            ans+=w;
            p[find(u)]=find(v);
            if(cnt==n*k){
                break;
            }
        }
    }
    printf("%d",ans);
    /*
    int ans=1e18;
    for(int i=0;i<1<<k;i++){
        int sum=0,e=0;
        cnt=0;
        for(int j=1;j<=m;j++){
            e[++e]=a[j];
        }
        for(int j=1;j<=k;j++){
            vis[n+j]=0;
            if(i&(1<<(j-1)){
                vis[n+j]=1;
                for(int l=1;l<=n;l++){
                    e[++m]={}
                }
            }
            sum+=c[j];
            cnt++;
        }
    }
    */
    return 0;
}
