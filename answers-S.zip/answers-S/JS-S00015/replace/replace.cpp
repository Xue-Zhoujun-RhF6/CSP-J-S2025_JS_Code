#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
const int N=2e5+5,base=233;
//11471543
int n,q;
string a[N],b[N],q1[N],q2[N];
vector<ull>v1[N],v2[N],g1,g2;
ull pw[N],ans;
ull hsh1(int x,int l,int r){
    //return v1[x][r]*pw[r-l+1]*v1[x][l-1];
    return v1[x][r]*pw[r-l+1]+v1[x][l-1];
}
ull hsh2(int x,int l,int r){
    //return v2[x][r]*pw[r-l+1]*v2[x][l-1];
    return v2[x][r]*pw[r-l+1]+v2[x][l-1];
}
ull hsh3(int l,int r){
    if(l>r){
        return 0;
    }
    //return g1[r]*pw[r-l+1]*g1[l-1];
    return g1[r]*pw[r-l+1]+g1[l-1];
}
ull hsh4(int l,int r){
    if(l>r){
        return 0;
    }
    //return g2[r]*pw[r-l+1]*g2[l-1];
    return g2[r]*pw[r-l+1]+g2[l-1];
}
signed main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    pw[0]=1;
    for(int i=1;i<N;i++){
        pw[i]=pw[i-1]*base;
    }
    bool flag=1;
    for(int i=1;i<=n;i++){
        cin>>a[i]>>b[i];
        v1[i].push_back(0);
        v2[i].push_back(0);
        ull r1=0,r2=0;
        for(int j=0;j<(int)a[i].size();j++){
            r1=r1*base+a[i][j];
            r2=r2*base+b[i][j];
            v1[i].push_back(r1);
            v2[i].push_back(r2);
        }
    }
    while(q--){
        string x,y;
        cin>>x>>y;
        g1.clear(),g2.clear();
        if(x.size()!=y.size()){
            puts("0");
            continue;
        }
        g1.push_back(0),g2.push_back(0);
        ull r1=0,r2=0;
        for(int j=0;j<(int)x.size();j++){
            r1=r1*base+x[j];
            r2=r2*base+y[j];
            g1.push_back(r1);
            g2.push_back(r2);
        }
        for(int j=0;j<(int)g1.size();j++){
            for(int i=1;i<=n;i++){
                if(j+(int)a[i].size()-1>=(int)g1.size()){
                    continue;
                }
                //if(v1[i].back()==hsh3(j,j+a[i].size()-1) && v2[i].back()==hsh4(j,j+a[i].size()-1)){
                //if(hsh1(i,1,a[i].size())==hsh3(j,j+a[i].size()-1) && hsh2(i,1,a[i].size())==hsh4(j,j+a[i].size()-1)){
                //if(hsh1(i,1,a[i].size()==hsh3(j,j+a[i].size()-1) && hsh2(i,1,a[i].size()==hsh4(j,j+a[i].size()-1) && hsh3(j,j+a[i].size()-1)==hsh4(j,j+a[i].size()-1)))){
                //if(v1[i].back()==hsh3(j,j+a[i].size()-1) && v2[i].back()==hsh4(j,j+a[i].size()-1) && hsh1(i,1,a[i].size())!=hsh2(i,1,a[i].size()) && hsh3(j,j+a[i].size()-1)!=hsh4(j,j+a[i].size()-1)){
                if(v1[i].back()==hsh3(j,j+a[i].size()-1) && v2[i].back()==hsh4(j,j+a[i].size()-1) && hsh3(j+a[i].size(),x.size())==hsh4(j+a[i].size(),x.size())){
                    ans++;
                }
            }
        /*
            if(x[j-1]!=y[j-1]){
                break;
            }
        */
        }
        printf("%lld",ans);
    }

}
