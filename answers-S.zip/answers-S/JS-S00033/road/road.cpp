#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int a,b,c,mina=1e9,minb=1e9,ans=0;
	int s1[10086][100],s2[10086][100];
	cin>>a>>b>>c;
	for(int i=1;i<=a;i++){
		for(int j=1;j<=3;j++){
			cin>>s1[i][j];
			mina=min(mina,s1[i][j]);
		}
		ans+=mina;
		mina=1e9;
	}
	for(int i=1;i<=c;i++){
		for(int j=1;j<=b+1;j++){
			cin>>s2[i][j];
			minb=min(minb,s2[i][j]);
			
	}
		ans+=minb;
		minb=1e9;
	}
	cout<<ans;
}
