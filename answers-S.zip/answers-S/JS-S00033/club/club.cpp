#include<bits/stdc++.h>
using namespace std;
#define int long long
int w[4]={0,0,0,0},e[4]={0,0,0,0},a[10005][4],b[10005][4],cnt=0;
int  maxa(int q){
	int ans=-1e9;
	for(int i=1;i<=q;i++){
		for(int j=1;j<=3;j++){
			ans=max(ans,a[i][j]);
			}
		}
	for(int i=1;i<=q;i++){
		for(int j=1;j<=3;j++){
			if(ans==a[i][j]&&w[j]+1<=q/2){
				w[j]++;
				for(int k=1;k<=3;k++)a[i][k]=-1e9;
				if(ans>=0)return ans;
				}else if(ans==a[i][j]&&w[j]+1>q/2){
					a[i][j]=-1e9;
					ans=max(a[i][1],max(a[i][2],a[i][3]));
					if(ans==a[i][1]){
						w[1]++;
						a[i][1]=-1e9;
					}
					if(ans==a[i][2]){
						w[2]++;
						a[i][2]=-1e9;
					}
					if(ans==a[i][3]){
						w[3]++;
						a[i][3]=-1e9;
					}
					if(w[1]<=q/2&&w[2]<=q/2&&w[3]<=q/2)return ans;
					else{
						if(a[i][1]!=-1e9){
							return a[i][1];
							a[i][1]=-1e9;
							w[1]++;
						}
						if(a[i][2]!=-1e9){
							return a[i][2];
							a[i][2]=-1e9;
							w[2]++;
						}
						if(a[i][3]!=-1e9){
							return a[i][3];
							a[i][3]=-1e9;
							w[3]++;
						}
					}
				}
			}
	}
	return 0;
}
int maxa1(int q){
	int ans=-1e9;
	for(int i=1;i<=q;i++){
		for(int j=1;j<=3;j++){
			ans=max(ans,b[i][j]);
		}
	}
	if(cnt==0){
		cnt++;
		for(int i=1;i<=q;i++){
			for(int j=1;j<=3;j++){
				if(ans==b[i][j]){
					b[i][j]=-1e9;
					ans=-1e9;
					ans=max(b[i][1],max(b[i][2],b[i][3]));
					if(ans==b[i][1]&&e[1]+1<=q/2){
						e[1]++;
						return ans;
					}else if(ans==b[i][2]&&e[2]+1<=q/2){
						e[2]++;
						return ans;
					}else if(ans==b[i][3]&&e[3]+1<=q/2){
						e[3]++;
						return ans;
				}
					for(int k=1;k<=3;k++)b[i][k]=-1e9;
				}
			}
		}
		
	}else{
		for(int i=1;i<=q;i++){
			for(int j=1;j<=3;j++){
				if(ans==b[i][j]&&e[j]+1<=q/2){
					e[j]++;
					for(int k=1;k<=3;k++)b[i][k]=-1e9;
					if(ans>=0)return ans;
					}else if(ans==b[i][j]&&e[j]+1>q/2){
						b[i][j]=-1e9;
						ans=-1e9;
						ans=max(b[i][1],max(b[i][2],b[i][3]));
						if(ans==b[i][1]&&e[1]+1<=q/2){
							e[1]++;
							b[i][1]=-1e9;
						}
						if(ans==b[i][2]&&e[2]+1<=q/2){
							e[2]++;
							b[i][2]=-1e9;
						}
						if(ans==b[i][3]&&e[3]+1<=q/2){
							e[3]++;
							b[i][3]=-1e9;
						}
						if(e[1]<=q/2&&e[2]<=q/2&&e[3]<=q/2)return ans;
						else{
							if(b[i][1]!=-1e9){
								return b[i][1];
								b[i][1]=-1e9;
								e[1]++;
							}
							if(b[i][2]!=-1e9){
								return b[i][2];
								b[i][2]=-1e9;
								e[2]++;
							}
							if(b[i][3]!=-1e9){
								return b[i][3];
								b[i][3]=-1e9;
								e[3]++;
						}
					}
				}
			}
	}	
	}
	return 0;
}
signed main(){
	freopen("club.in","r",stdin);
	freopen("club.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int t;
	cin>>t;
	while(t--){
		cnt=0;
		int n;
		cin>>n;
		int qus1=0,qus2=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=3;j++){
				cin>>a[i][j];
				b[i][j]=a[i][j];
				}	
			}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=3;j++){
				qus1+=maxa(n);
				qus2+=maxa1(n);
				//cout<<"     qus2 1       "<<qus2<<endl;
		}}
		//cout<<"     qus2       "<<qus2<<endl;
		cout<<max(qus1,qus2)<<endl;
		for(int i=0;i<=n;i++){
			w[i]=0;
			e[i]=0;
			for(int j=0;j<=n;j++){
				a[i][j]=0;
				b[i][j]=0;
			}
		}
	}
	
}
