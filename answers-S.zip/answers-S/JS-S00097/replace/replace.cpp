#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2e6+3e5;
int n,q,m,l[N],ans;
string t1,t2,s1,s2;
struct H{
    string s1,s2;
    int l;
}a[N];
bool cmp(H x,H y){
    return x.l<y.l;
}
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    scanf("%d%d",&n,&q);
    int x,y,z,b,c;
    for (int j=1;j<=n;j++){
            cin>>s1>>s2;
            if(s1==s2)continue;
        for (int i=0;i<s1.length();i++){
            if(s1[i]!=s2[i]){
                x=i;
                break;
            }
        }
        for (int i=s1.length()-1;i>=0;i--){
            if(s1[i]!=s2[i]){
                y=i;
                break;
            }
        }
        for (int i=x;i<=y;i++){
            a[j].s1+=s1[i];
            a[j].s2+=s2[i];
        }
        l[j]=a[j].l=a[j].s1.length();
        m=max(m,a[j].l);
    }
    sort(a+1,a+n+1,cmp);
    sort(l+1,l+n+1);
    
    while(q--){
        ans=0;
        cin>>t1>>t2;
        if(t1.length()!=t2.length()){
            printf("0\n");
                continue;
        }
        for (int i=0;i<t1.length();i++){
            if(t1[i]!=t2[i]){
                x=i;
                break;
            }
        }
        for (int i=t1.length()-1;i>=0;i--){
            if(t1[i]!=t2[i]){
                y=i;
                break;
            }
        }
        z=y-x+1;
        if(z>m){
            printf("0\n");
            continue;
        }
        string tt1,tt2;
        for (int i=x;i<=y;i++){
            tt1+=t1[i];
            tt2+=t2[i];
        }
        b=lower_bound(l+1,l+n+1,z)-l-1;
        c=upper_bound(l+1,l+n+1,z)-l-2;
        for (int i=b;i<=c;i++){
            if(tt1==a[i].s1&&tt2==a[i].s2)ans++;
        }
        printf("%d\n",ans);
    }
    return 0;
}