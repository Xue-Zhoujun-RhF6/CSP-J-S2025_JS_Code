#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+3;
int n,t;
struct H{
    int x,b,c,d;
    bool operator<(const H &i)const{
        return i.d<d;
    }
}a[N];

int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    scanf("%d",&t);
    
    while(t--){
        int x[4],k=0;
        ll ans=0;
        scanf("%d",&n);
        memset(x,0,sizeof(x));
        memset(a,0,sizeof(a));
        for(int j=1;j<=n;j++){
            for (int i=1;i<=3;i++){
                scanf("%d",&k);
                if(a[j].b<k){
                    a[j].c=a[j].b;
                    a[j].b=k;
                    a[j].x=i;
                }else if(a[j].c<k){
                    a[j].c=k;
                }
            }
            a[j].d=a[j].b-a[j].c;
            x[a[j].x]++;
            ans+=a[j].b;
        }
        priority_queue<H> q;
        for (int i=1;i<=3;i++){
            if(x[i]>(n/2)){
                for (int j=1;j<=n;j++){
                    if(a[j].x==i){
                        q.emplace(a[j]);
                    }
                }
                while(x[i]>(n/2)){
                    x[i]--;
                    ans-=q.top().d;
                    q.pop();
                }

                break;
            }
        }
        printf("%lld\n",ans);
    }
    return 0;
}