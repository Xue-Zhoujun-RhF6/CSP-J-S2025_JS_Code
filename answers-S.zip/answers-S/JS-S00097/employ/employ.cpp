#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=503,M=998244353;
int n,m,c[N],s0,s1,a[N];
char s[N];
ll ans;
bool h1,h2,h[N];
int main(){
   freopen("employ.in","r",stdin);
   freopen("employ.out","w",stdout);
    scanf("%d%d",&n,&m);
    scanf("%s",s);
    for (int i=1;i<=n;i++){
        scanf("%d",&c[i]);
        if(c[i]==0)h1=1;
        a[c[i]]++;
    }
    for (int i=0;i<n;i++){
        if(s[i]=='1')h[i+1]=1;
        if(h[i+1]==0)h2=1;
        if(h[i+1])s1++;
        else s0++;
        //cout<<h[i+1];
    }
    if(m==n){
        if(!h1&&!h2){
            ans=1;
            for (int i=2;i<=n;i++){
                (ans*=i)%=M;    
            }
            printf("%lld",ans);
                return 0;
        }else{
            printf("0");
            return 0;
        }
    }
    if(m==1){
            ll t=0,tot=0;
            ans=1;
            for (int i=0;i<n;i++){
                t+=a[i];
                if(s[i]){
                    tot++;
                    (ans*=(t-tot+1))%=M;
                    if(t-tot+1<0)ans=0;
                }
            } 
            for (int i=2;i<=s0;i++){
                (ans*=i)%=M;
            }
            t=1;
            for (int i=2;i<=n;i++){
                (t*=i)%=M;
            }
            printf("%lld",(t+M-ans)%M);
//cout<<endl<<ans<<' '<<t;
//cout<<endl<<s0<<endl<<s1;
            return 0;
        
    }
    return 0;
}