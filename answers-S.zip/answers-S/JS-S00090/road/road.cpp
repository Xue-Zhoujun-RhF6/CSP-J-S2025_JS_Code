#include<bits/stdc++.h>
#define sz(x) (int)(x.size())
#define mpr make_pair
using namespace std;
typedef pair<int,int> pii;
typedef long long ll;
inline int read(){
    char ch;int s=0,w=1;
    while((ch=getchar())>'9'||ch<'0')if(ch=='-')w=-1;
    while(ch>='0'&&ch<='9')s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return s*w;
}
const int N=1200005;
struct Edge{
    int u,v,w;
    bool operator <(const Edge &x){
        return w<x.w;
    }
}e[N];
int n,m,k,kd;
int c[15];
int fa[11005];
int find(int x){
    if(x==fa[x]) return x;
    return fa[x]=find(fa[x]);
}
int lowbit(int x){
    return x&(-x);
}
int mypopcnt(int x){
    int res=0;
    while(x>0){
        res++;
        x-=lowbit(x);
    }
    return res;
}
bool specialA(){
    n=read(),m=read(),k=read();
    for(int i=1;i<=m;i++){
        e[i].u=read(),e[i].v=read(),e[i].w=read();
    }
    bool res=1;
    kd=m;
    for(int i=0;i<k;i++){
        c[i]=read();
        res&=(c[i]==0);
        bool fl=0;
        for(int j=1;j<=n;j++){
            int x=read();
            fl|=(x==0);
            e[++kd]={i+n+1,j,x};
        }
        res&=fl;
    }
    return res;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    if(specialA()){
        sort(e+1,e+kd+1);
        for(int i=1;i<=n+k;i++) fa[i]=i;
        int cnt=0;
        ll ans=0;
        for(int i=1;i<=kd;i++){
            if(cnt==n+k-1) break;
            int u=e[i].u,v=e[i].v,w=e[i].w;
            int x=find(u),y=find(v);
            if(x==y) continue;
            cnt++;
            fa[x]=y;
            ans+=w;
        }
        cout<<ans<<'\n';
    }else{
        sort(e+1,e+kd+1);
        ll ans=3e15;
        for(int S=0;S<(1<<k);S++){
            ll res=0; int cnt=0;
            int p=mypopcnt(S);
            for(int i=1;i<=n+k;i++) fa[i]=i;
            for(int i=0;i<k;i++) if(S&(1<<i)) res+=c[i];
            for(int i=1;i<=kd;i++){
                if(cnt==n+p-1) break;
                int u=e[i].u,v=e[i].v,w=e[i].w;
                if(u>n&&!(S&(1<<(u-n-1)))) continue;
                int x=find(u),y=find(v);
                if(x==y) continue;
                cnt++;
                fa[x]=y;
                res+=w;
            }
            ans=min(ans,res);
        }
        cout<<ans<<'\n';
    }
    return 0;
}

/*
Things to check:
1. if MOD-ed / negative MODs
2. if overflow(long long)
3. if there is Undefined Behaviour(yuejie / no return value)
4. don't use 'auto'
5. filename / FileIO
6. move the cpp to folder 'JS-S00090'
CSP-S 2025 RP++!
*/