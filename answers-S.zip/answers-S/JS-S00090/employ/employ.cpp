#include<bits/stdc++.h>
#define sz(x) (int)(x.size())
#define mpr make_pair
using namespace std;
typedef pair<int,int> pii;
typedef long long ll;
inline int read(){
    char ch;int s=0,w=1;
    while((ch=getchar())>'9'||ch<'0')if(ch=='-')w=-1;
    while(ch>='0'&&ch<='9')s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return s*w;
}
const int N=505;
const int MOD=998244353;
int a[N],id[N];
int main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    int n,m; cin>>n>>m;
    string s; cin>>s;
    s=" "+s;
    for(int i=1;i<=n;i++) cin>>a[i];
    sort(a+1,a+n+1);
    for(int i=1;i<=n;i++) id[i]=i;
    ll ans=0;
    do{
        int ref=0;
        for(int i=1;i<=n;i++){
            if(ref>=a[id[i]]){
                ref++;
            }else if(s[i]=='0') ref++;
        }
        ans+=(n-ref>=m);
        ans%=MOD;
    }while(next_permutation(id+1,id+n+1));
    cout<<ans<<endl;
    return 0;
}

/*
Things to check:
1. if MOD-ed / negative MODs
2. if overflow(long long)
3. if there is Undefined Behaviour(yuejie / no return value)
4. don't use 'auto'
5. filename / FileIO
6. move the cpp to folder 'JS-S00090'
CSP-S 2025 RP++!
*/