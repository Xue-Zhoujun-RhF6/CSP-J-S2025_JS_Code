#include<bits/stdc++.h>
#define sz(x) (int)(x.size())
#define mpr make_pair
using namespace std;
typedef pair<int,int> pii;
typedef long long ll;
inline int read(){
    char ch;int s=0,w=1;
    while((ch=getchar())>'9'||ch<'0')if(ch=='-')w=-1;
    while(ch>='0'&&ch<='9')s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return s*w;
}
const int N=1e5+5;
int cnt[3],cost[N],cse[N];
void solve(){
    int n=read();
    for(int i=0;i<3;i++) cnt[i]=0;
    ll ans=0;
    for(int i=1;i<=n;i++){
        vector<pii> v;
        for(int j=0;j<3;j++) v.push_back(mpr(read(),j));
        sort(v.begin(),v.end(),greater<pii>());
        ans+=v[0].first;
        cnt[v[0].second]++;
        cse[i]=v[0].second;
        cost[i]=v[0].first-v[1].first;
    }
    for(int j=0;j<3;j++){
        if(cnt[j]>n/2){
            vector<int> ch;
            for(int i=1;i<=n;i++){
                if(cse[i]==j){
                    ch.push_back(cost[i]);
                }
            }
            sort(ch.begin(),ch.end());
            for(int i=0;i<cnt[j]-n/2;i++) ans-=ch[i];
            break;
        }
    }
    cout<<ans<<'\n';
}
int main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    int T=read();
    while(T--) solve();
    return 0;
}

/*
Things to check:
1. if MOD-ed / negative MODs
2. if overflow(long long)
3. if there is Undefined Behaviour(yuejie / no return value)
4. don't use 'auto'
5. filename / FileIO
6. move the cpp to folder 'JS-S00090'
CSP-S 2025 RP++!
*/