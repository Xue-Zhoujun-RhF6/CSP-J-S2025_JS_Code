#include<bits/stdc++.h>
#define sz(x) (int)(x.size())
#define mpr make_pair
using namespace std;
typedef pair<int,int> pii;
typedef long long ll;
inline int read(){
    char ch;int s=0,w=1;
    while((ch=getchar())>'9'||ch<'0')if(ch=='-')w=-1;
    while(ch>='0'&&ch<='9')s=(s<<1)+(s<<3)+(ch^48),ch=getchar();
    return s*w;
}
const int N=5e6+5;
string S[200005],T[200005];
map<int,multiset<pii> > mp[2];
int n,Q;
bool specialB(){
    n=read(),Q=read();
    bool fl=1;
    for(int i=1;i<=n;i++){
        string s,t;
        char ch;while((ch=getchar())>'z'||ch<'a');
        int cntb=0;
        while(ch>='a'&&ch<='z'){fl&=(ch=='a'||ch=='b');cntb+=(ch=='b');s+=ch;ch=getchar();}
        fl&=(cntb==1); cntb=0;
        while((ch=getchar())>'z'||ch<'a');
        while(ch>='a'&&ch<='z'){fl&=(ch=='a'||ch=='b');cntb+=(ch=='b');t+=ch;ch=getchar();}
        fl&=(cntb==1);
        S[i]=s,T[i]=t;
        int l=0,r=sz(s)-1;
        while(l<=r&&s[l]==t[l]) l++;
        while(l<=r&&s[r]==t[r]) r--;
        if(l>r) continue;
        if(s[l]=='b'){
            mp[0][r-l+1].insert({l,sz(s)-r-1});
        }else{
            mp[1][r-l+1].insert({l,sz(s)-r-1});
        }
    }
    return fl;
}

void solve1(){
    while(Q--){
        string s,t;
        char ch;while((ch=getchar())>'z'||ch<'a');
        while(ch>='a'&&ch<='z'){s+=ch;ch=getchar();}
        while((ch=getchar())>'z'||ch<'a');
        while(ch>='a'&&ch<='z'){t+=ch;ch=getchar();}
        if(sz(s)!=sz(t)){
            cout<<0<<'\n';
            continue;
        }
        int l=0,r=sz(s)-1;
        while(l<=r&&s[l]==t[l]) l++;
        while(l<=r&&s[r]==t[r]) r--;
        int op=(s[l]=='b'?0:1);
        int ans=0;
        for(pii x:mp[op][r-l+1]){
            if(x.first>l) break;
            if(x.second<=sz(s)-r-1) ans++;
        }
        cout<<ans<<'\n';
    }
}
struct Node{
    ll sh1,sh2,th1,th2;
    bool operator < (const Node &x) const{
        if(sh1==x.sh1){
            if(sh2==x.sh2){
                if(th1==x.th1){
                    return th2<x.th2;
                }
                return th1<x.th1;
            }
            return sh2<x.sh2;
        }
        return sh1<x.sh1;
    }
};
ll pw1[N],pw2[N];
void solve2(){
    const ll base1=41;
    const ll base2=37;
    const int MOD1=1e9+7;
    const int MOD2=1e9+9;
    pw1[0]=pw2[0]=1;
    for(int i=1;i<N;i++){
        pw1[i]=pw1[i-1]*base1%MOD1;
        pw2[i]=pw2[i-1]*base2%MOD2;
    }
    map<Node,int> mp;
    for(int i=1;i<=n;i++){
        ll sh1=0,sh2=0,th1=0,th2=0;
        for(int j=0;j<sz(S[i]);j++){
            sh1=(sh1+(S[i][j]-'a'+1)*pw1[j]%MOD1)%MOD1;
            sh2=(sh2+(S[i][j]-'a'+1)*pw2[j]%MOD2)%MOD2;
            th1=(th1+(T[i][j]-'a'+1)*pw1[j]%MOD1)%MOD1;
            th2=(th2+(T[i][j]-'a'+1)*pw2[j]%MOD2)%MOD2;
        }
        mp[{sh1,sh2,th1,th2}]++;
    }
    while(Q--){
        string s,t;
        char ch;while((ch=getchar())>'z'||ch<'a');
        while(ch>='a'&&ch<='z'){s+=ch;ch=getchar();}
        while((ch=getchar())>'z'||ch<'a');
        while(ch>='a'&&ch<='z'){t+=ch;ch=getchar();}
        if(sz(s)!=sz(t)){
            cout<<0<<'\n';
            continue;
        }
        int l=0,r=sz(s)-1;
        while(l<=r&&s[l]==t[l]) l++;
        while(l<=r&&s[r]==t[r]) r--;
        ll ans=0;
        for(int i=0;i<=l;i++){
            ll sh1=0,sh2=0,th1=0,th2=0;
            for(int j=i;j<sz(s);j++){
                sh1=(sh1+(s[j]-'a'+1)*pw1[j-i]%MOD1)%MOD1;
                sh2=(sh2+(s[j]-'a'+1)*pw2[j-i]%MOD2)%MOD2;
                th1=(th1+(t[j]-'a'+1)*pw1[j-i]%MOD1)%MOD1;
                th2=(th2+(t[j]-'a'+1)*pw2[j-i]%MOD2)%MOD2;
                if(j<r) continue;
                ans+=mp[{sh1,sh2,th1,th2}];
            }
        }
        cout<<ans<<'\n';
    }
}
int main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    if(specialB()){
        solve1();
        return 0;
    }else{
        solve2();
    }
    return 0;
}