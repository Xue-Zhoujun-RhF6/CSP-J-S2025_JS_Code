#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,t;
struct node{
    int a,b,c;
}x[100001];
int dp[2][201][201],ans=-1;
signed main(){
    freopen("club.in","r",stdin);
    freopen("club.out","w",stdout);
    cin>>t;
    while(t--){
        ans=-1;
        cin>>n;
        memset(dp,0,sizeof(dp));
        for(int i=1;i<=n;i++){
            cin>>x[i].a>>x[i].b>>x[i].c;
        }
        for(int i=1;i<=n;i++){
            for(int j=i;j>=0;j--){
                for(int k=i;k>=0;k--){
                    if(k+j>i || j>n/2 || k>n/2 || (i-j-k)>n/2){
                        continue;
                    }
                    if(j==0 && k==0){
                        dp[i%2][j][k]=dp[(i-1)%2][j][k]+x[i].c;
                    }
                    else if(j==0){
                        dp[i%2][j][k]=max(dp[(i-1)%2][j][k-1]+x[i].b,dp[(i-1)%2][j][k]+x[i].c);
                    }
                    else if(k==0){
                        dp[i%2][j][k]=max(dp[(i-1)%2][j-1][k]+x[i].a,dp[(i-1)%2][j][k]+x[i].c);
                    }
                    else{
                        dp[i%2][j][k]=max(dp[(i-1)%2][j][k-1]+x[i].b,max(dp[(i-1)%2][j-1][k]+x[i].a,dp[(i-1)%2][j][k]+x[i].c));
                    }
                }
            }
        }
        for(int i=0;i<=n/2;i++){
            for(int j=0;j<=n/2;j++){
                if((n-i-j)>n/2){
                    continue;
                }
                ans=max(ans,dp[n%2][i][j]);
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}   