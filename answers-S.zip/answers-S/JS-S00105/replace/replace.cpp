// #include<bits/stdc++.h>
// using namespace std;
// int n,q;
// pair<string,string> v[200001];
// vector<string>a;
// map<string,int>m;
// int find(string x,string y){
//     int lead[5000001];
//     int j=0;
//     for(int i=1;i<y.size();i++)
//     {
//         if(y[i]==y[j]){
//             lead[i]=lead[i-1]+1;
//         }
//         else{
//             if(j!=0){

//                 j==lead[j];
//                 i--;
//             }
//         }
//         j++;
//     }
//     j=0;
//     for(int i=0;i<x.size();i++){
//         if(x[i]==y[j]){
//         }
//         else{
//             j=lead[j];
//             i--;
//         }
//         if(j==y.size()){
//             return i;
//         }
//         j++;
//     }
//     return x.size();
// }
// bool check(string x,string y,int tmp){
//     int z=find(x,v[tmp].first);
//     if(z<x.size() && z==find(y,v[tmp].second)){
//         for(int i=0;i<z;i++){
//             if(x[i]!=y[i]){
//                 return 0;
//             }
//         }
//         for(int i=z+v[tmp].second.size();i<x.size();i++){
//             if(x[i]!=y[i]){
//                 return 0;
//             }
//         }
//         return 1;
//     }
//     else{
//         return 0;
//     }
// }
// signed main(){
//     freopen("replace.in","r",stdin);
//     freopen("replace.out","w",stdout);
//     cin>>n>>q;
//     string x,y;
//     for(int i=1;i<=n;i++){
//         cin>>x>>y;
//         v[i]={x,y};
//         a.push_back(x);
//     }
//     while(q--){
//         cin>>x>>y;
//         int ans=0;
//         for(int i=1;i<=n;i++){
//             if(x.size()!=y.size()){
//                 continue;
//             }
//             ans+=check(x,y,i);
//         }
//         cout<<ans<<endl;
//     }
//     return 0;
// }   
#include<bits/stdc++.h>
using namespace std;
int n,q;
pair<string,string> v[200001];
vector<string>a;
map<string,int>m;
bool check(string x,string y,int tmp){
    int z=x.find(v[tmp].first);
    if(z<x.size() && z==y.find(v[tmp].second)){
        for(int i=0;i<z;i++){
            if(x[i]!=y[i]){
                return 0;
            }
        }
        for(int i=z+v[tmp].second.size();i<x.size();i++){
            if(x[i]!=y[i]){
                return 0;
            }
        }
        return 1;
    }
    else{
        return 0;
    }
}
signed main(){
    freopen("replace.in","r",stdin);
    freopen("replace.out","w",stdout);
    cin>>n>>q;
    string x,y;
    for(int i=1;i<=n;i++){
        cin>>x>>y;
        v[i]={x,y};
        a.push_back(x);
    }
    while(q--){
        cin>>x>>y;
        int ans=0;
        for(int i=1;i<=n;i++){
            if(x.size()!=y.size()){
                continue;
            }
            ans+=check(x,y,i);
        }
        cout<<ans<<endl;
    }
    return 0;
}   