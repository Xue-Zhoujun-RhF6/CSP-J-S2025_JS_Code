#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,a[501],ans;
int mod=998244353;
bool vis[501];
string s;
void dfs(int sum,int pass,int fail){
    if(sum==n){
        ans+=(pass>=m);
        ans%=mod;
        return ;
    }
    if(n-fail<m){
        return ;
    }
    for(int i=1;i<=n;i++){
        if(!vis[i]){
            vis[i]=1;
            if(fail>=a[i] || s[sum]=='0'){
                dfs(sum+1,pass,fail+1);
            }
            else{
                dfs(sum+1,pass+1,fail);
            }
            vis[i]=0;
        }
    }
}
signed main(){
    freopen("employ.in","r",stdin);
    freopen("employ.out","w",stdout);
    cin>>n>>m>>s;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    if(n>18){
        ans=1;
        for(int i=2;i<=n;i++){
            ans*=i;
            ans%=mod;
        }
        cout<<ans;
        return 0;
    }
    dfs(0,0,0);
    cout<<ans;
    return 0;
}   