#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,k;
struct node{
    int from,to,val;
}edge[1100001];
int fa[10001];
int find(int x){
    int tmp=x;
    while(fa[x]!=x){
        x=fa[x];
    }
    while(fa[tmp]!=tmp)
    {
        int y=tmp;
        tmp=fa[tmp];
        fa[y]=x;
    }
    return x;
}
bool cmp(node x,node y){
    return x.val<y.val;
}
signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n>>m>>k;
    int cnt;
    for(int i=1;i<=n;i++){
        fa[i]=i;
    }
    for(cnt=1;cnt<=m;cnt++){
        cin>>edge[cnt].from>>edge[cnt].to>>edge[cnt].val;
    }
    for(int i=1;i<=k;i++)
    {
        int val,tmp[n+1];
        cin>>val;
        for(int j=1;j<=n;j++){
            cin>>tmp[j];
            for(int o=1;o<j;o++){
                edge[cnt].from=j;
                edge[cnt].to=o;
                edge[cnt++].val=tmp[j]+tmp[o]+val;

            }
        }
    }
    sort(edge+1,edge+cnt,cmp);
    int ans=0,t=1,sum=0;
    while(sum+1<n && t<cnt){
        if(find(edge[t].from)!=find(edge[t].to)){
            sum++;
            ans+=edge[t].val;
            fa[find(edge[t].from)]=find(edge[t].to);
        }
        t++;
    }
    cout<<ans;
    return 0;
}   