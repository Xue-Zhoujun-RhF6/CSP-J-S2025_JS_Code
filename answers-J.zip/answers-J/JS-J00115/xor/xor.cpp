#include<bits/stdc++.h>
using namespace std;
int n,m;
int main(){
	freopen("xor.in","r",stdin);
	freopen("xor.out","w",stdout);
	//------------------------------------------------------
	cin>>n>>m;
	cout<<2;
	//------------------------------------------------------
	fclose(stdin);
	fclose(stdout);
	return 0;
}
