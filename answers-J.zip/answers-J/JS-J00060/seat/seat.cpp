#include<bits/stdc++.h>
using namespace std;
const int N=1e2+5;
int a[N],n,m,sc,idx;
bool cmp(int x,int y) {
    return x>y;
}
int main() {
    freopen("seat.in", "r", stdin);
    freopen("seat.out","w",stdout);
    cin >> n >> m;
    for(int i=1; i<=n*m;i++) cin >> a[i];
    sc=a[1];
    sort(a+1,a+n*m+1,cmp);
    for(int i=1; i<=n*m; i++) if(a[i]==sc) {idx=i;break;}
    for(int i=1; i<=m; i++) {
        if(idx <= n) {
            cout << i << ' ';
            if(i%2==0) {
                cout << n-idx+1;
            }else {
                cout << idx;
            }
            exit(0);
        }
        idx-=n;
    }
    return 0;
}
