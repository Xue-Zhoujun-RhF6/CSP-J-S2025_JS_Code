#include<bits/stdc++.h>
using namespace std;
int a[4];
int main(){
    freopen("polygon.in","r",stdin);
    freopen("polygon.out","w",stdout);
    int n,cnt=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    cin>>a[i];
    sort(a+1,a+n+1);
    if(a[1]+a[2]+a[3]>a[3]*2){
        cnt++;
    }
    cout<<cnt;
    return 0;
}