#include<bits/stdc++.h>
using namespace std;
int a[100];
int main(){
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    cout<<0;
    return 0;
}
