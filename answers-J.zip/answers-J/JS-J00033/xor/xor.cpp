#include<bits/stdc++.h>
using namespace std;
int n,m,a[100005];
int main(){
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    cout<<1;
    fclose(stdin);
    fclose(stdout);
}
