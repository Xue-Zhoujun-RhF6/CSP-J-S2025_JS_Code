#include<bits/stdc++.h>
using namespace std;


/*
int yih(int j,int p){
int h[1010],q=0;

}*/
int main(){
freopen("xor.in","r",stdin);
freopen("xor.out","w",stdout);
int n,k;
cin>>n>>k;
int a[n+1];
for(int i=1;i<=n;i++){
    cin>>a[i];
}

    cout<<1;
return 0;
}
