#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("polygon.in","r",stdin);
	freopen("polygon.out","w",stdout);
	cout<<24;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
