#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,k,a[500001];
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    cin>>n>>k;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    cout<<2<<'\n';
    return 0;
}
