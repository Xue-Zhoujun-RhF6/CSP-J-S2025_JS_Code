#include<bits/stdc++.h>
using namespace std;
unsigned n,k;
unsigned a[500005];
int main() {
    // score:5%~10%
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    cin>> n >> k ;
    for(int i=1;i<=n;i++){
        cin>> a[i] ;
    }
    cout<< n/2 <<endl;
    return 0;
}