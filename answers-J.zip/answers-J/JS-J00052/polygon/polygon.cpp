#include <bits/stdc++.h>
using namespace std;
int a[105][105];
int n,m,b[10005],x;
int c;
int main()
{
    freopen("seat.in","r",stdin);
    freopen("seat.out","w",stdout);
    cin>>n;
    for(int i = 0;i<n;i++)
    {
        cin>>b[i];
    }
    cout<<6;
    return 0;
}
