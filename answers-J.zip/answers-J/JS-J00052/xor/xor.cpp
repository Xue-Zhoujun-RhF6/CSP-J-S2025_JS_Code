#include <bits/stdc++.h>
using namespace std;
int main()
{
    freopen("xor.in","r",stdin);
    freopen("xor.out","w",stdout);
    int n , m;
    int a[10005];
    cin>>n>>m;
    for(int i = 0 ; i<n;i++)
    {
        cin>>a[i];
    }
    cout<< 2;
    return 0;
}
