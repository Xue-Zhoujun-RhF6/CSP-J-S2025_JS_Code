#include <bits/stdc++.h>
using namespace std;
int a[105][105];
int n,m,b[10005],x;
int c;
int main()
{
    freopen("seat.in","r",stdin);
    freopen("seat.out","w",stdout);
    cin>>m>>n;
    x = m*n;
    cin>>x;
    cout<< m<< " "<<n;
    return 0;
}
