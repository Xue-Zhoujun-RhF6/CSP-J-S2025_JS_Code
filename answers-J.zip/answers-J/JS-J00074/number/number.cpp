#include<bits/stdc++.h>
using namespace std;
int a[10];
string s;
int main(){
    freopen("number.in","r",stdin);
    freopen("number.out","w",stdout);
    cin>>s;
    for(int i=0;i<s.size();i++){
        if(s[i]>='0'&&s[i]<='9'){
            int d=s[i]-'0';
            a[d]++;
        }
    }
    for(int i=9;i>=0;i--){
        for(int j=1;j<=a[i];j++)cout<<i;
    }
    return 0;
}
