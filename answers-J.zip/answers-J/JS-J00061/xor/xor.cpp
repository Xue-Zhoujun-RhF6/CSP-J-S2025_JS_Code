#include <iostream>
#include <cstdio>
using namespace std;
int n, k;
int a[500005];
int cnt;
int main()
{
	freopen("xor.in", "r", stdin);
	freopen("xor.out", "w", stdout);
	cin >> n >> k;
	for (int i = 0; i < n; i++) cin >> a[i];
	if (k == 0)
	{
		for (int i = 1; i < n; i++)
		{
			if (a[i] == a[i - 1])
			{
				cnt++;
				i++;
			}
		}
		cout << cnt << endl;
		return 0;
	}
	else if (k == 1)
	{
		for (int i = 1; i < n; i++)
		{
			if (a[i] != a[i - 1])
			{
				cnt++;
				i++;
			}
		}
		cout << cnt << endl;
		return 0;
	}
	return 0;
}
