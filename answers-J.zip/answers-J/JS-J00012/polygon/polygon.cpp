#include<bits/stdc++.h>
using namespace std;

int main()
{	
freopen("polygon.in","r",stdin);
freopen("polygon.out","w",stdout);
	int n,k;
	cin>>n>>k;
	cout<<0<<endl;
return 0;
}
