#include<bits/stdc++.h>
using namespace std;

int main()
{	
freopen("xor.in","r",stdin);
freopen("xor.out","w",stdout);
	int n,k;
	cin>>n>>k;
	cout<<k<<endl;
return 0;
}
